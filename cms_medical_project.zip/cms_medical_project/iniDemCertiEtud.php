
le bon

<?php
session_start();
require_once "db.php";

// Activation du debug
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Vérification de l'authentification et du rôle de l'utilisateur
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'etudiant') {
    header("Location: auth.php");
    exit;
}

// Génération du token CSRF sécurisé
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Récupération de l'ID utilisateur en supprimant "MES_"
$patient_id = intval(str_replace("MED_", "", $_SESSION['user_id']));

// Vérification du patient
$stmt = $pdoMedical->prepare("
        SELECT u.id, u.nom, e.prenom, u.email, e.matricule, e.date_naissance, e.filiere 
        FROM utilisateurs u
        LEFT JOIN campus_db.etudiants e ON u.matricule = e.matricule
        WHERE u.id = ?
        ");
$stmt->execute([$patient_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    throw new Exception("Utilisateur non trouvé.");
}

// Récupération des médecins disponibles
$stmt = $pdoMedical->prepare("SELECT id, nom, specialite FROM utilisateurs WHERE role = 'medecin'");
$stmt->execute();
$medecins = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Récupération des certificats du patient
$stmt = $pdoMedical->prepare("
 SELECT c.id, c.date_creation, c.contenu, u.nom AS patient_nom, 
           c.commentaire_medecin, c.statut, c.type_certificat, date_validation, c.medecin_nom, u.numero_professionnel
    FROM certificats c
    JOIN utilisateurs u ON c.medecin_id = u.id
    WHERE c.patient_id = ?
    ORDER BY c.date_creation DESC
");

$stmt->execute([$patient_id]); // Maintenant l'exécution correspond à la requête
$certificats = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Vérification CSRF
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception("Erreur de sécurité : token invalide.");
        }

        // Filtrage et validation des entrées
        $contenu = trim(filter_var($_POST['contenu'], FILTER_SANITIZE_STRING));
        $medecin_id = isset($_POST['medecin_id']) ? intval($_POST['medecin_id']) : null;
        $type_certificat = isset($_POST['type_certificat']) ? trim(filter_var($_POST['type_certificat'], FILTER_SANITIZE_STRING)) : 'standard';

        if (empty($contenu) || empty($medecin_id)) {
            throw new Exception("Tous les champs sont obligatoires.");
        }

        // Vérification du médecin
        $stmt = $pdoMedical->prepare("SELECT id, nom FROM utilisateurs WHERE id = ? AND role = 'medecin'");
        $stmt->execute([$medecin_id]);
        $medecin = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$medecin) {
            throw new Exception("Le médecin sélectionné est invalide.");
        }

        // Insertion de la demande
        $stmt = $pdoMedical->prepare("
            INSERT INTO certificats (patient_id, patient_nom, medecin_id, medecin_nom, type_certificat, contenu, statut, date_creation) 
            VALUES (?, ?, ?, ?, ?, ?, 'en attente', NOW())
        ");
        
        $stmt->execute([$patient['id'], $patient['nom'], $medecin['id'], $medecin['nom'], $type_certificat, $contenu]);

        $_SESSION['message'] = "✅ Votre demande a été enregistrée.";
        header("Location: demande_certificat.php");
        exit;

    } catch (Exception $e) {
        $message = "❌ Erreur : " . htmlspecialchars($e->getMessage());
    }
}
// Gestion sécurisée des messages flash
if (isset($_SESSION['flash_message'])) {
    $flash_message = [
        'type' => htmlspecialchars($_SESSION['flash_message']['type'] ?? '', ENT_QUOTES, 'UTF-8'),
        'message' => htmlspecialchars($_SESSION['flash_message']['message'] ?? '', ENT_QUOTES, 'UTF-8')
    ];
    unset($_SESSION['flash_message']);
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demande de Certificat Médical</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --primary-light: #3d566e;
            --secondary: #3498db;
            --secondary-light: #5dade2;
            --success: #27ae60;
            --success-light: #2ecc71;
            --danger: #e74c3c;
            --danger-light: #ec7063;
            --warning: #f39c12;
            --light: #ecf0f1;
            --lighter: #f8f9fa;
            --dark: #2c3e50;
            --gray: #95a5a6;
            --gray-light: #bdc3c7;
            --border-radius: 8px;
            --shadow: 0 4px 6px rgba(0,0,0,0.1);
            --transition: all 0.3s ease;
        }
        html, body {
        overflow: auto; /* Permet le défilement */
        height: 100%; /* S'assure que le body prend toute la hauteur */
    }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background: #f5f7fa;
            color: var(--dark);
            padding: 0;
            overflow-y: scroll !important;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .main-content {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 30px;
            margin-top: 20px;
        }
        
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light);
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .header-left h1 {
            color: var(--primary);
            font-size: 28px;
            margin-bottom: 5px;
        }
        
        .header-left p {
            color: var(--gray);
            font-size: 14px;
        }
        
        .user-card {
            background: var(--lighter);
            border-radius: var(--border-radius);
            padding: 15px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: var(--shadow);
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: var(--secondary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 20px;
        }
        
        .message {
            padding: 15px;
            margin-bottom: 25px;
            border-radius: var(--border-radius);
            background-color: #f8f9fa;
            border-left: 4px solid var(--secondary);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .message i {
            font-size: 20px;
        }
        
        .message.success {
            background-color: #e8f5e9;
            border-color: var(--success);
        }
        
        .message.error {
            background-color: #ffebee;
            border-color: var(--danger);
        }
        
        .message.warning {
            background-color: #fff8e1;
            border-color: var(--warning);
        }
        
        h2 {
            color: var(--primary);
            margin-bottom: 20px;
            font-size: 22px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        h2 i {
            color: var(--secondary);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--gray-light);
            border-radius: var(--border-radius);
            font-family: inherit;
            transition: var(--transition);
        }
        
        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }
        
        select.form-control {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 1em;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 25px;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: var(--transition);
            border: none;
        }
        
        .btn-primary {
            background-color: var(--secondary);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--secondary-light);
            transform: translateY(-2px);
        }
        
        .btn-success {
            background-color: var(--success);
            color: white;
        }
        
        .btn-success:hover {
            background-color: var(--success-light);
        }
        
        .btn-block {
            display: flex;
            width: 100%;
        }
        
        .certificat-list {
            margin-top: 30px;
        }
        
        .certificat-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 25px;
            margin-bottom: 25px;
            transition: var(--transition);
            border: 1px solid var(--light);
        }
        
        .certificat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .certificat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .certificat-title {
            color: var(--primary);
            margin-bottom: 10px;
            font-size: 18px;
        }
        
        .certificat-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;
            color: var(--gray);
            font-size: 14px;
        }
        
        .certificat-meta-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .certificat-meta-item i {
            color: var(--secondary);
        }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            background: var(--secondary);
            color: white;
        }
        
        .badge-success {
            background: var(--success);
        }
        
        .badge-warning {
            background: var(--warning);
        }
        
        .badge-danger {
            background: var(--danger);
        }
        
        .certificat-content {
            margin-top: 20px;
            padding: 15px;
            background: var(--lighter);
            border-radius: var(--border-radius);
        }
        
        .certificat-actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 30px;
            border-radius: var(--border-radius);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            width: 80%;
            max-width: 800px;
            position: relative;
        }
        
        .close {
            position: absolute;
            right: 20px;
            top: 20px;
            color: var(--gray);
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: var(--dark);
        }
        
        .certificat-print {
            background: white;
            padding: 30px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
        }
        
        .certificat-print-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light);
        }
        
        .certificat-print-body {
            margin-bottom: 30px;
        }
        
        .certificat-print-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid var(--light);
        }
        
        .signature {
            text-align: center;
            margin-top: 50px;
        }
        
        .signature-line {
            width: 200px;
            border-top: 1px solid var(--dark);
            margin: 0 auto;
            padding-top: 5px;
        }
        
        @media print {
            body * {
                visibility: hidden;
            }
            .certificat-print, .certificat-print * {
                visibility: visible;
            }
            .certificat-print {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                margin: 0;
                padding: 20px;
                box-shadow: none;
            }
            .no-print {
                display: none !important;
            }
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .main-content {
                padding: 20px;
            }
            
            header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .user-card {
                flex-direction: column;
                text-align: center;
            }
            
            .certificat-header {
                flex-direction: column;
            }
            
            .modal-content {
                width: 95%;
                margin: 10% auto;
                padding: 20px;
            }
        }
        
        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade {
            animation: fadeIn 0.5s ease-out;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="main-content animate-fade">
            <header>
                <div class="header-left">
                    <h1><i class="fas fa-file-medical"></i> Gestion des Certificats Médicaux</h1>
                    <p>Demander et consulter vos certificats médicaux</p>
                </div>
                
                <div class="user-card">
                    <div class="user-avatar">
                        <?= strtoupper(substr($patient['nom'], 0, 1) . substr($patient['prenom'], 0, 1)) ?>
                    </div>
                    <div class="user-info">
                        <strong><?= htmlspecialchars($patient['nom']) ?> <?= htmlspecialchars($patient['prenom']) ?></strong>
                        <span>Étudiant</span>
                    </div>
                </div>
            </header>
            
            <?php if (!empty($flash_message)): ?>
                <div class="message <?= htmlspecialchars($flash_message['type']) ?> animate-fade">
                    <i class="fas <?= $flash_message['type'] === 'error' ? 'fa-exclamation-circle' : 'fa-check-circle' ?>"></i>
                    <div><?= nl2br(htmlspecialchars($flash_message['message'])) ?></div>
                </div>
            <?php endif; ?>
            
            <section>
                <h2><i class="fas fa-plus-circle"></i> Nouvelle demande</h2>
                
                <form method="POST" id="certificatForm">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                    
                    <div class="form-group">
                        <label for="medecin_id" class="form-label"><i class="fas fa-user-md"></i> Médecin :</label>
                        <select id="medecin_id" name="medecin_id" class="form-control" required>
                            <option value="">-- Sélectionnez un médecin --</option>
                            <?php foreach ($medecins as $medecin): ?>
                                <option value="<?= htmlspecialchars($medecin['id']) ?>">
                                    Dr. <?= htmlspecialchars($medecin['nom']) ?> 
                                    (<?= htmlspecialchars($medecin['specialite']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="type_certificat" class="form-label"><i class="fas fa-tag"></i> Type de certificat :</label>
                        <select id="type_certificat" name="type_certificat" class="form-control" required>
                            <option value="standard">Standard</option>
                            <option value="urgence">Urgence</option>
                            <option value="aptitude">Aptitude médicale</option>
                            <option value="absence">Certificat d'absence</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="contenu" class="form-label"><i class="fas fa-edit"></i> Description :</label>
                        <textarea 
                            id="contenu" 
                            name="contenu" 
                            class="form-control" 
                            required
                            placeholder="Décrivez vos symptômes ou la raison de votre demande..."
                        ></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-paper-plane"></i> Envoyer la demande
                    </button>
                </form>
            </section>
            
            <section class="certificat-list">
                <h2><i class="fas fa-history"></i> Historique des demandes</h2>
                
                <?php if (empty($certificats)): ?>
                    <div class="message info">
                        <i class="fas fa-info-circle"></i>
                        <div>Vous n'avez aucune demande de certificat pour le moment.</div>
                    </div>
                <?php else: ?>
                    <?php foreach ($certificats as $cert): ?>
                        <div class="certificat-card animate-fade">
                            <div class="certificat-header">
                                <div>
                                    <h3 class="certificat-title">
                                        Certificat <?= htmlspecialchars(ucfirst($cert['type_certificat'])) ?>
                                    </h3>
                                    <div class="certificat-meta">
                                        <span class="certificat-meta-item">
                                            <i class="far fa-calendar-alt"></i> 
                                            Demandé le <?= date('d/m/Y à H:i', strtotime($cert['date_creation'])) ?>
                                        </span>
                                        <?php if ($cert['date_validation']): ?>
                                            <span class="certificat-meta-item">
                                                <i class="far fa-calendar-check"></i> 
                                                Validé le <?= date('d/m/Y à H:i', strtotime($cert['date_validation'])) ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <span class="badge badge-<?= 
                                    $cert['statut'] === 'validé' ? 'success' : 
                                    ($cert['statut'] === 'en attente' ? 'warning' : 'danger') 
                                ?>">
                                    <?= htmlspecialchars(ucfirst($cert['statut'])) ?>
                                </span>
                            </div>
                            
                            <?php if ($cert['medecin_nom']): ?>
                                <div class="certificat-meta">
                                    <span class="certificat-meta-item">
                                        <i class="fas fa-user-md"></i> 
                                        Médecin : <?= htmlspecialchars($cert['medecin_nom']) ?>
                                        <?php if ($cert['numero_professionnel']): ?>
                                            (N° RPPS: <?= htmlspecialchars($cert['numero_professionnel']) ?>)
                                        <?php endif; ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            
                            <div class="certificat-content">
                                <h4>Motif :</h4>
                                <p><?= nl2br(htmlspecialchars($cert['contenu'])) ?></p>
                                
                                <?php if ($cert['statut'] === 'validé' && !empty($cert['commentaire_medecin'])): ?>
                                    <h4>Commentaire du médecin :</h4>
                                    <p><?= nl2br(htmlspecialchars($cert['commentaire_medecin'])) ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="certificat-actions">
                                <?php if ($cert['statut'] === 'validé'): ?>
                                    <button 
                                        class="btn btn-success"
                                        onclick="openCertificatModal(<?= htmlspecialchars(json_encode($cert)) ?>)"
                                    >
                                        <i class="fas fa-eye"></i> Voir le certificat
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>
        </div>
    </div>
    
    <!-- Modal pour afficher le certificat -->
    <div id="certificatModal" class="modal">
    <div class="modal-content" style="max-width: 800px;">
        <span class="close" onclick="closeModal()" style="position: absolute; top: 15px; right: 30px; font-size: 45px; cursor: pointer; color: red;">&times;</span>
        
        <div id="certificatPrintContent" class="certificat-print" style="background: white; padding: 40px; border-radius: 5px;">
            <!-- En-tête avec logo (optionnel) -->
            <div class="certificat-print-header" style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid #e0e0e0; padding-bottom: 20px;">
                <h2 style="color: #2c3e50; font-size: 24px; margin-bottom: 10px;">CERTIFICAT MÉDICAL</h2>
                <p style="color: #7f8c8d; font-style: italic;">Document établi conformément à l'article R.4127-76 du code de la santé publique</p>
                <img src="../img/bg.png" alt="logo image">
            </div>
            
            <!-- Corps du certificat -->
            <div class="certificat-print-body" id="certificatDetails" style="line-height: 1.6; font-size: 15px;">
                <!-- Contenu dynamique injecté par JS -->
            </div>
            
            <!-- Pied de page professionnel -->
            <div class="certificat-print-footer" style=" display: flex; flex-direction: column; margin-top: 50px; padding-top: 30px; border-top: 1px solid #e0e0e0;">
                <div style="display: flex; justify-content: space-between; align-items: flex-end;">
                    <div style="width: 45%;">
                        <p style="margin-bottom: 5px;">Fait à : <strong><span id="certificatLieu">[Ville du cabinet]</span></strong></p>
                        <p>Le : <strong><span id="certificatDate"><?= date('d/m/Y') ?></span></strong></p>
                    </div>
                    
                    <div style="width: 45%; text-align: center;">
                        <div style="margin-top: 40px; position: relative;">
                            <div style="width: 250px; height: 80px; margin: 0 auto; position: relative;">
                                <!-- Espace pour le cachet (visuel en arrière-plan) -->
                                <div style="position: absolute; width: 100%; height: 100%; border: 1px dashed #ccc; border-radius: 5px;"></div>
                                <!-- Ligne de signature -->
                                <div style="position: absolute; bottom: 0; width: 100%; border-top: 1px solid #000; padding-top: 5px;">
                                    <p style="font-size: 13px; margin: 0;">Signature et cachet du médecin</p>
                                    <p id="medecinNom" style="font-weight: bold; margin-top: 3px; font-size: 14px;">[Nom du médecin]</p>
                                    <p id="medecinRpps" style="font-size: 11px; margin-top: 2px;">N° RPPS: [numéro]</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Mention légale -->
                <div style=" font-weight: bold; margin-top: 50px; font-size: 11px; color: #95a5a6; text-align: center;">
                    <p>Ce document est établi à l'attention exclusive du patient et ne peut être transmis à des tiers sans autorisation.</p>
                </div>
            </div>
        </div>
        
        <!-- Boutons d'action -->
        <div class="no-print" style="margin-top: 30px; text-align: center;">
                    <button onclick="window.print()" style="background: #3498db; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-size: 16px;">
                        <i class="fas fa-print"></i> Imprimer le certificat
                    </button>
                    <button onclick="closeModal()" style="margin-left: 15px; background: #95a5a6; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-size: 16px;">
                        <i class="fas fa-times"></i> Fermer
                    </button>
                </div>
            </div>
        </div>
    
    <script>
        // Fonction pour ouvrir la modal avec les détails du certificat
        function openCertificatModal(certificat) {
            const modal = document.getElementById('certificatModal');
            const contentDiv = document.getElementById('certificatDetails');
            
            // Construction du contenu HTML
            let html = `
                <div style="margin-bottom: 20px;">
                    <p>Je soussigné(e), <strong>${certificat.medecin_nom}</strong></p>
                    ${certificat.numero_professionnel ? `<p>Numéro RPPS : ${certificat.numero_professionnel}</p>` : ''}
                </div>
                
                <div style="margin-bottom: 20px;">
                    <p>Certifie avoir examiné ce jour :</p>
                    <p><strong>${certificat.patient_nom}</strong></p>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <h4>Motif de la consultation :</h4>
                    <p>${certificat.contenu.replace(/\n/g, '<br>')}</p>
                </div>
                
                ${certificat.commentaire_medecin ? `
                <div style="margin-bottom: 20px;">
                    <h4>Diagnostic et recommandations :</h4>
                    <p>${certificat.commentaire_medecin.replace(/\n/g, '<br>')}</p>
                </div>
                ` : ''}
                
                <div style="margin-bottom: 20px;">
                    <p>Le présent certificat est établi à la demande de l'intéressé(e) pour servir et valoir ce que de droit.</p>
                </div>
            `;
            
            contentDiv.innerHTML = html;
            document.getElementById('certificatLieu').textContent = certificat.ville || 'Paris';
            document.getElementById('medecinNom').textContent = certificat.medecin_nom || 'Dr. [Nom]';
            document.getElementById('medecinRpps').textContent = certificat.numero_professionnel 

            
            // Mise à jour de la date de validation
            if (certificat.date_validation) {
                const dateParts = certificat.date_validation.split(' ')[0].split('-');
                document.getElementById('certificatDate').textContent = `${dateParts[2]}/${dateParts[1]}/${dateParts[0]}`;
            }
            
            // Affichage de la modal
            modal.style.display = 'block';
        }
        
        // Fonction pour fermer la modal
        function closeModal() {
            document.getElementById('certificatModal').style.display = 'none';
        }
        
        // Fermer la modal si on clique en dehors
        window.onclick = function(event) {
            const modal = document.getElementById('certificatModal');
            if (event.target === modal) {
                closeModal();
            }
        }
        
        // Validation du formulaire
        document.getElementById('certificatForm').addEventListener('submit', function (e) {
                if (!document.getElementById('medecin_id').value) {
                    alert('Veuillez sélectionner un médecin');
                    e.preventDefault();
                    return false;
                }
                if (document.getElementById('contenu').value.trim().length < 10) {
                    alert('Veuillez décrire votre demande (minimum 10 caractères)');
                    e.preventDefault();
                    return false;
                }
                return true;
            });
                
        // Animation pour les messages flash
        document.addEventListener('DOMContentLoaded', function() {
            const messages = document.querySelectorAll('.message');
            messages.forEach(msg => {
                setTimeout(() => {
                    msg.style.opacity = '1';
                    msg.style.transform = 'translateY(0)';
                }, 100);
            });
        });
    </script>
</body>
</html>


<?php
session_start();
require_once "db.php";

// Activation du debug
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Vérification que l'utilisateur est un étudiant
if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit;
}

// Génération du token CSRF
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Extraction propre de l'ID utilisateur
$patient_id = intval(str_replace("MED_", "", $_SESSION['user_id']));

// Vérification que le patient existe
$stmt = $pdoMedical->prepare("SELECT id, nom FROM utilisateurs WHERE id = ?");
$stmt->execute([$patient_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    throw new Exception("Utilisateur non trouvé.");
}

// Récupération des médecins disponibles
$stmt = $pdoMedical->prepare("SELECT id, nom, specialite FROM utilisateurs WHERE role = 'medecin' ORDER BY nom");
$stmt->execute();
$medecins = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupération des certificats du patient
$stmt = $pdoMedical->prepare("
    SELECT c.id, c.type_certificat, c.contenu, c.statut, c.date_creation, c.date_validation, 
           u.nom AS medecin_nom, u.specialite AS medecin_specialite
        
    FROM certificats c
    LEFT JOIN utilisateurs u ON c.medecin_id = u.id
    WHERE c.patient_id = ?
    ORDER BY c.date_creation DESC
");
$stmt->execute([$patient_id]);
$certificats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Types de certificats disponibles
$typesCertificats = [
    'standard' => 'Certificat médical standard',
    'urgence' => 'Certificat médical d\'urgence',
    'aptitude' => 'Certificat d\'aptitude médicale',
    'arret_travail' => 'Certificat d\'arrêt de travail'
];

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Vérification CSRF
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception("Erreur de sécurité : token invalide.");
        }

        // Filtrage des entrées
        $contenu = trim(filter_var($_POST['contenu'], FILTER_SANITIZE_STRING));
        $medecin_id = isset($_POST['medecin_id']) ? intval($_POST['medecin_id']) : null;
        $type_certificat = isset($_POST['type_certificat']) ? trim(filter_var($_POST['type_certificat'], FILTER_SANITIZE_STRING)) : 'standard';

        if (empty($contenu) || empty($medecin_id)) {
            throw new Exception("Tous les champs sont obligatoires.");
        }

        // Vérification du médecin
        $stmt = $pdoMedical->prepare("SELECT id, nom FROM utilisateurs WHERE id = ? AND role = 'medecin'");
        $stmt->execute([$medecin_id]);
        $medecin = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$medecin) {
            throw new Exception("Le médecin sélectionné est invalide.");
        }

        // Insertion de la demande
        $stmt = $pdoMedical->prepare("
            INSERT INTO certificats (patient_id, patient_nom, medecin_id, medecin_nom, type_certificat, contenu, statut, date_creation) 
            VALUES (?, ?, ?, ?, ?, ?, 'en attente', NOW())
        ");
        
        $stmt->execute([
            $patient['id'], 
            $patient['nom'], 
            $medecin['id'], 
            $medecin['nom'], 
            $type_certificat, 
            $contenu
        ]);

        $_SESSION['message'] = [
            'type' => 'success',
            'text' => "Votre demande de certificat a été enregistrée avec succès."
        ];
        header("Location: demande_certificat.php");
        exit;

    } catch (Exception $e) {
        $message = [
            'type' => 'error',
            'text' => "Erreur : " . htmlspecialchars($e->getMessage())
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demande de Certificat Médical</title>
    <style>
        :root {
            --primary: #4361ee;
            --primary-dark: #3a56d4;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fb;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 15px 0;
            margin-bottom: 30px;
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
        
        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            background-color: var(--primary);
            color: white;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: background-color 0.3s ease;
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
        }
        
        .btn-block {
            display: block;
            width: 100%;
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
        }
        
        .status-en-attente {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-valide {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-rejete {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--gray);
        }
        
        tr:hover {
            background-color: #f8f9fa;
        }
        
        .doctor-card {
            display: flex;
            align-items: center;
            padding: 10px;
            border: 1px solid #eee;
            border-radius: 8px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .doctor-card:hover {
            border-color: var(--primary);
            background-color: #f8f9ff;
        }
        
        .doctor-card.selected {
            border-color: var(--primary);
            background-color: #eef2ff;
        }
        
        .doctor-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-weight: 600;
        }
        
        .doctor-info {
            flex-grow: 1;
        }
        
        .doctor-name {
            font-weight: 600;
            margin-bottom: 3px;
        }
        
        .doctor-specialite {
            font-size: 14px;
            color: var(--gray);
        }
        
        .hidden {
            display: none;
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .card-body {
                padding: 15px;
            }
            
            th, td {
                padding: 8px 10px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container header-content">
            <a href="#" class="logo">Certificats Médicaux en Ligne</a>
            <div class="user-info">
                <div class="avatar"><?= strtoupper(substr($patient['nom'], 0, 1)) ?></div>
                <span><?= htmlspecialchars($patient['nom']) ?></span>
            </div>
        </div>
    </header>
    
    <div class="container">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?= $_SESSION['message']['type'] ?>">
                <?= htmlspecialchars($_SESSION['message']['text']) ?>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <?php if (isset($message)): ?>
            <div class="alert alert-<?= $message['type'] ?>">
                <?= htmlspecialchars($message['text']) ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">
                Nouvelle demande de certificat médical
            </div>
            <div class="card-body">
                <form method="POST" id="certificatForm">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    
                    <div class="form-group">
                        <label for="type_certificat">Type de certificat</label>
                        <select id="type_certificat" name="type_certificat" class="form-control" required>
                            <?php foreach ($typesCertificats as $value => $label): ?>
                                <option value="<?= htmlspecialchars($value) ?>"><?= htmlspecialchars($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Sélectionnez un médecin</label>
                        <?php foreach ($medecins as $medecin): ?>
                            <div class="doctor-card" onclick="selectDoctor(this, <?= $medecin['id'] ?>)">
                                <div class="doctor-avatar"><?= strtoupper(substr($medecin['nom'], 0, 1)) ?></div>
                                <div class="doctor-info">
                                    <div class="doctor-name">Dr. <?= htmlspecialchars($medecin['nom']) ?></div>
                                    <?php if (!empty($medecin['specialite'])): ?>
                                        <div class="doctor-specialite">Spécialité : <?= htmlspecialchars($medecin['specialite']) ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <input type="hidden" id="medecin_id" name="medecin_id" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="contenu">Motif de votre demande</label>
                        <textarea id="contenu" name="contenu" class="form-control" required placeholder="Décrivez en détail les raisons de votre demande de certificat médical..."></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-block">Soumettre la demande</button>
                </form>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                Historique de vos demandes
            </div>
            <div class="card-body">
                <?php if (!empty($certificats)): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Motif</th>
                                <th>Médecin</th>
                                <th>Statut</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($certificats as $certificat): ?>
                                <tr>
                                    <td><?= htmlspecialchars($typesCertificats[$certificat['type_certificat']] ?? $certificat['type_certificat']) ?></td>
                                    <td><?= htmlspecialchars($certificat['contenu']) ?></td>
                                    <td>
                                        Dr. <?= htmlspecialchars($certificat['medecin_nom']) ?>
                                        <?php if (!empty($certificat['medecin_specialite'])): ?>
                                            <br><small>Spécialité : <?= htmlspecialchars($certificat['medecin_specialite']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?= str_replace(' ', '-', $certificat['statut']) ?>">
                                            <?= htmlspecialchars(ucfirst($certificat['statut'])) ?>
                                        </span>
                                        <?php if (!empty($certificat['commentaire_medecin'])): ?>
                                            <div class="mt-2"><small><strong>Commentaire :</strong> <?= htmlspecialchars($certificat['commentaire_medecin']) ?></small></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('d/m/Y H:i', strtotime($certificat['date_creation'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Aucune demande de certificat enregistrée pour le moment.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        function selectDoctor(card, doctorId) {
            // Désélectionner tous les cards
            document.querySelectorAll('.doctor-card').forEach(el => {
                el.classList.remove('selected');
            });
            
            // Sélectionner le card cliqué
            card.classList.add('selected');
            
            // Mettre à jour le champ caché
            document.getElementById('medecin_id').value = doctorId;
        }
        
        // Validation du formulaire
        document.getElementById('certificatForm').addEventListener('submit', function(e) {
            if (!document.getElementById('medecin_id').value) {
                alert('Veuillez sélectionner un médecin');
                e.preventDefault();
            }
        });
    </script>
</body>
</html>

