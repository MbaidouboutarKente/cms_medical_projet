<?php
session_start();
require_once "../config/db.php";

if (isset($_SESSION['user_id'])) {
    // Enregistrement du log avant de détruire la session
    enregistrerActivite($pdoMedical, str_replace(['ETU_', 'MED_'], '', $_SESSION['user_id']), 
                       "Déconnexion", "Session terminée");
}

session_destroy();
header("Location: ../../index.html");
// header("Location: auth.php");
exit;
?>

