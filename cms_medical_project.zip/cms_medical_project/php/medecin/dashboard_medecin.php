<?php
session_start();
require_once "../config/db.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Vérification rôle médecin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'medecin') {
    header("Location: auth.php");
    exit;
}

// Extraction ID numérique
$medecinID = intval(preg_replace('/^[A-Z]+_/', '', $_SESSION['user_id']));

// 1. Système de notifications avec persistance
$notifications = [];

try {
    // Récupération des informations du médecin
    $queryMedecin = $pdoMedical->prepare("SELECT id, nom, email, specialite FROM utilisateurs WHERE id = ?");
    $queryMedecin->execute([$medecinID]);
    $medecin = $queryMedecin->fetch();
    
    if (!$medecin) {
        throw new Exception("Médecin non trouvé");
    }

    // Vérifier les nouveaux patients référés (avec système de vue)
    $queryNewReferes = $pdoMedical->prepare("
        SELECT COUNT(*) as count 
        FROM rendez_vous 
        WHERE orientation_medecin = 'oui' 
        AND medecin_id IS NULL
        AND (vue IS NULL OR vue = 'non')
    ");
    $queryNewReferes->execute();
    $newReferesCount = $queryNewReferes->fetch()['count'];
    
    if ($newReferesCount > 0) {
        $notifications[] = [
            'type' => 'new_referral',
            'count' => $newReferesCount,
            'message' => "Vous avez $newReferesCount nouveau(x) patient(s) référé(s)",
            'icon' => 'fa-user-plus',
            'color' => 'var(--primary)',
            'persistent' => true
        ];
    }

    // Vérifier les nouveaux rendez-vous confirmés (avec système de vue)
    $queryNewRdvs = $pdoMedical->prepare("
        SELECT COUNT(*) as count 
        FROM rendez_vous 
        WHERE medecin_id = ? 
        AND statut = 'Confirmé'
        AND (vue IS NULL OR vue = 'non')
    ");
    $queryNewRdvs->execute([$medecinID]);
    $newRdvsCount = $queryNewRdvs->fetch()['count'];
    
    if ($newRdvsCount > 0) {
        $notifications[] = [
            'type' => 'new_appointment',
            'count' => $newRdvsCount,
            'message' => "Vous avez $newRdvsCount nouveau(x) rendez-vous",
            'icon' => 'fa-calendar-check',
            'color' => 'var(--success)',
            'persistent' => true
        ];
    }

    // Traitement de la marque comme vue si demandé
    if (isset($_GET['mark_viewed']) && $_GET['mark_viewed'] === 'true') {
        $markViewedStmt = $pdoMedical->prepare("
            UPDATE rendez_vous 
            SET vue = 'oui'
            WHERE (medecin_id = ? OR orientation_medecin = 'oui') 
            AND (vue IS NULL OR vue = 'non')
        ");
        $markViewedStmt->execute([$medecinID]);
        
        // Rediriger pour éviter la resoumission
        header("Location: dashboard_medecin.php");
        exit;
    }

    // Récupération des patients référés
    $queryReferes = $pdoMedical->prepare("
        SELECT rv.id, rv.date_rdv, rv.diagnostic_infirmier, rv.orientation_medecin, 
               e.nom AS patient_nom, e.prenom AS patient_prenom,
               i.nom AS infirmier_nom, i.prenom AS infirmier_prenom,
               rv.vue
        FROM rendez_vous rv
        JOIN utilisateurs e ON rv.patient_id = e.id
        JOIN utilisateurs i ON rv.infirmier_id = i.id
        WHERE rv.orientation_medecin = 'oui' AND rv.medecin_id IS NULL
        ORDER BY rv.date_rdv DESC
    ");
    $queryReferes->execute();
    $patientsReferes = $queryReferes->fetchAll();

    // Récupération des rendez-vous confirmés
    $queryRdvs = $pdoMedical->prepare("
        SELECT r.*, u.nom as patient_nom, u.prenom as patient_prenom,
               i.nom as infirmier_nom, i.prenom as infirmier_prenom,
               r.vue
        FROM rendez_vous r
        JOIN utilisateurs u ON r.patient_id = u.id
        LEFT JOIN utilisateurs i ON r.infirmier_id = i.id
        WHERE r.medecin_id = ?
        ORDER BY r.date_rdv DESC
    ");
    $queryRdvs->execute([$medecinID]);
    $rdvs = $queryRdvs->fetchAll();

} catch (PDOException $e) {
    die("Erreur base de données: " . $e->getMessage());
} catch (Exception $e) {
    die($e->getMessage());
}

// Récupération des dernières consultations
try {
    $queryLastConsultations = $pdoMedical->prepare("
        SELECT c.*, r.date_rdv, r.patient_id, u.nom AS patient_nom, u.prenom AS patient_prenom
        FROM consultations c
        JOIN rendez_vous r ON c.rendez_vous_id = r.id
        JOIN utilisateurs u ON r.patient_id = u.id
        WHERE r.medecin_id = ? 
        AND r.statut = 'Terminé'
        ORDER BY c.date_creation DESC
        LIMIT 10
    ");
    $queryLastConsultations->execute([$medecinID]);
    $lastConsultations = $queryLastConsultations->fetchAll();

} catch (PDOException $e) {
    $lastConsultations = [];
}

// Traitement des actions
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rdv_id = (int)$_POST['rdv_id'];
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === "accepter") {
            $recommandations = trim($_POST['recommandations_medecin']);
            
            if (empty($recommandations)) {
                throw new Exception("Les recommandations sont obligatoires");
            }
            
            $stmt = $pdoMedical->prepare("
                UPDATE rendez_vous 
                SET medecin_id = ?, 
                    recommandations_medecin = ?,
                    statut = 'Confirmé',
                    vue = 'oui'
                WHERE id = ? AND orientation_medecin = 'oui' AND medecin_id IS NULL
            ");
            
            if ($stmt->execute([$medecinID, $recommandations, $rdv_id])) {
                $message = "✅ Patient accepté et recommandations enregistrées";
                $queryReferes->execute();
                $patientsReferes = $queryReferes->fetchAll();
                $queryRdvs->execute([$medecinID]);
                $rdvs = $queryRdvs->fetchAll();
                $newReferesCount = max(0, $newReferesCount - 1);
            }
            
        } elseif ($action === "diagnostic") {
            $diagnostic = trim($_POST['diagnostic']);
            $prescription = trim($_POST['prescription'] ?? '');
            
            if (empty($diagnostic)) {
                throw new Exception("Le diagnostic ne peut pas être vide");
            }
            
            $stmt = $pdoMedical->prepare("
                UPDATE rendez_vous 
                SET diagnostic = ?,
                    prescription = ?,
                    statut = 'Terminé',
                    vue = 'oui'
                WHERE id = ? AND medecin_id = ?
            ");
            
            if ($stmt->execute([$diagnostic, $prescription, $rdv_id, $medecinID])) {
                $message = "✅ Diagnostic et prescription enregistrés - Consultation terminée";
                $queryRdvs->execute([$medecinID]);
                $rdvs = $queryRdvs->fetchAll();
            }
        }
        
    } catch (Exception $e) {
        $message = "🔴 Erreur: " . $e->getMessage();
    }
}

// Calcul du nombre total de notifications
$totalNotifications = array_sum(array_column($notifications, 'count'));
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Médecin | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            width: 95%;
            max-width: 1400px;
            margin: 1rem auto;
            padding: 0 1rem;
        }
        
        .header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--white);
            padding: 2rem;
            border-radius: var(--radius);
            margin-bottom: 2rem;
            text-align: center;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }
        
        .header::before {
            content: "";
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
            transform: rotate(30deg);
        }
        
        .header h1 {
            font-size: 2.2rem;
            margin-bottom: 0.5rem;
            position: relative;
        }
        
        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
            position: relative;
        }
        
        .profile-card {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            margin-bottom: 2rem;
            position: relative;
            border-left: 5px solid var(--primary);
        }
        
        .profile-card h2 {
            color: var(--primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            font-size: 1.5rem;
        }
        
        .profile-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }
        
        .info-item {
            background: var(--light-gray);
            padding: 1rem;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            transition: transform 0.3s ease;
        }
        
        .info-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .info-item i {
            color: var(--primary);
            font-size: 1.2rem;
            width: 30px;
            height: 30px;
            background: rgba(58, 123, 213, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .info-content h3 {
            font-size: 1rem;
            color: var(--dark);
            margin-bottom: 0.3rem;
        }
        
        .info-content p {
            font-size: 1.1rem;
            font-weight: 500;
            color: var(--primary-dark);
        }
        
        .rdv-card {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 0;
            margin-bottom: 3rem;
            overflow: hidden;
        }
        
        .alert {
            padding: 1.2rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            border-left: 5px solid;
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 1rem;
            animation: fadeIn 0.5s ease;
        }
        
        .alert i {
            font-size: 1.5rem;
        }
        
        .alert-success {
            background-color: rgba(46, 204, 113, 0.1);
            color: #27ae60;
            border-color: var(--success);
        }
        
        .alert-danger {
            background-color: rgba(231, 76, 60, 0.1);
            color: #c0392b;
            border-color: var(--danger);
        }
        
        .table-container {
            overflow-x: auto;
            padding: 0 1.5rem 1.5rem;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
            min-width: 800px;
        }
        
        .table th, .table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .table th {
            background-color: var(--primary);
            color: var(--white);
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
        }
        
        .table tr:nth-child(even) {
            background-color: var(--light-gray);
        }
        
        .table tr:hover {
            background-color: rgba(58, 123, 213, 0.05);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.7rem 1.5rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.95rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            margin: 0.3rem;
            white-space: nowrap;
        }
        
        .btn i {
            font-size: 1rem;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: var(--white);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.3);
        }
        
        .btn-success {
            background-color: var(--success);
            color: var(--white);
        }
        
        .btn-success:hover {
            background-color: #27ae60;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(46, 204, 113, 0.3);
        }
        
        .btn-outline {
            background: transparent;
            border: 1px solid var(--primary);
            color: var(--primary);
        }
        
        .btn-outline:hover {
            background: var(--primary);
            color: var(--white);
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(58, 123, 213, 0.2);
        }
        
        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }
        
        .nav-menu {
            display: flex;
            justify-content: space-between;
            background-color: var(--dark);
            padding: 1rem 2rem;
            border-radius: var(--radius);
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
        }
        
        .nav-menu a {
            color: var(--white);
            text-decoration: none;
            padding: 0.7rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.7rem;
        }
        
        .nav-menu a:hover {
            background-color: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        
        .tab-buttons {
            display: flex;
            margin-bottom: 0;
            border-bottom: 1px solid var(--light-gray);
            background: var(--light-gray);
        }
        
        .tab-btn {
            padding: 1.2rem 2rem;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            color: var(--gray);
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.7rem;
        }
        
        .tab-btn:hover {
            color: var(--primary);
            background: rgba(58, 123, 213, 0.05);
        }
        
        .tab-btn.active {
            color: var(--primary);
            border-bottom: 3px solid var(--primary);
            background: var(--white);
        }
        
        .tab-content {
            display: none;
            padding: 2rem;
            animation: fadeIn 0.5s ease;
        }
        
        .tab-content h2 {
            color: var(--primary-dark);
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .tab-content.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .diagnostic-form {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: var(--radius);
            margin-top: 1.5rem;
        }
        
        .status-badge {
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }
        
        .status-confirmed {
            background-color: rgba(46, 204, 113, 0.1);
            color: var(--success);
        }
        
        .status-pending {
            background-color: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }
        
        .status-completed {
            background-color: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }
        
        .patient-card {
            background: var(--white);
            border-radius: var(--radius);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            border-left: 4px solid var(--primary);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .patient-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .patient-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .patient-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--primary-dark);
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .patient-meta {
            display: flex;
            gap: 1.5rem;
            color: var(--gray);
            font-size: 0.9rem;
        }
        
        .patient-meta span {
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }
        
        .patient-details {
            background: var(--light-gray);
            padding: 1rem;
            border-radius: 8px;
            margin: 1rem 0;
        }
        
        .patient-details p {
            margin-bottom: 0.5rem;
        }
        
        .patient-details strong {
            color: var(--dark);
            font-weight: 500;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }
        
        .empty-state h3 {
            font-size: 1.3rem;
            margin-bottom: 0.5rem;
            color: var(--dark);
        }
        
        .badge {
            padding: 0.3rem 0.6rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-primary {
            background: rgba(58, 123, 213, 0.1);
            color: var(--primary);
        }
        
        .badge-secondary {
            background: rgba(0, 210, 255, 0.1);
            color: var(--secondary);
        }
        
        .badge-success {
            background: rgba(46, 204, 113, 0.1);
            color: var(--success);
        }
        
        .consultation-history {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .consultation-history h2 {
            color: var(--primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            font-size: 1.5rem;
        }
        
        .history-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .history-table th, .history-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .history-table th {
            background-color: var(--primary);
            color: var(--white);
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
        }
        
        .history-table tr:nth-child(even) {
            background-color: var(--light-gray);
        }
        
        .history-table tr:hover {
            background-color: rgba(58, 123, 213, 0.05);
        }
        
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        
        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
        }
        
        .btn-info {
            background-color: var(--info);
            color: var(--white);
        }
        
        .btn-info:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(52, 152, 219, 0.3);
        }
        
        .btn-secondary {
            background-color: var(--secondary);
            color: var(--white);
        }
        
        .btn-secondary:hover {
            background-color: #00b8d9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 210, 255, 0.3);
        }
        
        .tooltip {
            position: relative;
            display: inline-block;
        }
        
        .tooltip .tooltiptext {
            visibility: hidden;
            width: 120px;
            background-color: var(--dark);
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 0.8rem;
        }
        
        .tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }
        
        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 0 0.5rem;
            }
            
            .nav-menu {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem;
            }
            
            .profile-info {
                grid-template-columns: 1fr;
            }
            
            .tab-buttons {
                overflow-x: auto;
                white-space: nowrap;
                padding-bottom: 0.5rem;
            }
            
            .tab-btn {
                padding: 1rem 1.2rem;
                font-size: 0.9rem;
            }
            
            .header h1 {
                font-size: 1.8rem;
            }
            
            .patient-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.8rem;
            }
            
            .patient-meta {
                flex-wrap: wrap;
                gap: 0.8rem;
            }
            
            .history-table {
                display: block;
                overflow-x: auto;
            }
        }

        /* Styles améliorés pour les notifications */
        .notification-bell {
            position: relative;
            display: inline-block;
        }
        
        .notification-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: var(--danger);
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: bold;
        }
        
        .notifications-container {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 1000;
            max-width: 350px;
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .notification-item {
            background: white;
            border-left: 4px solid;
            padding: 15px;
            margin-bottom: 0;
            border-bottom: 1px solid var(--light-gray);
            display: flex;
            align-items: center;
            gap: 15px;
            animation: slideIn 0.3s ease-out;
            transform: translateX(0);
        }
        
        .notification-item:last-child {
            border-bottom: none;
        }
        
        .notification-item i {
            font-size: 1.5rem;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-close {
            cursor: pointer;
            opacity: 0.5;
            transition: opacity 0.2s;
            color: var(--gray);
        }
        
        .notification-close:hover {
            opacity: 1;
            color: var(--danger);
        }
        
        .notification-header {
            padding: 15px;
            background: var(--primary);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: var(--radius) var(--radius) 0 0;
        }
        
        .notification-actions {
            padding: 10px 15px;
            background: var(--light-gray);
            display: flex;
            justify-content: space-between;
            border-radius: 0 0 var(--radius) var(--radius);
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .notification-persistent {
            background: rgba(243, 156, 18, 0.05);
        }
    </style>
    <script>
        function openTab(evt, tabName) {
            // Masquer tous les contenus d'onglets
            const tabContents = document.getElementsByClassName("tab-content");
            for (let i = 0; i < tabContents.length; i++) {
                tabContents[i].classList.remove("active");
            }
            
            // Désactiver tous les boutons d'onglets
            const tabButtons = document.getElementsByClassName("tab-btn");
            for (let i = 0; i < tabButtons.length; i++) {
                tabButtons[i].classList.remove("active");
            }
            
            // Afficher l'onglet actuel
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
            
            // Stocker l'onglet actif dans localStorage
            localStorage.setItem('lastActiveTab', tabName);
        }
        
        // Par défaut, ouvrir le premier onglet ou le dernier onglet actif
        document.addEventListener('DOMContentLoaded', function() {
            const lastActiveTab = localStorage.getItem('lastActiveTab');
            if (lastActiveTab) {
                document.getElementById(lastActiveTab).classList.add("active");
                document.querySelector(`.tab-btn[onclick*="${lastActiveTab}"]`).classList.add("active");
            } else {
                document.querySelector('.tab-btn').click();
            }
        });
        
        // Confirmation pour les actions importantes
        function confirmAction(action) {
            return confirm(`Êtes-vous sûr de vouloir ${action} ?`);
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="nav-menu">
            <div>
                <a href="dashboard_medecin.php"><i class="fas fa-home"></i> Tableau de bord</a>
                <a href="calendrier.php"><i class="fas fa-calendar-alt"></i> Calendrier</a>
                <a href="../dossiers/liste_dossier.php"><i class="fas fa-user-injured"></i> Dossier patients</a>
                <a href="../consultations/certificats.php"><i class="fas fa-file-medical"></i> Certificats</a>
            </div>
            <div>
                <div class="notification-bell">
                    <a href="#" id="notificationToggle">
                        <i class="fas fa-bell"></i>
                        <?php if ($totalNotifications > 0): ?>
                            <span class="notification-count"><?= $totalNotifications ?></span>
                        <?php endif; ?>
                    </a>
                </div>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
            </div>
        </div>

        <!-- Zone des notifications -->
        <div class="notifications-container" id="notificationsPanel" style="display: none;">
            <div class="notification-header">
                <strong><i class="fas fa-bell"></i> Notifications</strong>
                <span class="notification-close" onclick="closeNotifications()">
                    <i class="fas fa-times"></i>
                </span>
            </div>
            
            <?php if (!empty($notifications)): ?>
                <?php foreach ($notifications as $notif): ?>
                    <div class="notification-item <?= $notif['persistent'] ?? false ? 'notification-persistent' : '' ?>" 
                         style="border-left-color: <?= $notif['color'] ?>">
                        <i class="fas <?= $notif['icon'] ?>" style="color: <?= $notif['color'] ?>"></i>
                        <div class="notification-content">
                            <strong><?= $notif['message'] ?></strong>
                            <p>Cliquez pour voir les détails</p>
                        </div>
                        <i class="fas fa-times notification-close" onclick="closeSingleNotification(this)"></i>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="notification-item">
                    <i class="fas fa-check-circle" style="color: var(--success)"></i>
                    <div class="notification-content">
                        <strong>Aucune nouvelle notification</strong>
                        <p>Vous êtes à jour</p>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($notifications)): ?>
                <div class="notification-actions">
                    <a href="?mark_viewed=true" class="btn btn-sm btn-outline">
                        <i class="fas fa-check-double"></i> Tout marquer comme lu
                    </a>
                    <a href="../rdv/liste_rdv.php" class="btn btn-sm btn-primary">
                        <i class="fas fa-eye"></i> Voir tous
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <div class="header">
            <h1><i class="fas fa-user-md"></i> Tableau de bord Médecin</h1>
            <p>Gérez vos consultations et vos patients en un seul endroit</p>
        </div>

        <?php if (!empty($message)): ?>
            <div class="alert alert-<?= strpos($message, '✅') !== false ? 'success' : 'danger' ?>">
                <i class="fas <?= strpos($message, '✅') !== false ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <div class="profile-card">
            <h2><i class="fas fa-id-card"></i> Profil Médecin</h2>
            <div class="profile-info">
                <div class="info-item">
                    <i class="fas fa-user"></i>
                    <div class="info-content">
                        <h3>Identité</h3>
                        <p>Dr. <?= htmlspecialchars($medecin['nom']) ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-id-badge"></i>
                    <div class="info-content">
                        <h3>Identifiant</h3>
                        <p>MED_<?= $medecin['id'] ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-envelope"></i>
                    <div class="info-content">
                        <h3>Email</h3>
                        <p><?= htmlspecialchars($medecin['email']) ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-stethoscope"></i>
                    <div class="info-content">
                        <h3>Spécialité</h3>
                        <p><?= htmlspecialchars($medecin['specialite'] ?? 'Généraliste') ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="rdv-card">
            <div class="tab-buttons">
                <button class="tab-btn active" onclick="openTab(event, 'referes')">
                    <i class="fas fa-user-clock"></i> Patients référés (<?= count($patientsReferes) ?>)
                </button>
                <button class="tab-btn" onclick="openTab(event, 'confirmes')">
                    <i class="fas fa-calendar-check"></i> Mes consultations (<?= count($rdvs) ?>)
                </button>
                <button class="tab-btn" onclick="openTab(event, 'diagnostic')">
                    <i class="fas fa-file-medical-alt"></i> Finaliser diagnostic
                </button>
            </div>

            <div id="referes" class="tab-content active">
                <h2><i class="fas fa-user-clock"></i> Patients référés par les infirmiers</h2>
                
                <?php if (empty($patientsReferes)): ?>
                    <div class="empty-state">
                        <i class="fas fa-user-slash"></i>
                        <h3>Aucun patient référé en attente</h3>
                        <p>Tous vos patients ont été pris en charge ou aucun n'a été référé pour le moment.</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <?php foreach ($patientsReferes as $patient): ?>
                            <div class="patient-card">
                                <div class="patient-header">
                                    <div class="patient-title">
                                        <i class="fas fa-user-injured"></i>
                                        <?= htmlspecialchars($patient['patient_nom']) ?>
                                        <?php if ($patient['vue'] === 'non' || $patient['vue'] === null): ?>
                                            <span class="badge badge-primary">Nouveau</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="patient-meta">
                                        <span><i class="fas fa-user-nurse"></i> <?= htmlspecialchars($patient['infirmier_nom']) ?></span>
                                        <span><i class="fas fa-calendar-day"></i> <?= date('d/m/Y H:i', strtotime($patient['date_rdv'])) ?></span>
                                    </div>
                                </div>
                                
                                <div class="patient-details">
                                    <p><strong><i class="fas fa-diagnosis"></i> Diagnostic infirmier :</strong></p>
                                    <p><?= htmlspecialchars($patient['diagnostic_infirmier']) ?></p>
                                </div>
                                
                                <form method="post" class="diagnostic-form">
                                    <input type="hidden" name="rdv_id" value="<?= $patient['id'] ?>">
                                    <input type="hidden" name="action" value="accepter">
                                    
                                    <div class="form-group">
                                        <label><i class="fas fa-comment-medical"></i> Recommandations préliminaires :</label>
                                        <textarea name="recommandations_medecin" class="form-control" 
                                            placeholder="Renseignez vos recommandations pour la prise en charge de ce patient..." required></textarea>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-check-circle"></i> Accepter le patient
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div id="confirmes" class="tab-content">
                <h2><i class="fas fa-calendar-check"></i> Mes consultations programmées</h2>
                
                <?php if (empty($rdvs)): ?>
                    <div class="empty-state">
                        <i class="fas fa-calendar-times"></i>
                        <h3>Aucune consultation programmée</h3>
                        <p>Vous n'avez aucune consultation de prévue pour le moment.</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Patient</th>
                                    <th>Date</th>
                                    <th>Infirmier</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rdvs as $rdv): ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($rdv['patient_nom']) ?></strong>
                                            <?php if ($rdv['vue'] === 'non' || $rdv['vue'] === null): ?>
                                                <span class="badge badge-primary">Nouveau</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?= date('d/m/Y', strtotime($rdv['date_rdv'])) ?><br>
                                            <small><?= date('H:i', strtotime($rdv['date_rdv'])) ?></small>
                                        </td>
                                        <td><?= htmlspecialchars($rdv['infirmier_nom'] ?? 'N/A') ?></td>
                                        <td>
                                            <span class="status-badge 
                                                <?= $rdv['statut'] === 'Confirmé' ? 'status-confirmed' : 
                                                   ($rdv['statut'] === 'Terminé' ? 'status-completed' : 'status-pending') ?>">
                                                <i class="fas <?= $rdv['statut'] === 'Confirmé' ? 'fa-check-circle' : 
                                                   ($rdv['statut'] === 'Terminé' ? 'fa-clipboard-check' : 'fa-clock') ?>"></i>
                                                <?= $rdv['statut'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="../dossiers/dossier_patient.php?id=<?= $rdv['patient_id'] ?>" class="btn btn-outline tooltip" title="Dossier patient">
                                                    <i class="fas fa-folder-open"></i>
                                                </a>
                                                <?php if ($rdv['statut'] === 'Confirmé'): ?>
                                                    <a href="#diagnostic" onclick="document.querySelector('.tab-btn:nth-child(3)').click();" 
                                                       class="btn btn-primary tooltip" title="Remplir diagnostic">
                                                        <i class="fas fa-file-medical-alt"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <a href="calendrier.php?rdv_id=<?= $rdv['id'] ?>" class="btn btn-secondary tooltip" title="Voir dans le calendrier">
                                                    <i class="fas fa-calendar-alt"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <div id="diagnostic" class="tab-content">
                <h2><i class="fas fa-file-medical-alt"></i> Finaliser un diagnostic médical</h2>
                
                <?php 
                    // Filtrer les RDV pouvant recevoir un diagnostic
                    $rdvsPourDiagnostic = array_filter($rdvs, fn($rdv) => $rdv['statut'] === 'Confirmé');
                ?>
                
                <?php if (empty($rdvsPourDiagnostic)): ?>
                    <div class="empty-state">
                        <i class="fas fa-file-medical"></i>
                        <h3>Aucune consultation nécessitant un diagnostic</h3>
                        <p>Toutes vos consultations ont déjà un diagnostic ou aucune n'est en attente.</p>
                    </div>
                <?php else: ?>
                    <form method="post" class="diagnostic-form">
                        <div class="form-group">
                            <label><i class="fas fa-calendar-check"></i> Sélectionner une consultation :</label>
                            <select name="rdv_id" class="form-control" required>
                                <?php foreach ($rdvsPourDiagnostic as $rdv): ?>
                                    <option value="<?= $rdv['id'] ?>">
                                        <?= htmlspecialchars($rdv['patient_nom']) ?> - 
                                        <?= date('d/m/Y H:i', strtotime($rdv['date_rdv'])) ?>
                                        (<?= htmlspecialchars($rdv['infirmier_nom'] ?? 'Sans infirmier') ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-diagnoses"></i> Diagnostic médical complet :</label>
                            <textarea name="diagnostic" class="form-control" 
                                placeholder="Décrire le diagnostic, les observations et les conclusions médicales..." required rows="5"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-prescription-bottle-alt"></i> Prescription médicale :</label>
                            <textarea name="prescription" class="form-control" 
                                placeholder="Renseignez les médicaments prescrits, posologie et durée du traitement..." rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label><i class="fas fa-file-prescription"></i> Recommandations supplémentaires :</label>
                            <textarea name="recommandations" class="form-control" 
                                placeholder="Conseils pour le patient, suivi à prévoir..." rows="2"></textarea>
                        </div>
                        
                        <input type="hidden" name="action" value="diagnostic">
                        <button type="submit" class="btn btn-primary" onclick="return confirmAction('enregistrer ce diagnostic')">
                            <i class="fas fa-save"></i> Enregistrer le diagnostic
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <!-- Section Historique des consultations -->
        <div class="consultation-history">
            <h2><i class="fas fa-history"></i> Historique des dernières consultations</h2>
            
            <?php if (empty($lastConsultations)): ?>
                <div class="empty-state">
                    <i class="fas fa-calendar-times"></i>
                    <h3>Aucune consultation enregistrée</h3>
                    <p>Vous n'avez pas encore réalisé de consultations.</p>
                </div>
            <?php else: ?>
                <div class="table-container">
                    <table class="history-table">
                        <thead>
                            <tr>
                                <th>Patient</th>
                                <th>Date du RDV</th>
                                <th>Diagnostic</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($lastConsultations as $consult): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($consult['patient_prenom'] . ' ' . $consult['patient_nom']) ?></strong>
                                </td>
                                <td>
                                    <?= date('d/m/Y H:i', strtotime($consult['date_rdv'])) ?><br>
                                    <small>Terminé le <?= date('d/m/Y', strtotime($consult['date_creation'])) ?></small>
                                </td>
                                <td>
                                    <?= !empty($consult['diagnostic']) ? htmlspecialchars(substr($consult['diagnostic'], 0, 50)) . "..." : "<em>Non renseigné</em>" ?>
                                </td>
                                <td>
                                <div class="action-buttons">
                                        <a href="../consultations/voir_consultation.php?id=<?= $consult['id'] ?>" class="btn btn-info btn-sm tooltip" title="Voir détails">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="../dossiers/dossier_patient.php?id=<?= $consult['patient_id'] ?>" class="btn btn-secondary btn-sm tooltip" title="Dossier patient">
                                            <i class="fas fa-folder"></i>
                                        </a>
                                        <a href="../consultations/certificats.php?consult_id=<?= $consult['id'] ?>" class="btn btn-outline btn-sm tooltip" title="Éditer certificat">
                                            <i class="fas fa-file-medical"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <script>
        // Gestion des notifications
        document.getElementById('notificationToggle').addEventListener('click', function(e) {
            e.preventDefault();
            const panel = document.getElementById('notificationsPanel');
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        });

        // Fermer les notifications
        function closeNotifications() {
            document.getElementById('notificationsPanel').style.display = 'none';
        }

        // Fermer une notification individuelle
        function closeSingleNotification(element) {
            const notificationItem = element.closest('.notification-item');
            notificationItem.style.animation = 'slideIn 0.3s ease-out reverse';
            setTimeout(() => {
                notificationItem.remove();
                
                // Masquer le panel si plus de notifications
                if (document.querySelectorAll('.notification-item').length === 0) {
                    document.getElementById('notificationsPanel').style.display = 'none';
                }
            }, 300);
        }

        // Auto-fermeture après 8 secondes
        setTimeout(() => {
            closeNotifications();
        }, 8000);

        // Fermer en cliquant à l'extérieur
        document.addEventListener('click', function(event) {
            const panel = document.getElementById('notificationsPanel');
            const bell = document.getElementById('notificationToggle');
            
            if (panel.style.display === 'block' && 
                !panel.contains(event.target) && 
                !bell.contains(event.target)) {
                closeNotifications();
            }
        });
    </script>
</body>
</html>