<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "../config/db.php";

// Vérification rôle médecin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'medecin') {
    header("Location: ../auth.php");
    exit;
}

$medecinID = intval(preg_replace('/^[A-Z]+_/', '', $_SESSION['user_id']));

// Récupérer la date courante ou celle sélectionnée
$currentDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$currentMonth = date('m', strtotime($currentDate));
$currentYear = date('Y', strtotime($currentDate));

// Navigation entre les mois
$prevMonth = date('Y-m-d', strtotime($currentDate . ' -1 month'));
$nextMonth = date('Y-m-d', strtotime($currentDate . ' +1 month'));

try {
    // Récupérer les rendez-vous du médecin pour le mois courant
    $queryRdv = $pdoMedical->prepare("
        SELECT r.*, 
               u.prenom AS patient_prenom, 
               u.nom AS patient_nom,
               u.email AS patient_email,
               r.date_rdv,
               r.type_rdv,
               r.motif,
               r.statut
        FROM rendez_vous r
        JOIN utilisateurs u ON r.patient_id = u.id
        WHERE r.medecin_id = ? 
        AND MONTH(r.date_rdv) = ? 
        AND YEAR(r.date_rdv) = ?
        ORDER BY r.date_rdv ASC
    ");
    $queryRdv->execute([$medecinID, $currentMonth, $currentYear]);
    $rendezVous = $queryRdv->fetchAll();

    // Organiser les RDV par date
    $rdvParDate = [];
    foreach ($rendezVous as $rdv) {
        $date = date('Y-m-d', strtotime($rdv['date_rdv']));
        $rdvParDate[$date][] = $rdv;
    }

    // Statistiques
    $rdvAujourdhui = array_filter($rendezVous, function($rdv) {
        return date('Y-m-d', strtotime($rdv['date_rdv'])) == date('Y-m-d');
    });

    $rdvThisMonth = count($rendezVous);
    $rdvConfirmes = count(array_filter($rendezVous, function($rdv) {
        return $rdv['statut'] === 'Confirmé';
    }));

} catch (PDOException $e) {
    die("Erreur base de données: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendrier Médical | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            width: 95%;
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
        /* Header Navigation */
        .nav-header {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1rem 2rem;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-links a {
            color: var(--primary);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .nav-links a:hover {
            color: var(--primary-dark);
        }
        
        /* Page Header */
        .page-header {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        .page-header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 2rem;
        }
        
        .header-title h1 {
            color: var(--primary);
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .header-title p {
            color: var(--gray);
        }
        
        .calendar-nav {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .calendar-nav-btn {
            background: var(--light-gray);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            color: var(--primary);
        }
        
        .calendar-nav-btn:hover {
            background: var(--primary);
            color: var(--white);
            transform: translateY(-2px);
        }
        
        .current-month {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--dark);
            min-width: 200px;
            text-align: center;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        .stat-card {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            text-align: center;
            border-left: 3px solid var(--primary);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 600;
            color: var(--primary);
            display: block;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: var(--gray);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Calendar Layout */
        .calendar-layout {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 2rem;
        }
        
        @media (max-width: 1200px) {
            .calendar-layout {
                grid-template-columns: 1fr;
            }
        }
        
        /* Calendar Grid */
        .calendar-container {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }
        
        .calendar-header {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            background: var(--primary);
            color: var(--white);
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }
        
        .calendar-header div {
            padding: 1rem;
            text-align: center;
            border-right: 1px solid rgba(255,255,255,0.1);
        }
        
        .calendar-header div:last-child {
            border-right: none;
        }
        
        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            grid-auto-rows: 120px;
        }
        
        .calendar-day {
            border: 1px solid var(--light-gray);
            padding: 0.5rem;
            position: relative;
            transition: all 0.3s ease;
            background: var(--white);
        }
        
        .calendar-day:hover {
            background: var(--light-gray);
            transform: scale(1.02);
            z-index: 1;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .day-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        
        .day-number {
            font-weight: 600;
            color: var(--dark);
            font-size: 1.1rem;
        }
        
        .today .day-number {
            background: var(--primary);
            color: var(--white);
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .other-month {
            background: #f8f9fa;
            color: var(--gray);
        }
        
        .other-month .day-number {
            color: var(--gray);
        }
        
        .weekend {
            background: #fafbfc;
        }
        
        .rdv-count {
            background: var(--primary);
            color: var(--white);
            font-size: 0.7rem;
            padding: 0.2rem 0.4rem;
            border-radius: 10px;
            min-width: 20px;
            text-align: center;
        }
        
        .rdv-list {
            max-height: 80px;
            overflow-y: auto;
        }
        
        .rdv-item {
            background: var(--success);
            color: var(--white);
            padding: 0.2rem 0.4rem;
            border-radius: 4px;
            font-size: 0.7rem;
            margin-bottom: 0.2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .rdv-item:hover {
            opacity: 0.8;
            transform: translateX(2px);
        }
        
        .rdv-type-consultation { background: var(--success); }
        .rdv-type-urgence { background: var(--danger); }
        .rdv-type-controle { background: var(--warning); }
        .rdv-type-vaccination { background: var(--info); }
        
        /* Sidebar */
        .calendar-sidebar {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            height: fit-content;
            position: sticky;
            top: 2rem;
        }
        
        .sidebar-section {
            margin-bottom: 2rem;
        }
        
        .sidebar-section:last-child {
            margin-bottom: 0;
        }
        
        .sidebar-section h3 {
            color: var(--primary);
            font-size: 1.2rem;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--light-gray);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .today-rdv-list {
            max-height: 300px;
            overflow-y: auto;
        }
        
        .rdv-card {
            background: var(--light-gray);
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border-left: 3px solid var(--success);
            transition: all 0.3s ease;
        }
        
        .rdv-card:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .rdv-card.urgence {
            border-left-color: var(--danger);
        }
        
        .rdv-card.controle {
            border-left-color: var(--warning);
        }
        
        .rdv-time {
            font-weight: 600;
            color: var(--primary);
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }
        
        .rdv-patient {
            font-weight: 500;
            color: var(--dark);
            margin-bottom: 0.25rem;
        }
        
        .rdv-motif {
            color: var(--gray);
            font-size: 0.85rem;
            margin-bottom: 0.5rem;
        }
        
        .rdv-status {
            display: inline-block;
            padding: 0.2rem 0.6rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .status-confirme { background: rgba(46, 204, 113, 0.1); color: var(--success); }
        .status-attente { background: rgba(243, 156, 18, 0.1); color: var(--warning); }
        .status-annule { background: rgba(231, 76, 60, 0.1); color: var(--danger); }
        
        .quick-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .action-btn {
            background: var(--light-gray);
            border: none;
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--dark);
        }
        
        .action-btn:hover {
            background: var(--primary);
            color: var(--white);
            transform: translateY(-2px);
        }
        
        .action-btn i {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
            display: block;
        }
        
        .legend {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
        }
        
        .legend-color {
            width: 12px;
            height: 12px;
            border-radius: 2px;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            background-color: var(--primary);
            color: var(--white);
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.2);
        }
        
        .btn-success {
            background-color: var(--success);
        }
        
        .btn-success:hover {
            background-color: #27ae60;
        }
        
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }
        
        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 0 0.5rem;
            }
            
            .nav-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .nav-links {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 1rem;
            }
            
            .nav-links a {
                margin: 0;
            }
            
            .header-content {
                flex-direction: column;
                text-align: center;
            }
            
            .calendar-grid {
                grid-auto-rows: 100px;
            }
            
            .quick-actions {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Header -->
        <div class="nav-header">
            <div>
                <h3><i class="fas fa-user-md"></i> Espace Médecin</h3>
            </div>
            <div class="nav-links">
                <a href="dashboard_medecin.php"><i class="fas fa-home"></i> Tableau de bord</a>
                <a href="../rdv/liste_rdv.php"><i class="fas fa-calendar-alt"></i> Mes RDV</a>
                <a href="../dossiers/liste_dossier.php"><i class="fas fa-user-injured"></i> Dossier patients</a>
                <!-- <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a> -->
            </div>
        </div>

        <!-- Page Header -->
        <div class="page-header">
            <div class="header-content">
                <div class="header-title">
                    <h1><i class="fas fa-calendar-alt"></i> Calendrier Médical</h1>
                    <p>Gérez votre emploi du temps et vos rendez-vous</p>
                </div>
                <div class="calendar-nav">
                    <a href="?date=<?= $prevMonth ?>" class="calendar-nav-btn">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                    <div class="current-month">
                        <?= 
                            // Tableau des mois en français
                            [
                                'January' => 'janvier', 'February' => 'février', 'March' => 'mars',
                                'April' => 'avril', 'May' => 'mai', 'June' => 'juin',
                                'July' => 'juillet', 'August' => 'août', 'September' => 'septembre',
                                'October' => 'octobre', 'November' => 'novembre', 'December' => 'décembre'
                            ][date('F', strtotime($currentDate))] 
                            . ' ' . date('Y', strtotime($currentDate))
                        ?>
                    </div>
                    <a href="?date=<?= $nextMonth ?>" class="calendar-nav-btn">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-number"><?= count($rdvAujourdhui) ?></span>
                    <span class="stat-label">RDV aujourd'hui</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?= $rdvThisMonth ?></span>
                    <span class="stat-label">RDV ce mois</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?= $rdvConfirmes ?></span>
                    <span class="stat-label">Confirmés</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?= $rdvThisMonth - $rdvConfirmes ?></span>
                    <span class="stat-label">En attente</span>
                </div>
            </div>
        </div>

        <div class="calendar-layout">
            <!-- Calendrier Principal -->
            <div class="calendar-container">
                <div class="calendar-header">
                    <div>Lundi</div>
                    <div>Mardi</div>
                    <div>Mercredi</div>
                    <div>Jeudi</div>
                    <div>Vendredi</div>
                    <div>Samedi</div>
                    <div>Dimanche</div>
                </div>
                <div class="calendar-grid">
                    <?php
                    // Générer le calendrier
                    $firstDay = date('N', strtotime($currentYear . '-' . $currentMonth . '-01'));
                    $daysInMonth = date('t', strtotime($currentDate));
                    $currentDay = 1;
                    
                    // Jours du mois précédent
                    for ($i = 1; $i < $firstDay; $i++) {
                        $prevMonthDays = date('t', strtotime($prevMonth));
                        $day = $prevMonthDays - ($firstDay - $i - 1);
                        echo '<div class="calendar-day other-month weekend">';
                        echo '<div class="day-header">';
                        echo '<span class="day-number">' . $day . '</span>';
                        echo '</div>';
                        echo '</div>';
                    }
                    
                    // Jours du mois courant
                    for ($day = 1; $day <= $daysInMonth; $day++) {
                        $currentDateStr = $currentYear . '-' . $currentMonth . '-' . sprintf('%02d', $day);
                        $isToday = $currentDateStr == date('Y-m-d');
                        $isWeekend = date('N', strtotime($currentDateStr)) >= 6;
                        $rdvCount = isset($rdvParDate[$currentDateStr]) ? count($rdvParDate[$currentDateStr]) : 0;
                        
                        $class = 'calendar-day';
                        if ($isToday) $class .= ' today';
                        if ($isWeekend) $class .= ' weekend';
                        
                        echo '<div class="' . $class . '">';
                        echo '<div class="day-header">';
                        echo '<span class="day-number">' . $day . '</span>';
                        if ($rdvCount > 0) {
                            echo '<span class="rdv-count">' . $rdvCount . '</span>';
                        }
                        echo '</div>';
                        
                        if ($rdvCount > 0) {
                            echo '<div class="rdv-list">';
                            foreach ($rdvParDate[$currentDateStr] as $rdv) {
                                $time = date('H:i', strtotime($rdv['date_rdv']));
                                $typeClass = 'rdv-type-' . strtolower($rdv['type_rdv'] ?? 'consultation');
                                echo '<div class="rdv-item ' . $typeClass . '" title="' . htmlspecialchars($rdv['patient_prenom'] . ' ' . $rdv['patient_nom'] . ' - ' . $rdv['motif']) . '">';
                                echo $time . ' - ' . htmlspecialchars($rdv['patient_nom'] ?? '');

                                echo '</div>';
                            }
                            echo '</div>';
                        }
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="calendar-sidebar">
                <!-- RDV du jour -->
                <div class="sidebar-section">
                    <h3><i class="fas fa-clock"></i> Aujourd'hui</h3>
                    <div class="today-rdv-list">
                        <?php if (empty($rdvAujourdhui)): ?>
                            <div class="empty-state">
                                <i class="fas fa-calendar-check"></i>
                                <p>Aucun rendez-vous aujourd'hui</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($rdvAujourdhui as $rdv): ?>
                                <div class="rdv-card <?= strtolower($rdv['type_rdv']) ?>">
                                    <div class="rdv-time">
                                        <i class="fas fa-clock"></i>
                                        <?= date('H:i', strtotime($rdv['date_rdv'])) ?>
                                    </div>
                                    <div class="rdv-patient">
                                        <?= htmlspecialchars($rdv['patient_prenom'] . ' ' . $rdv['patient_nom']) ?>
                                    </div>
                                    <div class="rdv-motif">
                                        <?= htmlspecialchars($rdv['motif']) ?>
                                    </div>
                                    <div>
                                        <span class="rdv-status status-<?= strtolower($rdv['statut']) ?>">
                                            <?= htmlspecialchars($rdv['statut']) ?>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Actions rapides -->
                <div class="sidebar-section">
                    <h3><i class="fas fa-bolt"></i> Actions rapides</h3>
                    <div class="quick-actions">
                        <a href="../rdv/prendre_rdv.php?action=add" class="action-btn">
                            <i class="fas fa-plus-circle"></i>
                            Nouveau RDV
                        </a>
                        <a href="gestion_rdv.php" class="action-btn">
                            <i class="fas fa-list"></i>
                            Liste RDV
                        </a>
                    </div>
                </div>

                <!-- Légende -->
                <div class="sidebar-section">
                    <h3><i class="fas fa-info-circle"></i> Légende</h3>
                    <div class="legend">
                        <div class="legend-item">
                            <div class="legend-color" style="background: var(--success);"></div>
                            <span>Consultation</span>
                        </div>
                        <div class="legend-item">
                            <div class="legend-color" style="background: var(--danger);"></div>
                            <span>Urgence</span>
                        </div>
                        <div class="legend-item">
                            <div class="legend-color" style="background: var(--warning);"></div>
                            <span>Contrôle</span>
                        </div>
                        <div class="legend-item">
                            <div class="legend-color" style="background: var(--info);"></div>
                            <span>Vaccination</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Animation au chargement
        document.addEventListener('DOMContentLoaded', function() {
            const calendarDays = document.querySelectorAll('.calendar-day');
            calendarDays.forEach((day, index) => {
                day.style.animationDelay = (index * 0.05) + 's';
            });
        });

        // Tooltip pour les RDV
        const rdvItems = document.querySelectorAll('.rdv-item');
        rdvItems.forEach(item => {
            item.addEventListener('mouseenter', function(e) {
                const tooltip = document.createElement('div');
                tooltip.className = 'tooltip';
                tooltip.textContent = this.title;
                tooltip.style.cssText = `
                    position: fixed;
                    background: var(--dark);
                    color: white;
                    padding: 0.5rem;
                    border-radius: 4px;
                    font-size: 0.8rem;
                    z-index: 1000;
                    pointer-events: none;
                `;
                document.body.appendChild(tooltip);
                
                this.addEventListener('mousemove', function(e) {
                    tooltip.style.left = (e.pageX + 10) + 'px';
                    tooltip.style.top = (e.pageY + 10) + 'px';
                });
                
                this.addEventListener('mouseleave', function() {
                    document.body.removeChild(tooltip);
                });
            });
        });
    </script>
</body>
</html>