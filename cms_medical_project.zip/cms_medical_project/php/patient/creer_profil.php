<?php
session_start();
require_once "../config/db.php";

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'etudiant') {
    header("Location: ../config/auth.php");
    exit;
}

// Extraction de l'ID utilisateur selon le format
if (strpos($_SESSION['user_id'], 'MED_') === 0) {
    $userID = intval(str_replace("MED_", "", $_SESSION['user_id']));
} elseif (strpos($_SESSION['user_id'], 'ETU_') === 0) {
    $userID = intval(str_replace("ETU_", "", $_SESSION['user_id']));
} else {
    $userID = intval($_SESSION['user_id']);
}

// Récupération des informations de base de l'utilisateur
try {
    $stmtUser = $pdoMedical->prepare("
        SELECT u.* 
        FROM utilisateurs u 
        WHERE u.id = ?
    ");
    
    $stmtUser->execute([$userID]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        die("Utilisateur non trouvé");
    }

} catch (PDOException $e) {
    die("Erreur lors de la récupération des données utilisateur: " . $e->getMessage());
}

// Vérifier si le profil patient existe déjà
try {
    $stmtCheckPatient = $pdoMedical->prepare("
        SELECT id FROM patients WHERE utilisateur_id = ?
    ");
    
    $stmtCheckPatient->execute([$userID]);
    $existingPatient = $stmtCheckPatient->fetch(PDO::FETCH_ASSOC);

    if ($existingPatient) {
        header("Location: ../dossiers/dossier_medical.php");
        exit;
    }

} catch (PDOException $e) {
    error_log("Erreur vérification profil patient: " . $e->getMessage());
}

// Traitement du formulaire
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et validation des données
    $date_naissance = $_POST['date_naissance'] ?? '';
    $groupe_sanguin = $_POST['groupe_sanguin'] ?? '';
    $allergies = $_POST['allergies'] ?? '';
    $antecedents = $_POST['antecedents'] ?? '';
    $taille = $_POST['taille'] ?? '';
    $poids = $_POST['poids'] ?? '';
    $assurance_maladie = $_POST['assurance_maladie'] ?? '';
    $numero_securite_sociale = $_POST['numero_securite_sociale'] ?? '';
    $telephone = $_POST['telephone'] ?? '';

    // Validation des champs requis
    if (empty($date_naissance)) {
        $errors[] = "La date de naissance est obligatoire";
    }

    if (empty($telephone)) {
        $errors[] = "Le numéro de téléphone est obligatoire";
    }

    // Validation de la date de naissance
    if (!empty($date_naissance)) {
        $birthDate = DateTime::createFromFormat('Y-m-d', $date_naissance);
        $today = new DateTime();
        if (!$birthDate || $birthDate > $today) {
            $errors[] = "La date de naissance n'est pas valide";
        }
    }

    // Validation de la taille et poids
    if (!empty($taille) && ($taille < 50 || $taille > 250)) {
        $errors[] = "La taille doit être comprise entre 50 et 250 cm";
    }

    if (!empty($poids) && ($poids < 2 || $poids > 300)) {
        $errors[] = "Le poids doit être compris entre 2 et 300 kg";
    }

    // Si pas d'erreurs, insertion en base
    if (empty($errors)) {
        try {
            $pdoMedical->beginTransaction();

            // Mise à jour du téléphone dans la table utilisateurs
            if (!empty($telephone)) {
                $stmtUpdatePhone = $pdoMedical->prepare("
                    UPDATE utilisateurs SET telephone = ? WHERE id = ?
                ");
                $stmtUpdatePhone->execute([$telephone, $userID]);
            }

            // Insertion dans la table patients
            $stmtInsertPatient = $pdoMedical->prepare("
                INSERT INTO patients (
                    utilisateur_id, date_naissance, groupe_sanguin, allergies, 
                    antecedents, taille, poids, assurance_maladie, numero_securite_sociale
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmtInsertPatient->execute([
                $userID,
                $date_naissance ?: null,
                $groupe_sanguin ?: null,
                $allergies ?: null,
                $antecedents ?: null,
                $taille ?: null,
                $poids ?: null,
                $assurance_maladie ?: null,
                $numero_securite_sociale ?: null
            ]);

            $pdoMedical->commit();
            $success = true;

            // Redirection après succès
            header("Refresh: 2; URL=../dossiers/dossier_medical.php");
            
        } catch (PDOException $e) {
            $pdoMedical->rollBack();
            $errors[] = "Erreur lors de la création du profil: " . $e->getMessage();
            error_log("Erreur création profil patient: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer mon Profil Patient | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #3498db;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--dark);
            line-height: 1.6;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        .btn-retour {
            position: fixed;
            top: 20px;
            left: 20px;
            background: var(--white);
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            box-shadow: var(--shadow);
            cursor: pointer;
            font-size: 1.2rem;
            color: var(--primary);
            z-index: 1000;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        .btn-retour:hover {
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .creation-card {
            background: var(--white);
            border-radius: var(--radius);
            padding: 3rem;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }

        .creation-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .page-title {
            color: var(--primary);
            font-size: 2.2rem;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .page-subtitle {
            color: var(--gray);
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }

        .user-info {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: var(--radius);
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-size: 1.5rem;
            font-weight: bold;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }

        .required::after {
            content: ' *';
            color: var(--danger);
        }

        input, select, textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 2px solid var(--light-gray);
            border-radius: var(--radius);
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--white);
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(58, 123, 213, 0.1);
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-help {
            font-size: 0.85rem;
            color: var(--gray);
            margin-top: 0.3rem;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.8rem;
            padding: 1rem 2.5rem;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: var(--primary);
            color: var(--white);
            box-shadow: 0 5px 15px rgba(58, 123, 213, 0.2);
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(58, 123, 213, 0.3);
        }

        .btn-full {
            width: 100%;
        }

        .alert {
            padding: 1rem 1.5rem;
            border-radius: var(--radius);
            margin-bottom: 2rem;
            border-left: 4px solid;
        }

        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            border-color: var(--success);
            color: var(--success);
        }

        .alert-danger {
            background: rgba(231, 76, 60, 0.1);
            border-color: var(--danger);
            color: var(--danger);
        }

        .alert-warning {
            background: rgba(243, 156, 18, 0.1);
            border-color: var(--warning);
            color: var(--warning);
        }

        .progress-steps {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3rem;
            position: relative;
        }

        .progress-steps::before {
            content: '';
            position: absolute;
            top: 15px;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--light-gray);
            z-index: 1;
        }

        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            z-index: 2;
        }

        .step-number {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: var(--light-gray);
            color: var(--gray);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }

        .step.active .step-number {
            background: var(--primary);
            color: var(--white);
        }

        .step-label {
            font-size: 0.9rem;
            color: var(--gray);
            text-align: center;
        }

        .step.active .step-label {
            color: var(--primary);
            font-weight: 500;
        }

        .section-title {
            color: var(--primary);
            font-size: 1.3rem;
            margin: 2rem 0 1rem 0;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--light-gray);
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        @media (max-width: 768px) {
            .container {
                padding: 1rem 0.5rem;
            }
            
            .creation-card {
                padding: 2rem 1.5rem;
            }
            
            .page-title {
                font-size: 1.8rem;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <a href="../dossiers/dossier_medical.php" class="btn-retour" title="Retour">
        <i class="fas fa-arrow-left"></i>
    </a>

    <div class="container">
        <div class="creation-card">
            <!-- En-tête -->
            <h1 class="page-title">
                <i class="fas fa-user-plus"></i>
                Créer mon Profil Patient
            </h1>
            <p class="page-subtitle">
                Complétez vos informations médicales pour bénéficier d'un suivi personnalisé
            </p>

            <!-- Informations utilisateur -->
            <div class="user-info">
                <div class="user-avatar">
                    <?= strtoupper(substr($user['prenom'], 0, 1) . substr($user['nom'], 0, 1)) ?>
                </div>
                <div>
                    <h3><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></h3>
                    <p style="color: var(--gray);"><?= htmlspecialchars($user['email']) ?></p>
                </div>
            </div>

            <!-- Messages d'alerte -->
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    Votre profil patient a été créé avec succès ! Redirection vers votre dossier médical...
                </div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Erreurs à corriger :</strong>
                    <ul style="margin-top: 0.5rem; margin-left: 1.5rem;">
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Étapes de progression -->
            <div class="progress-steps">
                <div class="step active">
                    <div class="step-number">1</div>
                    <div class="step-label">Informations<br>personnelles</div>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-label">Santé<br>et antécédents</div>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-label">Confirmation</div>
                </div>
            </div>

            <!-- Formulaire -->
            <form method="POST" action="">
                <!-- Section Informations personnelles -->
                <h3 class="section-title">
                    <i class="fas fa-id-card"></i>
                    Informations Personnelles
                </h3>

                <div class="form-row">
                    <div class="form-group">
                        <label for="date_naissance" class="required">Date de naissance</label>
                        <input type="date" id="date_naissance" name="date_naissance" 
                               value="<?= htmlspecialchars($_POST['date_naissance'] ?? '') ?>" 
                               max="<?= date('Y-m-d') ?>" required>
                        <div class="form-help">Format: JJ/MM/AAAA</div>
                    </div>

                    <div class="form-group">
                        <label for="telephone" class="required">Numéro de téléphone</label>
                        <input type="tel" id="telephone" name="telephone" 
                               value="<?= htmlspecialchars($_POST['telephone'] ?? '') ?>" 
                               placeholder="+33 1 23 45 67 89" required>
                        <div class="form-help">Format international recommandé</div>
                    </div>
                </div>

                <!-- Section Santé -->
                <h3 class="section-title">
                    <i class="fas fa-heartbeat"></i>
                    Informations Médicales
                </h3>

                <div class="form-row">
                    <div class="form-group">
                        <label for="groupe_sanguin">Groupe sanguin</label>
                        <select id="groupe_sanguin" name="groupe_sanguin">
                            <option value="">Sélectionnez...</option>
                            <option value="A+" <?= ($_POST['groupe_sanguin'] ?? '') === 'A+' ? 'selected' : '' ?>>A+</option>
                            <option value="A-" <?= ($_POST['groupe_sanguin'] ?? '') === 'A-' ? 'selected' : '' ?>>A-</option>
                            <option value="B+" <?= ($_POST['groupe_sanguin'] ?? '') === 'B+' ? 'selected' : '' ?>>B+</option>
                            <option value="B-" <?= ($_POST['groupe_sanguin'] ?? '') === 'B-' ? 'selected' : '' ?>>B-</option>
                            <option value="AB+" <?= ($_POST['groupe_sanguin'] ?? '') === 'AB+' ? 'selected' : '' ?>>AB+</option>
                            <option value="AB-" <?= ($_POST['groupe_sanguin'] ?? '') === 'AB-' ? 'selected' : '' ?>>AB-</option>
                            <option value="O+" <?= ($_POST['groupe_sanguin'] ?? '') === 'O+' ? 'selected' : '' ?>>O+</option>
                            <option value="O-" <?= ($_POST['groupe_sanguin'] ?? '') === 'O-' ? 'selected' : '' ?>>O-</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="assurance_maladie">Numéro de sécurité sociale</label>
                        <input type="text" id="assurance_maladie" name="assurance_maladie" 
                               value="<?= htmlspecialchars($_POST['assurance_maladie'] ?? '') ?>" 
                               placeholder="1 85 08 75 115 035 34">
                        <div class="form-help">15 chiffres sans espace</div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="taille">Taille (cm)</label>
                        <input type="number" id="taille" name="taille" 
                               value="<?= htmlspecialchars($_POST['taille'] ?? '') ?>" 
                               min="50" max="250" step="1" placeholder="175">
                    </div>

                    <div class="form-group">
                        <label for="poids">Poids (kg)</label>
                        <input type="number" id="poids" name="poids" 
                               value="<?= htmlspecialchars($_POST['poids'] ?? '') ?>" 
                               min="2" max="300" step="0.1" placeholder="70.5">
                    </div>
                </div>

                <div class="form-group">
                    <label for="allergies">Allergies connues</label>
                    <textarea id="allergies" name="allergies" 
                              placeholder="Listez vos allergies (médicaments, aliments, environnement...)"><?= htmlspecialchars($_POST['allergies'] ?? '') ?></textarea>
                    <div class="form-help">Séparez les différentes allergies par des virgules</div>
                </div>

                <div class="form-group">
                    <label for="antecedents">Antécédents médicaux</label>
                    <textarea id="antecedents" name="antecedents" 
                              placeholder="Maladies chroniques, interventions chirurgicales, antécédents familiaux..."><?= htmlspecialchars($_POST['antecedents'] ?? '') ?></textarea>
                    <div class="form-help">Décrivez brièvement vos antécédents médicaux importants</div>
                </div>

                <!-- Bouton de soumission -->
                <button type="submit" class="btn btn-primary btn-full">
                    <i class="fas fa-save"></i>
                    Créer mon profil patient
                </button>
            </form>

            <!-- Information de confidentialité -->
            <div style="margin-top: 2rem; padding: 1rem; background: var(--light-gray); border-radius: var(--radius); text-align: center;">
                <i class="fas fa-lock" style="color: var(--primary); margin-right: 0.5rem;"></i>
                <span style="color: var(--gray); font-size: 0.9rem;">
                    Vos données sont sécurisées et confidentielles conformément au RGPD
                </span>
            </div>
        </div>
    </div>

    <script>
        // Calcul automatique de l'âge
        document.getElementById('date_naissance').addEventListener('change', function() {
            const birthDate = new Date(this.value);
            const today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();
            const monthDiff = today.getMonth() - birthDate.getMonth();
            
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            
            if (age >= 0) {
                console.log('Âge calculé:', age + ' ans');
            }
        });

        // Formatage du numéro de téléphone
        document.getElementById('telephone').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.startsWith('33')) {
                value = '+' + value;
            } else if (value.startsWith('0')) {
                value = '+33' + value.substring(1);
            }
            
            // Formatage avec espaces
            if (value.length > 3) {
                value = value.replace(/(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/, '$1 $2 $3 $4 $5');
            }
            
            e.target.value = value;
        });

        // Validation en temps réel
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.addEventListener('submit', function(e) {
                const requiredFields = form.querySelectorAll('[required]');
                let valid = true;

                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        valid = false;
                        field.style.borderColor = 'var(--danger)';
                    } else {
                        field.style.borderColor = '';
                    }
                });

                if (!valid) {
                    e.preventDefault();
                    alert('Veuillez remplir tous les champs obligatoires');
                }
            });
        });
    </script>
</body>
</html>