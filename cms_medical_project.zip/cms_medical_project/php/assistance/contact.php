<?php
// contact.php

// Initialisation de la session
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "../config/db.php";

// Déterminer le rôle de l'utilisateur
$user_role = $_SESSION['role'] ?? 'visiteur';
// Récupérer l'ID utilisateur - vérifier différents emplacements possibles
$user_id = $_SESSION['id'] ?? $_SESSION['user_id'] ?? $_SESSION['user']['id'] ?? null;
$user_name = $_SESSION['nom'] ?? $_SESSION['user']['nom'] ?? '';
$user_email = $_SESSION['email'] ?? $_SESSION['user']['email'] ?? '';

// Sujets spécifiques selon les rôles
$role_subjects = [
    'visiteur' => [
        'Question générale',
        'Demande de renseignements',
        'Problème technique',
        'Autre'
    ],
    'patient' => [
        'Prise de rendez-vous',
        'Question médicale',
        'Modification de rendez-vous',
        'Problème avec mon compte',
        'Facturation',
        'Autre'
    ],
    'etudiant' => [
        'Question académique',
        'Stage médical',
        'Documentation',
        'Problème de connexion',
        'Autre'
    ],
    'infirmier' => [
        'Question soins patients',
        'Gestion des médicaments',
        'Problème technique',
        'Formation continue',
        'Rapport d\'activité',
        'Autre'
    ],
    'medecin' => [
        'Consultation patient',
        'Prescription médicale',
        'Urgence médicale',
        'Coordination soins',
        'Formation continue',
        'Autre'
    ],
    'admin' => [
        'Problème système',
        'Gestion utilisateurs',
        'Rapport d\'activité',
        'Suggestion amélioration',
        'Support technique',
        'Autre'
    ],
    'super_admin' => [
        'Audit système',
        'Sécurité plateforme',
        'Gestion administrateurs',
        'Rapport global',
        'Maintenance système',
        'Autre'
    ]
];

// Traitement du formulaire
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifier si c'est une action sur les messages ou un nouveau message
    if (isset($_POST['action']) && $_POST['action'] === 'delete_message' && isset($_POST['message_id'])) {
        // Traitement de la suppression de message
        $message_id = filter_var($_POST['message_id'], FILTER_VALIDATE_INT);
        if ($message_id && $user_id) {
            try {
                $stmt = $pdoMedical->prepare("DELETE FROM contacts WHERE id = ? AND user_id = ?");
                if ($stmt->execute([$message_id, $user_id])) {
                    $success_message = 'Message supprimé avec succès.';
                } else {
                    $error_message = 'Erreur lors de la suppression du message.';
                }
            } catch (PDOException $e) {
                $error_message = 'Erreur lors de la suppression : ' . $e->getMessage();
            }
        }
    } else {
        // Traitement d'un nouveau message
        $name = trim($_POST['name'] ?? '');
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
        $subject = trim($_POST['subject'] ?? '');
        $message_text = trim($_POST['message'] ?? '');
        
        // Utiliser les informations de session si l'utilisateur est connecté
        if ($user_id) {
            $name = $user_name ?: $name;
            $email = $user_email ?: $email;
        }
        
        // Validation
        if (empty($name)) {
            $error_message = 'Le nom est requis';
        } elseif (!$email) {
            $error_message = 'Email invalide';
        } elseif (empty($subject)) {
            $error_message = 'Le sujet est requis';
        } elseif (empty($message_text)) {
            $error_message = 'Le message est requis';
        } else {
            try {
                // Vérifier si la table contacts a les colonnes nécessaires
                $check_columns = $pdoMedical->query("SHOW COLUMNS FROM contacts");
                $columns = $check_columns->fetchAll(PDO::FETCH_COLUMN);
                
                // Préparer les colonnes et valeurs selon la structure de la table
                $insert_columns = ['name', 'email', 'subject', 'message'];
                $insert_values = [':name', ':email', ':subject', ':message'];
                
                // Ajouter les colonnes optionnelles si elles existent
                $params = [
                    ':name' => $name,
                    ':email' => $email,
                    ':subject' => $subject,
                    ':message' => $message_text
                ];
                
                // CORRECTION : Gestion flexible de user_id
                if (in_array('user_id', $columns)) {
                    if ($user_id && filter_var($user_id, FILTER_VALIDATE_INT)) {
                        // user_id est un entier valide
                        $insert_columns[] = 'user_id';
                        $insert_values[] = ':user_id';
                        $params[':user_id'] = (int)$user_id;
                    } else {
                        // user_id n'est pas valide, mettre NULL
                        $insert_columns[] = 'user_id';
                        $insert_values[] = 'NULL';
                    }
                }
                
                if (in_array('user_role', $columns)) {
                    $insert_columns[] = 'user_role';
                    $insert_values[] = ':user_role';
                    $params[':user_role'] = $user_role;
                }
                
                if (in_array('status', $columns)) {
                    $insert_columns[] = 'status';
                    $insert_values[] = ':status';
                    $params[':status'] = 'nouveau';
                }
                
                if (in_array('priority', $columns)) {
                    $insert_columns[] = 'priority';
                    $insert_values[] = ':priority';
                    $params[':priority'] = $_POST['priority'] ?? 'normal';
                }
                
                if (in_array('category', $columns)) {
                    $insert_columns[] = 'category';
                    $insert_values[] = ':category';
                    $params[':category'] = $_POST['category'] ?? 'general';
                }
                
                // Insertion dans la base de données
                $sql = "INSERT INTO contacts (" . implode(', ', $insert_columns) . ") 
                        VALUES (" . implode(', ', $insert_values) . ")";
                
                $stmt = $pdoMedical->prepare($sql);
                $stmt->execute($params);
                
                $success_message = 'Votre message a été envoyé avec succès !';
                
                // Réinitialisation du formulaire
                $_POST = [];
                
            } catch (PDOException $e) {
                $error_message = 'Une erreur est survenue. Veuillez réessayer plus tard. Erreur: ' . $e->getMessage();
            }
        }
    }
}

// Récupération des messages pour l'utilisateur connecté
$user_messages = [];
$all_messages = [];
$general_messages = []; // NOUVEAU : Messages généraux pour le personnel
$messages_error = '';

// CORRECTION : Vérification améliorée de la connexion utilisateur
$is_logged_in = false;
$user_id_int = null;

if ($user_id) {
    $user_id_int = filter_var($user_id, FILTER_VALIDATE_INT);
    if ($user_id_int !== false) {
        $is_logged_in = true;
    } else {
        // Essayer de récupérer l'ID utilisateur depuis la base de données
        try {
            $stmt = $pdoMedical->prepare("SELECT id FROM utilisateurs WHERE email = ? OR matricule = ?");
            $stmt->execute([$user_email, $user_id]);
            $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user_data && isset($user_data['id'])) {
                $user_id_int = $user_data['id'];
                $is_logged_in = true;
                // Mettre à jour la session pour les prochaines requêtes
                $_SESSION['id'] = $user_id_int;
            }
        } catch (PDOException $e) {
            error_log("Erreur récupération ID utilisateur: " . $e->getMessage());
        }
    }
}

if ($is_logged_in && $user_id_int) {
    try {
        // Messages de l'utilisateur
        $stmt = $pdoMedical->prepare("SELECT * FROM contacts WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$user_id_int]);
        $user_messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Messages globaux (selon les permissions)
        if (in_array($user_role, ['admin', 'super_admin', 'medecin'])) {
            $query = "SELECT * FROM contacts WHERE 1=1";
            $params = [];
            
            // Filtres selon le rôle
            if ($user_role === 'medecin') {
                $query .= " AND (user_role IN ('patient', 'medecin', 'infirmier') OR subject LIKE '%médical%' OR subject LIKE '%patient%' OR subject LIKE '%urgence%')";
            } elseif ($user_role === 'admin') {
                $query .= " AND user_role != 'super_admin'";
            }
            
            $query .= " ORDER BY created_at DESC LIMIT 50";
            $stmt = $pdoMedical->prepare($query);
            $stmt->execute($params);
            $all_messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        // NOUVEAU : Messages généraux pour tout le personnel médical
        if (in_array($user_role, ['medecin', 'infirmier', 'admin', 'super_admin'])) {
            $query = "SELECT * FROM contacts WHERE user_role IN ('medecin', 'infirmier', 'admin', 'super_admin') 
                     AND (subject NOT LIKE '%patient%' OR subject LIKE '%coordination%' OR subject LIKE '%formation%')
                     ORDER BY created_at DESC LIMIT 30";
            $stmt = $pdoMedical->prepare($query);
            $stmt->execute();
            $general_messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
    } catch (PDOException $e) {
        $messages_error = 'Erreur lors du chargement des messages: ' . $e->getMessage();
    }
} elseif ($user_id && !$user_id_int) {
    $messages_error = "Utilisateur connecté mais ID non valide. Vous pouvez toujours envoyer des messages.";
}

// Déterminer l'interface selon le rôle
function getRoleInterface($role) {
    switch ($role) {
        case 'super_admin':
            return [
                'title' => 'Centre de Support Super Admin',
                'description' => 'Interface de gestion et support système',
                'color' => 'linear-gradient(135deg, #8B008B, #6A0DAD)',
                'icon' => 'fas fa-crown',
                'show_priority' => true,
                'show_category' => true,
                'categories' => ['system', 'security', 'administration', 'technical'],
                'can_view_all' => true,
                'can_manage' => true,
                'can_view_general' => true // NOUVEAU
            ];
            
        case 'admin':
            return [
                'title' => 'Support Administratif',
                'description' => 'Interface de gestion et support administrateur',
                'color' => 'linear-gradient(135deg, #2563eb, #3b82f6)',
                'icon' => 'fas fa-user-shield',
                'show_priority' => true,
                'show_category' => true,
                'categories' => ['users', 'technical', 'reports', 'suggestions'],
                'can_view_all' => true,
                'can_manage' => true,
                'can_view_general' => true // NOUVEAU
            ];
            
        case 'medecin':
            return [
                'title' => 'Espace Médecin',
                'description' => 'Support médical et coordination des soins',
                'color' => 'linear-gradient(135deg, #10b981, #059669)',
                'icon' => 'fas fa-user-md',
                'show_priority' => true,
                'show_category' => false,
                'categories' => [],
                'can_view_all' => true,
                'can_manage' => false,
                'can_view_general' => true // NOUVEAU
            ];
            
        case 'infirmier':
            return [
                'title' => 'Espace Infirmier',
                'description' => 'Support soins patients et gestion médicale',
                'color' => 'linear-gradient(135deg, #6366f1, #4f46e5)',
                'icon' => 'fas fa-user-nurse',
                'show_priority' => false,
                'show_category' => false,
                'categories' => [],
                'can_view_all' => false,
                'can_manage' => false,
                'can_view_general' => true // NOUVEAU
            ];
            
        case 'etudiant':
            return [
                'title' => 'Espace Étudiant',
                'description' => 'Support académique et questions de stage',
                'color' => 'linear-gradient(135deg, #f59e0b, #d97706)',
                'icon' => 'fas fa-user-graduate',
                'show_priority' => false,
                'show_category' => true,
                'categories' => ['academic', 'internship', 'technical'],
                'can_view_all' => false,
                'can_manage' => false,
                'can_view_general' => false // NOUVEAU
            ];
            
        case 'patient':
            return [
                'title' => 'Espace Patient',
                'description' => 'Service client et support médical',
                'color' => 'linear-gradient(135deg, #ec4899, #db2777)',
                'icon' => 'fas fa-user-injured',
                'show_priority' => false,
                'show_category' => false,
                'categories' => [],
                'can_view_all' => false,
                'can_manage' => false,
                'can_view_general' => false // NOUVEAU
            ];
            
        default:
            return [
                'title' => 'Contactez-nous',
                'description' => 'Nous sommes là pour répondre à vos questions',
                'color' => 'linear-gradient(135deg, #6b7280, #4b5563)',
                'icon' => 'fas fa-envelope',
                'show_priority' => false,
                'show_category' => false,
                'categories' => [],
                'can_view_all' => false,
                'can_manage' => false,
                'can_view_general' => false // NOUVEAU
            ];
    }
}

$interface = getRoleInterface($user_role);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?= $interface['title'] ?> - CMS Médical</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2563eb;
            --primary-light: #3b82f6;
            --secondary: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --light: #f8fafc;
            --dark: #1e293b;
            --gray: #64748b;
            --border-radius: 8px;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background-color: #f5f7fa;
            color: var(--dark);
        }
        
        header {
            background: <?= $interface['color'] ?>;
            color: white;
            padding: 2rem 0;
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .role-badge {
            display: inline-block;
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1rem;
            border-radius: 50px;
            margin-top: 1rem;
            font-size: 0.9rem;
            backdrop-filter: blur(10px);
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .contact-form {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 30px;
            margin-bottom: 3rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        
        input, textarea, select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-family: inherit;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        
        textarea {
            min-height: 150px;
            resize: vertical;
        }
        
        button {
            background-color: var(--primary);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-size: 1rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        button:hover {
            background-color: var(--primary-light);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }
        
        .alert {
            padding: 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-left-color: var(--secondary);
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border-left-color: var(--danger);
        }
        
        .alert-warning {
            background-color: #fff3cd;
            color: #856404;
            border-left-color: var(--warning);
        }
        
        .alert-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border-left-color: var(--primary);
        }
        
        .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        
        .info-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .info-card:hover {
            transform: translateY(-5px);
        }
        
        .info-card i {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 15px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .priority-high { color: var(--danger); font-weight: bold; }
        .priority-medium { color: var(--warning); font-weight: bold; }
        .priority-low { color: var(--secondary); }
        
        .user-status {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: <?= $interface['color'] ?>;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .quick-action {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 15px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        
        .quick-action:hover {
            border-color: var(--primary);
            transform: translateY(-2px);
        }
        
        .quick-action i {
            font-size: 1.5rem;
            color: var(--primary);
            margin-bottom: 10px;
        }
        
        /* Styles pour les messages */
        .messages-section {
            margin-top: 3rem;
        }
        
        .messages-tabs {
            display: flex;
            border-bottom: 2px solid #e5e7eb;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .tab {
            padding: 12px 24px;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
            white-space: nowrap;
        }
        
        .tab.active {
            border-bottom-color: var(--primary);
            color: var(--primary);
            font-weight: 600;
        }
        
        .tab:hover {
            background-color: #f9fafb;
        }
        
        .messages-container {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }
        
        .message-item {
            padding: 20px;
            border-bottom: 1px solid #e5e7eb;
            transition: background-color 0.3s ease;
        }
        
        .message-item:hover {
            background-color: #f9fafb;
        }
        
        .message-item:last-child {
            border-bottom: none;
        }
        
        .message-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }
        
        .message-subject {
            font-weight: 600;
            font-size: 1.1rem;
            color: var(--dark);
        }
        
        .message-meta {
            display: flex;
            gap: 15px;
            font-size: 0.875rem;
            color: var(--gray);
            flex-wrap: wrap;
        }
        
        .message-priority {
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .priority-urgent { background-color: #fee2e2; color: var(--danger); }
        .priority-high { background-color: #fef3c7; color: var(--warning); }
        .priority-normal { background-color: #d1fae5; color: var(--secondary); }
        .priority-low { background-color: #e0e7ff; color: var(--primary); }
        
        .message-content {
            color: var(--dark);
            line-height: 1.5;
        }
        
        .message-actions {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.875rem;
        }
        
        .btn-danger {
            background-color: var(--danger);
        }
        
        .btn-danger:hover {
            background-color: #dc2626;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        
        .general-message-indicator {
            background: linear-gradient(45deg, #8B5CF6, #A78BFA);
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 500;
        }
        
        footer {
            background-color: var(--dark);
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .container {
                padding: 0 15px;
            }
            
            .message-header {
                flex-direction: column;
                gap: 10px;
            }
            
            .messages-tabs {
                flex-direction: column;
            }
            
            .tab {
                text-align: center;
            }
        }
    </style>
</head>
<body>

<header>
    <div class="container">
        <h1><i class="<?= $interface['icon'] ?>"></i> <?= $interface['title'] ?></h1>
        <p><?= $interface['description'] ?></p>
        <div class="role-badge">
            <i class="fas fa-user-tag"></i> 
            <?= ucfirst($user_role) ?> 
            <?= ($user_id || $user_email) ? '(Connecté)' : '(Visiteur)' ?>
        </div>
    </div>
</header>

<div class="container">
    <?php if ($success_message): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success_message) ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error_message) ?>
        </div>
    <?php endif; ?>
    
    <?php if ($messages_error): ?>
        <div class="alert alert-warning">
            <i class="fas fa-info-circle"></i> <?= htmlspecialchars($messages_error) ?>
        </div>
    <?php endif; ?>
    
    <!-- Statut utilisateur -->
    <?php if ($user_id || $user_email): ?>
        <div class="user-status">
            <div class="user-avatar">
                <i class="<?= $interface['icon'] ?>"></i>
            </div>
            <div>
                <h3>Bonjour, <?= htmlspecialchars($user_name) ?> !</h3>
                <p>Vous êtes connecté en tant que <strong><?= ucfirst($user_role) ?></strong></p>
                <?php if (!$user_id_int): ?>
                    <p class="text-warning"><small><i class="fas fa-exclamation-triangle"></i> ID utilisateur non valide, mais vous pouvez envoyer des messages</small></p>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Actions rapides selon le rôle -->
    <?php if ($user_role !== 'visiteur'): ?>
        <div class="quick-actions">
            <?php if (in_array($user_role, ['medecin', 'infirmier'])): ?>
                <div class="quick-action" onclick="document.getElementById('subject').value = 'Urgence médicale'; document.getElementById('priority').value = 'urgent'">
                    <i class="fas fa-ambulance"></i>
                    <h4>Urgence</h4>
                    <small>Signalement urgent</small>
                </div>
            <?php endif; ?>
            
            <?php if ($user_role === 'patient'): ?>
                <div class="quick-action" onclick="document.getElementById('subject').value = 'Prise de rendez-vous'">
                    <i class="fas fa-calendar-plus"></i>
                    <h4>Rendez-vous</h4>
                    <small>Nouvelle demande</small>
                </div>
            <?php endif; ?>
            
            <?php if (in_array($user_role, ['etudiant', 'medecin', 'infirmier'])): ?>
                <div class="quick-action" onclick="document.getElementById('subject').value = 'Question technique'">
                    <i class="fas fa-tools"></i>
                    <h4>Support technique</h4>
                    <small>Problème système</small>
                </div>
            <?php endif; ?>
            
            <?php if (in_array($user_role, ['admin', 'super_admin'])): ?>
                <div class="quick-action" onclick="document.getElementById('subject').value = 'Rapport système'">
                    <i class="fas fa-chart-bar"></i>
                    <h4>Rapport</h4>
                    <small>Demande de statistiques</small>
                </div>
            <?php endif; ?>
            
            <!-- NOUVEAU : Action rapide pour coordination du personnel -->
            <?php if ($interface['can_view_general']): ?>
                <div class="quick-action" onclick="document.getElementById('subject').value = 'Coordination équipe'">
                    <i class="fas fa-users"></i>
                    <h4>Coordination</h4>
                    <small>Message au personnel</small>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <!-- Formulaire de contact -->
    <div class="contact-form">
        <form method="POST" action="contact.php">
            <input type="hidden" name="csrf_token" value="<?= bin2hex(random_bytes(32)) ?>">
            
            <div class="form-row">
                <div class="form-group">
                    <label for="name">Votre nom complet <span class="text-danger">*</span></label>
                    <input type="text" id="name" name="name" required 
                           value="<?= htmlspecialchars($_POST['name'] ?? $user_name) ?>"
                           <?= $user_name ? 'readonly' : '' ?>>
                </div>
                
                <div class="form-group">
                    <label for="email">Adresse email <span class="text-danger">*</span></label>
                    <input type="email" id="email" name="email" required 
                           value="<?= htmlspecialchars($_POST['email'] ?? $user_email) ?>"
                           <?= $user_email ? 'readonly' : '' ?>>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="subject">Sujet <span class="text-danger">*</span></label>
                    <select id="subject" name="subject" required>
                        <option value="">Sélectionnez un sujet</option>
                        <?php foreach ($role_subjects[$user_role] as $subject_option): ?>
                            <option value="<?= $subject_option ?>" 
                                <?= ($_POST['subject'] ?? '') === $subject_option ? 'selected' : '' ?>>
                                <?= $subject_option ?>
                            </option>
                        <?php endforeach; ?>
                        <!-- NOUVEAU : Options supplémentaires pour le personnel -->
                        <?php if ($interface['can_view_general']): ?>
                            <option value="Coordination équipe">Coordination d'équipe</option>
                            <option value="Formation continue">Formation continue</option>
                            <option value="Réunion médicale">Réunion médicale</option>
                            <option value="Partage de protocole">Partage de protocole</option>
                        <?php endif; ?>
                    </select>
                </div>
                
                <?php if ($interface['show_priority']): ?>
                    <div class="form-group">
                        <label for="priority">Priorité</label>
                        <select id="priority" name="priority">
                            <option value="low" class="priority-low">Basse</option>
                            <option value="normal" selected>Normale</option>
                            <option value="high" class="priority-high">Haute</option>
                            <option value="urgent" class="priority-high">Urgente</option>
                        </select>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if ($interface['show_category'] && !empty($interface['categories'])): ?>
                <div class="form-group">
                    <label for="category">Catégorie</label>
                    <select id="category" name="category">
                        <?php 
                        $category_labels = [
                            'system' => 'Système',
                            'security' => 'Sécurité',
                            'administration' => 'Administration',
                            'technical' => 'Technique',
                            'users' => 'Utilisateurs',
                            'reports' => 'Rapports',
                            'suggestions' => 'Suggestions',
                            'academic' => 'Académique',
                            'internship' => 'Stage'
                        ];
                        ?>
                        <?php foreach ($interface['categories'] as $category): ?>
                            <option value="<?= $category ?>">
                                <?= $category_labels[$category] ?? ucfirst($category) ?>
                            </option>
                        <?php endforeach; ?>
                        <!-- NOUVEAU : Catégories pour le personnel médical -->
                        <?php if ($interface['can_view_general']): ?>
                            <option value="coordination">Coordination</option>
                            <option value="formation">Formation</option>
                            <option value="protocol">Protocole</option>
                        <?php endif; ?>
                    </select>
                </div>
            <?php endif; ?>
            
            <div class="form-group">
                <label for="message">Votre message <span class="text-danger">*</span></label>
                <textarea id="message" name="message" required placeholder="Décrivez votre demande en détail..."><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
            </div>
            
            <button type="submit">
                <i class="fas fa-paper-plane"></i> Envoyer le message
            </button>
        </form>
    </div>
    
    <!-- Section des messages (uniquement pour utilisateurs connectés avec ID valide) -->
    <?php if ($is_logged_in && $user_id_int): ?>
        <div class="messages-section">
            <div class="messages-tabs">
                <div class="tab active" onclick="switchTab('my-messages')">
                    <i class="fas fa-envelope me-2"></i>Mes Messages (<?= count($user_messages) ?>)
                </div>
                
                <!-- NOUVEAU : Onglet messages généraux pour le personnel -->
                <?php if ($interface['can_view_general'] && !empty($general_messages)): ?>
                    <div class="tab" onclick="switchTab('general-messages')">
                        <i class="fas fa-users me-2"></i>Messages Personnel (<?= count($general_messages) ?>)
                    </div>
                <?php endif; ?>
                
                <?php if ($interface['can_view_all'] && !empty($all_messages)): ?>
                    <div class="tab" onclick="switchTab('all-messages')">
                        <i class="fas fa-inbox me-2"></i>Messages Globaux (<?= count($all_messages) ?>)
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Mes messages -->
            <div id="my-messages" class="messages-container tab-content active">
                <?php if (empty($user_messages)): ?>
                    <div class="empty-state">
                        <i class="fas fa-envelope-open"></i>
                        <h3>Aucun message</h3>
                        <p>Vous n'avez pas encore envoyé de message.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($user_messages as $message): ?>
                        <div class="message-item">
                            <div class="message-header">
                                <div class="message-subject"><?= htmlspecialchars($message['subject']) ?></div>
                                <div class="message-meta">
                                    <?php if (isset($message['priority'])): ?>
                                        <span class="message-priority priority-<?= $message['priority'] ?? 'normal' ?>">
                                            <?= ucfirst($message['priority'] ?? 'normal') ?>
                                        </span>
                                    <?php endif; ?>
                                    <span><i class="far fa-clock me-1"></i><?= date('d/m/Y H:i', strtotime($message['created_at'])) ?></span>
                                </div>
                            </div>
                            <div class="message-content">
                                <?= nl2br(htmlspecialchars($message['message'])) ?>
                            </div>
                            <div class="message-actions">
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="delete_message">
                                    <input type="hidden" name="message_id" value="<?= $message['id'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Supprimer ce message ?')">
                                        <i class="fas fa-trash"></i> Supprimer
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- NOUVEAU : Messages généraux du personnel -->
            <?php if ($interface['can_view_general'] && !empty($general_messages)): ?>
                <div id="general-messages" class="messages-container tab-content">
                    <?php foreach ($general_messages as $message): ?>
                        <div class="message-item">
                            <div class="message-header">
                                <div class="message-subject">
                                    <?= htmlspecialchars($message['subject']) ?>
                                    <span class="general-message-indicator">Personnel</span>
                                </div>
                                <div class="message-meta">
                                    <?php if (isset($message['priority'])): ?>
                                        <span class="message-priority priority-<?= $message['priority'] ?? 'normal' ?>">
                                            <?= ucfirst($message['priority'] ?? 'normal') ?>
                                        </span>
                                    <?php endif; ?>
                                    <span><i class="fas fa-user me-1"></i><?= htmlspecialchars($message['name']) ?> (<?= $message['user_role'] ?? 'visiteur' ?>)</span>
                                    <span><i class="far fa-clock me-1"></i><?= date('d/m/Y H:i', strtotime($message['created_at'])) ?></span>
                                </div>
                            </div>
                            <div class="message-content">
                                <?= nl2br(htmlspecialchars($message['message'])) ?>
                            </div>
                            <?php if ($interface['can_manage'] || $message['user_id'] == $user_id_int): ?>
                                <div class="message-actions">
                                    <button class="btn btn-sm" onclick="replyToMessage('<?= htmlspecialchars($message['email']) ?>', '<?= htmlspecialchars($message['subject']) ?>')">
                                        <i class="fas fa-reply"></i> Répondre
                                    </button>
                                    <?php if ($message['user_id'] == $user_id_int): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="delete_message">
                                            <input type="hidden" name="message_id" value="<?= $message['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Supprimer ce message ?')">
                                                <i class="fas fa-trash"></i> Supprimer
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <!-- Messages globaux -->
            <?php if ($interface['can_view_all'] && !empty($all_messages)): ?>
                <div id="all-messages" class="messages-container tab-content">
                    <?php foreach ($all_messages as $message): ?>
                        <div class="message-item">
                            <div class="message-header">
                                <div class="message-subject"><?= htmlspecialchars($message['subject']) ?></div>
                                <div class="message-meta">
                                    <?php if (isset($message['priority'])): ?>
                                        <span class="message-priority priority-<?= $message['priority'] ?? 'normal' ?>">
                                            <?= ucfirst($message['priority'] ?? 'normal') ?>
                                        </span>
                                    <?php endif; ?>
                                    <span><i class="fas fa-user me-1"></i><?= htmlspecialchars($message['name']) ?> (<?= $message['user_role'] ?? 'visiteur' ?>)</span>
                                    <span><i class="far fa-clock me-1"></i><?= date('d/m/Y H:i', strtotime($message['created_at'])) ?></span>
                                </div>
                            </div>
                            <div class="message-content">
                                <?= nl2br(htmlspecialchars($message['message'])) ?>
                            </div>
                            <?php if ($interface['can_manage']): ?>
                                <div class="message-actions">
                                    <button class="btn btn-sm" onclick="replyToMessage('<?= htmlspecialchars($message['email']) ?>', '<?= htmlspecialchars($message['subject']) ?>')">
                                        <i class="fas fa-reply"></i> Répondre
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <!-- Informations de contact -->
    <div class="contact-info">
        <div class="info-card">
            <i class="fas fa-map-marker-alt"></i>
            <h3>Adresse</h3>
            <p>Université de Ngaoundéré<br>BP 454, Ngaoundéré, Cameroun</p>
        </div>
        
        <div class="info-card">
            <i class="fas fa-phone"></i>
            <h3>Téléphone</h3>
            <p>+237 6 96 33 02 02<br>Lundi-Vendredi, 8h-17h</p>
        </div>
        
        <div class="info-card">
            <i class="fas fa-envelope"></i>
            <h3>Email</h3>
            <p>support@cmsmedical.com<br>contact@cmsmedical.com</p>
        </div>
        
        <?php if (in_array($user_role, ['medecin', 'infirmier'])): ?>
            <div class="info-card">
                <i class="fas fa-ambulance"></i>
                <h3>Urgences</h3>
                <p>Service disponible<br>24h/24 - 7j/7</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<footer>
    <div class="container">
        <p>&copy; 2025 CMS Médical - Université de Ngaoundéré. Tous droits réservés.</p>
        <p style="opacity: 0.8; margin-top: 10px; font-size: 0.9rem;">
            Interface <?= ucfirst($user_role) ?> | 
            <?= ($user_id || $user_email) ? 'Session active' : 'Mode visiteur' ?>
        </p>
    </div>
</footer>

<script>
// Gestion des onglets
function switchTab(tabName) {
    // Masquer tous les contenus d'onglet
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Désactiver tous les onglets
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Activer l'onglet sélectionné
    document.getElementById(tabName).classList.add('active');
    event.currentTarget.classList.add('active');
}

// Répondre à un message
function replyToMessage(email, subject) {
    document.getElementById('email').value = 'support@cmsmedical.com';
    document.getElementById('subject').value = 'RE: ' + subject;
    document.getElementById('message').value = `En réponse à ${email}:\n\n`;
    document.getElementById('message').focus();
    
    // Scroll vers le formulaire
    document.querySelector('.contact-form').scrollIntoView({ behavior: 'smooth' });
}

// Auto-remplissage des champs pour les utilisateurs connectés
document.addEventListener('DOMContentLoaded', function() {
    // Pré-remplir le sujet si action rapide utilisée
    const quickActions = document.querySelectorAll('.quick-action');
    quickActions.forEach(action => {
        action.addEventListener('click', function() {
            const message = document.getElementById('message');
            message.focus();
            message.value = "Bonjour,\n\n";
        });
    });
    
    // Ajuster la hauteur du textarea automatiquement
    const textarea = document.getElementById('message');
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });
});
</script>

</body>
</html>