<?php
// ---------------------------
// Initialisation session et sécurité
// ---------------------------
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Headers sécurité
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');

// Protection session
if (!isset($_SESSION['created'])) {
    session_regenerate_id(true);
    $_SESSION['created'] = true;
}

require_once "../config/db.php";

// Vérification authentification
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth.php");
    exit;
}

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ---------------------------
// Variables globales
// ---------------------------
$message   = '';
$success   = false;
$infirmiers = [];
$medecins   = [];
$patients   = [];
$patientID  = null;

$userSessionID = $_SESSION['user_id'];
$userRole      = $_SESSION['role'] ?? 'etudiant';

// ---------------------------
// Fonction pour formater l'affichage utilisateur
// ---------------------------
function formatUserDisplay($sessionID, $role) {
    // Extraire l'ID numérique
    $numericID = 0;
    $prefix = '';
    
    foreach (['ETU_', 'MED_', 'INF_', 'ADM_', 'SUP_'] as $p) {
        if (strpos($sessionID, $p) === 0) {
            $numericID = intval(str_replace($p, "", $sessionID));
            $prefix = $p;
            break;
        }
    }
    
    // Déterminer le préfixe d'affichage selon le rôle
    $displayPrefix = '';
    switch($role) {
        case 'etudiant':
            $displayPrefix = 'ETU';
            break;
        case 'medecin':
            $displayPrefix = 'MED';
            break;
        case 'infirmier':
            $displayPrefix = 'INF';
            break;
        case 'admin':
            $displayPrefix = 'ADM';
            break;
        case 'super_admin':
            $displayPrefix = 'SUP';
            break;
        default:
            $displayPrefix = 'USR';
    }
    
    return [
        'display_id' => $displayPrefix . '_' . $numericID,
        'role' => $role,
        'numeric_id' => $numericID
    ];
}

// Formater l'affichage de l'utilisateur connecté
$userDisplay = formatUserDisplay($userSessionID, $userRole);
$userNumericID = $userDisplay['numeric_id'];

// ---------------------------
// Fonction utilitaire : récupérer/créer patient
// ---------------------------
function getPatientID(PDO $pdoMedical, int $userID): int {
    try {
        $stmt = $pdoMedical->prepare("SELECT id FROM patients WHERE utilisateur_id = ? LIMIT 1");
        $stmt->execute([$userID]);
        $patientID = $stmt->fetchColumn();

        if ($patientID) return (int)$patientID;

        // Création dossier patient minimal
        $insertStmt = $pdoMedical->prepare("
            INSERT INTO patients (utilisateur_id, date_naissance, groupe_sanguin, allergies, antecedents) 
            VALUES (?, '2000-01-01', '', '', '')
        ");
        if (!$insertStmt->execute([$userID])) {
            throw new RuntimeException("Échec de la création du dossier patient");
        }
        return (int)$pdoMedical->lastInsertId();

    } catch (PDOException $e) {
        error_log("Erreur patient - UserID:$userID - " . $e->getMessage());
        throw new RuntimeException("Erreur technique lors de l'accès au dossier patient");
    }
}

// ---------------------------
// Fonction pour déterminer created_by
// ---------------------------
function getCreatedBy(PDO $pdoMedical, string $userSessionID, string $userRole, int $patientID = null): int {
    // Extraire l'ID numérique selon le préfixe
    $userNumericID = 0;
    foreach (['ETU_', 'MED_', 'INF_', 'ADM_', 'SUP_'] as $prefix) {
        if (strpos($userSessionID, $prefix) === 0) {
            $userNumericID = intval(str_replace($prefix, "", $userSessionID));
            break;
        }
    }
    
    try {
        // Si c'est un étudiant, utiliser l'ID du patient
        if ($userRole === 'etudiant' && $patientID) {
            return $patientID;
        }
        
        // Si c'est un médecin ou infirmier, vérifier s'ils ont un profil patient
        if (in_array($userRole, ['medecin', 'infirmier'])) {
            $stmt = $pdoMedical->prepare("SELECT id FROM patients WHERE utilisateur_id = ? LIMIT 1");
            $stmt->execute([$userNumericID]);
            $professionnelPatientID = $stmt->fetchColumn();
            
            if ($professionnelPatientID) {
                return (int)$professionnelPatientID;
            }
        }
        
        // Pour admin/super_admin ou si aucun profil patient trouvé, utiliser l'ID utilisateur
        return $userNumericID;
        
    } catch (PDOException $e) {
        error_log("Erreur détermination created_by: " . $e->getMessage());
        return $userNumericID; // Fallback
    }
}

// ---------------------------
// Traitement principal
// ---------------------------
try {
    // Récupération patient si étudiant
    if ($userRole === 'etudiant') {
        $patientID = getPatientID($pdoMedical, $userNumericID);
    }

    // Soumission formulaire
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Vérification CSRF
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new RuntimeException("Session expirée. Veuillez actualiser la page.");
        }

        // Champs obligatoires selon le rôle
        $requiredFields = ['type_rdv', 'date_rdv'];
        
        switch($userRole) {
            case 'etudiant':
                // Étudiants prennent RDV pour eux-mêmes
                break;
                
            case 'medecin':
            case 'infirmier':
                // Professionnels doivent sélectionner un patient
                $requiredFields[] = 'patient_id';
                break;
                
            case 'admin':
            case 'super_admin':
                // Admins doivent sélectionner patient ET professionnel
                $requiredFields[] = 'patient_id';
                $requiredFields[] = 'professionnel_type';
                $requiredFields[] = 'professionnel_id';
                break;
        }

        foreach ($requiredFields as $field) {
            if (empty($_POST[$field])) {
                throw new RuntimeException("Le champ $field est obligatoire");
            }
        }

        // Détermination patient selon le rôle
        $patient_id = 0;
        switch($userRole) {
            case 'etudiant':
                $patient_id = $patientID;
                break;
            case 'medecin':
            case 'infirmier':
            case 'admin':
            case 'super_admin':
                $patient_id = (int)$_POST['patient_id'];
                break;
        }

        // Détermination professionnel selon le rôle
        $professionnel_id = 0;
        $professionnel_type = '';
        
        switch($userRole) {
            case 'etudiant':
            case 'admin':
            case 'super_admin':
                $professionnel_id = (int)$_POST['professionnel_id'];
                $professionnel_type = $_POST['professionnel_type'];
                if (!$professionnel_id) {
                    throw new RuntimeException("Veuillez sélectionner un professionnel de santé valide");
                }
                break;
            case 'medecin':
                $professionnel_id = $userNumericID;
                $professionnel_type = 'medecin';
                break;
            case 'infirmier':
                $professionnel_id = $userNumericID;
                $professionnel_type = 'infirmier';
                break;
        }

        // Nettoyage données
        $type_rdv = htmlspecialchars($_POST['type_rdv']);
        $date_rdv = htmlspecialchars($_POST['date_rdv']);
        $motif    = substr(htmlspecialchars($_POST['motif'] ?? ''), 0, 500);

        // Validation type
        $typesValides = ['consultation','controle','urgence','bilan','soins','vaccination'];
        if (!in_array($type_rdv, $typesValides)) {
            throw new RuntimeException("Type de rendez-vous non valide");
        }

        // Validation date future
        $selectedDate = new DateTime($date_rdv);
        if ($selectedDate < new DateTime()) {
            throw new RuntimeException("Veuillez sélectionner une date future");
        }

        // Déterminer created_by selon le type d'utilisateur
        $created_by = getCreatedBy($pdoMedical, $userSessionID, $userRole, $patientID);

        // Insertion RDV
        if ($professionnel_type === 'medecin') {
            $sql = "INSERT INTO rendez_vous 
                    (patient_id, type_rdv, medecin_id, date_rdv, statut, motif, created_by, created_at)
                    VALUES (?, ?, ?, ?, 'Confirmé', ?, ?, NOW())";
            $params = [$patient_id, $type_rdv, $professionnel_id, $date_rdv, $motif, $created_by];
        } else {
            $sql = "INSERT INTO rendez_vous 
                    (patient_id, type_rdv, infirmier_id, date_rdv, statut, motif, created_by, created_at)
                    VALUES (?, ?, ?, ?, 'en attente', ?, ?, NOW())";
            $params = [$patient_id, $type_rdv, $professionnel_id, $date_rdv, $motif, $created_by];
        }

        $rdvStmt = $pdoMedical->prepare($sql);
        if (!$rdvStmt->execute($params)) {
            throw new RuntimeException("Échec de l'enregistrement du rendez-vous");
        }

        // Succès
        $rdvId   = $pdoMedical->lastInsertId();
        $success = true;
        $message = "✅ Rendez-vous enregistré avec succès (N°$rdvId)";
        $_POST   = []; // reset
    }

} catch (RuntimeException $e) {
    $message = $e->getMessage();
} catch (PDOException $e) {
    error_log("Erreur DB: " . $e->getMessage());
    $message = "Une erreur technique est survenue. Veuillez réessayer plus tard.";
}

// ---------------------------
// Chargement données pour formulaire
// ---------------------------
try {
    // Récupération des infirmiers (uniquement rôle infirmier)
    $infirmiers = $pdoMedical->query("
        SELECT id, CONCAT(prenom, ' ', nom) AS nom_complet, role, specialite
        FROM utilisateurs 
        WHERE role = 'infirmier' AND is_active = 1
        ORDER BY nom, prenom
    ")->fetchAll();

    // Récupération des médecins (uniquement rôle médecin)
    $medecins = $pdoMedical->query("
        SELECT id, CONCAT(prenom, ' ', nom) AS nom_complet, specialite, role
        FROM utilisateurs 
        WHERE role = 'medecin' AND is_active = 1
        ORDER BY nom, prenom
    ")->fetchAll();

    // Récupération des patients (pour les non-étudiants)
    if ($userRole !== 'etudiant') {
        $patients = $pdoMedical->query("
            SELECT p.id,
                CONCAT(u.prenom, ' ', u.nom) AS nom_complet,
                u.email,
                u.role AS type_utilisateur
            FROM patients p
            JOIN utilisateurs u ON p.utilisateur_id = u.id
            WHERE u.is_active = 1 AND u.role = 'etudiant'
            ORDER BY u.nom, u.prenom
        ")->fetchAll();
    }

} catch (PDOException $e) {
    error_log("Erreur chargement données: " . $e->getMessage());
    $message = $message ?: "Erreur lors du chargement des données";
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prise de Rendez-vous | eHealth</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4efe9 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .container {
            max-width: 800px;
            margin-top: 2rem;
            margin-bottom: 2rem;
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            padding: 1.5rem;
        }
        
        .form-label {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(58, 123, 213, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border: none;
            border-radius: 10px;
            padding: 1rem 2rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(58, 123, 213, 0.4);
        }
        
        .required::after {
            content: " *";
            color: var(--danger);
        }
        
        .alert {
            border: none;
            border-radius: 10px;
            border-left: 4px solid;
        }
        
        .confirmation-card {
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            border-left: 4px solid var(--success);
        }
        
        .user-badge {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
        }
        
        .role-indicator {
            position: absolute;
            top: 1rem;
            right: 1rem;
            z-index: 10;
        }
        
        .info-badge {
            background: var(--info);
            color: white;
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }
        
        .role-color-etudiant { background: linear-gradient(135deg, #27ae60, #2ecc71); }
        .role-color-medecin { background: linear-gradient(135deg, #2980b9, #3498db); }
        .role-color-infirmier { background: linear-gradient(135deg, #8e44ad, #9b59b6); }
        .role-color-admin { background: linear-gradient(135deg, #e67e22, #f39c12); }
        .role-color-super_admin { background: linear-gradient(135deg, #c0392b, #e74c3c); }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation et rôle -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <button type="button" class="btn btn-outline-primary" onclick="history.back()">
    <i class="fas fa-arrow-left"></i> Retour
</button>

            </div>
            <div class="role-indicator">
                <span class="user-badge role-color-<?= $userRole ?>">
                    <i class="fas fa-user me-1"></i>
                    <?= strtoupper($userRole) ?> - <?= $userDisplay['display_id'] ?>
                </span>
            </div>
        </div>

        <!-- En-tête personnalisé selon le rôle -->
        <div class="text-center mb-4">
            <h1 class="display-5 fw-bold text-primary">
                <i class="fas fa-calendar-plus me-2"></i>
                <?php 
                switch($userRole) {
                    case 'etudiant':
                        echo 'Prendre un Rendez-vous';
                        break;
                    case 'medecin':
                    case 'infirmier':
                        echo 'Planifier un Rendez-vous';
                        break;
                    case 'admin':
                    case 'super_admin':
                        echo 'Créer un Rendez-vous';
                        break;
                    default:
                        echo 'Prise de Rendez-vous';
                }
                ?>
            </h1>
            <p class="lead text-muted">
                <?php 
                switch($userRole) {
                    case 'etudiant':
                        echo 'Choisissez le type de consultation et le professionnel de santé';
                        break;
                    case 'medecin':
                        echo 'Planifiez un rendez-vous avec un étudiant';
                        break;
                    case 'infirmier':
                        echo 'Organisez une séance de soins avec un étudiant';
                        break;
                    case 'admin':
                    case 'super_admin':
                        echo 'Créez un rendez-vous entre un étudiant et un professionnel';
                        break;
                }
                ?>
            </p>
            
            <!-- Information sur created_by -->
            <div class="mt-3">
                <span class="info-badge">
                    <i class="fas fa-info-circle me-1"></i>
                    Créateur : <?= $userDisplay['display_id'] ?> 
                    (<?= $userRole === 'etudiant' ? 'Patient' : strtoupper($userRole) ?>)
                </span>
            </div>
        </div>

        <!-- Messages -->
        <?php if ($message): ?>
            <div class="alert alert-<?= $success ? 'success' : 'danger' ?> mb-4">
                <i class="fas <?= $success ? 'fa-check-circle' : 'fa-exclamation-circle' ?> me-2"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <!-- Carte de confirmation -->
            <div class="card confirmation-card">
                <div class="card-body text-center py-5">
                    <i class="fas fa-check-circle text-success mb-3" style="font-size: 4rem;"></i>
                    <h3 class="text-success mb-3">Rendez-vous Confirmé !</h3>
                    <p class="lead">Le rendez-vous a été enregistré avec succès.</p>
                    <p class="text-muted">
                        <small>
                            <i class="fas fa-user-edit me-1"></i>
                            Créé par : <?= $userDisplay['display_id'] ?> 
                            (<?= $userRole === 'etudiant' ? 'Patient' : strtoupper($userRole) ?>)
                        </small>
                    </p>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-center mt-4">
                        <a href="prendre_rdv.php" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i>Nouveau rendez-vous
                        </a>
                        <a href="liste_rdv.php" class="btn btn-outline-primary">
                            <i class="fas fa-list me-2"></i>Voir mes rendez-vous
                        </a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Formulaire de prise de rendez-vous -->
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">
                        <i class="fas fa-calendar-plus me-2"></i>
                        Nouveau Rendez-vous
                        <small class="float-end opacity-75">
                            Créateur : <?= $userDisplay['display_id'] ?>
                        </small>
                    </h4>
                </div>
                <div class="card-body p-4">
                    <form method="POST" id="rdvForm">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                        <!-- Sélection du patient (pour les non-étudiants) -->
                        <?php if ($userRole !== 'etudiant'): ?>
                            <div class="mb-4">
                                <label for="patient_id" class="form-label required">
                                    <i class="fas fa-user-injured me-2"></i>
                                    <?= $userRole === 'admin' || $userRole === 'super_admin' ? 'Sélectionner un étudiant' : 'Étudiant' ?>
                                </label>
                                <select class="form-select" id="patient_id" name="patient_id" required>
                                    <option value="">-- Choisissez un étudiant --</option>
                                    <?php foreach ($patients as $patient): ?>
                                        <option value="<?= $patient['id'] ?>" 
                                            <?= isset($_POST['patient_id']) && $_POST['patient_id'] == $patient['id'] ? 'selected' : '' ?>>
                                            <?php echo htmlspecialchars(is_string($patient['nom_complet']) ? $patient['nom_complet'] : ''); ?>
                                            - <?= htmlspecialchars($patient['email']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if (empty($patients)): ?>
                                    <div class="alert alert-warning mt-2">
                                        <i class="fas fa-exclamation-triangle me-2"></i>
                                        Aucun étudiant trouvé dans la base de données.
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <!-- Affichage info étudiant connecté -->
                            <div class="alert alert-info mb-4">
                                <i class="fas fa-user-graduate me-2"></i>
                                <strong>Rendez-vous pour :</strong> 
                                Vous (<?= $userDisplay['display_id'] ?>)
                                <br>
                                <small>Vous serez enregistré comme créateur de ce rendez-vous</small>
                            </div>
                        <?php endif; ?>

                        <!-- Type de rendez-vous -->
                        <div class="mb-4">
                            <label for="type_rdv" class="form-label required">
                                <i class="fas fa-stethoscope me-2"></i>Type de rendez-vous
                            </label>
                            <select class="form-select" id="type_rdv" name="type_rdv" required>
                                <option value="">-- Sélectionnez le type --</option>
                                <?php 
                                $types = [
                                    'consultation' => '👨‍⚕️ Consultation médicale',
                                    'controle'     => '📋 Contrôle de santé',
                                    'urgence'      => '🚨 Urgence',
                                    'bilan'        => '📊 Bilan de santé',
                                    'soins'        => '💉 Soins infirmiers',
                                    'vaccination'  => '💊 Vaccination'
                                ];
                                foreach ($types as $val => $label): ?>
                                    <option value="<?= $val ?>" 
                                        <?= isset($_POST['type_rdv']) && $_POST['type_rdv'] === $val ? 'selected' : '' ?>>
                                        <?= $label ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Sélection du professionnel (pour étudiants et admins) -->
                        <?php if (in_array($userRole, ['etudiant', 'admin', 'super_admin'])): ?>
                            <div class="mb-4">
                                <label for="professionnel_type" class="form-label required">
                                    <i class="fas fa-user-md me-2"></i>Type de professionnel
                                </label>
                                <select class="form-select" id="professionnel_type" name="professionnel_type" required>
                                    <option value="">-- Choisissez le type --</option>
                                    <option value="medecin" <?= isset($_POST['professionnel_type']) && $_POST['professionnel_type'] === 'medecin' ? 'selected' : '' ?>>👨‍⚕️ Médecin</option>
                                    <option value="infirmier" <?= isset($_POST['professionnel_type']) && $_POST['professionnel_type'] === 'infirmier' ? 'selected' : '' ?>>💉 Infirmier</option>
                                </select>
                            </div>

                            <div class="mb-4">
                                <label for="professionnel_id" class="form-label required">
                                    <i class="fas fa-user-md me-2"></i>Choisir un professionnel
                                </label>
                                <select class="form-select" id="professionnel_id" name="professionnel_id" required>
                                    <option value="">-- Sélectionnez un professionnel --</option>
                                    <!-- Médecins -->
                                    <optgroup label="👨‍⚕️ Médecins">
                                        <?php foreach ($medecins as $medecin): ?>
                                            <option value="<?= $medecin['id'] ?>" data-type="medecin"
                                                <?= isset($_POST['professionnel_id']) && $_POST['professionnel_id'] == $medecin['id'] ? 'selected' : '' ?>>
                                                Dr. <?php echo htmlspecialchars(is_string($medecin['nom_complet']) ? $medecin['nom_complet'] : ''); ?>

                                                - <?= htmlspecialchars($medecin['specialite'] ?? 'Médecin généraliste') ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                    <!-- Infirmiers -->
                                    <optgroup label="💉 Infirmiers">
                                        <?php foreach ($infirmiers as $infirmier): ?>
                                            <option value="<?= $infirmier['id'] ?>" data-type="infirmier"
                                                <?= isset($_POST['professionnel_id']) && $_POST['professionnel_id'] == $infirmier['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($infirmier['nom_complet'] ?? '') ?> (Infirmier)
                                            </option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                </select>
                            </div>
                        <?php else: ?>
                            <!-- Pour les médecins/infirmiers connectés -->
                            <input type="hidden" name="professionnel_type" value="<?= $userRole ?>">
                            <input type="hidden" name="professionnel_id" value="<?= $userNumericID ?>">
                            <div class="alert alert-info mb-4">
                                <i class="fas fa-user-md me-2"></i>
                                <strong>Professionnel :</strong> 
                                Vous (<?= $userRole === 'medecin' ? '👨‍⚕️ Médecin' : '💉 Infirmier' ?>)
                                <br>
                                <small>Le rendez-vous sera associé à votre compte professionnel</small>
                            </div>
                        <?php endif; ?>

                        <!-- Date et heure -->
                        <div class="mb-4">
                            <label for="date_rdv" class="form-label required">
                                <i class="fas fa-calendar-alt me-2"></i>Date et heure du rendez-vous
                            </label>
                            <input type="datetime-local" class="form-control" id="date_rdv" name="date_rdv" 
                                required min="<?= date('Y-m-d\TH:i') ?>"
                                value="<?= isset($_POST['date_rdv']) ? htmlspecialchars($_POST['date_rdv']) : '' ?>">
                            <small class="form-text text-muted">Sélectionnez une date et heure futures</small>
                        </div>

                        <!-- Motif -->
                        <div class="mb-4">
                            <label for="motif" class="form-label">
                                <i class="fas fa-comment-medical me-2"></i>Motif de la consultation
                            </label>
                            <textarea class="form-control" id="motif" name="motif" rows="3" 
                                    placeholder="Décrivez brièvement le motif de la consultation (symptômes, demande particulière...)"
                                    maxlength="500"><?= isset($_POST['motif']) ? htmlspecialchars($_POST['motif']) : '' ?></textarea>
                            <small class="form-text text-muted">500 caractères maximum - Optionnel mais recommandé</small>
                        </div>

                        <!-- Bouton de soumission -->
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="fas fa-calendar-check me-2"></i>
                                <?php 
                                switch($userRole) {
                                    case 'etudiant':
                                        echo 'Confirmer mon rendez-vous';
                                        break;
                                    case 'medecin':
                                    case 'infirmier':
                                        echo 'Planifier le rendez-vous';
                                        break;
                                    case 'admin':
                                    case 'super_admin':
                                        echo 'Créer le rendez-vous';
                                        break;
                                    default:
                                        echo 'Enregistrer le rendez-vous';
                                }
                                ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Validation du formulaire
        document.getElementById('rdvForm').addEventListener('submit', function(e) {
            let isValid = true;
            
            // Validation date
            const dateInput = document.getElementById('date_rdv');
            const selectedDate = new Date(dateInput.value);
            const now = new Date();
            
            if (selectedDate < now) {
                alert("❌ Veuillez sélectionner une date et heure futures");
                dateInput.focus();
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
            }
        });

        // Affichage dynamique des professionnels selon le type
        <?php if (in_array($userRole, ['etudiant', 'admin', 'super_admin'])): ?>
        document.getElementById('professionnel_type').addEventListener('change', function() {
            const type = this.value;
            const professionnelSelect = document.getElementById('professionnel_id');
            const options = professionnelSelect.querySelectorAll('option');
            
            // Réinitialiser la sélection
            professionnelSelect.value = '';
            
            // Afficher/masquer les options selon le type
            options.forEach(option => {
                if (option.value === '') {
                    option.style.display = 'block'; // Toujours afficher l'option vide
                } else {
                    const optionType = option.getAttribute('data-type');
                    if (type === optionType) {
                        option.style.display = 'block';
                    } else {
                        option.style.display = 'none';
                    }
                }
            });
        });

        // Déclencher le changement au chargement si une valeur existe
        document.addEventListener('DOMContentLoaded', function() {
            const professionnelType = document.getElementById('professionnel_type');
            if (professionnelType.value) {
                professionnelType.dispatchEvent(new Event('change'));
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>