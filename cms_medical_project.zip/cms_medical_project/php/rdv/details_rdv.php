<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'etudiant') {
    header("Location: ../config/auth.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID de rendez-vous invalide.");
}

$rdvID = intval($_GET['id']);
$userID = $_SESSION['user_id'];

// Extraction de l'ID utilisateur selon le format
if (strpos($userID, 'MED_') === 0) {
    $userID = intval(str_replace("MED_", "", $userID));
} elseif (strpos($userID, 'ETU_') === 0) {
    $userID = intval(str_replace("ETU_", "", $userID));
} else {
    $userID = intval($userID);
}

try {
    $stmt = $pdoMedical->prepare("
        SELECT 
            r.*,
            COALESCE(m.prenom, i.prenom) AS professionnel_prenom,
            COALESCE(m.nom, i.nom) AS professionnel_nom,
            COALESCE(m.email, i.email) AS professionnel_email,
            COALESCE(m.telephone, i.telephone) AS professionnel_telephone,
            COALESCE(m.specialite, i.specialite) AS professionnel_specialite,
            CASE 
                WHEN r.medecin_id IS NOT NULL THEN 'Médecin'
                WHEN r.infirmier_id IS NOT NULL THEN 'Infirmier'
                ELSE 'Non attribué'
            END AS professionnel_type,
            c.diagnostic,
            c.prescription,
            c.examens,
            c.notes AS notes_consultation
        FROM rendez_vous r
        LEFT JOIN utilisateurs m ON r.medecin_id = m.id AND m.role = 'medecin'
        LEFT JOIN utilisateurs i ON r.infirmier_id = i.id AND i.role = 'infirmier'
        LEFT JOIN consultations c ON r.id = c.rendez_vous_id
        WHERE r.id = ? AND r.patient_id = ?
    ");
    
    $stmt->execute([$rdvID, $userID]);
    $rdv = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$rdv) {
        die("Rendez-vous introuvable ou accès non autorisé.");
    }
} catch (PDOException $e) {
    die("Erreur lors du chargement des détails: " . $e->getMessage());
}

// Traitement de l'annulation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'annuler_rdv') {
    try {
        $updateStmt = $pdoMedical->prepare("UPDATE rendez_vous SET statut = 'Annulé' WHERE id = ? AND patient_id = ?");
        $updateStmt->execute([$rdvID, $userID]);
        
        if ($updateStmt->rowCount() > 0) {
            $success_message = "Rendez-vous annulé avec succès";
            // Recharger les données
            $stmt->execute([$rdvID, $userID]);
            $rdv = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $error_message = "Erreur lors de l'annulation du rendez-vous";
        }
    } catch (PDOException $e) {
        $error_message = "Erreur technique: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails du Rendez-vous | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #3498db;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        .btn-retour {
            position: fixed;
            top: 20px;
            left: 20px;
            background: var(--white);
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            box-shadow: var(--shadow);
            cursor: pointer;
            font-size: 1.2rem;
            color: var(--primary);
            z-index: 1000;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        .btn-retour:hover {
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .header {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
            text-align: center;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .page-title {
            color: var(--primary);
            font-size: 2.2rem;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
        }

        .page-subtitle {
            color: var(--gray);
            font-size: 1.1rem;
        }

        .content-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        @media (max-width: 768px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        .card {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--light-gray);
        }

        .card-title {
            color: var(--primary);
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.5rem;
        }

        .info-item {
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            padding: 1rem;
            background: var(--light-gray);
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .info-item:hover {
            transform: translateX(5px);
            background: var(--white);
            box-shadow: var(--shadow);
        }

        .info-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-size: 1.2rem;
            flex-shrink: 0;
        }

        .info-content {
            flex: 1;
        }

        .info-label {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 0.3rem;
            display: block;
        }

        .info-value {
            color: var(--gray);
        }

        .badge {
            display: inline-block;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .badge-success {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
            border: 1px solid var(--success);
        }

        .badge-warning {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
            border: 1px solid var(--warning);
        }

        .badge-danger {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger);
            border: 1px solid var(--danger);
        }

        .badge-info {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
            border: 1px solid var(--info);
        }

        .badge-secondary {
            background: rgba(149, 165, 166, 0.1);
            color: var(--gray);
            border: 1px solid var(--gray);
        }

        .consultation-section {
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 2px solid var(--light-gray);
        }

        .consultation-title {
            color: var(--primary);
            font-size: 1.3rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .consultation-content {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            white-space: pre-line;
            line-height: 1.6;
        }

        .empty-state {
            text-align: center;
            padding: 2rem;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            background-color: var(--primary);
            color: var(--white);
        }

        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.2);
        }

        .btn-secondary {
            background: var(--gray);
        }

        .btn-secondary:hover {
            background: #7f8c8d;
        }

        .btn-warning {
            background: var(--warning);
        }

        .btn-warning:hover {
            background: #e67e22;
        }

        .btn-danger {
            background: var(--danger);
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-success {
            background: var(--success);
        }

        .btn-success:hover {
            background: #229954;
        }

        .alert {
            padding: 1rem;
            border-radius: var(--radius);
            margin-bottom: 1.5rem;
            text-align: center;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            border: 1px solid var(--success);
            color: var(--success);
        }

        .alert-danger {
            background: rgba(231, 76, 60, 0.1);
            border: 1px solid var(--danger);
            color: var(--danger);
        }

        .contact-info {
            display: flex;
            gap: 1rem;
            margin-top: 0.5rem;
            flex-wrap: wrap;
        }

        .contact-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            color: var(--gray);
        }

        @media (max-width: 480px) {
            .container {
                padding: 1rem 0.5rem;
            }
            
            .page-title {
                font-size: 1.8rem;
            }
            
            .card {
                padding: 1.5rem;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .info-item {
                flex-direction: column;
                text-align: center;
            }
            
            .contact-info {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <a href="javascript:history.back()" class="btn-retour" title="Retour">
        <i class="fas fa-arrow-left"></i>
    </a>

    <div class="container">
        <!-- En-tête -->
        <div class="header">
            <h1 class="page-title">
                <i class="fas fa-calendar-check"></i>
                Détails du Rendez-vous
            </h1>
            <p class="page-subtitle">Consultation #<?= $rdvID ?> - Informations complètes</p>
        </div>

        <!-- Messages d'alerte -->
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $success_message ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= $error_message ?>
            </div>
        <?php endif; ?>

        <div class="content-grid">
            <!-- Informations principales -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-info-circle"></i>
                        Informations du Rendez-vous
                    </h2>
                    <span class="badge badge-<?= 
                        $rdv['statut'] === 'Confirmé' ? 'success' : 
                        ($rdv['statut'] === 'En attente' ? 'warning' : 
                        ($rdv['statut'] === 'Annulé' ? 'danger' : 'info')) 
                    ?>">
                        <?= htmlspecialchars($rdv['statut']) ?>
                    </span>
                </div>

                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-calendar-day"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Date et heure</span>
                            <span class="info-value">
                                <?= date('d/m/Y à H:i', strtotime($rdv['date_rdv'])) ?>
                            </span>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-stethoscope"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Type de consultation</span>
                            <span class="info-value">
                                <?= htmlspecialchars(ucfirst($rdv['type_rdv'])) ?>
                            </span>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-user-md"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Professionnel de santé</span>
                            <span class="info-value">
                                <?= htmlspecialchars($rdv['professionnel_prenom'] . ' ' . $rdv['professionnel_nom']) ?>
                                <br>
                                <small class="badge badge-secondary">
                                    <?= htmlspecialchars($rdv['professionnel_type']) ?>
                                    <?php if ($rdv['professionnel_specialite']): ?>
                                        - <?= htmlspecialchars($rdv['professionnel_specialite']) ?>
                                    <?php endif; ?>
                                </small>
                            </span>
                            <?php if ($rdv['professionnel_email'] || $rdv['professionnel_telephone']): ?>
                            <div class="contact-info">
                                <?php if ($rdv['professionnel_email']): ?>
                                    <div class="contact-item">
                                        <i class="fas fa-envelope"></i>
                                        <?= htmlspecialchars($rdv['professionnel_email']) ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ($rdv['professionnel_telephone']): ?>
                                    <div class="contact-item">
                                        <i class="fas fa-phone"></i>
                                        <?= htmlspecialchars($rdv['professionnel_telephone']) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if (!empty($rdv['motif'])): ?>
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-comment-medical"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Motif de la consultation</span>
                            <span class="info-value"><?= nl2br(htmlspecialchars($rdv['motif'])) ?></span>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($rdv['duree'])): ?>
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Durée prévue</span>
                            <span class="info-value"><?= htmlspecialchars($rdv['duree']) ?> minutes</span>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Informations complémentaires -->
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        <i class="fas fa-clipboard-list"></i>
                        Détails Complémentaires
                    </h2>
                </div>

                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Lieu</span>
                            <span class="info-value">
                                <?= !empty($rdv['lieu']) ? htmlspecialchars($rdv['lieu']) : 'Cabinet médical principal' ?>
                            </span>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-exclamation-circle"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Instructions spéciales</span>
                            <span class="info-value">
                                <?= !empty($rdv['notes']) ? nl2br(htmlspecialchars($rdv['notes'])) : 'Aucune instruction particulière' ?>
                            </span>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-history"></i>
                        </div>
                        <div class="info-content">
                            <span class="info-label">Date de création</span>
                            <span class="info-value">
                                <?= !empty($rdv['created_at']) ? date('d/m/Y à H:i', strtotime($rdv['created_at'])) : 'Non spécifiée' ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Section consultation (si disponible) -->
                <?php if (!empty($rdv['diagnostic']) || !empty($rdv['prescription']) || !empty($rdv['examens'])): ?>
                <div class="consultation-section">
                    <h3 class="consultation-title">
                        <i class="fas fa-file-medical-alt"></i>
                        Compte-rendu de Consultation
                    </h3>

                    <?php if (!empty($rdv['diagnostic'])): ?>
                    <div class="consultation-content">
                        <strong><i class="fas fa-diagnoses"></i> Diagnostic:</strong><br>
                        <?= nl2br(htmlspecialchars($rdv['diagnostic'])) ?>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($rdv['prescription'])): ?>
                    <div class="consultation-content">
                        <strong><i class="fas fa-prescription"></i> Prescription:</strong><br>
                        <?= nl2br(htmlspecialchars($rdv['prescription'])) ?>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($rdv['examens'])): ?>
                    <div class="consultation-content">
                        <strong><i class="fas fa-microscope"></i> Examens:</strong><br>
                        <?= nl2br(htmlspecialchars($rdv['examens'])) ?>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($rdv['notes_consultation'])): ?>
                    <div class="consultation-content">
                        <strong><i class="fas fa-notes-medical"></i> Notes:</strong><br>
                        <?= nl2br(htmlspecialchars($rdv['notes_consultation'])) ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Boutons d'action -->
        <div class="action-buttons">
            <a href="liste_rdv.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Retour aux rendez-vous
            </a>

            <?php if ($rdv['statut'] === 'En attente'): ?>
                <a href="modifier_rdv.php?id=<?= $rdvID ?>" class="btn btn-warning">
                    <i class="fas fa-edit"></i> Modifier
                </a>
                
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="annuler_rdv">
                    <button type="submit" class="btn btn-danger" 
                            onclick="return confirm('Êtes-vous sûr de vouloir annuler ce rendez-vous ? Cette action est irréversible.')">
                        <i class="fas fa-times"></i> Annuler
                    </button>
                </form>
            <?php elseif ($rdv['statut'] === 'Confirmé'): ?>
                <button class="btn btn-success" onclick="alert('Fonction de rappel à implémenter')">
                    <i class="fas fa-bell"></i> Rappel
                </button>
            <?php endif; ?>

            <?php if (!empty($rdv['diagnostic'])): ?>
                <a href="../dossiers/dossier_medical.php" class="btn btn-info">
                    <i class="fas fa-folder-open"></i> Voir mon dossier
                </a>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Animation au chargement
        document.addEventListener('DOMContentLoaded', function() {
            const infoItems = document.querySelectorAll('.info-item');
            infoItems.forEach((item, index) => {
                item.style.animationDelay = (index * 0.1) + 's';
            });
        });

        // Confirmation améliorée pour l'annulation
        document.addEventListener('DOMContentLoaded', function() {
            const annulerBtn = document.querySelector('button[type="submit"]');
            if (annulerBtn) {
                annulerBtn.addEventListener('click', function(e) {
                    if (!confirm('Êtes-vous sûr de vouloir annuler ce rendez-vous ?\n\nCette action est irréversible et pourrait entraîner des frais d\'annulation.')) {
                        e.preventDefault();
                    }
                });
            }
        });
    </script>
</body>
</html>