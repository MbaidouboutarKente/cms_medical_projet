<?php
session_start();
require_once "../config/db.php";

// Vérification de l'authentification
if (!isset($_SESSION['user_id'])) {
    header("Location: ../config/auth.php");
    exit;
}

$userSessionID = $_SESSION['user_id'];
$userRole = $_SESSION['role'];
$userNumericID = (int)preg_replace('/^[A-Z]+_/', '', $userSessionID);

// Déterminer l'ID patient selon le rôle
$patientID = null;
if ($userRole === 'etudiant') {
    // Pour les étudiants, trouver leur ID patient
    $stmtPatient = $pdoMedical->prepare("SELECT id FROM patients WHERE utilisateur_id = ? LIMIT 1");
    $stmtPatient->execute([$userNumericID]);
    $patientData = $stmtPatient->fetch(PDO::FETCH_ASSOC);
    $patientID = $patientData ? $patientData['id'] : null;
} elseif (in_array($userRole, ['medecin', 'infirmier'])) {
    // Pour les professionnels, ils peuvent voir les RDV où ils sont impliqués
    $patientID = null; // Pas de filtre patient spécifique
} else {
    // Admins voient tout
    $patientID = null;
}

// Récupération des rendez-vous avec distinction créateur
$sqlBase = "
    SELECT r.*, 
           COALESCE(m.prenom, i.prenom) AS professionnel_prenom,
           COALESCE(m.nom, i.nom) AS professionnel_nom,
           COALESCE(m.email, i.email) AS professionnel_email,
           COALESCE(m.specialite, i.specialite) AS professionnel_specialite,
           CASE 
               WHEN r.medecin_id IS NOT NULL THEN 'Médecin' 
               WHEN r.infirmier_id IS NOT NULL THEN 'Infirmier' 
               ELSE 'Autre' 
           END AS professionnel_type,
           u_created.prenom AS created_prenom,
           u_created.nom AS created_nom,
           u_created.role AS created_role,
           CASE 
               WHEN r.created_by = ? THEN 'moi' 
               ELSE 'autre' 
           END AS createur_type,
           p.utilisateur_id AS patient_user_id,
           u_patient.prenom AS patient_prenom,
           u_patient.nom AS patient_nom
    FROM rendez_vous r
    LEFT JOIN utilisateurs m ON r.medecin_id = m.id
    LEFT JOIN utilisateurs i ON r.infirmier_id = i.id
    LEFT JOIN utilisateurs u_created ON r.created_by = u_created.id
    LEFT JOIN patients p ON r.patient_id = p.id
    LEFT JOIN utilisateurs u_patient ON p.utilisateur_id = u_patient.id
    WHERE 1=1
";

// Filtres selon le rôle
$params = [$userNumericID];
if ($userRole === 'etudiant' && $patientID) {
    $sqlBase .= " AND r.patient_id = ?";
    $params[] = $patientID;
} elseif (in_array($userRole, ['medecin', 'infirmier'])) {
    $sqlBase .= " AND (r.medecin_id = ? OR r.infirmier_id = ?)";
    $params[] = $userNumericID;
    $params[] = $userNumericID;
}
// Admins voient tout (pas de filtre supplémentaire)

// Récupération par statut
$rdvsParStatut = [];

// RDV en attente
$sqlEnAttente = $sqlBase . " AND r.statut = 'En attente' ORDER BY r.date_rdv ASC";
$stmt = $pdoMedical->prepare($sqlEnAttente);
$stmt->execute($params);
$rdvsParStatut['en_attente'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

// RDV confirmés
$sqlConfirmes = $sqlBase . " AND (r.statut = 'Confirmé' OR r.statut = 'Accepté') ORDER BY r.date_rdv ASC";
$stmt = $pdoMedical->prepare($sqlConfirmes);
$stmt->execute($params);
$rdvsParStatut['confirmes'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

// RDV à venir (pour tableau de bord)
$sqlProchains = $sqlBase . " AND r.statut IN ('Confirmé', 'Accepté') AND r.date_rdv >= NOW() ORDER BY r.date_rdv ASC LIMIT 5";
$stmt = $pdoMedical->prepare($sqlProchains);
$stmt->execute($params);
$rdvsProchains = $stmt->fetchAll(PDO::FETCH_ASSOC);

// RDV historiques
$sqlHistorique = $sqlBase . " AND r.statut IN ('Terminé', 'Réalisé', 'Annulé') ORDER BY r.date_rdv DESC LIMIT 20";
$stmt = $pdoMedical->prepare($sqlHistorique);
$stmt->execute($params);
$rdvsParStatut['historique'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Statistiques avec distinction créateur
$stats = [
    'total' => 0,
    'en_attente' => 0,
    'confirmes' => 0,
    'historique' => 0,
    'crees_par_moi' => 0,
    'crees_par_autres' => 0
];

foreach ($rdvsParStatut as $type => $rdvs) {
    $stats[$type] = count($rdvs);
    $stats['total'] += count($rdvs);
    
    foreach ($rdvs as $rdv) {
        if ($rdv['createur_type'] === 'moi') {
            $stats['crees_par_moi']++;
        } else {
            $stats['crees_par_autres']++;
        }
    }
}

// Traitement des actions
$message_success = $message_erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rdvId = intval($_POST['rdv_id'] ?? 0);
    
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'annuler_rdv':
                try {
                    $stmt = $pdoMedical->prepare("UPDATE rendez_vous SET statut = 'Annulé' WHERE id = ?");
                    $stmt->execute([$rdvId]);
                    $message_success = "Rendez-vous annulé avec succès";
                } catch (PDOException $e) {
                    $message_erreur = "Erreur lors de l'annulation";
                }
                break;
                
            case 'confirmer_rdv':
                try {
                    $stmt = $pdoMedical->prepare("UPDATE rendez_vous SET statut = 'Confirmé' WHERE id = ?");
                    $stmt->execute([$rdvId]);
                    $message_success = "Rendez-vous confirmé avec succès";
                } catch (PDOException $e) {
                    $message_erreur = "Erreur lors de la confirmation";
                }
                break;
        }
        
        // Recharger la page
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📅 Mes Rendez-vous | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #3498db;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--dark);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        .btn-retour {
            position: fixed;
            top: 20px;
            left: 20px;
            background: var(--white);
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            box-shadow: var(--shadow);
            cursor: pointer;
            font-size: 1.2rem;
            color: var(--primary);
            z-index: 1000;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-retour:hover {
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .header {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .header h1 {
            color: var(--primary);
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .role-badge {
            background: var(--primary);
            color: white;
            padding: 0.3rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin: 2rem 0;
        }

        .stat-card {
            background: var(--white);
            padding: 1.5rem;
            border-radius: var(--radius);
            text-align: center;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary);
            transition: transform 0.3s ease;
            position: relative;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card.moi {
            border-left-color: var(--success);
        }

        .stat-card.autres {
            border-left-color: var(--info);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary);
            display: block;
        }

        .stat-card.moi .stat-number {
            color: var(--success);
        }

        .stat-card.autres .stat-number {
            color: var(--info);
        }

        .stat-label {
            color: var(--gray);
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .quick-actions {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }

        .btn {
            padding: 1rem 1.5rem;
            border: none;
            border-radius: var(--radius);
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: var(--primary);
            color: var(--white);
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        .btn-success {
            background: var(--success);
            color: var(--white);
        }

        .btn-warning {
            background: var(--warning);
            color: var(--white);
        }

        .btn-active {
            background: var(--secondary);
            color: var(--white);
            box-shadow: 0 4px 12px rgba(0, 210, 255, 0.3);
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        @media (max-width: 1024px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        .section {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            animation: fadeIn 0.5s ease;
        }

        .hidden {
            display: none;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .section-title {
            color: var(--primary);
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--light-gray);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .rdv-card {
            background: var(--light-gray);
            border-radius: var(--radius);
            padding: 1.5rem;
            margin-bottom: 1rem;
            border-left: 4px solid;
            transition: all 0.3s ease;
            position: relative;
        }

        .rdv-card:hover {
            transform: translateX(5px);
            box-shadow: var(--shadow);
        }

        .rdv-card.attente {
            border-left-color: var(--warning);
        }

        .rdv-card.confirmé {
            border-left-color: var(--success);
        }

        .rdv-card.historique {
            border-left-color: var(--info);
        }

        .rdv-card.annulé {
            border-left-color: var(--danger);
            opacity: 0.7;
        }

        .rdv-card.moi {
            border-right: 4px solid var(--success);
        }

        .rdv-card.autre {
            border-right: 4px solid var(--info);
        }

        .createur-badge {
            position: absolute;
            top: 1rem;
            right: 1rem;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .createur-badge.moi {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }

        .createur-badge.autre {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }

        .status {
            position: absolute;
            top: 3rem;
            right: 1rem;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status.attente {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }

        .status.confirmé {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }

        .status.terminé {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }

        .status.annulé {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger);
        }

        .rdv-card p {
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }

        .btn-details {
            background: var(--info);
            color: var(--white);
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }

        .btn-danger {
            background: var(--danger);
            color: var(--white);
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }

        .btn-success {
            background: var(--success);
            color: var(--white);
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }

        .prochain-rdv {
            background: linear-gradient(135deg, var(--success), #2ecc71);
            color: white;
            padding: 1.5rem;
            border-radius: var(--radius);
            margin-bottom: 1rem;
        }

        .prochain-rdv h3 {
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .info {
            text-align: center;
            padding: 2rem;
            color: var(--gray);
            font-style: italic;
        }

        .alert {
            padding: 1rem;
            border-radius: var(--radius);
            margin-bottom: 1rem;
            text-align: center;
        }

        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            border: 1px solid var(--success);
            color: var(--success);
        }

        .alert-danger {
            background: rgba(231, 76, 60, 0.1);
            border: 1px solid var(--danger);
            color: var(--danger);
        }

        .filtres {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }

        .filtre-btn {
            padding: 0.5rem 1rem;
            border: 2px solid var(--light-gray);
            background: var(--white);
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .filtre-btn.active {
            background: var(--primary);
            color: var(--white);
            border-color: var(--primary);
        }

        @media (max-width: 768px) {
            .container {
                padding: 1rem 0.5rem;
            }
            
            .header h1 {
                font-size: 2rem;
            }
            
            .quick-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .card-actions {
                flex-direction: column;
            }
            
            .rdv-card p {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.2rem;
            }
            
            .createur-badge, .status {
                position: static;
                align-self: flex-start;
                margin-bottom: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <button class="btn-retour" onclick="history.back()" title="Retour">
        <i class="fas fa-arrow-left"></i>
    </button>

    <div class="container">
        <!-- En-tête -->
        <div class="header">
            <h1>
                <i class="fas fa-calendar-alt"></i> 
                <?php 
                switch($userRole) {
                    case 'etudiant': echo 'Mes Rendez-vous'; break;
                    case 'medecin': echo 'Rendez-vous - Médecin'; break;
                    case 'infirmier': echo 'Rendez-vous - Infirmier'; break;
                    default: echo 'Gestion des Rendez-vous';
                }
                ?>
                <span class="role-badge"><?= strtoupper($userRole) ?></span>
            </h1>
            <p>
                <?php 
                switch($userRole) {
                    case 'etudiant': echo 'Gérez vos rendez-vous médicaux'; break;
                    case 'medecin': echo 'Planifications et consultations médicales'; break;
                    case 'infirmier': echo 'Soins et suivis infirmiers'; break;
                    default: echo 'Gestion complète des rendez-vous';
                }
                ?>
            </p>
            
            <!-- Statistiques détaillées -->
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-number"><?= $stats['total'] ?></span>
                    <span class="stat-label">Total RDV</span>
                </div>
                <div class="stat-card moi">
                    <span class="stat-number"><?= $stats['crees_par_moi'] ?></span>
                    <span class="stat-label">Créés par moi</span>
                </div>
                <div class="stat-card autres">
                    <span class="stat-number"><?= $stats['crees_par_autres'] ?></span>
                    <span class="stat-label">Créés par d'autres</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?= $stats['en_attente'] ?></span>
                    <span class="stat-label">En attente</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number"><?= $stats['confirmes'] ?></span>
                    <span class="stat-label">Confirmés</span>
                </div>
            </div>
        </div>

        <!-- Messages d'alerte -->
        <?php if ($message_success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $message_success ?>
            </div>
        <?php endif; ?>

        <?php if ($message_erreur): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= $message_erreur ?>
            </div>
        <?php endif; ?>

        <!-- Actions rapides -->
        <div class="quick-actions">
            <a href="prendre_rdv.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Nouveau RDV
            </a>
            <button id="btnEnAttente" class="btn btn-warning btn-active" onclick="afficherSection('rdvEnAttente', this)">
                <i class="fas fa-clock"></i> En attente (<?= $stats['en_attente'] ?>)
            </button>
            <button id="btnConfirmes" class="btn btn-success" onclick="afficherSection('rdvConfirmes', this)">
                <i class="fas fa-check-circle"></i> Confirmés (<?= $stats['confirmes'] ?>)
            </button>
            <button id="btnHistorique" class="btn btn-primary" onclick="afficherSection('rdvHistorique', this)">
                <i class="fas fa-history"></i> Historique (<?= $stats['historique'] ?>)
            </button>
        </div>

        <!-- Filtres créateur -->
        <div class="filtres">
            <button class="filtre-btn active" onclick="filtrerParCreateur('tous')">Tous</button>
            <button class="filtre-btn" onclick="filtrerParCreateur('moi')">Créés par moi</button>
            <button class="filtre-btn" onclick="filtrerParCreateur('autre')">Créés par d'autres</button>
        </div>

        <!-- Dashboard avec prochains RDV -->
        <div class="dashboard-grid">
            <!-- Section principale -->
            <div>
                <!-- Section des rendez-vous en attente -->
                <div id="rdvEnAttente" class="section">
                    <h2 class="section-title"><i class="fas fa-clock"></i> Rendez-vous en attente</h2>
                    <?= afficherRDVs($rdvsParStatut['en_attente'], 'attente') ?>
                </div>

                <!-- Section des rendez-vous confirmés -->
                <div id="rdvConfirmes" class="section hidden">
                    <h2 class="section-title"><i class="fas fa-check-circle"></i> Rendez-vous confirmés</h2>
                    <?= afficherRDVs($rdvsParStatut['confirmes'], 'confirmé') ?>
                </div>

                <!-- Section de l'historique -->
                <div id="rdvHistorique" class="section hidden">
                    <h2 class="section-title"><i class="fas fa-history"></i> Historique des rendez-vous</h2>
                    <?= afficherRDVs($rdvsParStatut['historique'], 'historique') ?>
                </div>
            </div>

            <!-- Sidebar avec prochains RDV -->
            <div class="section">
                <h2 class="section-title"><i class="fas fa-calendar-check"></i> Prochains RDV</h2>
                <?php if (empty($rdvsProchains)): ?>
                    <p class="info">Aucun rendez-vous à venir</p>
                <?php else: ?>
                    <?php foreach ($rdvsProchains as $rdv): ?>
                    <div class="prochain-rdv">
                        <h3><i class="fas fa-stethoscope"></i> <?= ucfirst($rdv['type_rdv']) ?></h3>
                        <p><i class="fas fa-calendar-day"></i> <?= date('d/m/Y à H:i', strtotime($rdv['date_rdv'])) ?></p>
                        <p><i class="fas fa-user-md"></i> 
                            <?= $rdv['professionnel_type'] === 'Médecin' ? 'Dr. ' : '' ?>
                            <?= htmlspecialchars($rdv['professionnel_prenom']) ?> <?= htmlspecialchars($rdv['professionnel_nom']) ?>
                        </p>
                        <?php if ($userRole !== 'etudiant'): ?>
                            <p><i class="fas fa-user-injured"></i> Patient : <?= htmlspecialchars($rdv['patient_prenom']) ?> <?= htmlspecialchars($rdv['patient_nom']) ?></p>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function afficherSection(sectionId, bouton) {
            // Masquer toutes les sections
            document.querySelectorAll('.section').forEach(section => {
                section.classList.add('hidden');
            });
            
            // Afficher la section sélectionnée
            document.getElementById(sectionId).classList.remove('hidden');
            
            // Mettre à jour les boutons actifs
            document.querySelectorAll('.quick-actions .btn').forEach(btn => {
                btn.classList.remove('btn-active');
            });
            
            if (bouton) {
                bouton.classList.add('btn-active');
            }
        }

        function filtrerParCreateur(type) {
            const cards = document.querySelectorAll('.rdv-card');
            const filtres = document.querySelectorAll('.filtre-btn');
            
            // Mettre à jour les boutons de filtre
            filtres.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            // Filtrer les cartes
            cards.forEach(card => {
                if (type === 'tous') {
                    card.style.display = 'block';
                } else {
                    card.style.display = card.classList.contains(type) ? 'block' : 'none';
                }
            });
        }

        function confirmerAction(action, rdvId) {
            const messages = {
                'annuler_rdv': 'Êtes-vous sûr de vouloir annuler ce rendez-vous ?',
                'confirmer_rdv': 'Êtes-vous sûr de vouloir confirmer ce rendez-vous ?'
            };
            
            if (confirm(messages[action])) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="${action}">
                    <input type="hidden" name="rdv_id" value="${rdvId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Afficher la première section par défaut
        document.addEventListener('DOMContentLoaded', function() {
            afficherSection('rdvEnAttente', document.getElementById('btnEnAttente'));
        });
    </script>
</body>
</html>

<?php
// Fonction pour afficher les RDVs
function afficherRDVs($rdvs, $statut) {
    if (empty($rdvs)) {
        return '<p class="info"><i class="fas fa-info-circle"></i> Aucun rendez-vous.</p>';
    }
    
    $html = '';
    foreach ($rdvs as $rdv) {
        $classeCreateur = $rdv['createur_type'] === 'moi' ? 'moi' : 'autre';
        $classeStatut = strtolower($rdv['statut']);
        
        $html .= "
        <div class='rdv-card $classeStatut $classeCreateur'>
            <span class='createur-badge $classeCreateur'>
                " . ($rdv['createur_type'] === 'moi' ? '🟢 Par moi' : '🔵 Par ' . $rdv['created_prenom']) . "
            </span>
            <span class='status $classeStatut'>" . ucfirst($rdv['statut']) . "</span>
            
            <p><i class='fas fa-calendar-day'></i> <strong>Date :</strong> " . date('d/m/Y à H:i', strtotime($rdv['date_rdv'])) . "</p>
            <p><i class='fas fa-stethoscope'></i> <strong>Type :</strong> " . ucfirst($rdv['type_rdv']) . "</p>";
        
        // Afficher le patient pour les professionnels
        if ($GLOBALS['userRole'] !== 'etudiant') {
            $html .= "<p><i class='fas fa-user-injured'></i> <strong>Patient :</strong> " . htmlspecialchars($rdv['patient_prenom']) . " " . htmlspecialchars($rdv['patient_nom']) . "</p>";
        }
        
        $html .= "
            <p><i class='fas fa-user-md'></i> <strong>Professionnel :</strong> 
                " . ($rdv['professionnel_type'] === 'Médecin' ? 'Dr. ' : '') . "
                " . htmlspecialchars($rdv['professionnel_prenom']) . " " . htmlspecialchars($rdv['professionnel_nom']) . "
            </p>";
        
        if ($rdv['motif']) {
            $html .= "<p><i class='fas fa-comment-medical'></i> <strong>Motif :</strong> " . htmlspecialchars($rdv['motif']) . "</p>";
        }
        
        $html .= "<div class='card-actions'>";
        
        // Actions selon le statut et le rôle
        if ($statut === 'attente' && $rdv['createur_type'] === 'moi') {
            $html .= "
                <button onclick='confirmerAction(\"annuler_rdv\", {$rdv['id']})' class='btn btn-danger'>
                    <i class='fas fa-times'></i> Annuler
                </button>";
        }
        
        if ($statut === 'attente' && $rdv['createur_type'] === 'autre' && $GLOBALS['userRole'] === 'etudiant') {
            $html .= "
                <button onclick='confirmerAction(\"confirmer_rdv\", {$rdv['id']})' class='btn btn-success'>
                    <i class='fas fa-check'></i> Confirmer
                </button>
                <button onclick='confirmerAction(\"annuler_rdv\", {$rdv['id']})' class='btn btn-danger'>
                    <i class='fas fa-times'></i> Refuser
                </button>";
        }
        
        $html .= "
                <a href='details_rdv.php?id={$rdv['id']}' class='btn btn-details'>
                    <i class='fas fa-search'></i> Détails
                </a>
            </div>
        </div>";
    }
    
    return $html;
}
?>