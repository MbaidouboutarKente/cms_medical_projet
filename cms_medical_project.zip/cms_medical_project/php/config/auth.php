<?php
session_start();
require_once "db.php";
include "functions.php";

// Configuration du débogage
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$sectionActive = "login"; // Section active par défaut
$messageErreurInscription = "";
$messageErreurConnexion = "";

// Vérification des valeurs en session
$valeursInscription = [
    'matricule' => $_SESSION['form_data']['matricule'] ?? "",
    'nom' => $_SESSION['form_data']['nom'] ?? "",
    'email' => $_SESSION['form_data']['email'] ?? "",
    'role' => $_SESSION['form_data']['role'] ?? "etudiant"
];

$valeursConnexion = [
    'email' => $_SESSION['form_data']['login_email'] ?? ""
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'] ?? "";

    // 🔹 Gestion de l'inscription
    if ($action == "register") {
        $sectionActive = "register";
        $valeursInscription = [
            'matricule' => filter_input(INPUT_POST, "matricule", FILTER_SANITIZE_SPECIAL_CHARS),
            'nom' => filter_input(INPUT_POST, "nom", FILTER_SANITIZE_SPECIAL_CHARS),
            'email' => filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL),
            'role' => filter_input(INPUT_POST, "role", FILTER_SANITIZE_SPECIAL_CHARS) ?? "etudiant"
        ];
        $mot_de_passe = $_POST['mot_de_passe'] ?? "";

        $_SESSION['form_data'] = $valeursInscription;

        // 🚨 Vérification des champs obligatoires
        if (empty($valeursInscription['matricule']) || empty($valeursInscription['nom']) || 
            empty($valeursInscription['email']) || empty($mot_de_passe)) {
            $messageErreurInscription = "🔴 Tous les champs sont obligatoires.";
        } elseif (!$valeursInscription['email']) {
            $messageErreurInscription = "🔴 Format d'email invalide.";
        }

        // 🔍 Vérification étudiant dans la table `etudiants`
        if (empty($messageErreurInscription) && $valeursInscription['role'] === "etudiant") {
            $queryCampus = $pdoCampus->prepare("SELECT id, nom FROM etudiants WHERE matricule = ?");
            $queryCampus->execute([$valeursInscription['matricule']]);
            $etudiant = $queryCampus->fetch();

            if (!$etudiant || strtolower($etudiant['nom']) !== strtolower($valeursInscription['nom'])) {
                $messageErreurInscription = "🔴 Matricule ou nom incorrect.";
            }
        }

        if (empty($messageErreurInscription)) {
            $hashedPassword = password_hash($mot_de_passe, PASSWORD_DEFAULT);
            $queryMedical = $pdoMedical->prepare("
                INSERT INTO utilisateurs (matricule, nom, email, mot_de_passe, role, last_login) VALUES (?, ?, ?, ?, ?, NOW())
            ");

            if ($queryMedical->execute([
                $valeursInscription['matricule'], 
                $valeursInscription['nom'], 
                $valeursInscription['email'], 
                $hashedPassword, 
                $valeursInscription['role']
            ])) {
                $_SESSION['user_id'] = "MED_" . $pdoMedical->lastInsertId();
                $_SESSION['role'] = $valeursInscription['role'];
                $_SESSION['email'] = $valeursInscription['email'];

                enregistrerActivite($pdoMedical, $_SESSION['user_id'], "Inscription réussie", "Nouvel utilisateur enregistré.");
                
                unset($_SESSION['form_data']);
                header("Location: " . getRedirectPage($valeursInscription['role']));
                exit;
            }
        }
    } elseif ($action == "login") {
        $sectionActive = "login";
        $email = filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL);
        $mot_de_passe = $_POST['mot_de_passe'] ?? "";

        $_SESSION['form_data']['login_email'] = $email;

        if (empty($email) || empty($mot_de_passe)) {
            $messageErreurConnexion = "🔴 Email et mot de passe obligatoires.";
        }

        if (empty($messageErreurConnexion)) {
            $queryMedical = $pdoMedical->prepare("SELECT id, email, mot_de_passe, role FROM utilisateurs WHERE email = ?");
            $queryMedical->execute([$email]);
            $utilisateur = $queryMedical->fetch();

            if (!$utilisateur || !password_verify($mot_de_passe, $utilisateur['mot_de_passe'])) {
                $messageErreurConnexion = "🔴 Identifiants incorrects.";
            } else {

                   // Mise à jour du last_login avant de créer la session
                $queryUpdate = $pdoMedical->prepare("UPDATE utilisateurs SET last_login = NOW() WHERE id = ?");
                $queryUpdate->execute([$utilisateur['id']]);


                $_SESSION['user_id'] = "MED_" . $utilisateur['id'];
                $_SESSION['role'] = $utilisateur['role'];
                $_SESSION['email'] = $email;

                enregistrerActivite($pdoMedical, $utilisateur['id'], "Connexion réussie", "Utilisateur connecté.");
                
                unset($_SESSION['form_data']);
                header("Location: " . getRedirectPage($utilisateur['role']));
                exit;
            }
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    unset($_SESSION['form_data']);
}
?>
    

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <style>
        /* styles/auth.css */

        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4895ef;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --success-color: #4cc9f0;
            --error-color: #f72585;
            --border-radius: 8px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            line-height: 1.6;
        }

        .container {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            width: 100%;
            max-width: 500px;
            padding: 2rem;
            animation: fadeIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 {
            color: var(--dark-color);
            text-align: center;
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
            font-weight: 700;
        }

        h3 {
            color: var(--secondary-color);
            margin-bottom: 1.5rem;
            text-align: center;
            font-size: 1.4rem;
        }

        .tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 2rem;
            border-bottom: 1px solid #eee;
        }

        .tabs button {
            background: none;
            border: none;
            padding: 0.75rem 1.5rem;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            color: var(--dark-color);
            position: relative;
            transition: var(--transition);
            outline: none;
        }

        .tabs button:hover {
            color: var(--primary-color);
        }

        .tabs button::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            width: 0;
            height: 3px;
            background-color: var(--primary-color);
            transition: var(--transition);
        }

        .tabs button:hover::after {
            width: 100%;
        }

        .section {
            display: none;
            animation: slideUp 0.4s ease-out;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .section.active {
            display: block;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 1.25rem;
        }

        input, select {
            padding: 0.75rem 1rem;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: var(--transition);
            outline: none;
        }

        input:focus, select:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 2px rgba(72, 149, 239, 0.2);
        }

        input::placeholder {
            color: #aaa;
        }

        select {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 1rem;
        }

        button[type="submit"] {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 0.75rem;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            margin-top: 0.5rem;
        }

        button[type="submit"]:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }

        button[type="submit"]:active {
            transform: translateY(0);
        }

        p[style*="color:red"] {
            background-color: rgba(247, 37, 133, 0.1);
            padding: 0.75rem;
            border-radius: var(--border-radius);
            color: var(--error-color) !important;
            font-size: 0.9rem;
            margin-top: 0.5rem;
            animation: shake 0.5s;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%, 60% { transform: translateX(-5px); }
            40%, 80% { transform: translateX(5px); }
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            .container {
                padding: 1.5rem;
            }
            
            h2 {
                font-size: 1.5rem;
            }
            
            h3 {
                font-size: 1.2rem;
            }
            
            .tabs button {
                padding: 0.5rem 1rem;
                font-size: 0.9rem;
            }
        }

        /* Effet de chargement */
        .loading {
            position: relative;
            pointer-events: none;
            opacity: 0.7;
        }

        .loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: translate(-50%, -50%) rotate(360deg); }
        }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion & Inscription</title>
</head>
<body>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        showSection("<?php echo $sectionActive; ?>");
        
        // Surveillance dynamique des champs avec stockage local
        document.querySelectorAll('input, select').forEach(element => {
            // Récupération des valeurs stockées localement
            const savedValue = localStorage.getItem(`form_${element.name}`);
            if (savedValue !== null && element.value === "") {
                element.value = savedValue;
            }
            
            // Écoute des changements
            element.addEventListener('input', function() {
                localStorage.setItem(`form_${this.name}`, this.value);
            });
        });
        
        // Gestion spéciale pour le mot de passe (ne pas le stocker)
        document.querySelectorAll('input[type="password"]').forEach(element => {
            element.addEventListener('input', function() {
                localStorage.removeItem(`form_${this.name}`);
            });
        });
    });

    function showSection(section) {
        document.querySelectorAll(".section").forEach(div => div.style.display = "none");
        document.getElementById(section).style.display = "block";
    }
    
    function clearLocalStorage() {
        document.querySelectorAll('input, select').forEach(element => {
            if (element.type !== 'password') {
                localStorage.removeItem(`form_${element.name}`);
            }
        });
    }
</script>

<div class="container">
    <h2>Connexion & Inscription</h2>

    <div class="tabs">
        <button onclick="showSection('register')">Inscription</button>
        <button onclick="showSection('login')">Connexion</button>
    </div>

    <div id="register" class="section">
        <h3>Inscription</h3>
        <form method="POST">
            <input type="hidden" name="action" value="register">
            <input type="text" name="matricule" required placeholder="Matricule" value="<?php echo htmlspecialchars($valeursInscription['matricule']); ?>">
            <input type="text" name="nom" required placeholder="Nom" value="<?php echo htmlspecialchars($valeursInscription['nom']); ?>">
            <input type="email" name="email" required placeholder="Email" value="<?php echo htmlspecialchars($valeursInscription['email']); ?>">
            <input type="password" name="mot_de_passe" required placeholder="Mot de passe">
            <select name="role">
                <option value="etudiant" <?php echo $valeursInscription['role'] === 'etudiant' ? 'selected' : ''; ?>>Étudiant</option>
                <option value="infirmier" <?php echo $valeursInscription['role'] === 'infirmier' ? 'selected' : ''; ?>>Infirmier</option>
                <option value="medecin" <?php echo $valeursInscription['role'] === 'medecin' ? 'selected' : ''; ?>>Médecin</option>
                <!-- <option value="admin" <?php echo $valeursInscription['role'] === 'admin' ? 'selected' : ''; ?>>Administrateur</option>
                <option value="super_admin" <?php echo $valeursInscription['role'] === 'super_admin' ? 'selected' : ''; ?>>Super Admin</option> -->
            </select>
            <button type="submit">S'inscrire</button>
            <?php if (!empty($messageErreurInscription)): ?>
                <p style="color:red;"><?php echo $messageErreurInscription; ?></p>
            <?php endif; ?>
        </form>
    </div>

    <div id="login" class="section">
        <h3>Connexion</h3>
        <form method="POST">
            <input type="hidden" name="action" value="login">
            <input type="email" name="email" required placeholder="Email" value="<?php echo htmlspecialchars($valeursConnexion['email']); ?>">
            <input type="password" name="mot_de_passe" required placeholder="Mot de passe">
            <button type="submit">Se connecter</button>
            <?php if (!empty($messageErreurConnexion)): ?>
                <p style="color:red;"><?php echo $messageErreurConnexion; ?></p>
            <?php endif; ?>
        </form>
    </div>
</div>

</body>
</html>