<?php
session_start();
require_once "../config/db.php";

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'etudiant') {
    header("Location: ../config/auth.php");
    exit;
}

// Extraction de l'ID utilisateur selon le format
if (strpos($_SESSION['user_id'], 'MED_') === 0) {
    $userID = intval(str_replace("MED_", "", $_SESSION['user_id']));
} elseif (strpos($_SESSION['user_id'], 'ETU_') === 0) {
    $userID = intval(str_replace("ETU_", "", $_SESSION['user_id']));
} else {
    $userID = intval($_SESSION['user_id']);
}

// Récupération de l'ID du rendez-vous depuis l'URL
$rendez_vous_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($rendez_vous_id === 0) {
    die("ID de rendez-vous invalide");
}

// Vérifier d'abord si la table consultations existe
$tableConsultationsExists = $pdoMedical->query("SHOW TABLES LIKE 'consultations'")->fetch();

if ($tableConsultationsExists) {
    // Récupération depuis la table consultations
    try {
        $stmtConsultation = $pdoMedical->prepare("
            SELECT 
                c.*,
                r.date_rdv,
                r.type_rdv,
                r.motif,
                r.statut,
                r.duree,
                r.notes_medecin,
                m.prenom AS medecin_prenom,
                m.nom AS medecin_nom,
                m.email AS medecin_email,
                m.telephone AS medecin_telephone,
                m.specialite AS medecin_specialite,
                u.prenom AS patient_prenom,
                u.nom AS patient_nom,
                p.date_naissance,
                p.groupe_sanguin,
                p.allergies,
                p.antecedents
            FROM consultations c
            JOIN rendez_vous r ON c.rendez_vous_id = r.id
            JOIN utilisateurs m ON r.medecin_id = m.id
            JOIN utilisateurs u ON r.patient_id = u.id
            LEFT JOIN patients p ON u.id = p.utilisateur_id
            WHERE r.id = ? AND r.patient_id = ?
        ");
        
        $stmtConsultation->execute([$rendez_vous_id, $userID]);
        $consultation = $stmtConsultation->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        $consultation = false;
        error_log("Erreur consultation table: " . $e->getMessage());
    }
} else {
    $consultation = false;
}

// Si pas de consultation trouvée, chercher dans rendez_vous directement
if (!$consultation) {
    try {
        $stmtRendezVous = $pdoMedical->prepare("
            SELECT 
                r.*,
                m.prenom AS medecin_prenom,
                m.nom AS medecin_nom,
                m.email AS medecin_email,
                m.telephone AS medecin_telephone,
                m.specialite AS medecin_specialite,
                u.prenom AS patient_prenom,
                u.nom AS patient_nom,
                p.date_naissance,
                p.groupe_sanguin,
                p.allergies,
                p.antecedents
            FROM rendez_vous r
            JOIN utilisateurs m ON r.medecin_id = m.id
            JOIN utilisateurs u ON r.patient_id = u.id
            LEFT JOIN patients p ON u.id = p.utilisateur_id
            WHERE r.id = ? AND r.patient_id = ?
        ");
        
        $stmtRendezVous->execute([$rendez_vous_id, $userID]);
        $consultation = $stmtRendezVous->fetch(PDO::FETCH_ASSOC);

        if ($consultation) {
            // Transformer les données rendez_vous en format consultation
            $consultation['diagnostic'] = '';
            $consultation['prescription'] = '';
            $consultation['examens'] = '';
            $consultation['notes'] = $consultation['notes_medecin'] ?? '';
            
            // Essayer d'extraire les informations du motif ou notes_medecin
            if (!empty($consultation['motif']) && strpos($consultation['motif'], 'Consultation - ') === 0) {
                $consultation['diagnostic'] = str_replace('Consultation - ', '', $consultation['motif']);
            }
            
            if (!empty($consultation['notes_medecin'])) {
                $notes = $consultation['notes_medecin'];
                if (strpos($notes, 'Diagnostic:') !== false) {
                    $parts = explode("\n", $notes);
                    foreach ($parts as $part) {
                        if (strpos($part, 'Diagnostic:') === 0) {
                            $consultation['diagnostic'] = str_replace('Diagnostic: ', '', $part);
                        } elseif (strpos($part, 'Prescription:') === 0) {
                            $consultation['prescription'] = str_replace('Prescription: ', '', $part);
                        } elseif (strpos($part, 'Examens:') === 0) {
                            $consultation['examens'] = str_replace('Examens: ', '', $part);
                        } elseif (strpos($part, 'Notes:') === 0) {
                            $consultation['notes'] = str_replace('Notes: ', '', $part);
                        }
                    }
                } else {
                    // Si pas de format structuré, utiliser les notes comme diagnostic
                    $consultation['diagnostic'] = $notes;
                }
            }
        }

    } catch (PDOException $e) {
        die("Erreur lors de la récupération des données: " . $e->getMessage());
    }
}

if (!$consultation) {
    die("Consultation non trouvée ou accès non autorisé");
}

// DEBUG: Afficher les données pour vérifier
error_log("Consultation data: " . print_r($consultation, true));

// Récupération des médicaments prescrits (si table existe)
$medicaments_prescrits = [];
try {
    $tableExists = $pdoMedical->query("SHOW TABLES LIKE 'prescription_medicaments'")->fetch();
    
    if ($tableExists) {
        $stmtMedicaments = $pdoMedical->prepare("
            SELECT pm.*, m.nom, m.description, m.posologie_type
            FROM prescription_medicaments pm
            JOIN medicaments m ON pm.medicament_id = m.id
            WHERE pm.rendez_vous_id = ?
            ORDER BY pm.ordre
        ");
        $stmtMedicaments->execute([$rendez_vous_id]);
        $medicaments_prescrits = $stmtMedicaments->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("Table prescription_medicaments non disponible: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails Consultation | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #3498db;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        .btn-retour {
            position: fixed;
            top: 20px;
            left: 20px;
            background: var(--white);
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            box-shadow: var(--shadow);
            cursor: pointer;
            font-size: 1.2rem;
            color: var(--primary);
            z-index: 1000;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        .btn-retour:hover {
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .header {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .consultation-title {
            color: var(--primary);
            font-size: 2rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .consultation-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
        }

        .meta-card {
            background: var(--light-gray);
            padding: 1rem;
            border-radius: 8px;
            border-left: 4px solid var(--primary);
        }

        .meta-card h3 {
            color: var(--primary);
            margin-bottom: 0.5rem;
            font-size: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .content-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        @media (max-width: 968px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        .section {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .section-title {
            color: var(--primary);
            font-size: 1.3rem;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--light-gray);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .info-content {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            white-space: pre-line;
            line-height: 1.8;
        }

        .medicament-card {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border-left: 4px solid var(--success);
        }

        .medicament-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }

        .medicament-nom {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--dark);
            flex: 1;
        }

        .medicament-posologie {
            background: var(--success);
            color: var(--white);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }

        .badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-success {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }

        .badge-warning {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }

        .badge-info {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            background-color: var(--primary);
            color: var(--white);
        }

        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.2);
        }

        .btn-print {
            background: var(--info);
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
            flex-wrap: wrap;
        }

        @media (max-width: 768px) {
            .container {
                padding: 1rem 0.5rem;
            }
            
            .consultation-title {
                font-size: 1.5rem;
            }
            
            .consultation-meta {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <a href="javascript:history.back()" class="btn-retour" title="Retour">
        <i class="fas fa-arrow-left"></i>
    </a>

    <div class="container">
        <!-- En-tête de la consultation -->
        <div class="header">
            <h1 class="consultation-title">
                <i class="fas fa-file-medical-alt"></i>
                Compte-rendu de Consultation
            </h1>
            
            <div class="consultation-meta">
                <div class="meta-card">
                    <h3><i class="fas fa-calendar-day"></i> Date de la consultation</h3>
                    <p><?= date('d/m/Y à H:i', strtotime($consultation['date_rdv'])) ?></p>
                </div>
                
                <div class="meta-card">
                    <h3><i class="fas fa-user-md"></i> Médecin traitant</h3>
                    <p>Dr. <?= htmlspecialchars($consultation['medecin_prenom']) ?> <?= htmlspecialchars($consultation['medecin_nom']) ?></p>
                    <?php if ($consultation['medecin_specialite']): ?>
                        <p><em><?= htmlspecialchars($consultation['medecin_specialite']) ?></em></p>
                    <?php endif; ?>
                </div>
                
                <div class="meta-card">
                    <h3><i class="fas fa-stethoscope"></i> Type de consultation</h3>
                    <p><?= htmlspecialchars(ucfirst($consultation['type_rdv'])) ?></p>
                    <span class="badge badge-success"><?= htmlspecialchars($consultation['statut']) ?></span>
                </div>
                
                <div class="meta-card">
                    <h3><i class="fas fa-user-injured"></i> Patient</h3>
                    <p><?= htmlspecialchars($consultation['patient_prenom']) ?> <?= htmlspecialchars($consultation['patient_nom']) ?></p>
                    <?php if ($consultation['date_naissance']): ?>
                        <p>Né(e) le <?= date('d/m/Y', strtotime($consultation['date_naissance'])) ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="content-grid">
            <!-- Colonne de gauche : Informations médicales -->
            <div>
                <!-- Diagnostic -->
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-diagnoses"></i>
                        Diagnostic
                    </h2>
                    <?php if (!empty($consultation['diagnostic'])): ?>
                        <div class="info-content">
                            <?= nl2br(htmlspecialchars($consultation['diagnostic'])) ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-stethoscope"></i>
                            <p>Aucun diagnostic renseigné</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Prescription médicamenteuse -->
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-prescription"></i>
                        Ordonnance
                    </h2>
                    <?php if (!empty($consultation['prescription']) || !empty($medicaments_prescrits)): ?>
                        <?php if (!empty($medicaments_prescrits)): ?>
                            <?php foreach ($medicaments_prescrits as $medicament): ?>
                                <div class="medicament-card">
                                    <div class="medicament-header">
                                        <div class="medicament-nom">
                                            <?= htmlspecialchars($medicament['nom']) ?>
                                        </div>
                                        <div class="medicament-posologie">
                                            <?= htmlspecialchars($medicament['posologie']) ?>
                                        </div>
                                    </div>
                                    
                                    <?php if (!empty($medicament['description'])): ?>
                                        <p style="margin-bottom: 1rem; color: var(--gray);">
                                            <?= htmlspecialchars($medicament['description']) ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        
                        <?php if (!empty($consultation['prescription'])): ?>
                            <div class="info-content">
                                <h4 style="color: var(--primary); margin-bottom: 1rem;">
                                    <i class="fas fa-notes-medical"></i> Prescription générale
                                </h4>
                                <?= nl2br(htmlspecialchars($consultation['prescription'])) ?>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-pills"></i>
                            <p>Aucune prescription médicamenteuse</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Colonne de droite : Informations complémentaires -->
            <div>
                <!-- Examens complémentaires -->
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-microscope"></i>
                        Examens complémentaires
                    </h2>
                    <?php if (!empty($consultation['examens'])): ?>
                        <div class="info-content">
                            <?= nl2br(htmlspecialchars($consultation['examens'])) ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-vial"></i>
                            <p>Aucun examen complémentaire prescrit</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Notes et observations -->
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-notes-medical"></i>
                        Notes et observations
                    </h2>
                    <?php if (!empty($consultation['notes'])): ?>
                        <div class="info-content">
                            <?= nl2br(htmlspecialchars($consultation['notes'])) ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-file-alt"></i>
                            <p>Aucune note supplémentaire</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Informations patient -->
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-user-injured"></i>
                        Informations patient
                    </h2>
                    <div class="info-content">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                            <?php if ($consultation['groupe_sanguin']): ?>
                                <div>
                                    <strong>Groupe sanguin:</strong><br>
                                    <?= htmlspecialchars($consultation['groupe_sanguin']) ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($consultation['date_naissance']): ?>
                                <div>
                                    <strong>Âge:</strong><br>
                                    <?= date_diff(date_create($consultation['date_naissance']), date_create('today'))->y ?> ans
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($consultation['allergies']): ?>
                            <div style="margin-bottom: 1rem;">
                                <strong>Allergies connues:</strong><br>
                                <?= nl2br(htmlspecialchars($consultation['allergies'])) ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($consultation['antecedents']): ?>
                            <div>
                                <strong>Antécédents médicaux:</strong><br>
                                <?= nl2br(htmlspecialchars($consultation['antecedents'])) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Boutons d'action -->
        <div class="action-buttons">
            <button onclick="window.print()" class="btn btn-print">
                <i class="fas fa-print"></i> Imprimer le compte-rendu
            </button>
            <a href="../rdv/liste_rdv.php" class="btn">
                <i class="fas fa-arrow-left"></i> Retour aux rendez-vous
            </a>
            <a href="../dossiers/dossier_medical.php" class="btn">
                <i class="fas fa-folder-open"></i> Voir mon dossier complet
            </a>
        </div>
    </div>

    <script>
        // Animation de chargement
        document.addEventListener('DOMContentLoaded', function() {
            const sections = document.querySelectorAll('.section');
            sections.forEach((section, index) => {
                section.style.animationDelay = (index * 0.1) + 's';
            });
        });

        // Amélioration de l'impression
        window.addEventListener('beforeprint', function() {
            document.querySelector('.btn-retour').style.display = 'none';
        });

        window.addEventListener('afterprint', function() {
            document.querySelector('.btn-retour').style.display = 'flex';
        });
    </script>
</body>
</html>