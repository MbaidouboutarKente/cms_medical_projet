<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "../config/db.php";

// Vérification rôle patient/étudiant
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'patient' && $_SESSION['role'] !== 'etudiant')) {
    header("Location: ../auth.php");
    exit;
}

// Extraction correcte de l'ID patient
$userID = $_SESSION['user_id'];
$patientID = null;

if (preg_match('/^PAT_(\d+)$/', $userID, $matches)) {
    $patientID = (int)$matches[1];
} elseif (preg_match('/^ETU_(\d+)$/', $userID, $matches)) {
    $patientID = (int)$matches[1];
} else {
    $patientID = (int)filter_var($userID, FILTER_SANITIZE_NUMBER_INT);
}


try {
    // REQUÊTE CORRIGÉE POUR LISTER LES CONSULTATIONS DU PATIENT
    $sql = "
        SELECT 
            c.id AS consultation_id,
            c.diagnostic,
            c.prescription,
            c.examens,
            c.date_creation,
            r.date_rdv,
            r.type_rdv,
            r.motif,
            r.statut,
            u_medecin.nom AS medecin_nom,
            u_medecin.prenom AS medecin_prenom,
            m.specialite,
            TIMESTAMPDIFF(YEAR, p.date_naissance, CURDATE()) AS age
        FROM consultations c
        JOIN rendez_vous r ON c.rendez_vous_id = r.id
        JOIN utilisateurs m ON r.medecin_id = m.id
        JOIN utilisateurs u_medecin ON m.id = u_medecin.id
        JOIN patients p ON r.patient_id = p.utilisateur_id
        WHERE r.patient_id = :patient_id
        ORDER BY r.date_rdv DESC";
    
    $stmt = $pdoMedical->prepare($sql);
    $stmt->execute([':patient_id' => $patientID]);
    
    $consultations = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Erreur DB mes consultations: " . $e->getMessage());
    $error_message = "Une erreur est survenue lors de l'accès à vos données. Veuillez réessayer.";
}

// Fonction pour obtenir le statut badge
function getStatusBadge($statut) {
    switch ($statut) {
        case 'terminé':
        case 'realise':
            return '<span class="badge badge-success"><i class="fas fa-check-circle"></i> Terminé</span>';
        case 'annule':
            return '<span class="badge badge-danger"><i class="fas fa-times-circle"></i> Annulé</span>';
        case 'en_cours':
            return '<span class="badge badge-warning"><i class="fas fa-clock"></i> En cours</span>';
        default:
            return '<span class="badge badge-info"><i class="fas fa-calendar"></i> Planifié</span>';
    }
}

// Fonction pour obtenir le type de consultation
function getTypeBadge($type) {
    $types = [
        'consultation' => 'Consultation',
        'urgence' => 'Urgence',
        'controle' => 'Contrôle',
        'teleconsultation' => 'Téléconsultation'
    ];
    $color = [
        'consultation' => 'primary',
        'urgence' => 'danger',
        'controle' => 'info',
        'teleconsultation' => 'secondary'
    ];
    
    $type_key = strtolower($type);
    $type_text = $types[$type_key] ?? ucfirst($type);
    $type_color = $color[$type_key] ?? 'primary';
    
    return "<span class='badge badge-{$type_color}'><i class='fas fa-stethoscope'></i> {$type_text}</span>";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Consultations | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 12px;
            --transition: all 0.3s ease;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4efe9 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
        }
        
        .container {
            width: 95%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding: 1.5rem;
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary);
        }
        
        .header-content h1 {
            color: var(--primary);
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            margin-bottom: 0.5rem;
        }
        
        .header-content p {
            color: var(--gray);
            font-size: 0.95rem;
        }
        
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: var(--white);
            padding: 1.5rem;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            text-align: center;
            transition: var(--transition);
            border-top: 4px solid var(--primary);
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card.success {
            border-top-color: var(--success);
        }
        
        .stat-card.warning {
            border-top-color: var(--warning);
        }
        
        .stat-card.info {
            border-top-color: var(--info);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
            display: block;
        }
        
        .stat-card.success .stat-number {
            color: var(--success);
        }
        
        .stat-card.warning .stat-number {
            color: var(--warning);
        }
        
        .stat-card.info .stat-number {
            color: var(--info);
        }
        
        .stat-label {
            color: var(--gray);
            font-size: 0.9rem;
            margin-top: 0.5rem;
        }
        
        .consultation-list {
            display: grid;
            gap: 1.2rem;
        }
        
        .consultation-item {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1.8rem;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            transition: var(--transition);
            border-left: 4px solid var(--primary);
            position: relative;
            overflow: hidden;
        }
        
        .consultation-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--primary) 0%, transparent 100%);
            opacity: 0.02;
            z-index: 1;
        }
        
        .consultation-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .consultation-info {
            flex: 1;
            position: relative;
            z-index: 2;
        }
        
        .consultation-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .consultation-title {
            color: var(--primary);
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .consultation-meta {
            display: flex;
            gap: 1.5rem;
            color: var(--gray);
            font-size: 0.9rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        }
        
        .consultation-meta span {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .consultation-details {
            margin-top: 1rem;
        }
        
        .consultation-details p {
            margin-bottom: 0.5rem;
            color: var(--dark);
        }
        
        .consultation-actions {
            display: flex;
            flex-direction: column;
            gap: 0.8rem;
            position: relative;
            z-index: 2;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.7rem 1.4rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            transition: var(--transition);
            background-color: var(--primary);
            color: var(--white);
            white-space: nowrap;
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(58, 123, 213, 0.3);
        }
        
        .btn-outline {
            background: transparent;
            border: 2px solid var(--primary);
            color: var(--primary);
        }
        
        .btn-outline:hover {
            background: var(--primary);
            color: var(--white);
        }
        
        .btn-success {
            background-color: var(--success);
        }
        
        .btn-success:hover {
            background-color: #27ae60;
        }
        
        .badge {
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }
        
        .badge-primary {
            background: rgba(58, 123, 213, 0.1);
            color: var(--primary);
        }
        
        .badge-success {
            background: rgba(46, 204, 113, 0.1);
            color: var(--success);
        }
        
        .badge-warning {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }
        
        .badge-danger {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger);
        }
        
        .badge-info {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }
        
        .badge-secondary {
            background: rgba(0, 210, 255, 0.1);
            color: var(--secondary);
        }
        
        .no-data {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--gray);
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }
        
        .no-data i {
            font-size: 4rem;
            margin-bottom: 1.5rem;
            color: var(--light-gray);
        }
        
        .no-data h3 {
            color: var(--gray);
            margin-bottom: 1rem;
            font-weight: 500;
        }
        
        .error-message {
            background: #fee;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 1rem;
            border-radius: var(--radius);
            margin-bottom: 2rem;
            text-align: center;
        }
        
        .filters {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        
        .filter-select {
            padding: 0.7rem 1rem;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            background: var(--white);
            color: var(--dark);
            font-size: 0.9rem;
            min-width: 150px;
        }
        
        .filter-select:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .consultation-item {
                flex-direction: column;
                gap: 1.5rem;
            }
            
            .consultation-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .consultation-meta {
                flex-direction: column;
                gap: 0.8rem;
            }
            
            .consultation-actions {
                width: 100%;
                flex-direction: row;
                justify-content: space-between;
            }
            
            .filters {
                flex-direction: column;
            }
            
            .filter-select {
                width: 100%;
            }
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 2rem;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: var(--light-gray);
            margin-bottom: 1rem;
        }
        
        .consultation-preview {
            background: var(--light-gray);
            padding: 1rem;
            border-radius: 8px;
            margin-top: 0.5rem;
            font-size: 0.9rem;
            color: var(--dark);
            border-left: 3px solid var(--primary);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="header-content">
                <h1><i class="fas fa-file-medical-alt"></i> Mes Consultations</h1>
                <p>Retrouvez l'historique complet de vos consultations médicales</p>
            </div>
            <a href="../etudiant/dashboard_etudiant.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Tableau de bord
            </a>
        </div>

        <?php if (isset($error_message)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i> <?= $error_message ?>
            </div>
        <?php endif; ?>

        <!-- Statistiques -->
        <?php if (!empty($consultations)): ?>
        <div class="stats-container">
            <div class="stat-card">
                <span class="stat-number"><?= count($consultations) ?></span>
                <div class="stat-label">Total des consultations</div>
            </div>
            <div class="stat-card success">
                <span class="stat-number">
                    <?= count(array_filter($consultations, function($c) { 
                        return in_array(strtolower($c['statut'] ?? ''), ['terminé', 'realise']); 
                    })) ?>
                </span>
                <div class="stat-label">Consultations terminées</div>
            </div>
            <div class="stat-card info">
                <span class="stat-number">
                    <?= count(array_filter($consultations, function($c) { 
                        return strtolower($c['type_rdv'] ?? '') === 'teleconsultation'; 
                    })) ?>
                </span>
                <div class="stat-label">Téléconsultations</div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Filtres -->
        <?php if (!empty($consultations)): ?>
        <div class="filters">
            <select class="filter-select" onchange="filterConsultations(this.value, 'status')">
                <option value="">Tous les statuts</option>
                <option value="termine">Terminé</option>
                <option value="annule">Annulé</option>
                <option value="en_cours">En cours</option>
            </select>
            
            <select class="filter-select" onchange="filterConsultations(this.value, 'type')">
                <option value="">Tous les types</option>
                <option value="consultation">Consultation</option>
                <option value="urgence">Urgence</option>
                <option value="controle">Contrôle</option>
                <option value="teleconsultation">Téléconsultation</option>
            </select>
        </div>
        <?php endif; ?>
        
        <?php if (empty($consultations)): ?>
            <div class="no-data">
                <i class="fas fa-file-medical"></i>
                <h3>Aucune consultation trouvée</h3>
                <p>Vous n'avez pas encore de consultations enregistrées dans votre historique.</p>
                <div style="margin-top: 2rem;">
                    <a href="../rdv/prendre_rdv.php" class="btn btn-success">
                        <i class="fas fa-calendar-plus"></i> Prendre un rendez-vous
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="consultation-list" id="consultationList">
                <?php foreach ($consultations as $consultation): ?>
                    <div class="consultation-item" 
                         data-status="<?= strtolower($consultation['statut'] ?? '') ?>" 
                         data-type="<?= strtolower($consultation['type_rdv'] ?? '') ?>">
                        <div class="consultation-info">
                            <div class="consultation-header">
                                <div>
                                    <h3 class="consultation-title">
                                        Consultation #<?= $consultation['consultation_id'] ?>
                                    </h3>
                                    <?= getStatusBadge($consultation['statut'] ?? '') ?>
                                    <?= getTypeBadge($consultation['type_rdv'] ?? 'consultation') ?>
                                </div>
                            </div>
                            
                            <div class="consultation-meta">
                                <span><i class="fas fa-user-md"></i> Dr. <?= htmlspecialchars($consultation['medecin_prenom'] . ' ' . $consultation['medecin_nom']) ?></span>
                                <span><i class="fas fa-stethoscope"></i> <?= htmlspecialchars($consultation['specialite'] ?? 'Médecine générale') ?></span>
                                <span><i class="fas fa-calendar-alt"></i> <?= date('d/m/Y à H:i', strtotime($consultation['date_rdv'])) ?></span>
                            </div>
                            
                            <div class="consultation-details">
                                <p><strong>Motif:</strong> <?= !empty($consultation['motif']) ? htmlspecialchars($consultation['motif']) : htmlspecialchars($consultation['type_rdv']) ?></p>
                                
                                <?php if (!empty($consultation['diagnostic'])): ?>
                                    <div class="consultation-preview">
                                        <strong>Diagnostic:</strong> <?= substr(htmlspecialchars($consultation['diagnostic']), 0, 150) ?>...
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="consultation-actions">
                            <a href="mon_consultation.php?id=<?= $consultation['consultation_id'] ?>" class="btn">
                                <i class="fas fa-eye"></i> Détails
                            </a>
                            <?php if (!empty($consultation['prescription'])): ?>
                                <a href="mon_consultation.php?id=<?= $consultation['consultation_id'] ?>" class="btn btn-outline">
                                    <i class="fas fa-prescription"></i> Ordonnance
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function filterConsultations(value, type) {
            const items = document.querySelectorAll('.consultation-item');
            items.forEach(item => {
                const itemValue = item.getAttribute(`data-${type}`);
                const matches = !value || itemValue.includes(value);
                item.style.display = matches ? 'flex' : 'none';
            });
        }

        // Animation d'apparition progressive
        document.addEventListener('DOMContentLoaded', function() {
            const items = document.querySelectorAll('.consultation-item');
            items.forEach((item, index) => {
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    item.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>