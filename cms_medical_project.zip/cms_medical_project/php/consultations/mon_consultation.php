<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "../config/db.php";

// Vérification rôle patient/étudiant
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'patient' && $_SESSION['role'] !== 'etudiant')) {
    header("Location: ../auth.php");
    exit;
}

// Validation ID consultation
$consultationID = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($consultationID === false || $consultationID <= 0) {
    die("ID de consultation invalide");
}

// Extraction ID patient/étudiant
$userID = $_SESSION['user_id'];
$patientID = null;

// Gestion des différents formats d'ID
$patientID = filter_var(str_replace("MED_", "", $_SESSION['user_id']), FILTER_SANITIZE_NUMBER_INT);


try {
    // REQUÊTE SIMPLIFIÉE POUR DÉBOGUAGE
    $sql = "
        SELECT 
            c.id AS consultation_id,
            c.diagnostic,
            c.prescription,
            c.examens,
            c.date_creation,
            c.rendez_vous_id,
            r.id AS rdv_id,
            r.date_rdv,
            r.type_rdv,
            r.motif,
            r.patient_id,
            r.medecin_id,
            u_patient.nom AS patient_nom,
            u_patient.prenom AS patient_prenom,
            p.date_naissance,
            p.groupe_sanguin,
            p.allergies,
            p.antecedents,
            u_medecin.nom AS medecin_nom,
            u_medecin.prenom AS medecin_prenom,
            m.specialite
        FROM consultations c
        JOIN rendez_vous r ON c.rendez_vous_id = r.id
        JOIN patients p ON r.patient_id = p.utilisateur_id
        JOIN utilisateurs u_patient ON p.utilisateur_id = u_patient.id
        JOIN utilisateurs m ON r.medecin_id = m.id
        JOIN utilisateurs u_medecin ON m.id = u_medecin.id
        WHERE c.id = :consultation_id 
        AND r.patient_id = :patient_id";
    
    $stmt = $pdoMedical->prepare($sql);
    $stmt->execute([
        ':consultation_id' => $consultationID,
        ':patient_id' => $patientID
    ]);
    
    $consultation = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$consultation) {
        // Debug détaillé
        echo "<div style='background: #f8d7da; color: #721c24; padding: 1rem; margin: 1rem; border-radius: 5px;'>";
        echo "<h3>Erreur d'accès</h3>";
        echo "<p><strong>Consultation ID:</strong> $consultationID</p>";
        echo "<p><strong>Votre ID:</strong> $patientID</p>";
        echo "<p><strong>Votre rôle:</strong> " . $_SESSION['role'] . "</p>";
        
        // Vérifier si la consultation existe
        $checkConsultation = $pdoMedical->prepare("SELECT * FROM consultations WHERE id = ?");
        $checkConsultation->execute([$consultationID]);
        $consultationExists = $checkConsultation->fetch();
        
        if ($consultationExists) {
            echo "<p><strong>Statut consultation:</strong> Existe</p>";
            
            // Vérifier à quel patient appartient cette consultation
            $checkPatient = $pdoMedical->prepare("
                SELECT r.patient_id, r.medecin_id 
                FROM consultations c
                JOIN rendez_vous r ON c.rendez_vous_id = r.id
                WHERE c.id = ?
            ");
            $checkPatient->execute([$consultationID]);
            $rdvData = $checkPatient->fetch();
            
            if ($rdvData) {
                echo "<p><strong>Patient ID de la consultation:</strong> " . $rdvData['patient_id'] . "</p>";
                echo "<p><strong>Médecin ID de la consultation:</strong> " . $rdvData['medecin_id'] . "</p>";
            }
        } else {
            echo "<p><strong>Statut consultation:</strong> N'existe pas</p>";
        }
        echo "</div>";
        die("Consultation non trouvée ou vous n'avez pas accès à cette consultation");
    }

} catch (PDOException $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 1rem; margin: 1rem; border-radius: 5px;'>";
    echo "<h3>Erreur de base de données</h3>";
    echo "<p><strong>Message:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Consultation ID:</strong> $consultationID</p>";
    echo "<p><strong>Votre ID:</strong> $patientID</p>";
    echo "</div>";
    die("Erreur technique");
}

// Fonction utilitaire pour formater les dates
function formatDate(?string $dateString): string {
    if (empty($dateString)) {
        return 'Non spécifié';
    }
    
    try {
        $date = new DateTime($dateString);
        return $date->format('d/m/Y à H:i');
    } catch (Exception $e) {
        return 'Date invalide';
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ma Consultation #<?= $consultationID ?> | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            width: 95%;
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--light-gray);
        }
        
        h1 {
            color: var(--primary);
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .consultation-card {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .patient-header {
            background: linear-gradient(135deg, var(--success), var(--info));
            color: var(--white);
            padding: 1.5rem;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }
        
        .patient-header h2 {
            font-size: 1.5rem;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .patient-meta {
            display: flex;
            gap: 1.5rem;
            color: rgba(255,255,255,0.9);
            font-size: 0.95rem;
        }
        
        .patient-meta span {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .medecin-info {
            background: var(--light);
            padding: 1.5rem;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .medecin-info h3 {
            color: var(--primary);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.7rem;
        }
        
        .consultation-content {
            padding: 2rem;
        }
        
        .consultation-section {
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px dashed var(--light-gray);
        }
        
        .consultation-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        h3 {
            color: var(--primary-dark);
            margin-bottom: 1rem;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.7rem;
        }
        
        .consultation-text {
            background: var(--light-gray);
            padding: 1.2rem;
            border-radius: 8px;
            line-height: 1.7;
            white-space: pre-wrap;
        }
        
        .consultation-meta {
            background: var(--light-gray);
            padding: 1rem;
            text-align: center;
            font-size: 0.9rem;
            color: var(--gray);
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.95rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            background-color: var(--primary);
            color: var(--white);
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.3);
        }
        
        .btn-secondary {
            background-color: var(--gray);
        }
        
        .btn-secondary:hover {
            background-color: #7f8c8d;
        }
        
        .btn i {
            font-size: 1rem;
        }
        
        .medical-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .info-card {
            background: var(--light-gray);
            padding: 1rem;
            border-radius: 8px;
            border-left: 3px solid var(--primary);
        }
        
        .info-card h4 {
            font-size: 0.9rem;
            color: var(--gray);
            margin-bottom: 0.5rem;
        }
        
        .info-card p {
            font-weight: 500;
            color: var(--dark);
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            flex-wrap: wrap;
        }
        
        .no-data {
            color: var(--gray);
            font-style: italic;
            text-align: center;
            padding: 2rem;
        }
        
        .debug-info {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #856404;
        }
        
        @media (max-width: 768px) {
            .patient-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
            
            .patient-meta {
                flex-wrap: wrap;
                gap: 1rem;
            }
            
            .consultation-content {
                padding: 1.5rem;
            }
            
            .medical-info {
                grid-template-columns: 1fr;
            }
            
            .consultation-meta {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-file-medical-alt"></i> Ma Consultation #<?= $consultationID ?></h1>
            <a href="javascript:history.back()" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Retour</a>
        </div>
        
        <!-- Debug info -->
        <div class="debug-info">
            <strong>Informations de session:</strong> 
            Consultation ID: <?= $consultationID ?> | 
            Votre ID: <?= $patientID ?> | 
            Rôle: <?= $_SESSION['role'] ?> |
            User ID session: <?= $_SESSION['user_id'] ?>
        </div>
        
        <div class="consultation-meta">
            <span><i class="fas fa-hashtag"></i> Consultation ID: <?= $consultation['consultation_id'] ?></span>
            <span><i class="fas fa-calendar-alt"></i> Rendez-vous ID: <?= $consultation['rdv_id'] ?></span>
            <span><i class="fas fa-clock"></i> Date: <?= formatDate($consultation['date_rdv']) ?></span>
        </div>
        
        <div class="consultation-card">
            <div class="patient-header">
                <h2><i class="fas fa-user-injured"></i> <?= htmlspecialchars($consultation['patient_prenom'] . ' ' . $consultation['patient_nom']) ?></h2>
                <div class="patient-meta">
                    <span><i class="fas fa-birthday-cake"></i> Né(e) le <?= date('d/m/Y', strtotime($consultation['date_naissance'])) ?></span>
                    <span><i class="fas fa-calendar-day"></i> Consultation du <?= date('d/m/Y', strtotime($consultation['date_rdv'])) ?></span>
                </div>
            </div>
            
            <div class="medecin-info">
                <h3><i class="fas fa-user-md"></i> Médecin traitant</h3>
                <p><strong>Dr. <?= htmlspecialchars($consultation['medecin_prenom'] . ' ' . $consultation['medecin_nom']) ?></strong> - <?= htmlspecialchars($consultation['specialite'] ?? 'Médecine générale') ?></p>
            </div>
            
            <div class="consultation-content">
                <div class="medical-info">
                    <div class="info-card">
                        <h4><i class="fas fa-tint"></i> Groupe sanguin</h4>
                        <p><?= $consultation['groupe_sanguin'] ?? 'Non renseigné' ?></p>
                    </div>
                    
                    <div class="info-card">
                        <h4><i class="fas fa-allergies"></i> Allergies connues</h4>
                        <p><?= !empty($consultation['allergies']) ? nl2br(htmlspecialchars($consultation['allergies'])) : 'Aucune allergie déclarée' ?></p>
                    </div>
                    
                    <div class="info-card">
                        <h4><i class="fas fa-history"></i> Antécédents médicaux</h4>
                        <p><?= !empty($consultation['antecedents']) ? nl2br(htmlspecialchars($consultation['antecedents'])) : 'Aucun antécédent déclaré' ?></p>
                    </div>
                </div>
                
                <div class="consultation-section">
                    <h3><i class="fas fa-comment-medical"></i> Motif de la consultation</h3>
                    <div class="consultation-text">
                        <?= !empty($consultation['motif']) ? nl2br(htmlspecialchars($consultation['motif'])) : nl2br(htmlspecialchars($consultation['type_rdv'])) ?>
                    </div>
                </div>
                
                <?php if (!empty($consultation['diagnostic'])): ?>
                <div class="consultation-section">
                    <h3><i class="fas fa-diagnoses"></i> Diagnostic médical</h3>
                    <div class="consultation-text">
                        <?= nl2br(htmlspecialchars($consultation['diagnostic'])) ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($consultation['prescription'])): ?>
                <div class="consultation-section">
                    <h3><i class="fas fa-prescription-bottle-alt"></i> Prescription médicale</h3>
                    <div class="consultation-text">
                        <?= nl2br(htmlspecialchars($consultation['prescription'])) ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($consultation['examens'])): ?>
                <div class="consultation-section">
                    <h3><i class="fas fa-microscope"></i> Examens demandés</h3>
                    <div class="consultation-text">
                        <?= nl2br(htmlspecialchars($consultation['examens'])) ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (empty($consultation['diagnostic']) && empty($consultation['prescription']) && empty($consultation['examens'])): ?>
                <div class="no-data">
                    <i class="fas fa-info-circle fa-2x" style="margin-bottom: 1rem;"></i>
                    <p>Les détails de cette consultation ne sont pas encore disponibles.<br>Veuillez contacter votre médecin pour plus d'informations.</p>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="consultation-meta">
                <p><i class="fas fa-calendar-check"></i> Consultation enregistrée le <?= date('d/m/Y à H:i', strtotime($consultation['date_creation'])) ?></p>
            </div>
        </div>
        
        <div class="action-buttons">
            <a href="mes_consultation.php" class="btn"><i class="fas fa-list"></i> Mes Consultations</a>
            <a href="../etudiant/dashboard_etudiant.php" class="btn btn-secondary"><i class="fas fa-home"></i> Tableau de bord</a>
            <button onclick="window.print()" class="btn"><i class="fas fa-print"></i> Imprimer</button>
        </div>
    </div>
</body>
</html>