<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "../config/db.php";

// Vérification rôle médecin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'medecin') {
    header("Location: ../auth.php");
    exit;
}

$medecinID = intval(preg_replace('/^[A-Z]+_/', '', $_SESSION['user_id']));
$patientID = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : 0;

if ($patientID === 0) {
    die("ID patient invalide");
}

// Récupérer les informations du patient
try {
    $queryPatient = $pdoMedical->prepare("
        SELECT u.id, u.prenom, u.nom, u.email, u.telephone,
               p.date_naissance, p.groupe_sanguin, p.allergies, p.antecedents
        FROM utilisateurs u
        JOIN patients p ON u.id = p.utilisateur_id
        WHERE u.id = ? AND u.role = 'etudiant'
    ");
    $queryPatient->execute([$patientID]);
    $patient = $queryPatient->fetch();

    if (!$patient) {
        die("Patient non trouvé");
    }

} catch (PDOException $e) {
    die("Erreur base de données: " . $e->getMessage());
}

// Traitement du formulaire
$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validation CSRF
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new RuntimeException("Session expirée. Veuillez actualiser la page.");
        }

        // Validation des champs obligatoires
        $requiredFields = ['diagnostic', 'date_consultation'];
        foreach ($requiredFields as $field) {
            if (empty($_POST[$field])) {
                throw new RuntimeException("Le champ $field est obligatoire");
            }
        }

        // Nettoyage des données
        $diagnostic = htmlspecialchars($_POST['diagnostic']);
        $prescription = htmlspecialchars($_POST['prescription'] ?? '');
        $examens = htmlspecialchars($_POST['examens'] ?? '');
        $notes = htmlspecialchars($_POST['notes'] ?? '');
        $date_consultation = $_POST['date_consultation'];

        // Vérifier si un rendez-vous existe pour cette consultation
        $queryRdv = $pdoMedical->prepare("
            SELECT id FROM rendez_vous 
            WHERE patient_id = ? AND medecin_id = ? AND DATE(date_rdv) = ?
            ORDER BY date_rdv DESC LIMIT 1
        ");
        $queryRdv->execute([$patientID, $medecinID, $date_consultation]);
        $rdv = $queryRdv->fetch();

        $rendez_vous_id = null;
        
        if ($rdv) {
            $rendez_vous_id = $rdv['id'];
        } else {
            // Créer un nouveau rendez-vous pour cette consultation
            // Vérifier d'abord la structure de la table rendez_vous
            $tableStructure = $pdoMedical->query("DESCRIBE rendez_vous")->fetchAll(PDO::FETCH_COLUMN);
            
            if (in_array('created_by', $tableStructure)) {
                $insertRdv = $pdoMedical->prepare("
                    INSERT INTO rendez_vous (patient_id, medecin_id, type_rdv, date_rdv, statut, motif, created_by, created_at)
                    VALUES (?, ?, 'consultation', ?, 'Terminé', 'Consultation médicale', ?, NOW())
                ");
                $insertRdv->execute([$patientID, $medecinID, $date_consultation, $medecinID]);
            } else {
                $insertRdv = $pdoMedical->prepare("
                    INSERT INTO rendez_vous (patient_id, medecin_id, type_rdv, date_rdv, statut, motif)
                    VALUES (?, ?, 'consultation', ?, 'Terminé', 'Consultation médicale')
                ");
                $insertRdv->execute([$patientID, $medecinID, $date_consultation]);
            }
            $rendez_vous_id = $pdoMedical->lastInsertId();
        }

        // Vérifier si la table consultations existe
        $tables = $pdoMedical->query("SHOW TABLES LIKE 'consultations'")->fetch();
        
        if ($tables) {
            // Vérifier la structure de la table consultations
            $consultStructure = $pdoMedical->query("DESCRIBE consultations")->fetchAll(PDO::FETCH_COLUMN);
            
            if (in_array('created_by', $consultStructure)) {
                $insertConsultation = $pdoMedical->prepare("
                    INSERT INTO consultations (rendez_vous_id, diagnostic, prescription, examens, notes, created_by, date_creation)
                    VALUES (?, ?, ?, ?, ?, ?, NOW())
                ");
                $insertConsultation->execute([
                    $rendez_vous_id, 
                    $diagnostic, 
                    $prescription, 
                    $examens, 
                    $notes, 
                    $medecinID
                ]);
            } else {
                $insertConsultation = $pdoMedical->prepare("
                    INSERT INTO consultations (rendez_vous_id, diagnostic, prescription, examens, notes, date_creation)
                    VALUES (?, ?, ?, ?, ?, NOW())
                ");
                $insertConsultation->execute([
                    $rendez_vous_id, 
                    $diagnostic, 
                    $prescription, 
                    $examens, 
                    $notes
                ]);
            }
        } else {
            // Stocker les informations dans rendez_vous si consultations n'existe pas
            // Vérifier si la colonne notes_medecin existe
            $rdvStructure = $pdoMedical->query("DESCRIBE rendez_vous")->fetchAll(PDO::FETCH_COLUMN);
            
            if (in_array('notes_medecin', $rdvStructure)) {
                $updateRdv = $pdoMedical->prepare("
                    UPDATE rendez_vous 
                    SET motif = ?, notes_medecin = ?, statut = 'Terminé'
                    WHERE id = ?
                ");
                $updateRdv->execute([
                    "Consultation - " . substr($diagnostic, 0, 100),
                    "Diagnostic: " . $diagnostic . "\nPrescription: " . $prescription . "\nExamens: " . $examens . "\nNotes: " . $notes,
                    $rendez_vous_id
                ]);
            } else {
                // Si notes_medecin n'existe pas, utiliser motif pour stocker les informations
                $updateRdv = $pdoMedical->prepare("
                    UPDATE rendez_vous 
                    SET motif = ?, statut = 'Terminé'
                    WHERE id = ?
                ");
                $updateRdv->execute([
                    "Consultation - Diagnostic: " . substr($diagnostic, 0, 200),
                    $rendez_vous_id
                ]);
            }
        }

        $success = true;
        $message = "Consultation enregistrée avec succès";

    } catch (RuntimeException $e) {
        $message = $e->getMessage();
    } catch (PDOException $e) {
        error_log("Erreur consultation: " . $e->getMessage());
        $message = "Erreur lors de l'enregistrement de la consultation: " . $e->getMessage();
    }
}

// Générer token CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nouvelle Consultation | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            width: 95%;
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
        .nav-header {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1rem 2rem;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-links a {
            color: var(--primary);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .nav-links a:hover {
            color: var(--primary-dark);
        }
        
        .page-header {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        .page-header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
        }
        
        .patient-info-card {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            border-left: 4px solid var(--primary);
        }
        
        .consultation-form {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 2px solid var(--light-gray);
            border-radius: 6px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            background-color: var(--primary);
            color: var(--white);
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.2);
        }
        
        .btn-success {
            background-color: var(--success);
        }
        
        .btn-success:hover {
            background-color: #27ae60;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1.5rem;
        }
        
        .alert-success {
            background-color: rgba(46, 204, 113, 0.1);
            border: 1px solid var(--success);
            color: #155724;
        }
        
        .alert-danger {
            background-color: rgba(231, 76, 60, 0.1);
            border: 1px solid var(--danger);
            color: #721c24;
        }
        
        .required::after {
            content: " *";
            color: var(--danger);
        }
        
        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 0 0.5rem;
            }
            
            .nav-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .nav-links {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 1rem;
            }
            
            .nav-links a {
                margin: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Header -->
        <div class="nav-header">
            <div>
                <h3><i class="fas fa-user-md"></i> Espace Médecin</h3>
            </div>
            <div class="nav-links">
                <a href="../dossiers/liste_dossier.php"><i class="fas fa-folder-open"></i> Dossiers</a>
                <a href="../medecin/dashboard_medecin.php"><i class="fas fa-home"></i> Tableau de bord</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
            </div>
        </div>

        <!-- Page Header -->
        <div class="page-header">
            <h1><i class="fas fa-stethoscope"></i> Nouvelle Consultation</h1>
            <p class="text-gray">Rédiger un nouveau compte-rendu de consultation</p>
        </div>

        <!-- Informations patient -->
        <div class="patient-info-card">
            <h3><i class="fas fa-user-injured"></i> Patient : <?= htmlspecialchars($patient['prenom'] . ' ' . $patient['nom']) ?></h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem;">
                <div>
                    <strong>Email :</strong> <?= htmlspecialchars($patient['email']) ?>
                </div>
                <div>
                    <strong>Téléphone :</strong> <?= htmlspecialchars($patient['telephone'] ?? 'Non renseigné') ?>
                </div>
                <div>
                    <strong>Date de naissance :</strong> 
                    <?= $patient['date_naissance'] ? date('d/m/Y', strtotime($patient['date_naissance'])) : 'Non renseignée' ?>
                </div>
                <div>
                    <strong>Groupe sanguin :</strong> <?= htmlspecialchars($patient['groupe_sanguin'] ?? 'Non renseigné') ?>
                </div>
            </div>
            <?php if ($patient['allergies']): ?>
            <div style="margin-top: 1rem;">
                <strong>Allergies :</strong> <?= nl2br(htmlspecialchars($patient['allergies'])) ?>
            </div>
            <?php endif; ?>
            <?php if ($patient['antecedents']): ?>
            <div style="margin-top: 1rem;">
                <strong>Antécédents :</strong> <?= nl2br(htmlspecialchars($patient['antecedents'])) ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Messages -->
        <?php if ($message): ?>
            <div class="alert alert-<?= $success ? 'success' : 'danger' ?>">
                <i class="fas <?= $success ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
                <?= htmlspecialchars($message) ?>
            </div>
            
            <?php if ($success): ?>
                <div style="text-align: center; margin: 2rem 0;">
                    <a href="../dossiers/dossier_patient.php?id=<?= $patientID ?>" class="btn btn-success">
                        <i class="fas fa-folder-open"></i> Voir le dossier patient
                    </a>
                    <a href="nouvelle_consultation.php?patient_id=<?= $patientID ?>" class="btn">
                        <i class="fas fa-plus"></i> Nouvelle consultation
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php if (!$success): ?>
        <!-- Formulaire de consultation -->
        <form method="POST" class="consultation-form">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <div class="form-group">
                <label for="date_consultation" class="required">
                    <i class="fas fa-calendar-alt"></i> Date de la consultation
                </label>
                <input type="date" 
                       id="date_consultation" 
                       name="date_consultation" 
                       class="form-control" 
                       value="<?= date('Y-m-d') ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label for="diagnostic" class="required">
                    <i class="fas fa-diagnoses"></i> Diagnostic
                </label>
                <textarea id="diagnostic" 
                          name="diagnostic" 
                          class="form-control" 
                          placeholder="Décrivez le diagnostic..."
                          required><?= isset($_POST['diagnostic']) ? htmlspecialchars($_POST['diagnostic']) : '' ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="prescription">
                    <i class="fas fa-prescription"></i> Prescription
                </label>
                <textarea id="prescription" 
                          name="prescription" 
                          class="form-control" 
                          placeholder="Médicaments prescrits, posologie..."><?= isset($_POST['prescription']) ? htmlspecialchars($_POST['prescription']) : '' ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="examens">
                    <i class="fas fa-microscope"></i> Examens complémentaires
                </label>
                <textarea id="examens" 
                          name="examens" 
                          class="form-control" 
                          placeholder="Examens demandés, résultats..."><?= isset($_POST['examens']) ? htmlspecialchars($_POST['examens']) : '' ?></textarea>
            </div>
            
            <div class="form-group">
                <label for="notes">
                    <i class="fas fa-notes-medical"></i> Notes supplémentaires
                </label>
                <textarea id="notes" 
                          name="notes" 
                          class="form-control" 
                          placeholder="Observations, recommandations..."><?= isset($_POST['notes']) ? htmlspecialchars($_POST['notes']) : '' ?>
                </textarea>
            </div>
            
            <div class="form-group" style="text-align: center; margin-top: 2rem;">
                <button type="submit" class="btn btn-success" style="padding: 1rem 2rem; font-size: 1.1rem;">
                    <i class="fas fa-save"></i> Enregistrer la consultation
                </button>
                <a href="../dossiers/dossier_medical.php?id=<?= $patientID ?>" class="btn" style="margin-left: 1rem;">
                    <i class="fas fa-times"></i> Annuler
                </a>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <script>
        // Définir la date d'aujourd'hui par défaut
        document.addEventListener('DOMContentLoaded', function() {
            const dateField = document.getElementById('date_consultation');
            if (dateField && !dateField.value) {
                dateField.value = '<?= date('Y-m-d') ?>';
            }
        });
    </script>
</body>
</html>