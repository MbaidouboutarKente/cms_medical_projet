<?php
session_start();
require_once "../../config/db.php";

// Vérification du rôle Admin ou Super Admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'super_admin' && $_SESSION['role'] !== 'admin')) {
    header("Location: ../../config/auth.php");
    exit;
}

// Gestion des erreurs et des messages
$errors = $_SESSION['errors'] ?? [];
$success = $_SESSION['success'] ?? "";
unset($_SESSION['errors'], $_SESSION['success']);

// Initialisation des variables
$medicaments = [];
$totalMedicaments = 0;
$totalPages = 1;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Recherche et filtres
$search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '';
$stockFilter = filter_input(INPUT_GET, 'stock', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '';

// Vérification des permissions des dossiers
$uploadDirs = [
    '../../../img/medicaments/' => 'Dossier principal',
    '../../../img/' => 'Dossier images',
    '../../../uploads/' => 'Dossier uploads',
    '../../temp_images/' => 'Dossier temporaire'
];

$writableDir = null;
foreach ($uploadDirs as $dir => $description) {
    if (is_dir($dir) && is_writable($dir)) {
        $writableDir = $dir;
        break;
    }
}

// Si aucun dossier n'est accessible en écriture, utiliser le dossier temporaire système
if (!$writableDir) {
    $tempDir = sys_get_temp_dir() . '/medicaments/';
    if (!is_dir($tempDir)) {
        mkdir($tempDir, 0755, true);
    }
    if (is_dir($tempDir) && is_writable($tempDir)) {
        $writableDir = $tempDir;
    }
}

try {
    // Vérification de la connexion à la base de données
    if (!$pdoMedical) {
        throw new PDOException("Impossible de se connecter à la base de données");
    }

    // Construction de la requête avec filtres
    $query = "SELECT * FROM medicaments WHERE 1=1";
    $countQuery = "SELECT COUNT(*) FROM medicaments WHERE 1=1";
    $params = [];
    
    if (!empty($search)) {
        $query .= " AND nom LIKE ?";
        $countQuery .= " AND nom LIKE ?";
        $params[] = "%$search%";
    }
    
    if ($stockFilter === 'low') {
        $query .= " AND stock <= 10";
        $countQuery .= " AND stock <= 10";
    } elseif ($stockFilter === 'out') {
        $query .= " AND stock = 0";
        $countQuery .= " AND stock = 0";
    }
    
    $query .= " ORDER BY nom LIMIT ? OFFSET ?";
    
    // Préparation et exécution de la requête principale
    $stmt = $pdoMedical->prepare($query);
    
    // Ajout des paramètres pour la pagination
    $paginationParams = array_merge($params, [$limit, $offset]);
    
    // Liaison des paramètres
    foreach ($paginationParams as $key => $value) {
        $paramType = is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR;
        $stmt->bindValue($key + 1, $value, $paramType);
    }
    
    $stmt->execute();
    $medicaments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Comptage total pour la pagination
    $countStmt = $pdoMedical->prepare($countQuery);
    if (!empty($params)) {
        $countStmt->execute($params);
    } else {
        $countStmt->execute();
    }
    $totalMedicaments = $countStmt->fetchColumn();
    $totalPages = ceil($totalMedicaments / $limit);
    
} catch (PDOException $e) {
    error_log("Erreur BD médicaments: " . $e->getMessage());
    $errors[] = "❌ Erreur de chargement des médicaments : " . $e->getMessage();
}

// Suppression d'un médicament
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_id"])) {
    $deleteId = intval($_POST["delete_id"]);
    
    try {
        // Vérifier si le médicament est utilisé dans des commandes
        $stmt = $pdoMedical->prepare("SELECT COUNT(*) FROM details_commande WHERE medicament_id = ?");
        $stmt->execute([$deleteId]);
        $usageCount = $stmt->fetchColumn();
        
        if ($usageCount > 0) {
            $_SESSION['errors'] = ["❌ Ce médicament est utilisé dans des commandes et ne peut pas être supprimé."];
        } else {
            // Supprimer les images associées de tous les dossiers possibles
            foreach ($uploadDirs as $dir => $description) {
                if (is_dir($dir)) {
                    $imagePattern = $dir . $deleteId . ".*";
                    $files = glob($imagePattern);
                    foreach ($files as $file) {
                        if (is_file($file)) {
                            unlink($file);
                        }
                    }
                }
            }
            
            // Supprimer le médicament
            $stmt = $pdoMedical->prepare("DELETE FROM medicaments WHERE id = ?");
            $stmt->execute([$deleteId]);
            
            $_SESSION['success'] = "✅ Médicament supprimé avec succès.";
        }
        
        header("Location: gestion_medicaments.php");
        exit;
    } catch (PDOException $e) {
        $_SESSION['errors'] = ["❌ Erreur lors de la suppression : " . $e->getMessage()];
        header("Location: gestion_medicaments.php");
        exit;
    }
}

// Récupération du médicament à modifier
$editId = isset($_GET['edit_id']) ? intval($_GET['edit_id']) : null;
$medicamentEdit = null;

if ($editId) {
    try {
        $stmt = $pdoMedical->prepare("SELECT * FROM medicaments WHERE id = ?");
        $stmt->execute([$editId]);
        $medicamentEdit = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$medicamentEdit) {
            $errors[] = "❌ Médicament non trouvé.";
            $editId = null;
        }
    } catch (PDOException $e) {
        $errors[] = "❌ Erreur de récupération du médicament : " . $e->getMessage();
    }
}

// Modification d'un médicament
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["modifier"])) {
    $editId = intval($_POST["edit_id"]);
    $nom = filter_input(INPUT_POST, "nom", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $prix = filter_input(INPUT_POST, "prix", FILTER_VALIDATE_FLOAT);
    $stock = filter_input(INPUT_POST, "stock", FILTER_VALIDATE_INT);
    $description = filter_input(INPUT_POST, "description", FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    if (empty($nom)) {
        $errors[] = "⚠️ Le nom est obligatoire.";
    }
    if ($prix === false || $prix <= 0) {
        $errors[] = "⚠️ Prix invalide.";
    }
    if ($stock === false || $stock < 0) {
        $errors[] = "⚠️ Stock invalide.";
    }

    if (empty($errors)) {
        try {
            $stmt = $pdoMedical->prepare("UPDATE medicaments SET nom = ?, prix = ?, stock = ?, description = COALESCE(?, description) WHERE id = ?");
            $stmt->execute([$nom, $prix, $stock, $description, $editId]);

            // Gestion de l'image si téléchargée - UTILISATION DU DOSSIER ACCESSIBLE
            if (!empty($_FILES['image']['name']) && $writableDir) {
                // Supprimer les anciennes images de tous les dossiers
                foreach ($uploadDirs as $dir => $description) {
                    if (is_dir($dir)) {
                        $oldImages = glob($dir . $editId . ".*");
                        foreach ($oldImages as $oldImage) {
                            if (is_file($oldImage)) {
                                unlink($oldImage);
                            }
                        }
                    }
                }
                
                // Télécharger la nouvelle image dans le dossier accessible
                $extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
                
                if (in_array($extension, $allowedExtensions)) {
                    $targetFile = $writableDir . $editId . '.' . $extension;
                    
                    if (!move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                        // Si move_uploaded_file échoue, essayer avec copy
                        if (!copy($_FILES['image']['tmp_name'], $targetFile)) {
                            $errors[] = "⚠️ Erreur lors du téléchargement de l'image. Dossier utilisé: " . $writableDir;
                        }
                    }
                } else {
                    $errors[] = "⚠️ Format d'image non supporté. Utilisez JPG, PNG ou WebP.";
                }
            } elseif (!empty($_FILES['image']['name']) && !$writableDir) {
                $errors[] = "⚠️ Impossible de sauvegarder l'image : aucun dossier n'est accessible en écriture.";
            }

            if (empty($errors)) {
                $_SESSION["success"] = "✅ Médicament mis à jour avec succès." . 
                                     ($writableDir ? " Images sauvegardées dans: " . $writableDir : "");
                header("Location: gestion_medicaments.php");
                exit;
            }
        } catch (PDOException $e) {
            $errors[] = "❌ Erreur lors de la modification : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🩺 Gestion des Médicaments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
            --light-color: #f8f9fc;
            --dark-color: #5a5c69;
        }
        
        .medicament-management {
            background-color: #f8f9fc;
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
            padding: 1rem 1.25rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
        }
        
        .permission-info {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .permission-info.alert-warning {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        
        .debug-info {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1rem;
            font-family: monospace;
            font-size: 0.875rem;
        }
        
        .table-responsive {
            border-radius: 0 0 0.75rem 0.75rem;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: var(--dark-color);
            padding: 1rem 0.75rem;
            background-color: #f8f9fc;
        }
        
        .table td {
            padding: 0.75rem;
            vertical-align: middle;
        }
        
        .medicament-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #e3e6f0;
        }
        
        .stock-low {
            color: var(--warning-color);
            font-weight: bold;
        }
        
        .stock-out {
            color: var(--danger-color);
            font-weight: bold;
        }
        
        .stock-ok {
            color: var(--success-color);
            font-weight: bold;
        }
        
        .btn-action {
            padding: 0.25rem 0.5rem;
            margin: 0.1rem;
            border-radius: 0.35rem;
            transition: all 0.15s ease-in-out;
        }
        
        .btn-action:hover {
            transform: translateY(-1px);
        }
        
        .image-preview {
            max-width: 200px;
            max-height: 200px;
            border-radius: 8px;
            border: 2px dashed #dee2e6;
            padding: 0.5rem;
        }
        
        .solution-box {
            background: #e8f5e8;
            border: 1px solid #4caf50;
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .code-block {
            background: #2d3748;
            color: #e2e8f0;
            padding: 1rem;
            border-radius: 0.25rem;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            margin: 0.5rem 0;
        }
    </style>
</head>
<body class="medicament-management">
    <div class="container-fluid py-4">
        <!-- Messages flash -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Erreurs</h5>
                <?php foreach ($errors as $error): ?>
                    <div><?= htmlspecialchars($error) ?></div>
                <?php endforeach; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Information sur les permissions -->
        <div class="permission-info <?= $writableDir ? 'alert-info' : 'alert-warning' ?>">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-1">
                        <i class="fas fa-<?= $writableDir ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
                        Statut des permissions
                    </h5>
                    <p class="mb-0">
                        <?php if ($writableDir): ?>
                            ✓ Les images sont sauvegardées dans : <strong><?= htmlspecialchars($writableDir) ?></strong>
                        <?php else: ?>
                            ✗ Aucun dossier n'est accessible en écriture. Les images ne seront pas sauvegardées.
                        <?php endif; ?>
                    </p>
                </div>
                <?php if (!$writableDir): ?>
                    <button type="button" class="btn btn-light btn-sm" data-bs-toggle="collapse" data-bs-target="#solution">
                        <i class="fas fa-wrench me-1"></i> Solution
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <!-- Solution pour les permissions -->
        <?php if (!$writableDir): ?>
        <div class="collapse" id="solution">
            <div class="solution-box">
                <h5><i class="fas fa-tools me-2"></i>Pour résoudre le problème de permissions :</h5>
                <p class="mb-3">Exécutez ces commandes dans votre terminal :</p>
                
                <div class="code-block">
                    # Se placer dans le dossier du projet<br>
                    cd /opt/lampp/htdocs/clark/cms_medical_project/<br><br>
                    
                    # Créer le dossier et donner les permissions<br>
                    sudo mkdir -p img/medicaments/<br>
                    sudo chmod 755 img/medicaments/<br>
                    sudo chown www-data:www-data img/medicaments/
                </div>
                
                <p class="mb-0 mt-2">
                    <strong>Alternative :</strong> Utilisez le shell de XAMPP et exécutez les mêmes commandes sans "sudo".
                </p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Debug info -->
        <?php if (!empty($errors)): ?>
        <div class="debug-info">
            <strong>Informations de débogage :</strong><br>
            - Connexion BD : <?= $pdoMedical ? 'OK' : 'ERREUR' ?><br>
            - Dossier accessible : <?= $writableDir ? htmlspecialchars($writableDir) : 'AUCUN' ?><br>
            - Nombre de médicaments : <?= $totalMedicaments ?><br>
            - Page actuelle : <?= $page ?><br>
            - Recherche : "<?= $search ?>"
        </div>
        <?php endif; ?>

        <!-- Le reste du code reste inchangé -->
        <!-- Titre et boutons -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-pills me-2"></i>Gestion des Médicaments</h1>
                <p class="text-muted mb-0">Gérez l'inventaire et les informations des médicaments</p>
            </div>
            <a href="ajout_medicament.php" class="d-none d-sm-inline-block btn btn-primary shadow-sm">
                <i class="fas fa-plus fa-sm text-white-50 me-1"></i> Ajouter un médicament
            </a>
        </div>

        <!-- Cartes de statistiques -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Total Médicaments
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalMedicaments ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-pills fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Les autres cartes de statistiques restent inchangées -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100 border-left-success">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    En Stock
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php 
                                        try {
                                            $stmt = $pdoMedical->query("SELECT COUNT(*) FROM medicaments WHERE stock > 10");
                                            echo $stmt->fetchColumn();
                                        } catch (PDOException $e) {
                                            echo "0";
                                        }
                                    ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100 border-left-warning">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    Stock Faible
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php 
                                        try {
                                            $stmt = $pdoMedical->query("SELECT COUNT(*) FROM medicaments WHERE stock <= 10 AND stock > 0");
                                            echo $stmt->fetchColumn();
                                        } catch (PDOException $e) {
                                            echo "0";
                                        }
                                    ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100 border-left-danger">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                    Rupture de Stock
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php 
                                        try {
                                            $stmt = $pdoMedical->query("SELECT COUNT(*) FROM medicaments WHERE stock = 0");
                                            echo $stmt->fetchColumn();
                                        } catch (PDOException $e) {
                                            echo "0";
                                        }
                                    ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-times-circle fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filtres et recherche -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-filter me-2"></i>Filtres et Recherche
                </h6>
            </div>
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-5">
                        <label class="form-label">Recherche par nom</label>
                        <input type="text" name="search" class="form-control" placeholder="Rechercher..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">État du stock</label>
                        <select name="stock" class="form-control">
                            <option value="">Tous les stocks</option>
                            <option value="low" <?= $stockFilter === 'low' ? 'selected' : '' ?>>Stock faible (≤ 10)</option>
                            <option value="out" <?= $stockFilter === 'out' ? 'selected' : '' ?>>Rupture de stock</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">&nbsp;</label>
                        <div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-filter me-1"></i> Appliquer
                            </button>
                            <a href="gestion_medicaments.php" class="btn btn-secondary w-100 mt-2">
                                <i class="fas fa-times me-1"></i> Réinitialiser
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tableau des médicaments -->
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-table me-2"></i>Liste des Médicaments
                </h6>
                <span class="badge bg-primary"><?= $totalMedicaments ?> médicament(s)</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover" width="100%" cellspacing="0">
                        <thead class="table-light">
                            <tr>
                                <th>Image</th>
                                <th>Nom</th>
                                <th>Prix</th>
                                <th>Stock</th>
                                <th>Description</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($medicaments)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <i class="fas fa-pills fa-2x text-muted mb-2 d-block"></i>
                                        <span class="text-muted">Aucun médicament trouvé</span>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($medicaments as $medicament): 
                                    // Recherche de l'image dans tous les dossiers possibles
                                    $imagePath = null;
                                    $allDirs = array_merge(array_keys($uploadDirs), $writableDir ? [$writableDir] : []);
                                    foreach ($allDirs as $dir) {
                                        if (is_dir($dir)) {
                                            foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
                                                $potentialPath = $dir . $medicament['id'] . '.' . $ext;
                                                if (file_exists($potentialPath)) {
                                                    $imagePath = $potentialPath;
                                                    break 2;
                                                }
                                            }
                                        }
                                    }
                                    
                                    $stockClass = $medicament['stock'] == 0 ? 'stock-out' : ($medicament['stock'] <= 10 ? 'stock-low' : 'stock-ok');
                                ?>
                                <tr>
                                    <td>
                                        <?php if ($imagePath): ?>
                                            <img src="<?= $imagePath ?>" alt="<?= htmlspecialchars($medicament['nom']) ?>" class="medicament-image">
                                        <?php else: ?>
                                            <div class="medicament-image bg-light d-flex align-items-center justify-content-center">
                                                <i class="fas fa-pills text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?= htmlspecialchars($medicament['nom']) ?></div>
                                        <small class="text-muted">ID: <?= $medicament['id'] ?></small>
                                    </td>
                                    <td class="fw-bold text-primary"><?= number_format($medicament['prix'], 2) ?> Frc</td>
                                    <td class="<?= $stockClass ?>"><?= $medicament['stock'] ?> unités</td>
                                    <td>
                                        <small class="text-muted">
                                            <?= !empty($medicament['description']) ? htmlspecialchars(substr($medicament['description'], 0, 50)) . '...' : 'Aucune description' ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            <a href="?edit_id=<?= $medicament['id'] ?>" class="btn btn-outline-primary btn-action" title="Modifier">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form method="POST" class="d-inline" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer ce médicament ?');">
                                                <input type="hidden" name="delete_id" value="<?= $medicament['id'] ?>">
                                                <button type="submit" class="btn btn-outline-danger btn-action" title="Supprimer">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <div class="card-footer">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&stock=<?= $stockFilter ?>">
                                        <i class="fas fa-chevron-left"></i> Précédent
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php 
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            
                            for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&stock=<?= $stockFilter ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&stock=<?= $stockFilter ?>">
                                        Suivant <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Formulaire de modification -->
        <?php if ($medicamentEdit): ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-edit me-2"></i>Modifier le Médicament
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <form method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="edit_id" value="<?= htmlspecialchars($medicamentEdit['id']) ?>">
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="nom" class="form-label">Nom du médicament</label>
                                        <input type="text" class="form-control" id="nom" name="nom" 
                                               value="<?= htmlspecialchars($medicamentEdit['nom']) ?>" required>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="prix" class="form-label">Prix (Frc)</label>
                                        <input type="number" class="form-control" id="prix" name="prix" 
                                               step="0.01" min="0" value="<?= htmlspecialchars($medicamentEdit['prix']) ?>" required>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="stock" class="form-label">Stock</label>
                                        <input type="number" class="form-control" id="stock" name="stock" 
                                               min="0" value="<?= htmlspecialchars($medicamentEdit['stock']) ?>" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($medicamentEdit['description'] ?? '') ?></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="image" class="form-label">Image du médicament</label>
                                    <input type="file" class="form-control" id="image" name="image" accept="image/jpeg, image/png, image/webp"
                                           <?= !$writableDir ? 'disabled' : '' ?>>
                                    <div class="form-text">
                                        Formats supportés : JPG, PNG, WebP. Taille maximale : 2MB
                                        <?php if (!$writableDir): ?>
                                            <span class="text-danger">- Upload désactivé (problème de permissions)</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <button type="submit" name="modifier" class="btn btn-primary" <?= !$writableDir ? 'title="Les images ne seront pas sauvegardées"' : '' ?>>
                                        <i class="fas fa-save me-1"></i> Mettre à jour
                                    </button>
                                    <a href="gestion_medicaments.php" class="btn btn-secondary">
                                        <i class="fas fa-times me-1"></i> Annuler
                                    </a>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-4">
                            <div class="text-center">
                                <h6 class="mb-3">Image actuelle</h6>
                                <?php
                                $currentImage = null;
                                $allDirs = array_merge(array_keys($uploadDirs), $writableDir ? [$writableDir] : []);
                                foreach ($allDirs as $dir) {
                                    if (is_dir($dir)) {
                                        foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
                                            $path = $dir . $medicamentEdit['id'] . '.' . $ext;
                                            if (file_exists($path)) {
                                                $currentImage = $path;
                                                break 2;
                                            }
                                        }
                                    }
                                }
                                ?>
                                <?php if ($currentImage): ?>
                                    <img src="<?= $currentImage ?>" alt="Image actuelle" class="image-preview img-fluid mb-3">
                                <?php else: ?>
                                    <div class="image-preview d-flex align-items-center justify-content-center bg-light mb-3">
                                        <i class="fas fa-pills fa-3x text-muted"></i>
                                    </div>
                                    <small class="text-muted">Aucune image disponible</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                if (alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }
            }, 5000);
        });
    });
    </script>
</body>
</html> 