<?php
session_start();
require_once "../../config/db.php";

// Vérification du rôle Admin ou Super Admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'super_admin' && $_SESSION['role'] !== 'admin')) {
    header("Location: ../../config/auth.php");
    exit;
}

// Initialisation des variables
$errors = [];
$success = "";
$medicamentData = [
    'nom' => '',
    'prix' => '',
    'stock' => '',
    'description' => '',
    'categorie_id' => ''
];

// Récupération des catégories depuis la base de données
$categories = [];
try {
    if ($pdoMedical) {
        $stmt = $pdoMedical->query("SELECT id, nom FROM categories ORDER BY nom");
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    $errors[] = "❌ Erreur lors du chargement des catégories : " . $e->getMessage();
}

// Vérification des permissions des dossiers
$uploadDirs = [
    '../../../img/medicaments/' => 'Dossier principal',
    '../../../img/' => 'Dossier images',
    '../../../uploads/' => 'Dossier uploads'
];

$writableDir = null;
foreach ($uploadDirs as $dir => $description) {
    if (is_dir($dir) && is_writable($dir)) {
        $writableDir = $dir;
        break;
    }
}

// Si aucun dossier n'est accessible en écriture, utiliser le dossier temporaire système
if (!$writableDir) {
    $tempDir = sys_get_temp_dir() . '/medicaments/';
    if (!is_dir($tempDir)) {
        mkdir($tempDir, 0755, true);
    }
    if (is_dir($tempDir) && is_writable($tempDir)) {
        $writableDir = $tempDir;
    }
}

// Traitement du formulaire d'ajout
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["ajouter"])) {
    // Récupération et validation des données
    $nom = filter_input(INPUT_POST, "nom", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $prix = filter_input(INPUT_POST, "prix", FILTER_VALIDATE_FLOAT);
    $stock = filter_input(INPUT_POST, "stock", FILTER_VALIDATE_INT);
    $description = filter_input(INPUT_POST, "description", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $categorie_id = filter_input(INPUT_POST, "categorie_id", FILTER_VALIDATE_INT);

    // Validation des champs
    if (empty($nom)) {
        $errors[] = "⚠️ Le nom du médicament est obligatoire.";
    }
    
    if ($prix === false || $prix <= 0) {
        $errors[] = "⚠️ Le prix doit être un nombre positif.";
    }
    
    if ($stock === false || $stock < 0) {
        $errors[] = "⚠️ Le stock doit être un nombre positif ou zéro.";
    }
    
    if ($categorie_id === false || $categorie_id <= 0) {
        $errors[] = "⚠️ Veuillez sélectionner une catégorie.";
    }

    // Sauvegarde des données pour réaffichage
    $medicamentData = [
        'nom' => $nom,
        'prix' => $prix,
        'stock' => $stock,
        'description' => $description,
        'categorie_id' => $categorie_id
    ];

    // Si pas d'erreurs, insertion en base
    if (empty($errors)) {
        try {
            // Vérification de la connexion à la base de données
            if (!$pdoMedical) {
                throw new PDOException("Impossible de se connecter à la base de données");
            }

            // Insertion du médicament AVEC la catégorie
            $stmt = $pdoMedical->prepare("INSERT INTO medicaments (nom, prix, stock, description, categorie_id) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$nom, $prix, $stock, $description, $categorie_id]);
            
            // Récupération de l'ID du médicament inséré
            $medicamentId = $pdoMedical->lastInsertId();

            // Gestion de l'image si téléchargée
            $imageUploaded = false;
            if (!empty($_FILES['image']['name']) && $writableDir) {
                $extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
                
                if (in_array($extension, $allowedExtensions)) {
                    // Vérification de la taille du fichier (max 2MB)
                    if ($_FILES['image']['size'] > 2 * 1024 * 1024) {
                        $errors[] = "⚠️ L'image est trop volumineuse. Taille maximale : 2MB.";
                    } else {
                        $targetFile = $writableDir . $medicamentId . '.' . $extension;
                        
                        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                            $imageUploaded = true;
                        } else {
                            $errors[] = "⚠️ Erreur lors du téléchargement de l'image.";
                        }
                    }
                } else {
                    $errors[] = "⚠️ Format d'image non supporté. Utilisez JPG, PNG ou WebP.";
                }
            } elseif (!empty($_FILES['image']['name']) && !$writableDir) {
                $errors[] = "⚠️ Impossible de sauvegarder l'image : aucun dossier n'est accessible en écriture.";
            }

            // Si tout s'est bien passé
            if (empty($errors)) {
                $successMessage = "✅ Médicament ajouté avec succès !";
                if ($imageUploaded) {
                    $successMessage .= " Image sauvegardée dans : " . $writableDir;
                }
                
                $_SESSION['success'] = $successMessage;
                header("Location: gestion_medicaments.php");
                exit;
            }

        } catch (PDOException $e) {
            $errors[] = "❌ Erreur lors de l'ajout du médicament : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🩺 Ajouter un Médicament</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
            --light-color: #f8f9fc;
            --dark-color: #5a5c69;
        }
        
        .medicament-creation {
            background-color: #f8f9fc;
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
            padding: 1.25rem 1.5rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
        }
        
        .permission-info {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .permission-info.alert-warning {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        
        .image-preview-container {
            border: 2px dashed #dee2e6;
            border-radius: 0.5rem;
            padding: 1rem;
            text-align: center;
            background-color: #f8f9fa;
            transition: all 0.3s ease;
        }
        
        .image-preview-container:hover {
            border-color: var(--primary-color);
            background-color: #e3f2fd;
        }
        
        .image-preview {
            max-width: 100%;
            max-height: 300px;
            border-radius: 0.5rem;
            display: none;
        }
        
        .preview-placeholder {
            color: #6c757d;
            font-size: 4rem;
            margin-bottom: 1rem;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }
        
        .required::after {
            content: " *";
            color: var(--danger-color);
        }
        
        .btn {
            border-radius: 0.5rem;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, var(--primary-color), #2e59d9);
            border: none;
            box-shadow: 0 4px 15px rgba(78, 115, 223, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(78, 115, 223, 0.4);
        }
        
        .solution-box {
            background: #e8f5e8;
            border: 1px solid #4caf50;
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        .code-block {
            background: #2d3748;
            color: #e2e8f0;
            padding: 1rem;
            border-radius: 0.25rem;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            margin: 0.5rem 0;
        }
        
        .feature-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(45deg, var(--primary-color), #2e59d9);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .feature-card {
            text-align: center;
            padding: 1.5rem;
            border-radius: 0.5rem;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
        }
        
        .category-badge {
            background: linear-gradient(45deg, var(--info-color), #2c9faf);
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
        }
    </style>
</head>
<body class="medicament-creation">
    <div class="container-fluid py-4">
        <!-- Messages d'erreur -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Erreurs</h5>
                <?php foreach ($errors as $error): ?>
                    <div><?= htmlspecialchars($error) ?></div>
                <?php endforeach; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Information sur les permissions -->
        <div class="permission-info <?= $writableDir ? 'alert-info' : 'alert-warning' ?>">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-1">
                        <i class="fas fa-<?= $writableDir ? 'check-circle' : 'exclamation-triangle' ?> me-2"></i>
                        Statut des permissions
                    </h5>
                    <p class="mb-0">
                        <?php if ($writableDir): ?>
                            ✓ Les images seront sauvegardées dans : <strong><?= htmlspecialchars($writableDir) ?></strong>
                        <?php else: ?>
                            ✗ Aucun dossier n'est accessible en écriture. Les images ne seront pas sauvegardées.
                        <?php endif; ?>
                    </p>
                </div>
                <?php if (!$writableDir): ?>
                    <button type="button" class="btn btn-light btn-sm" data-bs-toggle="collapse" data-bs-target="#solution">
                        <i class="fas fa-wrench me-1"></i> Solution
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <!-- Solution pour les permissions -->
        <?php if (!$writableDir): ?>
        <div class="collapse" id="solution">
            <div class="solution-box">
                <h5><i class="fas fa-tools me-2"></i>Pour résoudre le problème de permissions :</h5>
                <p class="mb-3">Exécutez ces commandes dans votre terminal :</p>
                
                <div class="code-block">
                    # Se placer dans le dossier du projet<br>
                    cd /opt/lampp/htdocs/clark/cms_medical_project/<br><br>
                    
                    # Créer le dossier et donner les permissions<br>
                    sudo mkdir -p img/medicaments/<br>
                    sudo chmod 755 img/medicaments/<br>
                    sudo chown www-data:www-data img/medicaments/
                </div>
                
                <p class="mb-0 mt-2">
                    <strong>Alternative :</strong> Utilisez le shell de XAMPP et exécutez les mêmes commandes sans "sudo".
                </p>
            </div>
        </div>
        <?php endif; ?>

        <!-- En-tête -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 mb-0 text-gray-800">
                    <i class="fas fa-plus-circle me-2"></i>Ajouter un Médicament
                </h1>
                <p class="text-muted mb-0">Remplissez le formulaire pour ajouter un nouveau médicament à l'inventaire</p>
            </div>
            <div class="d-flex gap-2">
                <a href="gestion_medicaments.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Retour à la liste
                </a>
            </div>
        </div>

        <div class="row">
            <!-- Formulaire d'ajout -->
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-pills me-2"></i>Informations du médicament
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data" id="medicamentForm">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="nom" class="form-label required">Nom du médicament</label>
                                    <input type="text" class="form-control" id="nom" name="nom" 
                                           value="<?= htmlspecialchars($medicamentData['nom']) ?>" 
                                           placeholder="Ex: Paracétamol 500mg" required>
                                    <div class="form-text">Nom commercial du médicament</div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="prix" class="form-label required">Prix (Frc)</label>
                                    <input type="number" class="form-control" id="prix" name="prix" 
                                           step="0.01" min="0" value="<?= htmlspecialchars($medicamentData['prix']) ?>" 
                                           placeholder="0.00" required>
                                    <div class="form-text">Prix unitaire en francs</div>
                                </div>
                                
                                <div class="col-md-3 mb-3">
                                    <label for="stock" class="form-label required">Stock initial</label>
                                    <input type="number" class="form-control" id="stock" name="stock" 
                                           min="0" value="<?= htmlspecialchars($medicamentData['stock']) ?>" 
                                           placeholder="0" required>
                                    <div class="form-text">Quantité disponible</div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="categorie_id" class="form-label required">Catégorie</label>
                                    <select class="form-control" id="categorie_id" name="categorie_id" required>
                                        <option value="">Sélectionnez une catégorie</option>
                                        <?php foreach ($categories as $categorie): ?>
                                            <option value="<?= $categorie['id'] ?>" 
                                                <?= $medicamentData['categorie_id'] == $categorie['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($categorie['nom']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">Catégorie du médicament</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Statut des catégories</label>
                                    <div class="d-flex align-items-center h-100">
                                        <?php if (empty($categories)): ?>
                                            <span class="badge bg-danger">
                                                <i class="fas fa-exclamation-triangle me-1"></i>
                                                Aucune catégorie disponible
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-success">
                                                <i class="fas fa-check me-1"></i>
                                                <?= count($categories) ?> catégorie(s) disponible(s)
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" 
                                          rows="3" placeholder="Description du médicament (optionnelle)"><?= htmlspecialchars($medicamentData['description']) ?></textarea>
                                <div class="form-text">Informations supplémentaires sur le médicament</div>
                            </div>
                            
                            <div class="mb-4">
                                <label for="image" class="form-label">Image du médicament</label>
                                <input type="file" class="form-control" id="image" name="image" 
                                       accept="image/jpeg, image/png, image/webp"
                                       <?= !$writableDir ? 'disabled' : '' ?>>
                                <div class="form-text">
                                    Formats supportés : JPG, PNG, WebP. Taille maximale : 2MB
                                    <?php if (!$writableDir): ?>
                                        <span class="text-danger">- Upload désactivé (problème de permissions)</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <button type="submit" name="ajouter" class="btn btn-primary" 
                                        <?= !$writableDir || empty($categories) ? 'disabled' : '' ?>
                                        title="<?= empty($categories) ? 'Aucune catégorie disponible' : (!$writableDir ? 'Les images ne seront pas sauvegardées' : '') ?>">
                                    <i class="fas fa-save me-1"></i> 
                                    <?= empty($categories) ? 'Catégories manquantes' : 'Ajouter le médicament' ?>
                                </button>
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-undo me-1"></i> Réinitialiser
                                </button>
                            </div>
                            
                            <?php if (empty($categories)): ?>
                                <div class="alert alert-warning mt-3">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Attention :</strong> Aucune catégorie n'est disponible. 
                                    <a href="gestion_categories.php" class="alert-link">Créez d'abord une catégorie</a> avant d'ajouter un médicament.
                                </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Aperçu et informations -->
            <div class="col-lg-4">
                <!-- Aperçu de l'image -->
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-image me-2"></i>Aperçu de l'image
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="image-preview-container">
                            <div id="imagePlaceholder" class="preview-placeholder">
                                <i class="fas fa-camera"></i>
                            </div>
                            <img id="imagePreview" class="image-preview" alt="Aperçu de l'image">
                            <div id="imageText" class="text-muted">Aucune image sélectionnée</div>
                        </div>
                    </div>
                </div>
                
                <!-- Informations sur les catégories -->
                <?php if (!empty($categories)): ?>
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-tags me-2"></i>Catégories disponibles
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="d-flex flex-wrap gap-2">
                            <?php foreach ($categories as $categorie): ?>
                                <span class="category-badge"><?= htmlspecialchars($categorie['nom']) ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Fonctionnalités -->
                <div class="card shadow">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-info-circle me-2"></i>Fonctionnalités
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="feature-card">
                                    <div class="feature-icon mx-auto">
                                        <i class="fas fa-search"></i>
                                    </div>
                                    <h6>Recherche</h6>
                                    <small class="text-muted">Recherche rapide par nom</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="feature-card">
                                    <div class="feature-icon mx-auto">
                                        <i class="fas fa-chart-bar"></i>
                                    </div>
                                    <h6>Statistiques</h6>
                                    <small class="text-muted">Suivi des stocks en temps réel</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="feature-card">
                                    <div class="feature-icon mx-auto">
                                        <i class="fas fa-bell"></i>
                                    </div>
                                    <h6>Alertes</h6>
                                    <small class="text-muted">Alertes stock faible</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="feature-card">
                                    <div class="feature-icon mx-auto">
                                        <i class="fas fa-edit"></i>
                                    </div>
                                    <h6>Modification</h6>
                                    <small class="text-muted">Édition facile</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Gestion de l'aperçu de l'image
        const imageInput = document.getElementById('image');
        const imagePreview = document.getElementById('imagePreview');
        const imagePlaceholder = document.getElementById('imagePlaceholder');
        const imageText = document.getElementById('imageText');
        
        imageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                    imagePlaceholder.style.display = 'none';
                    imageText.textContent = file.name;
                };
                
                reader.readAsDataURL(file);
            } else {
                imagePreview.style.display = 'none';
                imagePlaceholder.style.display = 'block';
                imageText.textContent = 'Aucune image sélectionnée';
            }
        });
        
        // Validation du formulaire
        const form = document.getElementById('medicamentForm');
        form.addEventListener('submit', function(e) {
            const nom = document.getElementById('nom').value.trim();
            const prix = document.getElementById('prix').value;
            const stock = document.getElementById('stock').value;
            const categorie = document.getElementById('categorie_id').value;
            
            if (!nom) {
                e.preventDefault();
                alert('Veuillez saisir le nom du médicament');
                document.getElementById('nom').focus();
                return;
            }
            
            if (!prix || parseFloat(prix) <= 0) {
                e.preventDefault();
                alert('Veuillez saisir un prix valide');
                document.getElementById('prix').focus();
                return;
            }
            
            if (!stock || parseInt(stock) < 0) {
                e.preventDefault();
                alert('Veuillez saisir une quantité de stock valide');
                document.getElementById('stock').focus();
                return;
            }
            
            if (!categorie) {
                e.preventDefault();
                alert('Veuillez sélectionner une catégorie');
                document.getElementById('categorie_id').focus();
                return;
            }
        });
        
        // Auto-format du prix
        const prixInput = document.getElementById('prix');
        prixInput.addEventListener('blur', function() {
            if (this.value) {
                this.value = parseFloat(this.value).toFixed(2);
            }
        });
        
        // Fermeture automatique des alertes
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                if (alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }
            }, 5000);
        });
    });
    </script>
</body>
</html>