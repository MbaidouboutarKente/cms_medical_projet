<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Vérification rôle admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../config/auth.php");
    exit;
}

try {
    require_once "../config/db.php";
    
    // Test de connexion
    $pdoMedical->query("SELECT 1");
} catch (Exception $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}

// Extraction ID numérique
$adminID = intval(preg_replace('/^[A-Z]+_/', '', $_SESSION['user_id']));

// Récupération des informations du admin
try {
    $queryAdmin = $pdoMedical->prepare("SELECT id, nom, prenom, email, telephone FROM utilisateurs WHERE id = ?");
    $queryAdmin->execute([$adminID]);
    $admin = $queryAdmin->fetch();
    
    if (!$admin) {
        throw new Exception("Administrateur non trouvé");
    }

    // Vérification de l'existence des tables
    function tableExists($pdo, $tableName) {
        try {
            $result = $pdo->query("SELECT 1 FROM $tableName LIMIT 1");
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    // Vérification de l'existence des colonnes
    function columnExists($pdo, $table, $column) {
        try {
            $stmt = $pdo->prepare("SHOW COLUMNS FROM $table LIKE ?");
            $stmt->execute([$column]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    // Initialisation des statistiques avec valeurs par défaut
    $stats = [
        'medecins' => 0,
        'infirmiers' => 0,
        'patients' => 0,
        'rdv_attente' => 0,
        'rdv_confirme' => 0,
        'rdv_aujourdhui' => 0,
        'contacts' => 0,
        'medicaments' => 0
    ];

    // Récupération des statistiques avec vérifications
    if (tableExists($pdoMedical, 'utilisateurs')) {
        try {
            // Médecins
            if (columnExists($pdoMedical, 'utilisateurs', 'statut')) {
                $stats['medecins'] = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'medecin' AND statut = 'actif'")->fetchColumn();
            } else {
                $stats['medecins'] = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'medecin'")->fetchColumn();
            }
        } catch (PDOException $e) {
            error_log("Erreur stat médecins: " . $e->getMessage());
        }

        try {
            // Infirmiers
            if (columnExists($pdoMedical, 'utilisateurs', 'statut')) {
                $stats['infirmiers'] = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'infirmier' AND statut = 'actif'")->fetchColumn();
            } else {
                $stats['infirmiers'] = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'infirmier'")->fetchColumn();
            }
        } catch (PDOException $e) {
            error_log("Erreur stat infirmiers: " . $e->getMessage());
        }
    }

    // Patients (basé sur les rendez-vous)
    if (tableExists($pdoMedical, 'rendez_vous')) {
        try {
            if (columnExists($pdoMedical, 'rendez_vous', 'statut')) {
                $stats['patients'] = $pdoMedical->query("SELECT COUNT(DISTINCT patient_id) FROM rendez_vous WHERE statut != 'annulé'")->fetchColumn();
            } else {
                $stats['patients'] = $pdoMedical->query("SELECT COUNT(DISTINCT patient_id) FROM rendez_vous")->fetchColumn();
            }
        } catch (PDOException $e) {
            error_log("Erreur stat patients: " . $e->getMessage());
        }

        // Rendez-vous en attente
        try {
            if (columnExists($pdoMedical, 'rendez_vous', 'statut')) {
                $stats['rdv_attente'] = $pdoMedical->query("SELECT COUNT(*) FROM rendez_vous WHERE statut = 'en attente'")->fetchColumn();
            }
        } catch (PDOException $e) {
            error_log("Erreur stat RDV attente: " . $e->getMessage());
        }

        // Rendez-vous confirmés
        try {
            if (columnExists($pdoMedical, 'rendez_vous', 'statut')) {
                $stats['rdv_confirme'] = $pdoMedical->query("SELECT COUNT(*) FROM rendez_vous WHERE statut = 'confirmé'")->fetchColumn();
            }
        } catch (PDOException $e) {
            error_log("Erreur stat RDV confirmés: " . $e->getMessage());
        }

        // Rendez-vous aujourd'hui
        try {
            if (columnExists($pdoMedical, 'rendez_vous', 'date_rdv') && columnExists($pdoMedical, 'rendez_vous', 'statut')) {
                $stats['rdv_aujourdhui'] = $pdoMedical->query("SELECT COUNT(*) FROM rendez_vous WHERE DATE(date_rdv) = CURDATE() AND statut = 'confirmé'")->fetchColumn();
            }
        } catch (PDOException $e) {
            error_log("Erreur stat RDV aujourd'hui: " . $e->getMessage());
        }
    }

    // Messages de contact
    if (tableExists($pdoMedical, 'contacts')) {
        try {
            if (columnExists($pdoMedical, 'contacts', 'lu')) {
                $stats['contacts'] = $pdoMedical->query("SELECT COUNT(*) FROM contacts WHERE lu = 0")->fetchColumn();
            } else {
                $stats['contacts'] = $pdoMedical->query("SELECT COUNT(*) FROM contacts")->fetchColumn();
            }
        } catch (PDOException $e) {
            error_log("Erreur stat contacts: " . $e->getMessage());
        }
    }

    // Médicaments
    if (tableExists($pdoMedical, 'medicaments')) {
        try {
            if (columnExists($pdoMedical, 'medicaments', 'quantite_stock')) {
                $stats['medicaments'] = $pdoMedical->query("SELECT COUNT(*) FROM medicaments WHERE quantite_stock > 0")->fetchColumn();
            } else {
                $stats['medicaments'] = $pdoMedical->query("SELECT COUNT(*) FROM medicaments")->fetchColumn();
            }
        } catch (PDOException $e) {
            error_log("Erreur stat médicaments: " . $e->getMessage());
        }
    }

    // Récupération des utilisateurs récents
    $users = [];
    if (tableExists($pdoMedical, 'utilisateurs')) {
        try {
            $queryUsers = $pdoMedical->prepare("
                SELECT id, nom, prenom, email, telephone, role, date_creation 
                FROM utilisateurs 
                WHERE role IN ('medecin', 'infirmier', 'patient')
                ORDER BY date_creation DESC 
                LIMIT 5
            ");
            $queryUsers->execute();
            $users = $queryUsers->fetchAll();
        } catch (PDOException $e) {
            error_log("Erreur récupération utilisateurs: " . $e->getMessage());
        }
    }

    // Récupération des messages de contact
    $contacts = [];
    if (tableExists($pdoMedical, 'contacts')) {
        try {
            $queryContacts = $pdoMedical->prepare("SELECT * FROM contacts ORDER BY created_at DESC LIMIT 5");
            $queryContacts->execute();
            $contacts = $queryContacts->fetchAll();
        } catch (PDOException $e) {
            error_log("Erreur récupération contacts: " . $e->getMessage());
        }
    }

    // Récupération des rendez-vous du jour
    $rdvAujourdhui = [];
    if (tableExists($pdoMedical, 'rendez_vous') && tableExists($pdoMedical, 'utilisateurs')) {
        try {
            // Vérifier si les colonnes nécessaires existent
            $hasDateRdv = columnExists($pdoMedical, 'rendez_vous', 'date_rdv');
            $hasStatut = columnExists($pdoMedical, 'rendez_vous', 'statut');
            $hasPatientId = columnExists($pdoMedical, 'rendez_vous', 'patient_id');
            
            if ($hasDateRdv && $hasStatut && $hasPatientId) {
                $queryRdvAujourdhui = $pdoMedical->prepare("
                    SELECT r.*, u.nom as patient_nom, u.prenom as patient_prenom
                    FROM rendez_vous r
                    JOIN utilisateurs u ON r.patient_id = u.id
                    WHERE DATE(r.date_rdv) = CURDATE() AND r.statut = 'confirmé'
                    ORDER BY r.date_rdv ASC
                    LIMIT 5
                ");
                $queryRdvAujourdhui->execute();
                $rdvAujourdhui = $queryRdvAujourdhui->fetchAll();
            }
        } catch (PDOException $e) {
            error_log("Erreur récupération RDV aujourd'hui: " . $e->getMessage());
        }
    }

    // Récupération des alertes stock médicaments
    $alertesStock = [];
    if (tableExists($pdoMedical, 'medicaments')) {
        try {
            $hasQuantite = columnExists($pdoMedical, 'medicaments', 'quantite_stock');
            $hasSeuil = columnExists($pdoMedical, 'medicaments', 'seuil_alerte');
            
            if ($hasQuantite && $hasSeuil) {
                $queryAlertesStock = $pdoMedical->prepare("
                    SELECT nom, quantite_stock, seuil_alerte 
                    FROM medicaments 
                    WHERE quantite_stock <= seuil_alerte 
                    ORDER BY quantite_stock ASC 
                    LIMIT 5
                ");
                $queryAlertesStock->execute();
                $alertesStock = $queryAlertesStock->fetchAll();
            }
        } catch (PDOException $e) {
            error_log("Erreur récupération alertes stock: " . $e->getMessage());
        }
    }

    // Statistiques mensuelles pour le graphique
    $statsMensuelles = [];
    if (tableExists($pdoMedical, 'utilisateurs')) {
        try {
            $hasDateCreation = columnExists($pdoMedical, 'utilisateurs', 'date_creation');
            $hasRole = columnExists($pdoMedical, 'utilisateurs', 'role');
            
            if ($hasDateCreation && $hasRole) {
                $queryStatsMensuelles = $pdoMedical->query("
                    SELECT 
                        MONTH(date_creation) as mois,
                        COUNT(*) as total_utilisateurs,
                        SUM(role = 'medecin') as medecins,
                        SUM(role = 'infirmier') as infirmiers,
                        SUM(role = 'patient') as patients
                    FROM utilisateurs 
                    WHERE YEAR(date_creation) = YEAR(CURDATE())
                    GROUP BY MONTH(date_creation)
                    ORDER BY mois
                ");
                $statsMensuelles = $queryStatsMensuelles->fetchAll();
            }
        } catch (PDOException $e) {
            error_log("Erreur récupération stats mensuelles: " . $e->getMessage());
        }
    }

} catch (PDOException $e) {
    error_log("Erreur base de données: " . $e->getMessage());
    $errorMessage = "Erreur de connexion à la base de données";
} catch (Exception $e) {
    error_log("Erreur application: " . $e->getMessage());
    $errorMessage = $e->getMessage();
}

// Gestion des actions avec vérifications de sécurité
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    try {
        $action = $_POST['action'];
        
        if ($action === 'marquer_lu' && isset($_POST['contact_id'])) {
            if (tableExists($pdoMedical, 'contacts') && columnExists($pdoMedical, 'contacts', 'lu')) {
                $contactId = intval($_POST['contact_id']);
                $updateStmt = $pdoMedical->prepare("UPDATE contacts SET lu = 1 WHERE id = ?");
                $updateStmt->execute([$contactId]);
                
                $_SESSION['message'] = [
                    'type' => 'success',
                    'text' => 'Message marqué comme lu'
                ];
            }
        }
        
    } catch (Exception $e) {
        $_SESSION['message'] = [
            'type' => 'error',
            'text' => $e->getMessage()
        ];
    }
    header("Location: dashboard_admin.php");
    exit;
}

if (isset($_GET['action'])) {
    try {
        $userId = intval($_GET['id'] ?? 0);
        
        if ($_GET['action'] === 'delete' && $userId > 0) {
            if ($userId === $adminID) {
                throw new Exception("Vous ne pouvez pas supprimer votre propre compte");
            }
            
            // Vérifier si la colonne statut existe
            if (columnExists($pdoMedical, 'utilisateurs', 'statut')) {
                $deleteStmt = $pdoMedical->prepare("UPDATE utilisateurs SET statut = 'inactif' WHERE id = ?");
            } else {
                $deleteStmt = $pdoMedical->prepare("DELETE FROM utilisateurs WHERE id = ?");
            }
            
            $deleteStmt->execute([$userId]);
            
            $_SESSION['message'] = [
                'type' => 'success',
                'text' => 'Utilisateur désactivé avec succès'
            ];
            header("Location: dashboard_admin.php");
            exit;
        }
        
        if ($_GET['action'] === 'delete_contact' && isset($_GET['contact_id'])) {
            if (tableExists($pdoMedical, 'contacts')) {
                $contactId = intval($_GET['contact_id']);
                $deleteStmt = $pdoMedical->prepare("DELETE FROM contacts WHERE id = ?");
                $deleteStmt->execute([$contactId]);
                
                $_SESSION['message'] = [
                    'type' => 'success',
                    'text' => 'Message supprimé avec succès'
                ];
            }
            header("Location: dashboard_admin.php");
            exit;
        }
    } catch (Exception $e) {
        $_SESSION['message'] = [
            'type' => 'error',
            'text' => $e->getMessage()
        ];
        header("Location: dashboard_admin.php");
        exit;
    }
}

// Gestion des messages
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Administrateur | Système Médical</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #4a6fa5;
            --primary-dark: #3a5a8a;
            --secondary: #166088;
            --light: #f8f9fa;
            --dark: #343a40;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-hover: 0 8px 15px rgba(0, 0, 0, 0.15);
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fb 0%, #e4e8f0 100%);
            min-height: 100vh;
        }
        
        .sidebar {
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            height: 100vh;
            position: fixed;
            width: 280px;
            transition: all 0.3s;
            box-shadow: var(--shadow);
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 25px 20px;
            background: rgba(0,0,0,0.1);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu a {
            color: rgba(255,255,255,0.9);
            padding: 12px 25px;
            display: block;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
            margin: 2px 0;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
            border-left-color: rgba(255,255,255,0.3);
        }
        
        .sidebar-menu a.active {
            background: rgba(255,255,255,0.15);
            color: white;
            border-left-color: white;
        }
        
        .sidebar-menu i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
            font-size: 1.1em;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 25px;
            transition: all 0.3s;
            min-height: 100vh;
        }
        
        .stat-card {
            border-radius: 15px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            border: none;
            overflow: hidden;
            position: relative;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: rgba(255,255,255,0.3);
        }
        
        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-hover);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }
        
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: var(--shadow);
            margin-bottom: 25px;
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: var(--shadow-hover);
        }
        
        .card-header {
            background: linear-gradient(135deg, white 0%, #f8f9fa 100%);
            border-bottom: 1px solid var(--light-gray);
            font-weight: 600;
            padding: 20px 25px;
            border-radius: 15px 15px 0 0 !important;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2em;
            box-shadow: var(--shadow);
        }
        
        .contact-message {
            border-left: 4px solid var(--primary);
            padding-left: 15px;
            background: var(--light);
            border-radius: 0 8px 8px 0;
        }
        
        .badge-role {
            font-weight: 500;
            text-transform: capitalize;
            padding: 6px 12px;
            border-radius: 20px;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 0.7em;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .alert-stock {
            border-left: 4px solid var(--danger);
            background: rgba(220, 53, 69, 0.05);
        }
        
        .welcome-banner {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
        }
        
        .welcome-banner::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 200%;
            background: rgba(255,255,255,0.1);
            transform: rotate(30deg);
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -280px;
                width: 280px;
            }
            
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
            
            .sidebar.active {
                margin-left: 0;
            }
            
            .welcome-banner {
                padding: 20px;
            }
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .quick-action-btn {
            background: white;
            border: none;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--dark);
        }
        
        .quick-action-btn:hover {
            transform: translateY(-3px);
            box-shadow: var(--shadow-hover);
            color: var(--primary);
        }
        
        .quick-action-btn i {
            font-size: 2em;
            margin-bottom: 10px;
            color: var(--primary);
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="d-flex align-items-center">
                <div class="user-avatar me-3">
                    <?= strtoupper(substr($admin['prenom'], 0, 1) . substr($admin['nom'], 0, 1)) ?>
                </div>
                <div>
                    <h6 class="mb-0"><?= htmlspecialchars($admin['prenom'] . ' ' . $admin['nom']) ?></h6>
                    <small>Administrateur</small>
                </div>
            </div>
        </div>
        
        <div class="sidebar-menu">
            <a href="#" class="active"><i class="fas fa-tachometer-alt"></i> Tableau de bord</a>
            <a href="utilisateur_ges/liste_users.php"><i class="fas fa-users-cog"></i> Gestion utilisateurs</a>
            <a href="gestion_rendezvous.php"><i class="fas fa-calendar-alt"></i> Rendez-vous</a>
            <a href="medicament_ges/gestion_medicaments.php"><i class="fas fa-pills"></i> Médicaments</a>
            <a href="../assistance/contact.php">
                <i class="fas fa-envelope"></i> Messages
                <?php if ($stats['contacts'] > 0): ?>
                    <span class="notification-badge"><?= $stats['contacts'] ?></span>
                <?php endif; ?>
            </a>
            <a href="parametres.php"><i class="fas fa-cog"></i> Paramètres</a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-1"><i class="fas fa-tachometer-alt me-2"></i> Tableau de bord</h2>
                <p class="text-muted mb-0">Bienvenue, <?= htmlspecialchars($admin['prenom']) ?> !</p>
            </div>
            <div class="d-flex align-items-center gap-3">
                <span class="text-muted d-none d-md-block">
                    <i class="fas fa-calendar me-1"></i>
                    <?= date('d/m/Y') ?>
                </span>
                <button class="btn btn-sm btn-primary d-md-none" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>

        <!-- Messages d'alerte -->
        <?php if (isset($message)): ?>
            <div class="alert alert-<?= $message['type'] === 'error' ? 'danger' : 'success' ?> alert-dismissible fade show">
                <i class="fas fa-<?= $message['type'] === 'error' ? 'exclamation-triangle' : 'check-circle' ?> me-2"></i>
                <?= htmlspecialchars($message['text']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Actions rapides -->
        <div class="quick-actions">
            <a href="utilisateur_ges/ajout_user.php" class="quick-action-btn">
                <i class="fas fa-user-plus"></i>
                <div>Nouvel utilisateur</div>
            </a>
            <a href="medicament_ges/ajout_medicament.php" class="quick-action-btn">
                <i class="fas fa-pills"></i>
                <div>Ajouter médicament</div>
            </a>
            <a href="gestion_rendezvous.php" class="quick-action-btn">
                <i class="fas fa-calendar-plus"></i>
                <div>Nouveau RDV</div>
            </a>
            <a href="../assistance/contact.php" class="quick-action-btn">
                <i class="fas fa-envelope"></i>
                <div>Messages
                    <?php if ($stats['contacts'] > 0): ?>
                        <span class="badge bg-danger ms-1"><?= $stats['contacts'] ?></span>
                    <?php endif; ?>
                </div>
            </a>
        </div>

        <!-- Statistiques principales -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stat-card bg-primary text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="text-uppercase opacity-85">Médecins</h6>
                                <h2 class="mb-0"><?= $stats['medecins'] ?></h2>
                                <small class="opacity-75">Actifs</small>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-user-md"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stat-card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="text-uppercase opacity-85">Infirmiers</h6>
                                <h2 class="mb-0"><?= $stats['infirmiers'] ?></h2>
                                <small class="opacity-75">Actifs</small>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-user-nurse"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stat-card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="text-uppercase opacity-85">Patients</h6>
                                <h2 class="mb-0"><?= $stats['patients'] ?></h2>
                                <small class="opacity-75">Avec RDV</small>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-user-injured"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stat-card bg-warning text-dark">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="text-uppercase opacity-85">RDV Aujourd'hui</h6>
                                <h2 class="mb-0"><?= $stats['rdv_aujourdhui'] ?></h2>
                                <small class="opacity-75">Confirmés</small>
                            </div>
                            <div class="stat-icon">
                                <i class="fas fa-calendar-day"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Graphique et utilisateurs -->
            <div class="col-lg-8">
                <!-- Graphique des statistiques -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-chart-line me-2"></i> Statistiques mensuelles</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="statsChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Derniers utilisateurs -->
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-users me-2"></i> Derniers utilisateurs inscrits</h5>
                        <a href="utilisateur_ges/liste_users.php" class="btn btn-sm btn-primary">Voir tout</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Nom</th>
                                        <th>Email</th>
                                        <th>Téléphone</th>
                                        <th>Rôle</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="user-avatar me-2" style="width: 35px; height: 35px; font-size: 0.9em;">
                                                        <?= strtoupper(substr($user['prenom'] ?? '', 0, 1) . substr($user['nom'], 0, 1)) ?>
                                                    </div>
                                                    <?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?>
                                                </div>
                                            </td>
                                            <td><?= htmlspecialchars($user['email']) ?></td>
                                            <td><?= htmlspecialchars($user['telephone'] ?? 'N/A') ?></td>
                                            <td>
                                                <span class="badge bg-<?= 
                                                    $user['role'] === 'medecin' ? 'primary' : 
                                                    ($user['role'] === 'infirmier' ? 'success' : 
                                                    ($user['role'] === 'admin' ? 'danger' : 'info'))
                                                ?> badge-role">
                                                    <?= htmlspecialchars($user['role']) ?>
                                                </span>
                                            </td>
                                            <td><?= date('d/m/Y', strtotime($user['date_creation'])) ?></td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="utilisateur_ges/view_user.php?id=<?= $user['id'] ?>" 
                                                       class="btn btn-outline-primary" 
                                                       title="Voir profil">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="?action=delete&id=<?= $user['id'] ?>" 
                                                       class="btn btn-outline-danger"
                                                       onclick="return confirm('Êtes-vous sûr de vouloir désactiver cet utilisateur ?')"
                                                       title="Désactiver">
                                                        <i class="fas fa-user-slash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar droite -->
            <div class="col-lg-4">
                <!-- Alertes stock -->
                <?php if (!empty($alertesStock)): ?>
                <div class="card mb-4">
                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i> Alertes Stock</h5>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <?php foreach ($alertesStock as $medicament): ?>
                                <div class="list-group-item alert-stock">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1"><?= htmlspecialchars($medicament['nom']) ?></h6>
                                            <small>Stock: <?= $medicament['quantite_stock'] ?> / Seuil: <?= $medicament['seuil_alerte'] ?></small>
                                        </div>
                                        <span class="badge bg-danger">Faible</span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Derniers messages -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-envelope me-2"></i> Derniers messages</h5>
                        <span class="badge bg-primary"><?= count($contacts) ?></span>
                    </div>
                    <div class="card-body">
                        <?php if (empty($contacts)): ?>
                            <div class="alert alert-info mb-0">Aucun message récent</div>
                        <?php else: ?>
                            <div class="list-group">
                                <?php foreach ($contacts as $contact): ?>
                                    <div class="list-group-item list-group-item-action">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <h6 class="mb-1"><?= htmlspecialchars($contact['name']) ?></h6>
                                            <small><?= date('H:i', strtotime($contact['created_at'])) ?></small>
                                        </div>
                                        <p class="mb-1 contact-message"><?= htmlspecialchars(substr($contact['message'], 0, 80)) ?>...</p>
                                        <small class="text-muted"><?= htmlspecialchars($contact['subject']) ?></small>
                                        <div class="mt-2 d-flex gap-2">
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="contact_id" value="<?= $contact['id'] ?>">
                                                <input type="hidden" name="action" value="marquer_lu">
                                                <button type="submit" class="btn btn-sm btn-outline-success">
                                                    <i class="fas fa-check"></i> Lu
                                                </button>
                                            </form>
                                            <a href="mailto:<?= htmlspecialchars($contact['email']) ?>" 
                                               class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-reply"></i>
                                            </a>
                                            <a href="?action=delete_contact&contact_id=<?= $contact['id'] ?>" 
                                               class="btn btn-sm btn-outline-danger"
                                               onclick="return confirm('Supprimer ce message ?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- RDV du jour -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-calendar-day me-2"></i> RDV aujourd'hui</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($rdvAujourdhui)): ?>
                            <div class="alert alert-info mb-0">Aucun rendez-vous aujourd'hui</div>
                        <?php else: ?>
                            <div class="list-group">
                                <?php foreach ($rdvAujourdhui as $rdv): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div>
                                                <h6 class="mb-1"><?= htmlspecialchars($rdv['patient_prenom'] . ' ' . $rdv['patient_nom']) ?></h6>
                                                <small class="text-muted"><?= date('H:i', strtotime($rdv['date_rdv'])) ?></small>
                                            </div>
                                            <span class="badge bg-success">Confirmé</span>
                                        </div>
                                        <small><?= htmlspecialchars($rdv['type_rdv']) ?></small>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle sidebar on mobile
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
        
        // Auto-close alerts after 5 seconds
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                let bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);

        // Graphique des statistiques
        const ctx = document.getElementById('statsChart').getContext('2d');
        const statsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [
                    {
                        label: 'Médecins',
                        data: [<?= implode(',', array_column($statsMensuelles, 'medecins')) ?>],
                        borderColor: '#4a6fa5',
                        backgroundColor: 'rgba(74, 111, 165, 0.1)',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Infirmiers',
                        data: [<?= implode(',', array_column($statsMensuelles, 'infirmiers')) ?>],
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.1)',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Patients',
                        data: [<?= implode(',', array_column($statsMensuelles, 'patients')) ?>],
                        borderColor: '#17a2b8',
                        backgroundColor: 'rgba(23, 162, 184, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // Mise à jour en temps réel (simulée)
        function updateStats() {
            // Ici vous pourriez faire un appel AJAX pour des données en temps réel
            console.log('Mise à jour des statistiques...');
        }

        // Mettre à jour toutes les 2 minutes
        setInterval(updateStats, 120000);
    </script>
</body>
</html>