<?php
session_start();
require_once "../../config/db.php";


if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    header('HTTP/1.0 403 Forbidden');
    exit('Accès non autorisé');
}

if (!isset($_GET['file'])) {
    header('HTTP/1.0 400 Bad Request');
    exit('Fichier non spécifié');
}

$filename = basename($_GET['file']);
$filePath = __DIR__ . '/../../../reports/' . $filename;

if (!file_exists($filePath)) {
    header('HTTP/1.0 404 Not Found');
    exit('Fichier non trouvé');
}

// Déterminer le type MIME
$extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
$mimeTypes = [
    'pdf' => 'application/pdf',
    'csv' => 'text/csv',
    'html' => 'text/html',
    'txt' => 'text/plain'
];

$mimeType = $mimeTypes[$extension] ?? 'application/octet-stream';

// Envoyer le fichier
header('Content-Type: ' . $mimeType);
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . filesize($filePath));
header('Cache-Control: no-cache');

readfile($filePath);
exit;
?>