<?php
session_start();
require_once "../../config/db.php";

// Configuration
define('REPORTS_DIR', __DIR__ . '/../../../reports/');
define('TCPDF_PATH', __DIR__ . '/../../tcpdf/tcpdf.php');
define('LOG_FILE', '../report_errors.log');

// Désactiver l'affichage des erreurs en production
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

header('Content-Type: application/json; charset=utf-8');

// Fonction utilitaire pour logger
function logError($message) {
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "$timestamp - $message\n";
    @file_put_contents(LOG_FILE, $logMessage, FILE_APPEND | LOCK_EX);
}

class ReportGenerator {
    private $pdo;
    private $reportsDir;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->reportsDir = REPORTS_DIR;
        $this->ensureDirectories();
    }
    
    /**
     * Génère un rapport complet
     */
    public function generate($config, $userId) {
        $this->logError("=== DÉBUT GÉNÉRATION RAPPORT ===");
        
        try {
            $this->validateConfig($config);
            
            // Récupération des données
            $data = $this->collectData($config);
            
            // Génération du fichier
            $fileInfo = $this->generateFile($config, $data);
            
            // Sauvegarde en base de données
            $savedInDb = $this->saveToDatabase($fileInfo, $userId, $config);
            
            $this->logError("Rapport généré avec succès: " . $fileInfo['filename']);
            
            return [
                'success' => true,
                'message' => 'Rapport généré et sauvegardé avec succès !',
                'filename' => $fileInfo['filename'],
                'format' => $fileInfo['format'],
                'savedToServer' => true,
                'savedToDatabase' => $savedInDb,
                'emailed' => isset($config['emailReport']) ? $config['emailReport'] : false,
                'downloadUrl' => 'download_report.php?file=' . urlencode($fileInfo['filename']) . '&t=' . time(),
                'fileSize' => $this->formatFileSize($fileInfo['file_size']),
                'timestamp' => date('d/m/Y H:i:s')
            ];
            
        } catch (Exception $e) {
            $this->logError("ERREUR GÉNÉRATION: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * Valide la configuration du rapport
     */
    private function validateConfig($config) {
        $required = ['title', 'format', 'period'];
        foreach ($required as $field) {
            if (empty($config[$field])) {
                throw new Exception("Champ requis manquant: $field");
            }
        }
        
        $allowedFormats = ['pdf', 'csv', 'excel', 'html', 'txt'];
        $format = $config['format'];
        if (!in_array($format, $allowedFormats)) {
            throw new Exception("Format non supporté: " . $format);
        }
        
        $this->logError("Configuration valide - Format: " . $format);
    }
    
    /**
     * Collecte les données pour le rapport
     */
    private function collectData($config) {
        $this->logError("Collecte des données...");
        
        $data = [
            'stats' => $this->getSystemStats(),
            'healthStats' => $this->getHealthStats(),
            'recentUsers' => [],
            'adminActivity' => []
        ];
        
        if (isset($config['includeUsers']) && $config['includeUsers']) {
            $data['recentUsers'] = $this->getRecentUsers();
        }
        
        if (isset($config['includeActivity']) && $config['includeActivity']) {
            $data['adminActivity'] = $this->getAdminActivity();
        }
        
        $this->logError("Données collectées avec succès");
        return $data;
    }
    
    /**
     * Génère le fichier de rapport
     */
    private function generateFile($config, $data) {
        $filename = $this->generateFilename($config['format']);
        $filePath = $this->reportsDir . $filename;
        
        $this->logError("Génération du fichier: " . $filename);
        
        $finalFormat = $config['format'];
        
        try {
            switch ($config['format']) {
                case 'pdf':
                    if ($this->generatePDF($config, $data, $filePath)) {
                        $this->logError("PDF généré avec succès");
                    } else {
                        // Fallback vers HTML
                        $this->logError("Fallback PDF -> HTML");
                        $filename = $this->generateFilename('html');
                        $filePath = $this->reportsDir . $filename;
                        $this->generateHTML($config, $data, $filePath);
                        $finalFormat = 'html';
                    }
                    break;
                    
                case 'csv':
                case 'excel':
                    $this->generateCSV($config, $data, $filePath);
                    $finalFormat = 'csv';
                    break;
                    
                case 'html':
                    $this->generateHTML($config, $data, $filePath);
                    break;
                    
                default:
                    $this->generateText($config, $data, $filePath);
                    $finalFormat = 'txt';
                    break;
            }
            
            // Vérification du fichier généré
            if (!file_exists($filePath)) {
                throw new Exception('Fichier créé mais introuvable: ' . $filePath);
            }
            
            $fileSize = filesize($filePath);
            $this->logError("Fichier vérifié - Taille: " . $fileSize . " bytes");
            
            return [
                'filename' => $filename,
                'file_path' => $filePath,
                'file_size' => $fileSize,
                'format' => $finalFormat
            ];
            
        } catch (Exception $e) {
            // Nettoyer le fichier partiellement créé
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            throw $e;
        }
    }
    
    /**
     * Génère un nom de fichier unique
     */
    private function generateFilename($format) {
        $timestamp = date('Y-m-d_H-i-s');
        $extensions = [
            'pdf' => '.pdf',
            'excel' => '.csv',
            'csv' => '.csv',
            'html' => '.html',
            'txt' => '.txt'
        ];
        
        $extension = $extensions[$format] ?? '.txt';
        return 'rapport_' . $timestamp . '_' . uniqid() . $extension;
    }
    
    /**
     * Génère un PDF avec TCPDF
     */
    private function generatePDF($config, $data, $filePath) {
        try {
            if (!file_exists(TCPDF_PATH)) {
                $this->logError("TCPDF non trouvé: " . TCPDF_PATH);
                return false;
            }
            
            require_once(TCPDF_PATH);
            
            $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
            $pdf->SetCreator('CMS Medical');
            $pdf->SetAuthor('Super Administrateur');
            $pdf->SetTitle($config['title']);
            $pdf->SetSubject('Rapport Système');
            $pdf->AddPage();
            $pdf->SetFont('helvetica', '', 10);
            
            $content = $this->generatePDFContent($config, $data);
            $pdf->writeHTML($content, true, false, true, false, '');
            $pdf->Output($filePath, 'F');
            
            return true;
            
        } catch (Exception $e) {
            $this->logError("Erreur génération PDF: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Génère le contenu PDF
     */
    private function generatePDFContent($config, $data) {
        $content = '
        <style>
            h1 { color: #2c3e50; font-size: 18px; font-weight: bold; border-bottom: 1px solid #3498db; padding-bottom: 5px; }
            h2 { color: #34495e; font-size: 14px; font-weight: bold; margin-top: 15px; }
            table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 10px; }
            th { background-color: #f8f9fa; font-weight: bold; border: 1px solid #ddd; padding: 6px; }
            td { border: 1px solid #ddd; padding: 6px; }
            .header { background: #f8f9fa; padding: 10px; margin-bottom: 15px; }
            .section { margin-bottom: 15px; }
        </style>
        
        <div class="header">
            <h1>RAPPORT SYSTÈME</h1>
            <h2>' . htmlspecialchars($config['title']) . '</h2>
            <p><strong>Date de génération:</strong> ' . date('d/m/Y à H:i') . '</p>
            <p><strong>Période:</strong> ' . $this->getPeriodText($config['period']) . '</p>
            <p><strong>Généré par:</strong> Super Administrateur</p>
        </div>';
        
        $content .= $this->buildContentSections($config, $data, 'pdf');
        $content .= $this->buildFooter('pdf');
        
        return $content;
    }
    
    /**
     * Génère un fichier CSV
     */
    private function generateCSV($config, $data, $filePath) {
        $content = $this->generateCSVContent($config, $data);
        $result = file_put_contents($filePath, $content);
        
        if ($result === false) {
            throw new Exception('Échec sauvegarde CSV: ' . $filePath);
        }
        
        $this->logError("CSV généré - Taille: " . $result . " bytes");
    }
    
    /**
     * Génère le contenu CSV
     */
    private function generateCSVContent($config, $data) {
        $output = "\xEF\xBB\xBF"; // BOM UTF-8 pour Excel
        
        $output .= "RAPPORT SYSTÈME;" . $config['title'] . "\n";
        $output .= "Date de génération;" . date('d/m/Y à H:i') . "\n";
        $output .= "Période;" . $this->getPeriodText($config['period']) . "\n";
        $output .= "Généré par;Super Administrateur\n";
        $output .= ";;\n";
        
        if (isset($config['includeStats']) && $config['includeStats']) {
            $output .= "STATISTIQUES GÉNÉRALES\n";
            $output .= "Catégorie;Valeur\n";
            $output .= "Utilisateurs totaux;" . $data['stats']['total_users'] . "\n";
            $output .= "Utilisateurs actifs (30j);" . $data['stats']['active_users'] . "\n";
            $output .= "Administrateurs;" . $data['stats']['admins'] . "\n";
            $output .= "Médecins;" . $data['stats']['medecins'] . "\n";
            $output .= "Infirmiers;" . $data['stats']['infirmiers'] . "\n";
            $output .= "Patients uniques;" . $data['stats']['patients'] . "\n";
            $output .= "Rendez-vous totaux;" . $data['stats']['rdv_total'] . "\n";
            $output .= "Messages non lus;" . $data['stats']['unread_messages'] . "\n";
            $output .= "Alertes système;" . $data['stats']['system_alerts'] . "\n";
            $output .= ";;\n";
        }
        
        if (isset($config['includeHealth']) && $config['includeHealth']) {
            $output .= "STATISTIQUES DE SANTÉ\n";
            $output .= "Catégorie;Valeur\n";
            $output .= "Certificats médicaux;" . $data['healthStats']['certificats'] . "\n";
            $output .= "Prescriptions;" . $data['healthStats']['prescriptions'] . "\n";
            $output .= "Médicaments;" . $data['healthStats']['medicaments'] . "\n";
            $output .= "Consultations;" . $data['healthStats']['consultations'] . "\n";
            $output .= ";;\n";
        }
        
        if (isset($config['includeUsers']) && $config['includeUsers'] && !empty($data['recentUsers'])) {
            $output .= "DERNIERS UTILISATEURS INSCRITS\n";
            $output .= "Nom;Email;Rôle;Date d'inscription\n";
            foreach ($data['recentUsers'] as $user) {
                $output .= $this->escapeCSV($user['nom']) . ";" . 
                          $this->escapeCSV($user['email']) . ";" . 
                          $this->escapeCSV($user['role']) . ";" . 
                          $this->escapeCSV($user['date_inscription']) . "\n";
            }
            $output .= ";;\n";
        }
        
        if (isset($config['includeActivity']) && $config['includeActivity'] && !empty($data['adminActivity'])) {
            $output .= "ACTIVITÉ RÉCENTE DES ADMINISTRATEURS\n";
            $output .= "Administrateur;Action;Date\n";
            foreach ($data['adminActivity'] as $activity) {
                $output .= $this->escapeCSV($activity['nom']) . ";" . 
                          $this->escapeCSV($activity['action']) . ";" . 
                          $this->escapeCSV($activity['created_at']) . "\n";
            }
            $output .= ";;\n";
        }
        
        if (!empty($config['comments'])) {
            $output .= "COMMENTAIRES\n";
            $output .= $this->escapeCSV($config['comments']) . "\n";
        }
        
        return $output;
    }
    
    /**
     * Échape les caractères spéciaux pour CSV
     */
    private function escapeCSV($value) {
        if (strpos($value, ';') !== false || strpos($value, '"') !== false || strpos($value, "\n") !== false) {
            $value = '"' . str_replace('"', '""', $value) . '"';
        }
        return $value;
    }
    
    /**
     * Génère un fichier HTML
     */
    private function generateHTML($config, $data, $filePath) {
        $content = $this->generateHTMLContent($config, $data);
        $result = file_put_contents($filePath, $content);
        
        if ($result === false) {
            throw new Exception('Échec sauvegarde HTML: ' . $filePath);
        }
        
        $this->logError("HTML généré - Taille: " . $result . " bytes");
    }
    
    /**
     * Génère le contenu HTML
     */
    private function generateHTMLContent($config, $data) {
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>' . htmlspecialchars($config['title']) . '</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
                h2 { color: #34495e; margin-top: 30px; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
                th { background-color: #f8f9fa; font-weight: bold; }
                .section { margin-bottom: 30px; }
                .header { background: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 30px; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>RAPPORT SYSTÈME</h1>
                <h2>' . htmlspecialchars($config['title']) . '</h2>
                <p><strong>Date de génération:</strong> ' . date('d/m/Y à H:i') . '</p>
                <p><strong>Période:</strong> ' . $this->getPeriodText($config['period']) . '</p>
                <p><strong>Généré par:</strong> Super Administrateur</p>
            </div>';
            
        $html .= $this->buildContentSections($config, $data, 'html');
        $html .= $this->buildFooter('html');
        $html .= '</body></html>';
        
        return $html;
    }
    
    /**
     * Génère un fichier texte
     */
    private function generateText($config, $data, $filePath) {
        $content = $this->generateTextContent($config, $data);
        $result = file_put_contents($filePath, $content);
        
        if ($result === false) {
            throw new Exception('Échec sauvegarde texte: ' . $filePath);
        }
        
        $this->logError("Texte généré - Taille: " . $result . " bytes");
    }
    
    /**
     * Génère le contenu texte
     */
    private function generateTextContent($config, $data) {
        $content = "RAPPORT SYSTÈME - " . $config['title'] . "\n";
        $content .= "==========================================\n\n";
        $content .= "Généré le: " . date('d/m/Y à H:i') . "\n";
        $content .= "Période: " . $this->getPeriodText($config['period']) . "\n";
        $content .= "Format: Texte\n";
        $content .= "Généré par: Super Administrateur\n\n";
        
        if (isset($config['includeStats']) && $config['includeStats']) {
            $content .= "STATISTIQUES GÉNÉRALES\n";
            $content .= "-------------------\n";
            $content .= "Utilisateurs totaux: " . $data['stats']['total_users'] . "\n";
            $content .= "Utilisateurs actifs (30j): " . $data['stats']['active_users'] . "\n";
            $content .= "Administrateurs: " . $data['stats']['admins'] . "\n";
            $content .= "Médecins: " . $data['stats']['medecins'] . "\n";
            $content .= "Infirmiers: " . $data['stats']['infirmiers'] . "\n";
            $content .= "Patients uniques: " . $data['stats']['patients'] . "\n";
            $content .= "Rendez-vous totaux: " . $data['stats']['rdv_total'] . "\n";
            $content .= "Messages non lus: " . $data['stats']['unread_messages'] . "\n";
            $content .= "Alertes système: " . $data['stats']['system_alerts'] . "\n\n";
        }
        
        if (isset($config['includeHealth']) && $config['includeHealth']) {
            $content .= "STATISTIQUES DE SANTÉ\n";
            $content .= "--------------------\n";
            $content .= "Certificats médicaux: " . $data['healthStats']['certificats'] . "\n";
            $content .= "Prescriptions: " . $data['healthStats']['prescriptions'] . "\n";
            $content .= "Médicaments: " . $data['healthStats']['medicaments'] . "\n";
            $content .= "Consultations: " . $data['healthStats']['consultations'] . "\n\n";
        }
        
        if (isset($config['includeUsers']) && $config['includeUsers'] && !empty($data['recentUsers'])) {
            $content .= "DERNIERS UTILISATEURS INSCRITS\n";
            $content .= "------------------------------\n";
            foreach ($data['recentUsers'] as $user) {
                $content .= "- " . $user['nom'] . " (" . $user['email'] . ") - " . $user['role'] . " - " . $user['date_inscription'] . "\n";
            }
            $content .= "\n";
        }
        
        if (isset($config['includeActivity']) && $config['includeActivity'] && !empty($data['adminActivity'])) {
            $content .= "ACTIVITÉ RÉCENTE DES ADMINISTRATEURS\n";
            $content .= "-----------------------------------\n";
            foreach ($data['adminActivity'] as $activity) {
                $content .= "- " . $activity['nom'] . ": " . $activity['action'] . " (" . $activity['created_at'] . ")\n";
            }
            $content .= "\n";
        }
        
        if (!empty($config['comments'])) {
            $content .= "COMMENTAIRES\n";
            $content .= "------------\n";
            $content .= $config['comments'] . "\n\n";
        }
        
        $content .= "==========================================\n";
        $content .= "Fin du rapport - " . date('d/m/Y H:i:s') . "\n";
        
        return $content;
    }
    
    /**
     * Construit les sections de contenu
     */
    private function buildContentSections($config, $data, $format) {
        $content = '';
        $isHTML = ($format === 'html');
        $isPDF = ($format === 'pdf');
        
        if (isset($config['includeStats']) && $config['includeStats']) {
            if ($isHTML || $isPDF) {
                $content .= '
                <div class="section">
                    <h2>📊 STATISTIQUES GÉNÉRALES</h2>
                    <table>
                        <tr><th>Catégorie</th><th>Valeur</th></tr>
                        <tr><td>Utilisateurs totaux</td><td>' . $data['stats']['total_users'] . '</td></tr>
                        <tr><td>Utilisateurs actifs (30j)</td><td>' . $data['stats']['active_users'] . '</td></tr>
                        <tr><td>Administrateurs</td><td>' . $data['stats']['admins'] . '</td></tr>
                        <tr><td>Médecins</td><td>' . $data['stats']['medecins'] . '</td></tr>
                        <tr><td>Infirmiers</td><td>' . $data['stats']['infirmiers'] . '</td></tr>
                        <tr><td>Patients uniques</td><td>' . $data['stats']['patients'] . '</td></tr>
                        <tr><td>Rendez-vous totaux</td><td>' . $data['stats']['rdv_total'] . '</td></tr>
                        <tr><td>Messages non lus</td><td>' . $data['stats']['unread_messages'] . '</td></tr>
                        <tr><td>Alertes système</td><td>' . $data['stats']['system_alerts'] . '</td></tr>
                    </table>
                </div>';
            }
        }
        
        if (isset($config['includeHealth']) && $config['includeHealth']) {
            if ($isHTML || $isPDF) {
                $content .= '
                <div class="section">
                    <h2>🏥 STATISTIQUES DE SANTÉ</h2>
                    <table>
                        <tr><th>Catégorie</th><th>Valeur</th></tr>
                        <tr><td>Certificats médicaux</td><td>' . $data['healthStats']['certificats'] . '</td></tr>
                        <tr><td>Prescriptions</td><td>' . $data['healthStats']['prescriptions'] . '</td></tr>
                        <tr><td>Médicaments</td><td>' . $data['healthStats']['medicaments'] . '</td></tr>
                        <tr><td>Consultations</td><td>' . $data['healthStats']['consultations'] . '</td></tr>
                    </table>
                </div>';
            }
        }
        
        if (isset($config['includeUsers']) && $config['includeUsers'] && !empty($data['recentUsers'])) {
            if ($isHTML || $isPDF) {
                $content .= '
                <div class="section">
                    <h2>👥 DERNIERS UTILISATEURS INSCRITS</h2>
                    <table>
                        <tr><th>Nom</th><th>Email</th><th>Rôle</th><th>Date d\'inscription</th></tr>';
                foreach ($data['recentUsers'] as $user) {
                    $content .= '<tr>
                        <td>' . htmlspecialchars($user['nom']) . '</td>
                        <td>' . htmlspecialchars($user['email']) . '</td>
                        <td>' . htmlspecialchars($user['role']) . '</td>
                        <td>' . htmlspecialchars($user['date_inscription']) . '</td>
                    </tr>';
                }
                $content .= '</table>
                </div>';
            }
        }
        
        if (isset($config['includeActivity']) && $config['includeActivity'] && !empty($data['adminActivity'])) {
            if ($isHTML || $isPDF) {
                $content .= '
                <div class="section">
                    <h2>📝 ACTIVITÉ RÉCENTE DES ADMINISTRATEURS</h2>
                    <table>
                        <tr><th>Administrateur</th><th>Action</th><th>Date</th></tr>';
                foreach ($data['adminActivity'] as $activity) {
                    $content .= '<tr>
                        <td>' . htmlspecialchars($activity['nom']) . '</td>
                        <td>' . htmlspecialchars($activity['action']) . '</td>
                        <td>' . htmlspecialchars($activity['created_at']) . '</td>
                    </tr>';
                }
                $content .= '</table>
                </div>';
            }
        }
        
        if (!empty($config['comments'])) {
            if ($isHTML || $isPDF) {
                $content .= '
                <div class="section">
                    <h2>💬 COMMENTAIRES</h2>
                    <div style="background: #f8f9fa; padding: ' . ($isPDF ? '8px' : '15px') . '; border: 1px solid #ddd;' . ($isHTML ? ' border-radius: 5px;' : '') . '">
                        ' . nl2br(htmlspecialchars($config['comments'])) . '
                    </div>
                </div>';
            }
        }
        
        return $content;
    }
    
    /**
     * Construit le pied de page
     */
    private function buildFooter($format) {
        $isHTML = ($format === 'html');
        
        if ($isHTML) {
            return '<div style="margin-top: 50px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #7f8c8d;">
                <p>Rapport généré le ' . date('d/m/Y à H:i:s') . '</p>
            </div>';
        } else {
            return '<div style="margin-top: 20px; padding-top: 10px; border-top: 1px solid #ddd; text-align: center; color: #7f8c8d; font-size: 8px;">
                <p>Rapport généré le ' . date('d/m/Y à H:i:s') . '</p>
            </div>';
        }
    }
    
    /**
     * S'assure que les répertoires nécessaires existent
     */
    private function ensureDirectories() {
        if (!is_dir($this->reportsDir)) {
            $this->logError("Création du dossier reports...");
            if (!mkdir($this->reportsDir, 0755, true)) {
                throw new Exception('Impossible de créer le dossier reports: ' . $this->reportsDir);
            }
            $this->logError("Dossier reports créé");
        }
        
        if (!is_writable($this->reportsDir)) {
            $perms = substr(sprintf('%o', fileperms($this->reportsDir)), -4);
            throw new Exception('Dossier reports non accessible en écriture. Permissions: ' . $perms);
        }
        
        $this->logError("Dossier reports accessible en écriture");
        $this->createReportsTableIfNotExists();
    }
    
    /**
     * Crée la table des rapports si elle n'existe pas
     */
    private function createReportsTableIfNotExists() {
        try {
            $tableExists = $this->pdo->query("SHOW TABLES LIKE 'generated_reports'")->rowCount() > 0;
            
            if (!$tableExists) {
                $this->logError("Création de la table generated_reports...");
                
                $sql = "
                    CREATE TABLE generated_reports (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        user_id INT NOT NULL,
                        filename VARCHAR(255) NOT NULL,
                        title VARCHAR(255) NOT NULL,
                        format VARCHAR(20) NOT NULL,
                        period VARCHAR(50) NOT NULL,
                        file_path VARCHAR(500) NOT NULL,
                        file_size VARCHAR(20) NOT NULL,
                        created_at DATETIME NOT NULL,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                ";
                
                $this->pdo->exec($sql);
                $this->logError("Table generated_reports créée avec succès");
            }
            
        } catch (Exception $e) {
            $this->logError("Erreur création table: " . $e->getMessage());
            // Ne pas bloquer si la table existe déjà
        }
    }
    
    /**
     * Sauvegarde le rapport en base de données
     */
    private function saveToDatabase($fileInfo, $userId, $config) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO generated_reports 
                (user_id, filename, title, format, period, file_path, file_size, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $success = $stmt->execute([
                $userId,
                $fileInfo['filename'],
                $config['title'],
                $fileInfo['format'],
                $config['period'],
                $fileInfo['file_path'],
                $fileInfo['file_size']
            ]);
            
            if ($success) {
                $this->logError("Rapport sauvegardé en BD avec ID: " . $this->pdo->lastInsertId());
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            $this->logError("Erreur sauvegarde BD: " . $e->getMessage());
            return false;
        }
    }
    
    // === MÉTHODES DE RÉCUPÉRATION DES DONNÉES ===
    
    private function getSystemStats() {
        return [
            'total_users' => $this->safeCount('utilisateurs', 'statut = "actif"'),
            'active_users' => $this->safeCount('utilisateurs', 'last_login > DATE_SUB(NOW(), INTERVAL 30 DAY) AND statut = "actif"'),
            'admins' => $this->safeCount('utilisateurs', "role = 'admin' AND statut = 'actif'"),
            'medecins' => $this->safeCount('utilisateurs', "role = 'medecin' AND statut = 'actif'"),
            'infirmiers' => $this->safeCount('utilisateurs', "role = 'infirmier' AND statut = 'actif'"),
            'patients' => $this->safeCount('rendez_vous', "1 GROUP BY patient_id"),
            'rdv_total' => $this->safeCount('rendez_vous'),
            'unread_messages' => $this->safeCount('contacts', "status = 'unread'"),
            'system_alerts' => $this->safeCount('system_alerts', "is_read = 0")
        ];
    }
    
    private function getHealthStats() {
        return [
            'certificats' => $this->tableExists('certificats') ? $this->safeCount('certificats') : 0,
            'prescriptions' => $this->tableExists('prescriptions') ? $this->safeCount('prescriptions') : 0,
            'medicaments' => $this->tableExists('medicaments') ? $this->safeCount('medicaments') : 0,
            'consultations' => $this->tableExists('consultations') ? $this->safeCount('consultations') : 0
        ];
    }
    
    private function getRecentUsers() {
        return $this->safeFetchAll(
            "SELECT nom, email, role, DATE_FORMAT(date_inscription, '%d/%m/%Y') as date_inscription
             FROM utilisateurs 
             WHERE statut = 'actif'
             ORDER BY date_inscription DESC 
             LIMIT 5"
        );
    }
    
    private function getAdminActivity() {
        if (!$this->tableExists('admin_activity')) {
            return [];
        }
        
        return $this->safeFetchAll(
            "SELECT u.nom, a.action, DATE_FORMAT(a.created_at, '%d/%m/%Y %H:%i') as created_at
             FROM admin_activity a
             JOIN utilisateurs u ON a.user_id = u.id
             WHERE u.role IN ('super_admin', 'admin') AND u.statut = 'actif'
             ORDER BY a.created_at DESC 
             LIMIT 5"
        );
    }
    
    private function safeCount($table, $condition = '') {
        try {
            $sql = "SELECT COUNT(*) FROM `$table`";
            if (!empty($condition)) $sql .= " WHERE $condition";
            return $this->pdo->query($sql)->fetchColumn();
        } catch (Exception $e) {
            $this->logError("Erreur safeCount $table: " . $e->getMessage());
            return 0;
        }
    }
    
    private function safeFetchAll($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            $this->logError("Erreur safeFetchAll: " . $e->getMessage());
            return [];
        }
    }
    
    private function tableExists($tableName) {
        try {
            $result = $this->pdo->query("SELECT 1 FROM $tableName LIMIT 1");
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Convertit la période en texte
     */
    private function getPeriodText($period) {
        $periods = [
            'today' => 'Aujourd\'hui',
            'week' => 'Cette semaine', 
            'month' => 'Ce mois',
            'quarter' => 'Ce trimestre',
            'year' => 'Cette année',
            'custom' => 'Personnalisée'
        ];
        return $periods[$period] ?? $period;
    }
    
    /**
     * Formate la taille du fichier
     */
    private function formatFileSize($bytes) {
        if ($bytes == 0) return '0 Bytes';
        $k = 1024;
        $sizes = ['Bytes', 'KB', 'MB', 'GB'];
        $i = floor(log($bytes) / log($k));
        return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
    }
    
    /**
     * Journalise les erreurs
     */
    private function logError($message) {
        logError($message);
    }
}

// === POINT D'ENTRÉE PRINCIPAL ===

// Nettoyer tout output potentiel
if (ob_get_length()) ob_clean();

try {
    logError("=== DÉBUT GÉNÉRATION RAPPORT ===");

    // Vérifications de sécurité
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Méthode non autorisée');
    }

    if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        throw new Exception('Token CSRF invalide');
    }

    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
        throw new Exception('Accès non autorisé');
    }

    if (!isset($_POST['action']) || $_POST['action'] !== 'generate_report') {
        throw new Exception('Action invalide');
    }

    if (!isset($_POST['config'])) {
        throw new Exception('Configuration manquante');
    }
    
    $config = json_decode($_POST['config'], true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Configuration JSON invalide: ' . json_last_error_msg());
    }

    // Initialisation du générateur
    $generator = new ReportGenerator($pdoMedical);
    $response = $generator->generate($config, $_SESSION['user_id']);

    // Envoyer une réponse JSON valide
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;

} catch (Exception $e) {
    // Nettoyer tout output
    if (ob_get_length()) ob_clean();
    
    logError("ERREUR FINALE: " . $e->getMessage());
    
    // Réponse d'erreur JSON valide
    header('Content-Type: application/json; charset=utf-8');
    header('HTTP/1.1 500 Internal Server Error');
    
    echo json_encode([
        'success' => false, 
        'message' => 'Erreur lors de la génération du rapport: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
?>