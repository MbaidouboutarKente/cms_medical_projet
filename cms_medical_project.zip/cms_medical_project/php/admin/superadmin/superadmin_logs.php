<?php
session_start();
require_once '../db.php';

// Vérification du rôle Super Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    header("Location: ../auth.php");
    exit;
}

// Vérification de la connexion PDO
if (!isset($pdoMedical)) {
    die("❌ Erreur de connexion à la base de données");
}

// Paramètres de pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Filtres
$typeFilter = $_GET['type'] ?? '';
$userFilter = $_GET['user'] ?? '';
$dateFilter = $_GET['date'] ?? '';
$searchFilter = $_GET['search'] ?? '';

// Construction de la requête
$query = "SELECT l.*, u.nom as user_name 
          FROM system_logs l 
          LEFT JOIN utilisateurs u ON l.user_id = u.id 
          WHERE 1=1";
$countQuery = "SELECT COUNT(*) FROM system_logs l WHERE 1=1";
$params = [];
$countParams = [];

// Application des filtres
if (!empty($typeFilter)) {
    $query .= " AND l.action_type = ?";
    $countQuery .= " AND l.action_type = ?";
    $params[] = $typeFilter;
    $countParams[] = $typeFilter;
}

if (!empty($userFilter)) {
    $query .= " AND l.user_id = ?";
    $countQuery .= " AND l.user_id = ?";
    $params[] = $userFilter;
    $countParams[] = $userFilter;
}

if (!empty($dateFilter)) {
    $query .= " AND DATE(l.created_at) = ?";
    $countQuery .= " AND DATE(l.created_at) = ?";
    $params[] = $dateFilter;
    $countParams[] = $dateFilter;
}

if (!empty($searchFilter)) {
    $query .= " AND (l.action_description LIKE ? OR l.ip_address LIKE ? OR u.nom LIKE ?)";
    $countQuery .= " AND (l.action_description LIKE ? OR l.ip_address LIKE ? OR u.nom LIKE ?)";
    $searchTerm = "%$searchFilter%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $countParams[] = $searchTerm;
    $countParams[] = $searchTerm;
    $countParams[] = $searchTerm;
}

// CORRECTION : Utiliser des paramètres nommés pour LIMIT et OFFSET
$query .= " ORDER BY l.created_at DESC LIMIT :limit OFFSET :offset";

try {
    // Récupération des logs
    $stmt = $pdoMedical->prepare($query);
    
    // Liaison des paramètres de filtres
    $paramIndex = 1;
    foreach ($params as $param) {
        $stmt->bindValue($paramIndex, $param);
        $paramIndex++;
    }
    
    // Liaison des paramètres de pagination avec type explicite
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Comptage total
    $countStmt = $pdoMedical->prepare($countQuery);
    $countStmt->execute($countParams);
    $totalLogs = $countStmt->fetchColumn();
    $totalPages = ceil($totalLogs / $limit);

    // Récupération des types d'actions uniques
    $typesStmt = $pdoMedical->query("SELECT DISTINCT action_type FROM system_logs ORDER BY action_type");
    $actionTypes = $typesStmt->fetchAll(PDO::FETCH_COLUMN);

    // Récupération des utilisateurs uniques
    $usersStmt = $pdoMedical->query("
        SELECT DISTINCT u.id, u.nom 
        FROM system_logs l 
        JOIN utilisateurs u ON l.user_id = u.id 
        ORDER BY u.nom
    ");
    $users = $usersStmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Erreur chargement logs: " . $e->getMessage());
    $logs = [];
    $totalLogs = 0;
    $totalPages = 1;
    $actionTypes = [];
    $users = [];
    $error = "Erreur lors du chargement des logs: " . $e->getMessage();
}

// Le reste du code reste inchangé...
// Action de suppression des logs
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_logs'])) {
    try {
        $pdoMedical->beginTransaction();
        
        // Garder les logs des 30 derniers jours
        $deleteStmt = $pdoMedical->prepare("
            DELETE FROM system_logs 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");
        $deleteStmt->execute();
        
        $deletedRows = $deleteStmt->rowCount();
        
        $pdoMedical->commit();
        
        $_SESSION['success'] = "✅ $deletedRows logs anciens ont été supprimés (conservation des 30 derniers jours).";
        header("Location: superadmin_logs.php");
        exit;
        
    } catch (Exception $e) {
        $pdoMedical->rollBack();
        $_SESSION['error'] = "❌ Erreur lors de la suppression des logs: " . $e->getMessage();
        header("Location: superadmin_logs.php");
        exit;
    }
}

// Vérifier si la table system_logs existe, sinon la créer
try {
    $tableExists = $pdoMedical->query("SHOW TABLES LIKE 'system_logs'")->rowCount() > 0;
    
    if (!$tableExists) {
        createLogsTable($pdoMedical);
    }
} catch (PDOException $e) {
    error_log("Erreur vérification table logs: " . $e->getMessage());
}

// Fonction pour créer la table des logs
function createLogsTable($pdo) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS system_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            action_type VARCHAR(50) NOT NULL,
            action_description TEXT NOT NULL,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES utilisateurs(id) ON DELETE SET NULL
        )";
        
        $pdo->exec($sql);
        
    } catch (PDOException $e) {
        error_log("Erreur création table logs: " . $e->getMessage());
        throw $e;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Journaux Système - MedicalSystem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
        }
        
        body {
            background-color: #f8f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            border-radius: 0.75rem 0.75rem 0 0 !important;
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #5a5c69;
            background-color: #f8f9fc;
        }
        
        .log-type-badge {
            font-size: 0.75rem;
            font-weight: 500;
            padding: 0.35em 0.65em;
        }
        
        .log-success { background-color: var(--success-color); }
        .log-warning { background-color: var(--warning-color); color: #000; }
        .log-danger { background-color: var(--danger-color); }
        .log-info { background-color: var(--info-color); }
        .log-primary { background-color: var(--primary-color); }
        
        .btn {
            border-radius: 0.5rem;
            font-weight: 500;
        }
        
        .form-control, .form-select {
            border-radius: 0.5rem;
        }
        
        .pagination .page-link {
            border-radius: 0.35rem;
            color: var(--primary-color);
        }
        
        .pagination .page-item.active .page-link {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .stats-card {
            border-left: 0.25rem solid var(--primary-color);
        }
        
        .log-details {
            background-color: #f8f9fa;
            border-radius: 0.5rem;
            padding: 1rem;
            font-size: 0.875rem;
        }
        
        .ip-address {
            font-family: 'Courier New', monospace;
            background-color: #e9ecef;
            padding: 0.2rem 0.4rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="superadmin_dashboard.php">
                <i class="fas fa-hospital me-2"></i>
                <strong>MedicalSystem</strong> - Super Admin
            </a>
            
            <div class="d-flex align-items-center">
                <span class="navbar-text text-light me-3">
                    <i class="fas fa-user-shield me-1"></i>
                    <?= htmlspecialchars($_SESSION['user_name'] ?? 'Super Admin') ?>
                </span>
                <a href="../auth.php?logout=true" class="btn btn-outline-light btn-sm">
                    <i class="fas fa-sign-out-alt me-1"></i>Déconnexion
                </a>
            </div>
        </div>
    </nav>

    <div class="container-fluid py-4">
        <!-- En-tête -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 mb-1 text-gray-800">
                    <i class="fas fa-clipboard-list me-2"></i>Journaux Système
                </h1>
                <p class="text-muted mb-0">Surveillance et audit des activités du système</p>
            </div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#clearLogsModal">
                    <i class="fas fa-trash me-2"></i>Nettoyer les logs
                </button>
                <button type="button" class="btn btn-outline-info" onclick="exportLogs()">
                    <i class="fas fa-download me-2"></i>Exporter
                </button>
            </div>
        </div>

        <!-- Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?= $_SESSION['success'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i><?= $_SESSION['error'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Cartes de statistiques -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Total des logs
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($totalLogs) ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100 border-left-success">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Aujourd'hui
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php
                                    try {
                                        $todayStmt = $pdoMedical->prepare("
                                            SELECT COUNT(*) FROM system_logs 
                                            WHERE DATE(created_at) = CURDATE()
                                        ");
                                        $todayStmt->execute();
                                        echo number_format($todayStmt->fetchColumn());
                                    } catch (Exception $e) {
                                        echo "0";
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-calendar-day fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100 border-left-warning">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    7 derniers jours
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php
                                    try {
                                        $weekStmt = $pdoMedical->prepare("
                                            SELECT COUNT(*) FROM system_logs 
                                            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                                        ");
                                        $weekStmt->execute();
                                        echo number_format($weekStmt->fetchColumn());
                                    } catch (Exception $e) {
                                        echo "0";
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-calendar-week fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100 border-left-danger">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                    Actions critiques
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php
                                    try {
                                        $criticalStmt = $pdoMedical->prepare("
                                            SELECT COUNT(*) FROM system_logs 
                                            WHERE action_type IN ('SECURITY_BREACH', 'UNAUTHORIZED_ACCESS', 'SYSTEM_ERROR')
                                        ");
                                        $criticalStmt->execute();
                                        echo number_format($criticalStmt->fetchColumn());
                                    } catch (Exception $e) {
                                        echo "0";
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filtres -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-filter me-2"></i>Filtres de recherche
                </h6>
            </div>
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Type d'action</label>
                        <select name="type" class="form-select">
                            <option value="">Tous les types</option>
                            <?php foreach ($actionTypes as $type): ?>
                                <option value="<?= htmlspecialchars($type) ?>" <?= $type === $typeFilter ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($type) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">Utilisateur</label>
                        <select name="user" class="form-select">
                            <option value="">Tous les utilisateurs</option>
                            <?php foreach ($users as $user): ?>
                                <option value="<?= $user['id'] ?>" <?= $user['id'] == $userFilter ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($user['nom']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Date</label>
                        <input type="date" name="date" class="form-control" value="<?= htmlspecialchars($dateFilter) ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label class="form-label">Recherche</label>
                        <input type="text" name="search" class="form-control" placeholder="Description, IP, utilisateur..." value="<?= htmlspecialchars($searchFilter) ?>">
                    </div>
                    
                    <div class="col-12">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search me-2"></i>Appliquer les filtres
                            </button>
                            <a href="superadmin_logs.php" class="btn btn-secondary">
                                <i class="fas fa-times me-2"></i>Réinitialiser
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tableau des logs -->
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-table me-2"></i>Journal des activités
                </h6>
                <span class="badge bg-primary"><?= number_format($totalLogs) ?> entrée(s)</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover" width="100%" cellspacing="0">
                        <thead class="table-light">
                            <tr>
                                <th>Date/Heure</th>
                                <th>Utilisateur</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th>Adresse IP</th>
                                <th>Détails</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($logs)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4">
                                        <i class="fas fa-clipboard-list fa-2x text-muted mb-2 d-block"></i>
                                        <span class="text-muted">Aucun log trouvé</span>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td>
                                        <small class="text-muted">
                                            <?= date('d/m/Y H:i:s', strtotime($log['created_at'])) ?>
                                        </small>
                                    </td>
                                    <td>
                                        <?php if ($log['user_name']): ?>
                                            <strong><?= htmlspecialchars($log['user_name']) ?></strong>
                                            <br>
                                            <small class="text-muted">ID: <?= $log['user_id'] ?></small>
                                        <?php else: ?>
                                            <span class="text-muted">Système</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $badgeClass = 'log-primary';
                                        if (strpos($log['action_type'], 'ERROR') !== false || strpos($log['action_type'], 'SECURITY') !== false) {
                                            $badgeClass = 'log-danger';
                                        } elseif (strpos($log['action_type'], 'WARNING') !== false) {
                                            $badgeClass = 'log-warning';
                                        } elseif (strpos($log['action_type'], 'SUCCESS') !== false) {
                                            $badgeClass = 'log-success';
                                        } elseif (strpos($log['action_type'], 'INFO') !== false) {
                                            $badgeClass = 'log-info';
                                        }
                                        ?>
                                        <span class="badge log-type-badge <?= $badgeClass ?>">
                                            <?= htmlspecialchars($log['action_type']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?= htmlspecialchars($log['action_description']) ?></div>
                                    </td>
                                    <td>
                                        <?php if ($log['ip_address']): ?>
                                            <span class="ip-address"><?= htmlspecialchars($log['ip_address']) ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-outline-info" 
                                                onclick="showLogDetails(<?= htmlspecialchars(json_encode($log)) ?>)">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <div class="card-footer">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page - 1 ?>&type=<?= urlencode($typeFilter) ?>&user=<?= urlencode($userFilter) ?>&date=<?= urlencode($dateFilter) ?>&search=<?= urlencode($searchFilter) ?>">
                                        <i class="fas fa-chevron-left"></i> Précédent
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php 
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            
                            for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&type=<?= urlencode($typeFilter) ?>&user=<?= urlencode($userFilter) ?>&date=<?= urlencode($dateFilter) ?>&search=<?= urlencode($searchFilter) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page + 1 ?>&type=<?= urlencode($typeFilter) ?>&user=<?= urlencode($userFilter) ?>&date=<?= urlencode($dateFilter) ?>&search=<?= urlencode($searchFilter) ?>">
                                        Suivant <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal de détails du log -->
    <div class="modal fade" id="logDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Détails du log</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="logDetailsContent">
                    <!-- Contenu chargé dynamiquement -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de nettoyage des logs -->
    <div class="modal fade" id="clearLogsModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Nettoyer les logs</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Êtes-vous sûr de vouloir supprimer les logs de plus de 30 jours ?</p>
                    <p class="text-muted small">
                        Cette action conservera les logs des 30 derniers jours et supprimera les anciennes entrées.
                        Cette action est irréversible.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <form method="POST" class="d-inline">
                        <button type="submit" name="clear_logs" class="btn btn-danger">
                            <i class="fas fa-trash me-2"></i>Supprimer les anciens logs
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer mt-5 py-3 bg-white border-top">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted">&copy; 2024 MedicalSystem. Super Admin Dashboard.</span>
                </div>
                <div>
                    <span class="text-muted">
                        <i class="fas fa-clock me-1"></i>
                        <?= date('d/m/Y H:i') ?>
                    </span>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function showLogDetails(log) {
        const modalContent = document.getElementById('logDetailsContent');
        
        const detailsHtml = `
            <div class="log-details">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <strong>ID:</strong> ${log.id}
                    </div>
                    <div class="col-md-6">
                        <strong>Date:</strong> ${new Date(log.created_at).toLocaleString('fr-FR')}
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <strong>Utilisateur:</strong> ${log.user_name || 'Système'}
                    </div>
                    <div class="col-md-6">
                        <strong>Type:</strong> <span class="badge">${log.action_type}</span>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-12">
                        <strong>Description:</strong><br>
                        ${log.action_description}
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <strong>Adresse IP:</strong><br>
                        <code>${log.ip_address || 'N/A'}</code>
                    </div>
                    <div class="col-md-6">
                        <strong>User Agent:</strong><br>
                        <small>${log.user_agent || 'N/A'}</small>
                    </div>
                </div>
            </div>
        `;
        
        modalContent.innerHTML = detailsHtml;
        new bootstrap.Modal(document.getElementById('logDetailsModal')).show();
    }

    function exportLogs() {
        // Simulation d'export
        const params = new URLSearchParams({
            type: '<?= $typeFilter ?>',
            user: '<?= $userFilter ?>',
            date: '<?= $dateFilter ?>',
            search: '<?= $searchFilter ?>',
            export: 'csv'
        });
        
        showAlert('Export des logs démarré...', 'info');
        
        // Dans une vraie application, cela téléchargerait un fichier CSV
        setTimeout(() => {
            showAlert('Logs exportés avec succès!', 'success');
        }, 1500);
    }

    function showAlert(message, type) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.querySelector('.container-fluid').insertBefore(alertDiv, document.querySelector('.container-fluid').firstChild);
        
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    // Auto-refresh toutes les 2 minutes
    setInterval(() => {
        if (!document.hidden) {
            window.location.reload();
        }
    }, 120000);
    </script>
</body>
</html>