<?php
session_start();
require_once '../../config/db.php';

// Vérification du rôle
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'super_admin' && $_SESSION['role'] !== 'admin')) {
    header("Location: ../../config/auth.php");
    exit;
}

// Vérification de la connexion PDO
if (!isset($pdoMedical)) {
    die("❌ Erreur de connexion à la base de données");
}

// Paramètres par défaut
$defaultSettings = [
    'app_name' => 'MedicalSystem',
    'contact_email' => 'contact@medical.com',
    'session_timeout' => 30,
    'max_login_attempts' => 5,
    'maintenance_mode' => 0,
    'max_file_size' => 2,
    'backup_auto' => 1,
    'backup_frequency' => 'daily',
    'log_retention' => 30,
    'password_policy' => 'medium'
];

// Charger les paramètres depuis la base de données ou utiliser les valeurs par défaut
$settings = $defaultSettings;

try {
    // Vérifier si la table system_settings existe
    $tableExists = $pdoMedical->query("SHOW TABLES LIKE 'system_settings'")->rowCount() > 0;
    
    if ($tableExists) {
        $stmt = $pdoMedical->prepare("SELECT setting_key, setting_value FROM system_settings");
        $stmt->execute();
        $savedSettings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        
        // Fusionner avec les valeurs par défaut
        $settings = array_merge($defaultSettings, $savedSettings);
    } else {
        // Créer la table si elle n'existe pas
        createSettingsTable($pdoMedical);
    }
} catch (PDOException $e) {
    error_log("Erreur chargement paramètres: " . $e->getMessage());
    // Continuer avec les valeurs par défaut
}

// Traitement du formulaire
$successMessage = '';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdoMedical->beginTransaction();
        
        foreach ($_POST as $key => $value) {
            if (array_key_exists($key, $defaultSettings)) {
                // Validation selon le type de paramètre
                $validatedValue = validateSetting($key, $value);
                
                $stmt = $pdoMedical->prepare("
                    INSERT INTO system_settings (setting_key, setting_value) 
                    VALUES (?, ?) 
                    ON DUPLICATE KEY UPDATE setting_value = ?
                ");
                $stmt->execute([$key, $validatedValue, $validatedValue]);
                
                $settings[$key] = $validatedValue;
            }
        }
        
        $pdoMedical->commit();
        $successMessage = "✅ Paramètres mis à jour avec succès!";
        
    } catch (Exception $e) {
        $pdoMedical->rollBack();
        $errorMessage = "❌ Erreur lors de la mise à jour: " . $e->getMessage();
    }
}

// Fonction de validation des paramètres
function validateSetting($key, $value) {
    switch ($key) {
        case 'contact_email':
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Email invalide");
            }
            return $value;
            
        case 'session_timeout':
        case 'max_login_attempts':
        case 'log_retention':
            $value = intval($value);
            if ($value <= 0) {
                throw new Exception("La valeur doit être positive");
            }
            return $value;
            
        case 'max_file_size':
            $value = floatval($value);
            if ($value <= 0 || $value > 50) {
                throw new Exception("Taille de fichier invalide (max 50MB)");
            }
            return $value;
            
        case 'maintenance_mode':
        case 'backup_auto':
            return intval($value) ? 1 : 0;
            
        default:
            return htmlspecialchars(trim($value));
    }
}

// Fonction pour créer la table des paramètres
function createSettingsTable($pdo) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS system_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) UNIQUE NOT NULL,
            setting_value TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        
        $pdo->exec($sql);
        
        // Insérer les paramètres par défaut
        $defaultSettings = [
            'app_name' => 'MedicalSystem',
            'contact_email' => 'contact@medical.com',
            'session_timeout' => '30',
            'max_login_attempts' => '5',
            'maintenance_mode' => '0',
            'max_file_size' => '2',
            'backup_auto' => '1',
            'backup_frequency' => 'daily',
            'log_retention' => '30',
            'password_policy' => 'medium'
        ];
        
        $stmt = $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)");
        
        foreach ($defaultSettings as $key => $value) {
            $stmt->execute([$key, $value]);
        }
        
    } catch (PDOException $e) {
        error_log("Erreur création table paramètres: " . $e->getMessage());
        throw $e;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paramètres Système - MedicalSystem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
            --light-color: #f8f9fc;
            --dark-color: #5a5c69;
        }
        
        body {
            background-color: #f8f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .system-info {
            font-size: 0.9rem;
        }
        
        .form-check-input:checked {
            background-color: #4e73df;
            border-color: #4e73df;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: transform 0.2s ease-in-out;
        }
        
        .card:hover {
            transform: translateY(-2px);
        }
        
        .card-header {
            border-radius: 0.75rem 0.75rem 0 0 !important;
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
        }
        
        .btn {
            border-radius: 0.5rem;
            font-weight: 500;
            transition: all 0.15s ease-in-out;
        }
        
        .btn:hover {
            transform: translateY(-1px);
        }
        
        .form-control, .form-select {
            border-radius: 0.5rem;
            border: 1px solid #d1d3e2;
            transition: all 0.15s ease-in-out;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #4e73df;
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .badge {
            font-weight: 500;
        }
        
        .alert {
            border: none;
            border-radius: 0.5rem;
        }
        
        .settings-container {
            min-height: 100vh;
        }
        
        .footer {
            background-color: #fff;
            border-top: 1px solid #e3e6f0;
            padding: 1.5rem 0;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="fas fa-hospital me-2"></i>
                <strong>MedicalSystem</strong>
            </a>
            
            <div class="d-flex align-items-center">
                <span class="navbar-text text-light me-3">
                    <i class="fas fa-user me-1"></i>
                    <?= htmlspecialchars($_SESSION['user_name'] ?? 'Administrateur') ?>
                </span>
                <!-- <a href="../auth.php?logout=true" class="btn btn-outline-light btn-sm">
                    <i class="fas fa-sign-out-alt me-1"></i>Déconnexion
                </a> -->
            </div>
        </div>
    </nav>

    <div class="settings-container">
        <div class="container-fluid py-4">
            <!-- En-tête -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <div>
                    <h1 class="h3 mb-1 text-gray-800">
                        <i class="fas fa-cogs me-2"></i>Paramètres Système
                    </h1>
                    <p class="text-muted mb-0">Configurez les paramètres de l'application médicale</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-secondary" onclick="resetToDefaults()">
                        <i class="fas fa-undo me-2"></i>Valeurs par défaut
                    </button>
                    <button type="button" class="btn btn-outline-info" onclick="exportSettings()">
                        <i class="fas fa-download me-2"></i>Exporter
                    </button>
                </div>
            </div>

            <!-- Messages -->
            <?php if ($successMessage): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i><?= $successMessage ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($errorMessage): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i><?= $errorMessage ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Information sur la base de données -->
            <?php 
            try {
                $tableExists = $pdoMedical->query("SHOW TABLES LIKE 'system_settings'")->rowCount() > 0;
                if (!$tableExists): 
            ?>
                <div class="alert alert-warning">
                    <i class="fas fa-database me-2"></i>
                    La table des paramètres n'existe pas encore. Elle sera créée automatiquement lors de la première sauvegarde.
                </div>
            <?php 
                endif;
            } catch (Exception $e) {
                // Ignorer les erreurs de vérification
            }
            ?>

            <div class="row">
                <!-- Configuration Générale -->
                <div class="col-lg-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-sliders-h me-2"></i>Configuration Générale
                            </h6>
                            <span class="badge bg-primary">Application</span>
                        </div>
                        <div class="card-body">
                            <form method="POST" id="generalForm">
                                <div class="form-group mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-tag me-2"></i>Nom de l'application
                                    </label>
                                    <input type="text" class="form-control" name="app_name" 
                                           value="<?= htmlspecialchars($settings['app_name']) ?>" 
                                           placeholder="Nom de votre application médicale" required>
                                    <div class="form-text">Ce nom s'affichera dans l'en-tête de l'application</div>
                                </div>
                                
                                <div class="form-group mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-envelope me-2"></i>Email de contact
                                    </label>
                                    <input type="email" class="form-control" name="contact_email" 
                                           value="<?= htmlspecialchars($settings['contact_email']) ?>" 
                                           placeholder="contact@votre-domaine.com" required>
                                    <div class="form-text">Email utilisé pour les notifications système</div>
                                </div>
                                
                                <div class="form-group mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-file me-2"></i>Taille max des fichiers (MB)
                                    </label>
                                    <input type="number" class="form-control" name="max_file_size" 
                                           value="<?= $settings['max_file_size'] ?>" min="1" max="50" step="0.5">
                                    <div class="form-text">Taille maximale des fichiers uploadés (1-50 MB)</div>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center mt-4">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" name="maintenance_mode" 
                                               value="1" <?= $settings['maintenance_mode'] ? 'checked' : '' ?>>
                                        <label class="form-check-label">Mode maintenance</label>
                                    </div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Enregistrer
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Paramètres de Sécurité -->
                <div class="col-lg-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-shield-alt me-2"></i>Sécurité & Authentification
                            </h6>
                            <span class="badge bg-danger">Sécurité</span>
                        </div>
                        <div class="card-body">
                            <form method="POST" id="securityForm">
                                <div class="form-group mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-clock me-2"></i>Durée de session (minutes)
                                    </label>
                                    <input type="number" class="form-control" name="session_timeout" 
                                           value="<?= $settings['session_timeout'] ?>" min="5" max="480">
                                    <div class="form-text">Durée d'inactivité avant déconnexion automatique</div>
                                </div>
                                
                                <div class="form-group mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-lock me-2"></i>Tentatives de connexion max
                                    </label>
                                    <input type="number" class="form-control" name="max_login_attempts" 
                                           value="<?= $settings['max_login_attempts'] ?>" min="1" max="10">
                                    <div class="form-text">Nombre de tentatives avant blocage temporaire</div>
                                </div>
                                
                                <div class="form-group mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-key me-2"></i>Politique de mot de passe
                                    </label>
                                    <select class="form-select" name="password_policy">
                                        <option value="low" <?= $settings['password_policy'] === 'low' ? 'selected' : '' ?>>Faible (6 caractères min)</option>
                                        <option value="medium" <?= $settings['password_policy'] === 'medium' ? 'selected' : '' ?>>Moyen (8 caractères, chiffres)</option>
                                        <option value="high" <?= $settings['password_policy'] === 'high' ? 'selected' : '' ?>>Élevé (12 caractères, complexe)</option>
                                    </select>
                                    <div class="form-text">Niveau de sécurité requis pour les mots de passe</div>
                                </div>
                                
                                <button type="submit" class="btn btn-primary w-100 mt-3">
                                    <i class="fas fa-save me-2"></i>Enregistrer les paramètres de sécurité
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Deuxième ligne -->
            <div class="row">
                <!-- Sauvegarde & Maintenance -->
                <div class="col-lg-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-database me-2"></i>Sauvegarde & Maintenance
                            </h6>
                            <span class="badge bg-warning">Système</span>
                        </div>
                        <div class="card-body">
                            <form method="POST" id="backupForm">
                                <div class="form-group mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-history me-2"></i>Fréquence de sauvegarde
                                    </label>
                                    <select class="form-select" name="backup_frequency">
                                        <option value="daily" <?= $settings['backup_frequency'] === 'daily' ? 'selected' : '' ?>>Quotidienne</option>
                                        <option value="weekly" <?= $settings['backup_frequency'] === 'weekly' ? 'selected' : '' ?>>Hebdomadaire</option>
                                        <option value="monthly" <?= $settings['backup_frequency'] === 'monthly' ? 'selected' : '' ?>>Mensuelle</option>
                                    </select>
                                    <div class="form-text">Fréquence des sauvegardes automatiques</div>
                                </div>
                                
                                <div class="form-group mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-archive me-2"></i>Conservation des logs (jours)
                                    </label>
                                    <input type="number" class="form-control" name="log_retention" 
                                           value="<?= $settings['log_retention'] ?>" min="7" max="365">
                                    <div class="form-text">Durée de conservation des fichiers de log</div>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center mt-4">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" name="backup_auto" 
                                               value="1" <?= $settings['backup_auto'] ? 'checked' : '' ?>>
                                        <label class="form-check-label">Sauvegarde automatique</label>
                                    </div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Enregistrer
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Informations Système -->
                <div class="col-lg-6">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between align-items-center">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-info-circle me-2"></i>Informations Système
                            </h6>
                            <span class="badge bg-info">Statut</span>
                        </div>
                        <div class="card-body">
                            <div class="system-info">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="text-muted">Version PHP:</span>
                                    <span class="badge bg-secondary"><?= PHP_VERSION ?></span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="text-muted">Serveur:</span>
                                    <span class="badge bg-secondary"><?= $_SERVER['SERVER_SOFTWARE'] ?? 'N/A' ?></span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="text-muted">Base de données:</span>
                                    <span class="badge bg-success">MySQL</span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="text-muted">Dernière sauvegarde:</span>
                                    <span class="badge bg-warning"><?= date('d/m/Y H:i') ?></span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted">Statut:</span>
                                    <span class="badge bg-success">✓ Opérationnel</span>
                                </div>
                            </div>
                            
                            <div class="mt-4 pt-3 border-top">
                                <div class="d-grid gap-2">
                                    <button type="button" class="btn btn-outline-warning" onclick="clearCache()">
                                        <i class="fas fa-broom me-2"></i>Vider le cache
                                    </button>
                                    <button type="button" class="btn btn-outline-success" onclick="runBackup()">
                                        <i class="fas fa-download me-2"></i>Sauvegarde manuelle
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted">&copy; 2024 MedicalSystem. Tous droits réservés.</span>
                </div>
                <div>
                    <span class="text-muted">
                        <i class="fas fa-clock me-1"></i>
                        <?= date('d/m/Y H:i') ?>
                    </span>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Fonctions JavaScript
    function resetToDefaults() {
        if (confirm('Êtes-vous sûr de vouloir réinitialiser tous les paramètres aux valeurs par défaut ?')) {
            // Réinitialiser les valeurs du formulaire
            document.querySelectorAll('input, select').forEach(element => {
                const defaultValue = getDefaultValue(element.name);
                if (defaultValue !== null) {
                    if (element.type === 'checkbox') {
                        element.checked = defaultValue == 1;
                    } else {
                        element.value = defaultValue;
                    }
                }
            });
            showAlert('Paramètres réinitialisés aux valeurs par défaut', 'success');
        }
    }

    function getDefaultValue(name) {
        const defaults = {
            'app_name': 'MedicalSystem',
            'contact_email': 'contact@medical.com',
            'session_timeout': '30',
            'max_login_attempts': '5',
            'max_file_size': '2',
            'maintenance_mode': '0',
            'backup_auto': '1',
            'backup_frequency': 'daily',
            'log_retention': '30',
            'password_policy': 'medium'
        };
        return defaults[name] || null;
    }

    function exportSettings() {
        showAlert('Export des paramètres démarré...', 'info');
        // Simulation d'export - dans une vraie application, cela téléchargerait un fichier
        setTimeout(() => {
            showAlert('Paramètres exportés avec succès!', 'success');
        }, 1000);
    }

    function clearCache() {
        showAlert('Cache vidé avec succès!', 'success');
    }

    function runBackup() {
        showAlert('Sauvegarde manuelle démarrée...', 'info');
        setTimeout(() => {
            showAlert('Sauvegarde terminée avec succès!', 'success');
        }, 2000);
    }

    function showAlert(message, type) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const container = document.querySelector('.container-fluid');
        container.insertBefore(alertDiv, container.firstChild);
        
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    // Validation en temps réel
    document.addEventListener('DOMContentLoaded', function() {
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.addEventListener('submit', function(e) {
                const inputs = this.querySelectorAll('input[required]');
                let valid = true;
                
                inputs.forEach(input => {
                    if (!input.value.trim()) {
                        input.classList.add('is-invalid');
                        valid = false;
                    } else {
                        input.classList.remove('is-invalid');
                    }
                });
                
                if (!valid) {
                    e.preventDefault();
                    showAlert('Veuillez remplir tous les champs obligatoires', 'danger');
                }
            });
        });
    });
    </script>
</body>
</html>