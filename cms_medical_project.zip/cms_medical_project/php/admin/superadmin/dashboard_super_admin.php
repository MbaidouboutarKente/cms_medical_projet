<?php
// Activation des erreurs en développement (à désactiver en production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

require_once "../../config/db.php";

// Vérification rôle super admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    header("Location: ../../config/auth.php");
    exit;
}


// Génération du token CSRF s'il n'existe pas
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Validation de l'ID utilisateur
$superadminID = filter_var($_SESSION['user_id'], FILTER_SANITIZE_NUMBER_INT);
if (empty($superadminID)) {
    die("ID utilisateur invalide");
}

/**
 * Vérifie si une table existe dans la base de données
 */
function tableExists($pdoMedical, $tableName) {
    try {
        $result = $pdoMedical->query("SELECT 1 FROM $tableName LIMIT 1");
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Exécute une requête SQL de manière sécurisée avec fallback
 */
function safeFetchAll($pdoMedical, $sql, $params = [], $default = []) {
    try {
        $stmt = $pdoMedical->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("SQL Error: " . $e->getMessage());
        return $default;
    }
}

/**
 * Compte les entrées dans une table avec condition optionnelle
 */
function safeCount($pdoMedical, $table, $condition = '') {
    try {
        $sql = "SELECT COUNT(*) FROM $table";
        if (!empty($condition)) {
            $sql .= " WHERE $condition";
        }
        return $pdoMedical->query($sql)->fetchColumn();
    } catch (PDOException $e) {
        error_log("Count Error for $table: " . $e->getMessage());
        return 0;
    }
}

// Initialisation des données
$superadmin = [];
$stats = [];
$recentUsers = [];
$recentContacts = [];
$recentAlertes = [];
$adminActivity = [];
$healthStats = [];


try {
    // 1. Récupération des informations du superadmin
    $superadmin = safeFetchAll($pdoMedical, 
        "SELECT id, nom, email
         FROM utilisateurs 
         WHERE id = ?", 
        [$superadminID]
    )[0] ?? [];

    if (empty($superadmin)) {
        throw new Exception("Compte SuperAdmin introuvable");
    }

    // 2. Statistiques globales
    $stats = [
        'total_users' => safeCount($pdoMedical, 'utilisateurs'),
        'active_users' => safeCount($pdoMedical, 'utilisateurs', "last_login > DATE_SUB(NOW(), INTERVAL 30 DAY)"),
        'admins' => safeCount($pdoMedical, 'utilisateurs', "role = 'admin'"),
        'medecins' => safeCount($pdoMedical, 'utilisateurs', "role = 'medecin'"),
        'infirmiers' => safeCount($pdoMedical, 'utilisateurs', "role = 'infirmier'"),
        'patients' => tableExists($pdoMedical, 'rendez_vous') ? 
                     safeCount($pdoMedical, 'rendez_vous', "1 GROUP BY patient_id") : 0,
        'rdv_total' => safeCount($pdoMedical, 'rendez_vous'),
        'contacts' => safeCount($pdoMedical, 'contacts'),
        'system_alerts' => safeCount($pdoMedical, 'system_alerts', "is_read = 0"),
        'unread_messages' => safeCount($pdoMedical, 'contacts', "status = 'unread'")
    ];

    // 3. Derniers utilisateurs inscrits
    if (tableExists($pdoMedical, 'utilisateurs')) {
        $recentUsers = safeFetchAll($pdoMedical,
            "SELECT id, nom, email, role, date_inscription
             FROM utilisateurs 
             ORDER BY date_inscription DESC 
             LIMIT 5"
        );
    }

    // 4. Derniers messages de contact
    if (tableExists($pdoMedical, 'contacts')) {
        $recentContacts = safeFetchAll($pdoMedical,
            "SELECT * FROM contacts 
             ORDER BY created_at DESC 
             LIMIT 5"
        );
    }

       // 4. Derniers Alertes
       if (tableExists($pdoMedical, 'system_alerts ')) {
        $recentAlertes = safeFetchAll($pdoMedical,
            "SELECT * FROM system_alerts  
             ORDER BY created_at DESC 
             LIMIT 5"
        );
    }

    // 5. Activité récente des administrateurs
    if (tableExists($pdoMedical, 'admin_activity')) {
        $adminActivity = safeFetchAll($pdoMedical,
            "SELECT u.nom, a.action, a.created_at 
             FROM admin_activity a
             JOIN utilisateurs u ON a.user_id = u.id
             WHERE u.role IN ('super_admin', 'admin')
             ORDER BY a.created_at DESC 
             LIMIT 5"
        );
    }

    // 6. Statistiques du système de santé
    $healthStats = [
        'certificats' => tableExists($pdoMedical, 'certificats') ? safeCount($pdoMedical, 'certificats') : 0,
        'prescriptions' => tableExists($pdoMedical, 'prescriptions') ? safeCount($pdoMedical, 'prescriptions') : 0,
        'medicaments' => tableExists($pdoMedical, 'medicaments') ? safeCount($pdoMedical, 'medicaments') : 0,
        'consultations' => tableExists($pdoMedical, 'consultations') ? safeCount($pdoMedical, 'consultations') : 0
    ];

} catch (Exception $e) {
    // Journalisation de l'erreur
    error_log("[SuperAdmin Dashboard] " . date('Y-m-d H:i:s') . " - " . $e->getMessage());
    
    // Message générique pour l'utilisateur
    die("Une erreur est survenue. Veuillez réessayer plus tard.");
}

// Gestion des actions POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    require_once 'action_handlers.php'; // Externalisation du traitement des actions
}

// Le reste de votre code HTML/JS suit ici...

// Gestion des actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Vérification CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Erreur de sécurité : Token invalide");
    }

    try {
        switch ($_POST['action']) {
            case 'promote_to_admin':
                $userId = intval($_POST['user_id']);
                $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET role = 'admin' WHERE id = ? AND role != 'superadmin'");
                $stmt->execute([$userId]);
                
                // Journalisation
                $logStmt = $pdoMedical->prepare("INSERT INTO admin_activity (user_id, action) VALUES (?, ?)");
                $logStmt->execute([$superadminID, "Promotion de l'utilisateur $userId en admin"]);
                
                $_SESSION['message'] = [
                    'type' => 'success',
                    'text' => 'Utilisateur promu administrateur avec succès'
                ];
                break;
                
            case 'demote_from_admin':
                $userId = intval($_POST['user_id']);
                $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET role = 'medecin' WHERE id = ? AND role = 'admin'");
                $stmt->execute([$userId]);
                
                $logStmt = $pdoMedical->prepare("INSERT INTO admin_activity (user_id, action) VALUES (?, ?)");
                $logStmt->execute([$superadminID, "Rétrogradation de l'admin $userId"]);
                
                $_SESSION['message'] = [
                    'type' => 'success',
                    'text' => 'Administrateur rétrogradé avec succès'
                ];
                break;
                
            case 'delete_user':
                $userId = intval($_POST['user_id']);
                if ($userId === $superadminID) {
                    throw new Exception("Vous ne pouvez pas supprimer votre propre compte");
                }
                
                $pdoMedical->beginTransaction();
                
                // Suppression en cascade (exemple)
                $stmt = $pdoMedical->prepare("DELETE FROM utilisateurs WHERE id = ?");
                $stmt->execute([$userId]);
                
              
                $_SESSION['message'] = [
                    'type' => 'success',
                    'text' => 'Utilisateur supprimé avec succès'
                ];
                break;
                
            case 'mark_message_read':
                $messageId = intval($_POST['message_id']);
                $stmt = $pdoMedical->prepare("UPDATE contacts SET status = 'read' WHERE id = ?");
                $stmt->execute([$messageId]);
                
                $_SESSION['message'] = [
                    'type' => 'success',
                    'text' => 'Message marqué comme lu'
                ];
                break;
        }
        
        header("Location: dashboard_super_admin.php");
        exit;
        
    } catch (Exception $e) {
        if ($pdoMedical->inTransaction()) {
            $pdoMedical->rollBack();
        }
        
        $_SESSION['message'] = [
            'type' => 'error',
            'text' => $e->getMessage()
        ];
        header("Location: dashboard_super_admin.php");
        exit;
    }
}

// Gestion des messages flash
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}
?>
<!DOCTYPE html>
<html lang="fr" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4e73df;
            --primary-dark: #2e59d9;
            --secondary: #1cc88a;
            --danger: #e74a3b;
            --warning: #f6c23e;
            --info: #36b9cc;
            --dark: #5a5c69;
            --light: #f8f9fc;
            --sidebar: #212529;
            --sidebar-dark: #191c1f;
            --card-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            --hover-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }

        [data-bs-theme="dark"] {
            --primary: #4e73df;
            --primary-dark: #2e59d9;
            --secondary: #1cc88a;
            --danger: #e74a3b;
            --warning: #f6c23e;
            --info: #36b9cc;
            --dark: #f8f9fc;
            --light: #212529;
            --sidebar: #191c1f;
            --sidebar-dark: #121416;
            --card-shadow: 0 0.15rem 1.75rem 0 rgba(0, 0, 0, 0.3);
            --hover-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.4);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            min-height: 100vh;
            color: var(--dark);
            transition: all 0.3s ease;
            overflow-x: hidden;
        }

        [data-bs-theme="dark"] body {
            background: linear-gradient(135deg, #1a1d23 0%, #2d3748 100%);
            color: #e2e8f0;
        }

        /* Layout amélioré */
        #wrapper {
            display: flex;
            min-height: 100vh;
            position: relative;
        }

        /* Sidebar moderne - CORRECTION */
        #sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--sidebar) 0%, var(--sidebar-dark) 100%);
            color: white;
            min-height: 100vh;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.1);
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            bottom: 0;
            overflow-y: auto; /* Permettre le défilement si nécessaire */
            display: flex;
            flex-direction: column;
        }

        .sidebar-brand {
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding: 0 1.5rem;
            flex-shrink: 0; /* Empêcher la réduction */
        }

        .sidebar-brand-icon {
            font-size: 1.8rem;
            color: var(--primary);
            margin-right: 0.75rem;
        }

        .sidebar-brand-text {
            font-size: 1.3rem;
            font-weight: 700;
            background: linear-gradient(45deg, #fff, #e0e0e0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .sidebar-nav {
            padding: 1.5rem 0;
            flex: 1; /* Prendre l'espace disponible */
            overflow-y: auto; /* Permettre le défilement */
        }

        .sidebar-nav::-webkit-scrollbar {
            width: 4px;
        }

        .sidebar-nav::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 2px;
        }

        .sidebar-nav::-webkit-scrollbar-thumb {
            background: var(--primary);
            border-radius: 2px;
        }

        .nav-item {
            margin: 0.25rem 1rem;
        }

        .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.875rem 1rem;
            border-radius: 0.5rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            font-weight: 500;
            text-decoration: none;
            white-space: nowrap; /* Empêcher le retour à la ligne */
        }

        .nav-link:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }

        .nav-link.active {
            color: white;
            background: linear-gradient(45deg, var(--primary), var(--primary-dark));
            box-shadow: 0 4px 15px rgba(78, 115, 223, 0.3);
        }

        .nav-link i {
            width: 20px;
            margin-right: 0.75rem;
            font-size: 1.1rem;
            flex-shrink: 0; /* Empêcher la réduction des icônes */
        }

        .sidebar-divider {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin: 1.5rem;
        }

        .sidebar-heading {
            color: rgba(255, 255, 255, 0.5);
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 0 1.5rem;
            margin-bottom: 0.5rem;
            white-space: nowrap;
        }

        /* Contenu principal */
        #content {
            flex: 1;
            margin-left: 280px;
            transition: all 0.3s ease;
            background: transparent;
            min-width: 0; /* Permettre le rétrécissement */
        }

        /* Topbar améliorée */
        .topbar {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            padding: 0.75rem 1.5rem;
            position: sticky;
            top: 0;
            z-index: 999;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .topbar-nav {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-item {
            position: relative;
        }

        .nav-icon {
            color: rgba(255, 255, 255, 0.9);
            font-size: 1.1rem;
            padding: 0.75rem;
            border-radius: 0.75rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            position: relative;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .nav-icon:hover {
            color: white;
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .icon-wrapper {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
        }

        .badge-counter {
            position: absolute;
            top: -8px;
            right: -8px;
            background: linear-gradient(45deg, var(--danger), #c53030);
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 0.7rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            border: 2px solid var(--primary-dark);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }

        .badge-counter.pulse {
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        /* Menu utilisateur */
        .user-menu {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            color: white;
            text-decoration: none;
            padding: 0.5rem;
            border-radius: 0.75rem;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .user-menu:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--secondary), var(--info));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.1rem;
            border: 2px solid rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
        }

        .user-menu:hover .user-avatar {
            transform: scale(1.1);
            border-color: rgba(255, 255, 255, 0.5);
        }

        .user-details {
            text-align: left;
        }

        .user-name {
            font-weight: 600;
            font-size: 0.9rem;
            line-height: 1.2;
        }

        .user-role {
            font-size: 0.75rem;
            opacity: 0.8;
            line-height: 1.2;
        }

        .dropdown-arrow {
            font-size: 0.8rem;
            opacity: 0.7;
            transition: transform 0.3s ease;
        }

        .user-menu.show .dropdown-arrow {
            transform: rotate(180deg);
        }

        /* Dropdown menus */
        .dropdown-menu {
            border: none;
            border-radius: 1rem;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(0, 0, 0, 0.05);
            min-width: 280px;
        }

        [data-bs-theme="dark"] .dropdown-menu {
            background: #2d3748;
            border-color: #4a5568;
            color: #e2e8f0;
        }

        .dropdown-header {
            padding: 1rem 1.25rem;
            background: linear-gradient(135deg, #f8f9fc 0%, #e9ecef 100%);
            border-radius: 1rem 1rem 0 0;
        }

        [data-bs-theme="dark"] .dropdown-header {
            background: linear-gradient(135deg, #374151 0%, #4b5563 100%);
            color: #e2e8f0;
        }

        .dropdown-footer {
            padding: 0.75rem 1.25rem;
            background: #f8f9fa;
            border-radius: 0 0 1rem 1rem;
        }

        [data-bs-theme="dark"] .dropdown-footer {
            background: #374151;
        }

        .dropdown-item {
            padding: 0.75rem 1.25rem;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border-radius: 0.5rem;
            margin: 0.125rem 0.5rem;
            width: auto;
        }

        [data-bs-theme="dark"] .dropdown-item {
            color: #e2e8f0;
        }

        .dropdown-item:hover {
            background: linear-gradient(45deg, var(--primary), var(--primary-dark));
            color: white;
            transform: translateX(5px);
        }

        .dropdown-item i {
            width: 16px;
            text-align: center;
        }

        .alert-item {
            border-radius: 0.5rem;
            margin: 0.25rem 0;
        }

        .alert-item:hover {
            background: rgba(78, 115, 223, 0.05);
            transform: translateX(5px);
        }

        [data-bs-theme="dark"] .alert-item:hover {
            background: rgba(78, 115, 223, 0.2);
        }

        .alert-icon {
            font-size: 1.1rem;
            margin-top: 0.125rem;
        }

        /* Bouton thème */
        .theme-toggle {
            cursor: pointer;
            border: none;
            background: rgba(255, 255, 255, 0.1);
        }

        .theme-toggle:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        /* Cartes modernes */
        .card {
            border: none;
            border-radius: 1rem;
            box-shadow: var(--card-shadow);
            transition: all 0.3s ease;
            background: white;
            overflow: hidden;
        }

        [data-bs-theme="dark"] .card {
            background: #2d3748;
            color: #e2e8f0;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: var(--hover-shadow);
        }

        .card-header {
            background: linear-gradient(135deg, #f8f9fc 0%, #e9ecef 100%);
            border-bottom: 1px solid #e3e6f0;
            padding: 1.25rem 1.5rem;
            font-weight: 600;
        }

        [data-bs-theme="dark"] .card-header {
            background: linear-gradient(135deg, #374151 0%, #4b5563 100%);
            border-bottom-color: #4a5568;
            color: #e2e8f0;
        }

        /* Responsive */
        @media (max-width: 768px) {
            #sidebar {
                margin-left: -280px;
                width: 280px;
            }
            
            #sidebar.active {
                margin-left: 0;
            }
            
            #content {
                margin-left: 0;
                width: 100%;
            }
            
            .topbar {
                padding: 1rem;
            }
            
            .user-details {
                display: none !important;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.6s ease-out;
        }

        /* Scrollbar personnalisée */
        ::-webkit-scrollbar {
            width: 6px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        [data-bs-theme="dark"] ::-webkit-scrollbar-track {
            background: #374151;
        }

        ::-webkit-scrollbar-thumb {
            background: var(--primary);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary-dark);
        }
    </style>
</head>
<body>
    <div id="wrapper">
        <!-- Sidebar moderne -->
        <nav id="sidebar">
            <div class="sidebar-brand">
                <i class="fas fa-shield-alt sidebar-brand-icon"></i>
                <div class="sidebar-brand-text">Super Admin</div>
            </div>
            
            <div class="sidebar-nav">
                <div class="sidebar-heading">Navigation Principale</div>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard_super_admin.php">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Tableau de bord</span>
                        </a>
                    </li>
                </ul>
                
                <div class="sidebar-divider"></div>
                
                <div class="sidebar-heading">Administration</div>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../utilisateur_ges/liste_users.php">
                            <i class="fas fa-users-cog"></i>
                            <span>Gestion des utilisateurs</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="superadmin_roles.php">
                            <i class="fas fa-user-tag"></i>
                            <span>Gestion des rôles</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../medicament_ges/gestion_medicaments.php">
                            <i class="fas fa-pills"></i>
                            <span>Médicaments</span>
                        </a>
                    </li>
                </ul>
                
                <div class="sidebar-divider"></div>
                
                <div class="sidebar-heading">Système</div>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        
                        <a class="nav-link" href="../../assistance/contact.php">
                            <i class="fas fa-inbox me-1"></i>Consulter les messages
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../rdv/prendre_rdv.php">
                            <i class="fas fa-database"></i>
                            <span>Prendre rendez vous</span>
                        </a>
                    <li class="nav-item">
                        <a class="nav-link" href="superadmin_settings.php">
                            <i class="fas fa-cogs"></i>
                            <span>Paramètres système</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="superadmin_logs.php">
                            <i class="fas fa-clipboard-list"></i>
                            <span>Journaux d'activité</span>
                        </a>
                    </li>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="superadmin_reports.php">
                            <i class="fas fa-chart-bar"></i>
                            <span>Rapports</span>
                        </a>
                    </li>
                </ul>

                <div class="sidebar-divider"></div>
                
                <div class="sidebar-heading">Gestion d'administrateur</div>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../admin_ges/ajout_admin.php">
                            <i class="fas fa-user-plus"></i>
                            <span>Ajouter Administrateur</span>
                        </a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="superadmin_logs.php">
                            <i class="fas fa-clipboard-list"></i>
                            <span>Journaux d'activité</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="superadmin_backup.php">
                            <i class="fas fa-database"></i>
                            <span>Sauvegarde</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="superadmin_reports.php">
                            <i class="fas fa-chart-bar"></i>
                            <span>Rapports</span>
                        </a>
                    </li> -->
                </ul>

                <div class="sidebar-divider"></div>
                
                <div class="sidebar-heading">Gestion Campus</div>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../campus_ges/ajout_etudiant.php">
                            <i class="fas fa-user-plus"></i>
                            <span>Ajouter Étudiant</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../campus_ges/liste_etudiants.php">
                            <i class="fas fa-list"></i>
                            <span>Liste des Étudiants</span>
                        </a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="../campus_ges/gestion_filieres.php">
                            <i class="fas fa-graduation-cap"></i>
                            <span>Filières</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../campus_ges/statistiques_campus.php">
                            <i class="fas fa-chart-pie"></i>
                            <span>Statistiques Campus</span>
                        </a>
                    </li> -->
                </ul>
            </div>
        </nav>
        
        <!-- Content Wrapper -->
        <div id="content">
            <!-- Topbar moderne -->
            <nav class="topbar">
                <div class="container-fluid">
                    <div class="d-flex justify-content-between align-items-center">
                        <!-- Bouton menu mobile -->
                        <button id="sidebarToggle" class="btn btn-light d-lg-none">
                            <i class="fas fa-bars"></i>
                        </button>

                        <!-- Recherche et titre -->
                        <div class="d-none d-md-flex align-items-center">
                            <!-- <h4 class="mb-0 text-white fw-bold"> </h4> -->
                        </div>
                        
                        <!-- Navigation utilisateur -->
                        <div class="topbar-nav">
                            <!-- Alertes -->
                            <div class="nav-item dropdown">
                                <a class="nav-icon dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <div class="icon-wrapper">
                                        <i class="fas fa-bell"></i>
                                        <?php if ($stats['system_alerts'] > 0): ?>
                                            <span class="badge-counter pulse"><?= $stats['system_alerts'] ?></span>
                                        <?php endif; ?>
                                    </div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end shadow-lg">
                                    <div class="dropdown-header d-flex justify-content-between align-items-center">
                                        <h6 class="mb-0">Centre d'alertes</h6>
                                        <?php if ($stats['system_alerts'] > 0): ?>
                                            <span class="badge bg-danger"><?= $stats['system_alerts'] ?> nouvelle(s)</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="dropdown-divider"></div>
                                    <div class="alert-list">
                                        <?php if ($stats['system_alerts'] > 0): ?>
                                            <?php foreach (array_slice($recentAlertes, 0, 5) as $index => $alerte): ?>
                                                <a class="dropdown-item alert-item" href="#">
                                                    <div class="d-flex align-items-start">
                                                        <div class="alert-icon me-3">
                                                            <i class="fas fa-<?= $index % 3 == 0 ? 'exclamation-triangle text-warning' : ($index % 3 == 1 ? 'info-circle text-info' : 'shield-alt text-primary') ?>"></i>
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <div class="small text-muted mb-1">
                                                                <i class="fas fa-clock me-1"></i>
                                                                <?= date('d/m/Y H:i', strtotime($alerte['created_at'])) ?>
                                                            </div>
                                                            <div class="fw-medium"><?= htmlspecialchars($alerte['message']) ?></div>
                                                        </div>
                                                    </div>
                                                </a>
                                                <?php if ($index < count(array_slice($recentAlertes, 0, 5)) - 1): ?>
                                                    <div class="dropdown-divider"></div>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                            <div class="dropdown-footer text-center pt-2">
                                                <a class="btn btn-outline-primary btn-sm" href="superadmin_messages.php">
                                                    <i class="fas fa-list me-1"></i>Voir toutes les alertes
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-center py-4">
                                                <i class="fas fa-bell-slash fa-2x text-muted mb-3"></i>
                                                <p class="text-muted mb-0">Aucune alerte pour le moment</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Messages -->
                            <div class="nav-item dropdown">
                                <a class="nav-icon dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <div class="icon-wrapper">
                                        <i class="fas fa-envelope"></i>
                                        <?php if ($stats['unread_messages'] > 0): ?>
                                            <span class="badge-counter pulse"><?= $stats['unread_messages'] ?></span>
                                        <?php endif; ?>
                                    </div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end shadow-lg">
                                    <div class="dropdown-header d-flex justify-content-between align-items-center">
                                        <h6 class="mb-0">Messages</h6>
                                        <?php if ($stats['unread_messages'] > 0): ?>
                                            <span class="badge bg-primary"><?= $stats['unread_messages'] ?> non lu(s)</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="dropdown-divider"></div>
                                    <div class="message-preview">
                                        <?php if ($stats['unread_messages'] > 0): ?>
                                            <div class="text-center py-3">
                                                <i class="fas fa-envelope-open-text fa-2x text-primary mb-2"></i>
                                                <h6 class="fw-bold"><?= $stats['unread_messages'] ?> message(s) non lu(s)</h6>
                                                <p class="text-muted small mb-3">Vous avez des messages en attente de lecture</p>
                                                <a class="btn btn-primary btn-sm" href="../../assistance/contact.php">
                                                    <i class="fas fa-inbox me-1"></i>Consulter les messages
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-center py-4">
                                                <i class="fas fa-check-circle fa-2x text-success mb-3"></i>
                                                <p class="text-muted mb-0">Aucun message non lu</p>
                                                <small class="text-muted">Votre boîte de réception est à jour</small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Mode sombre/clair -->
                            <div class="nav-item">
                                <button class="nav-icon theme-toggle" id="themeToggle">
                                    <i class="fas fa-moon"></i>
                                </button>
                            </div>
                            
                            <!-- Utilisateur -->
                            <div class="nav-item dropdown">
                                <a class="user-menu dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <div class="user-info">
                                        <div class="user-avatar">
                                            <?= strtoupper(substr($superadmin['nom'], 0, 1)) ?>
                                        </div>
                                        <div class="user-details d-none d-xl-block">
                                            <div class="user-name"><?= htmlspecialchars($superadmin['nom']) ?></div>
                                            <div class="user-role">Super Administrateur</div>
                                        </div>
                                        <i class="fas fa-chevron-down dropdown-arrow"></i>
                                    </div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end shadow-lg">
                                    <div class="dropdown-header">
                                        <div class="d-flex align-items-center">
                                            <div class="user-avatar me-3">
                                                <?= strtoupper(substr($superadmin['nom'], 0, 1)) ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold"><?= htmlspecialchars($superadmin['nom']) ?></div>
                                                <div class="small text-muted">Super Administrateur</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="superadmin_profile.php">
                                        <i class="fas fa-user me-3"></i>
                                        <span>Mon profil</span>
                                    </a>
                                    <a class="dropdown-item" href="superadmin_settings.php">
                                        <i class="fas fa-cogs me-3"></i>
                                        <span>Paramètres</span>
                                    </a>
                                    <a class="dropdown-item" href="#">
                                        <i class="fas fa-question-circle me-3"></i>
                                        <span>Aide & Support</span>
                                    </a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="../logout.php">
                                        <i class="fas fa-sign-out-alt me-3"></i>
                                        <span>Déconnexion</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            
            <!-- Contenu principal -->
            <div class="container-fluid py-4">
                <!-- En-tête -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4 fade-in">
                    <div>
                        <h1 class="h3 mb-2 text-gray-800 fw-bold">Tableau de bord</h1>
                        <p class="text-muted">Bienvenue, <?= htmlspecialchars($superadmin['nom']) ?> - Super Administrateur</p>
                    </div>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#reportModal">
                        <i class="fas fa-download me-2"></i>Générer rapport
                    </button>
                </div>
                
                <!-- Cartes de statistiques -->
                <div class="row mb-4 fade-in">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card primary h-100">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="stat-label">Utilisateurs totaux</div>
                                        <div class="stat-value"><?= $stats['total_users'] ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users stat-icon text-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card success h-100">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="stat-label">Utilisateurs actifs (30j)</div>
                                        <div class="stat-value"><?= $stats['active_users'] ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-check stat-icon text-success"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card info h-100">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="stat-label">Administrateurs</div>
                                        <div class="stat-value"><?= $stats['admins'] ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-shield stat-icon text-info"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stat-card warning h-100">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <div class="stat-label">Messages non lus</div>
                                        <div class="stat-value"><?= $stats['unread_messages'] ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-envelope stat-icon text-warning"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Contenu principal -->
                <div class="row">
                    <!-- Derniers utilisateurs -->
                    <div class="col-lg-6 mb-4 fade-in">
                        <div class="card h-100">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h6 class="m-0 fw-bold">Derniers utilisateurs inscrits</h6>
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                        <i class="fas fa-ellipsis-v"></i>
                                    </button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="superadmin_users.php">Voir tous</a>
                                        <a class="dropdown-item" href="superadmin_add_user.php">Ajouter un utilisateur</a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Nom</th>
                                                <th>Rôle</th>
                                                <th>Date</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($recentUsers as $user): ?>
                                            <tr>
                                                <td>
                                                    <div class="fw-semibold"><?= htmlspecialchars($user['nom']) ?></div>
                                                    <small class="text-muted"><?= htmlspecialchars($user['email']) ?></small>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?= 
                                                        $user['role'] === 'admin' ? 'primary' : 
                                                        ($user['role'] === 'medecin' ? 'info' : 
                                                        ($user['role'] === 'infirmier' ? 'success' : 'secondary'))
                                                    ?>">
                                                        <?= htmlspecialchars($user['role']) ?>
                                                    </span>
                                                </td>
                                                <td><?= date('d/m/Y', strtotime($user['date_inscription'])) ?></td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a href="../utilisateur_ges/view_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                        <a href="../utilisateur_ges/edit_user.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-outline-secondary">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Activité récente -->
                    <div class="col-lg-6 mb-4 fade-in">
                        <div class="card h-100">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h6 class="m-0 fw-bold">Activité récente</h6>
                                <a href="superadmin_logs.php" class="btn btn-sm btn-outline-primary">Voir tout</a>
                            </div>
                            <div class="card-body">
                                <div class="activity-timeline">
                                    <?php if (!empty($adminActivity)): ?>
                                        <?php foreach ($adminActivity as $activity): ?>
                                        <div class="activity-item <?= 
                                            strpos($activity['action'], 'Suppression') !== false ? 'danger' : 
                                            (strpos($activity['action'], 'Promotion') !== false ? 'success' : 'primary')
                                        ?>">
                                            <div class="d-flex justify-content-between">
                                                <h6 class="mb-1"><?= htmlspecialchars($activity['nom']) ?></h6>
                                                <small class="text-muted"><?= date('H:i', strtotime($activity['created_at'])) ?></small>
                                            </div>
                                            <p class="mb-1"><?= htmlspecialchars($activity['action']) ?></p>
                                            <small class="text-muted"><?= date('d/m/Y', strtotime($activity['created_at'])) ?></small>
                                        </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div class="text-center py-4 text-muted">
                                            <i class="fas fa-clipboard-list fa-3x mb-3"></i>
                                            <p>Aucune activité récente</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Statistiques supplémentaires -->
                <div class="row fade-in">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="m-0 fw-bold">Statistiques du système de santé</h6>
                            </div>
                            <div class="card-body">
                                <div class="row text-center">
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="p-3">
                                            <i class="fas fa-file-medical fa-2x text-primary mb-2"></i>
                                            <h4><?= $healthStats['certificats'] ?></h4>
                                            <p class="text-muted mb-0">Certificats médicaux</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="p-3">
                                            <i class="fas fa-prescription-bottle-alt fa-2x text-success mb-2"></i>
                                            <h4><?= $healthStats['prescriptions'] ?></h4>
                                            <p class="text-muted mb-0">Prescriptions</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="p-3">
                                            <i class="fas fa-pills fa-2x text-info mb-2"></i>
                                            <h4><?= $healthStats['medicaments'] ?></h4>
                                            <p class="text-muted mb-0">Médicaments</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-6 mb-3">
                                        <div class="p-3">
                                            <i class="fas fa-stethoscope fa-2x text-warning mb-2"></i>
                                            <h4><?= $healthStats['consultations'] ?></h4>
                                            <p class="text-muted mb-0">Consultations</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de génération de rapport -->
    <div class="modal fade report-modal" id="reportModal" tabindex="-1" aria-labelledby="reportModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reportModalLabel">
                        <i class="fas fa-file-pdf me-2"></i>Génération de Rapport
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <!-- Personnalisation du rapport -->
                            <h6 class="fw-bold mb-3">Personnaliser le rapport</h6>
                            
                            <div class="customization-option">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="includeStats" checked>
                                    <label class="form-check-label" for="includeStats">
                                        Statistiques générales
                                    </label>
                                </div>
                                <small class="text-muted">Utilisateurs, activités, messages, etc.</small>
                            </div>
                            
                            <div class="customization-option">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="includeUsers" checked>
                                    <label class="form-check-label" for="includeUsers">
                                        Détails des utilisateurs
                                    </label>
                                </div>
                                <small class="text-muted">Liste des derniers utilisateurs inscrits</small>
                            </div>
                            
                            <div class="customization-option">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="includeHealth" checked>
                                    <label class="form-check-label" for="includeHealth">
                                        Statistiques de santé
                                    </label>
                                </div>
                                <small class="text-muted">Certificats, prescriptions, médicaments</small>
                            </div>
                            
                            <div class="customization-option">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="includeActivity" checked>
                                    <label class="form-check-label" for="includeActivity">
                                        Activité récente
                                    </label>
                                </div>
                                <small class="text-muted">Journal des activités administrateurs</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="reportPeriod" class="form-label fw-semibold">Période du rapport</label>
                                <select class="form-select" id="reportPeriod">
                                    <option value="today">Aujourd'hui</option>
                                    <option value="week" selected>Cette semaine</option>
                                    <option value="month">Ce mois</option>
                                    <option value="quarter">Ce trimestre</option>
                                    <option value="year">Cette année</option>
                                    <option value="custom">Personnalisée</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="reportFormat" class="form-label fw-semibold">Format du rapport</label>
                                <select class="form-select" id="reportFormat">
                                    <option value="pdf" selected>PDF</option>
                                    <option value="excel">Excel</option>
                                    <option value="csv">CSV</option>
                                    <option value="html">HTML</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label for="reportTitle" class="form-label fw-semibold">Titre du rapport</label>
                                <input type="text" class="form-control" id="reportTitle" value="Rapport d'activité - <?= date('d/m/Y') ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="reportComments" class="form-label fw-semibold">Commentaires additionnels</label>
                                <textarea class="form-control" id="reportComments" rows="3" placeholder="Ajoutez des commentaires ou notes..."></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <!-- Aperçu du rapport -->
                            <h6 class="fw-bold mb-3">Aperçu du rapport</h6>
                            <div class="report-preview" id="reportPreview">
                                <!-- L'aperçu sera généré dynamiquement -->
                            </div>
                            
                            <div class="mt-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="includeCharts" checked>
                                    <label class="form-check-label" for="includeCharts">
                                        Inclure les graphiques
                                    </label>
                                </div>
                                
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="emailReport">
                                    <label class="form-check-label" for="emailReport">
                                        Envoyer par email
                                    </label>
                                </div>
                                
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="saveToServer" checked>
                                    <label class="form-check-label" for="saveToServer">
                                        Sauvegarder sur le serveur
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="button" class="btn btn-outline-primary" id="previewReport">
                        <i class="fas fa-eye me-2"></i>Aperçu complet
                    </button>
                    <button type="button" class="btn btn-primary" id="generateReport">
                        <i class="fas fa-download me-2"></i>Générer le rapport
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal d'aperçu complet -->
    <div class="modal fade preview-modal" id="previewModal" tabindex="-1" aria-labelledby="previewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="previewModalLabel">
                        <i class="fas fa-search me-2"></i>Aperçu du Rapport
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="fullPreviewContent">
                        <!-- Contenu de l'aperçu complet -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                    <button type="button" class="btn btn-primary" onclick="generateReportFromPreview()">
                        <i class="fas fa-download me-2"></i>Générer maintenant
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Données pour les rapports (simulées)
        const reportData = {
            stats: <?= json_encode($stats) ?>,
            healthStats: <?= json_encode($healthStats) ?>,
            recentUsers: <?= json_encode($recentUsers) ?>,
            adminActivity: <?= json_encode($adminActivity) ?>,
            superadmin: <?= json_encode($superadmin) ?>
        };

        // Fonction pour générer l'aperçu du rapport
        function generateReportPreview() {
            const includeStats = document.getElementById('includeStats').checked;
            const includeUsers = document.getElementById('includeUsers').checked;
            const includeHealth = document.getElementById('includeHealth').checked;
            const includeActivity = document.getElementById('includeActivity').checked;
            const reportTitle = document.getElementById('reportTitle').value;
            
            let previewHTML = '';
            
            if (includeStats) {
                previewHTML += `
                    <div class="report-section">
                        <h6 class="fw-bold text-primary">📊 Statistiques Générales</h6>
                        <div class="small">
                            <div><strong>Utilisateurs totaux:</strong> ${reportData.stats.total_users}</div>
                            <div><strong>Utilisateurs actifs (30j):</strong> ${reportData.stats.active_users}</div>
                            <div><strong>Administrateurs:</strong> ${reportData.stats.admins}</div>
                            <div><strong>Médecins:</strong> ${reportData.stats.medecins}</div>
                            <div><strong>Infirmiers:</strong> ${reportData.stats.infirmiers}</div>
                            <div><strong>Messages non lus:</strong> ${reportData.stats.unread_messages}</div>
                        </div>
                    </div>
                `;
            }
            
            if (includeHealth) {
                previewHTML += `
                    <div class="report-section">
                        <h6 class="fw-bold text-success">🏥 Système de Santé</h6>
                        <div class="small">
                            <div><strong>Certificats médicaux:</strong> ${reportData.healthStats.certificats}</div>
                            <div><strong>Prescriptions:</strong> ${reportData.healthStats.prescriptions}</div>
                            <div><strong>Médicaments:</strong> ${reportData.healthStats.medicaments}</div>
                            <div><strong>Consultations:</strong> ${reportData.healthStats.consultations}</div>
                        </div>
                    </div>
                `;
            }
            
            if (includeUsers && reportData.recentUsers.length > 0) {
                let usersList = '';
                reportData.recentUsers.forEach(user => {
                    usersList += `<div>• ${user.nom} (${user.email}) - ${user.role}</div>`;
                });
                
                previewHTML += `
                    <div class="report-section">
                        <h6 class="fw-bold text-info">👥 Derniers Utilisateurs</h6>
                        <div class="small">
                            ${usersList}
                        </div>
                    </div>
                `;
            }
            
            if (includeActivity && reportData.adminActivity.length > 0) {
                let activityList = '';
                reportData.adminActivity.forEach(activity => {
                    activityList += `<div>• <strong>${activity.nom}:</strong> ${activity.action}</div>`;
                });
                
                previewHTML += `
                    <div class="report-section">
                        <h6 class="fw-bold text-warning">📝 Activité Récente</h6>
                        <div class="small">
                            ${activityList}
                        </div>
                    </div>
                `;
            }
            
            previewHTML += `
                <div class="text-center text-muted small mt-3">
                    <hr>
                    Rapport généré le ${new Date().toLocaleDateString('fr-FR')} par ${reportData.superadmin.nom}
                </div>
            `;
            
            document.getElementById('reportPreview').innerHTML = previewHTML;
        }

        // Fonction pour générer l'aperçu complet
        function generateFullPreview() {
            const reportConfig = getReportConfig();
            let fullHTML = `
                <div class="container-fluid">
                    <div class="text-center mb-4">
                        <h2 class="text-primary">${reportConfig.title}</h2>
                        <p class="text-muted">Période: ${getPeriodText(reportConfig.period)} | Format: ${reportConfig.format.toUpperCase()}</p>
                        <hr>
                    </div>
            `;
            
            if (reportConfig.includeStats) {
                fullHTML += `
                    <div class="mb-4">
                        <h4 class="text-primary">📊 Statistiques Générales</h4>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <h3 class="text-primary">${reportData.stats.total_users}</h3>
                                        <p class="text-muted">Utilisateurs totaux</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <h3 class="text-success">${reportData.stats.active_users}</h3>
                                        <p class="text-muted">Utilisateurs actifs</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <h3 class="text-info">${reportData.stats.admins}</h3>
                                        <p class="text-muted">Administrateurs</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <h3 class="text-warning">${reportData.stats.unread_messages}</h3>
                                        <p class="text-muted">Messages non lus</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }
            
            // ... (autres sections similaires)
            
            fullHTML += `</div>`;
            document.getElementById('fullPreviewContent').innerHTML = fullHTML;
        }

        // Fonction pour obtenir la configuration du rapport
        function getReportConfig() {
            return {
                title: document.getElementById('reportTitle').value,
                period: document.getElementById('reportPeriod').value,
                format: document.getElementById('reportFormat').value,
                includeStats: document.getElementById('includeStats').checked,
                includeUsers: document.getElementById('includeUsers').checked,
                includeHealth: document.getElementById('includeHealth').checked,
                includeActivity: document.getElementById('includeActivity').checked,
                includeCharts: document.getElementById('includeCharts').checked,
                emailReport: document.getElementById('emailReport').checked,
                saveToServer: document.getElementById('saveToServer').checked,
                comments: document.getElementById('reportComments').value
            };
        }

        // Fonction pour obtenir le texte de la période
        function getPeriodText(period) {
            const periods = {
                'today': 'Aujourd\'hui',
                'week': 'Cette semaine',
                'month': 'Ce mois',
                'quarter': 'Ce trimestre',
                'year': 'Cette année',
                'custom': 'Personnalisée'
            };
            return periods[period] || period;
        }

        // Fonction pour générer le rapport
        async function generateReport() {
            const reportConfig = getReportConfig();
            
            // Afficher un indicateur de chargement
            const btn = document.getElementById('generateReport');
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Génération...';
            btn.disabled = true;
            
            try {
                // Préparer les données pour l'envoi
                const formData = new FormData();
                formData.append('action', 'generate_report');
                formData.append('config', JSON.stringify(reportConfig));
                formData.append('csrf_token', '<?= $_SESSION['csrf_token'] ?>');
                
                // Envoyer les données au serveur
                const response = await fetch('generate_report.php', {
                    method: 'POST',
                    body: formData
                });
                
                // Vérifier si la réponse est du JSON valide
                const text = await response.text();
                let data;
                
                try {
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Réponse invalide:', text);
                    throw new Error('Le serveur a renvoyé une réponse invalide');
                }
                
                if (!response.ok) {
                    throw new Error(data.message || `Erreur HTTP: ${response.status}`);
                }
                
                if (data.success) {
                    // Afficher le résultat
                    showReportResult(data);
                } else {
                    throw new Error(data.message || 'Erreur lors de la génération');
                }
                
            } catch (error) {
                console.error('Erreur:', error);
                showError('Erreur lors de la génération du rapport: ' + error.message);
            } finally {
                // Restaurer le bouton
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        }
        
        // Fonction pour afficher le résultat du rapport
        function showReportResult(data) {
            let message = `
                <div class="alert alert-success alert-dismissible fade show">
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    <div class="d-flex align-items-center">
                        <i class="fas fa-check-circle fa-2x me-3 text-success"></i>
                        <div>
                            <h5 class="alert-heading mb-2">${data.message}</h5>
            `;
            
            // Informations du fichier
            message += `<div class="mb-2"><strong>Fichier:</strong> ${data.filename}</div>`;
            message += `<div class="mb-2"><strong>Taille:</strong> ${data.fileSize}</div>`;
            message += `<div class="mb-2"><strong>Généré le:</strong> ${data.timestamp}</div>`;
            
            // Boutons d'action
            message += `<div class="mt-3">`;
            
            if (data.downloadUrl) {
                message += `
                    <a href="${data.downloadUrl}" class="btn btn-success me-2" target="_blank">
                        <i class="fas fa-download me-1"></i>Télécharger
                    </a>
                `;
            }
            
            message += `
                <button class="btn btn-outline-secondary" onclick="showReportDetails(this)">
                    <i class="fas fa-info-circle me-1"></i>Détails
                </button>
            `;
            
            message += `</div>`;
            
            // Détails cachés
            message += `
                <div class="report-details mt-3" style="display: none;">
                    <div class="card">
                        <div class="card-body">
                            <h6>Détails techniques:</h6>
                            <ul class="mb-0">
                                <li><strong>Sauvegardé sur serveur:</strong> ${data.savedToServer ? '✅ Oui' : '❌ Non'}</li>
                                <li><strong>Sauvegardé en base:</strong> ${data.savedToDatabase ? '✅ Oui' : '❌ Non'}</li>
                                <li><strong>Envoyé par email:</strong> ${data.emailed ? '✅ Oui' : '❌ Non'}</li>
                                ${data.filePath ? `<li><strong>Chemin:</strong> ${data.filePath}</li>` : ''}
                            </ul>
                        </div>
                    </div>
                </div>
            `;
            
            message += `</div></div></div>`;
            
            // Afficher l'alerte en haut de page
            const alertDiv = document.createElement('div');
            alertDiv.innerHTML = message;
            
            const container = document.querySelector('.container-fluid');
            container.insertBefore(alertDiv, container.firstChild);
            
            // Auto-supprimer après 15 secondes
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    const bsAlert = new bootstrap.Alert(alertDiv.querySelector('.alert'));
                    bsAlert.close();
                }
            }, 15000);
        }

        // Fonction pour afficher/masquer les détails
        function showReportDetails(btn) {
            const detailsDiv = btn.closest('.alert').querySelector('.report-details');
            const isVisible = detailsDiv.style.display !== 'none';
            
            detailsDiv.style.display = isVisible ? 'none' : 'block';
            btn.innerHTML = isVisible ? 
                '<i class="fas fa-info-circle me-1"></i>Détails' : 
                '<i class="fas fa-eye-slash me-1"></i>Masquer';
        }

        // Fonction pour afficher les erreurs
        function showError(message) {
            const alertDiv = document.createElement('div');
            alertDiv.className = 'alert alert-danger alert-dismissible fade show';
            alertDiv.innerHTML = `
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <div class="d-flex align-items-center">
                    <i class="fas fa-exclamation-triangle fa-2x me-3 text-danger"></i>
                    <div>
                        <h5 class="alert-heading mb-1">Erreur</h5>
                        <div class="mb-0">${message}</div>
                    </div>
                </div>
            `;
            
            const container = document.querySelector('.container-fluid');
            container.insertBefore(alertDiv, container.firstChild);
            
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    const bsAlert = new bootstrap.Alert(alertDiv);
                    bsAlert.close();
                }
            }, 10000);
        }

        // Initialisation
        document.addEventListener('DOMContentLoaded', function() {
            // Générer l'aperçu initial
            generateReportPreview();
            
            // Écouter les changements pour mettre à jour l'aperçu
            document.querySelectorAll('.form-check-input, .form-select, .form-control').forEach(element => {
                element.addEventListener('change', generateReportPreview);
            });
            
            // Gestion de l'aperçu complet
            document.getElementById('previewReport').addEventListener('click', function() {
                generateFullPreview();
                new bootstrap.Modal(document.getElementById('previewModal')).show();
            });
            
            // Gestion de la génération du rapport
            document.getElementById('generateReport').addEventListener('click', generateReport);
        });

        // Sidebar toggle
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
            document.getElementById('content').classList.toggle('active');
        });

        // Fonction pour générer depuis l'aperçu
        function generateReportFromPreview() {
            const previewModal = bootstrap.Modal.getInstance(document.getElementById('previewModal'));
            previewModal.hide();
            generateReport();
        }

        // Script pour le toggle du thème
        document.getElementById('themeToggle')?.addEventListener('click', function() {
            const html = document.documentElement;
            const isDark = html.getAttribute('data-bs-theme') === 'dark';
            
            if (isDark) {
                html.setAttribute('data-bs-theme', 'light');
                this.innerHTML = '<i class="fas fa-moon"></i>';
                localStorage.setItem('theme', 'light');
            } else {
                html.setAttribute('data-bs-theme', 'dark');
                this.innerHTML = '<i class="fas fa-sun"></i>';
                localStorage.setItem('theme', 'dark');
            }
        });

        // Vérifier le thème sauvegardé
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme') || 'light';
            const themeToggle = document.getElementById('themeToggle');
            
            document.documentElement.setAttribute('data-bs-theme', savedTheme);
            if (themeToggle) {
                themeToggle.innerHTML = savedTheme === 'dark' ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
            }
        });
    </script>
</body>
</html>