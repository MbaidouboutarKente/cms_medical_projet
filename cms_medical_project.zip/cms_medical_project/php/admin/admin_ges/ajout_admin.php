<?php
session_start();
require_once "../../config/db.php";

// Vérification du rôle Super Admin uniquement
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    header("Location: ../../config/auth.php");
    exit;
}

// Initialisation des variables
$errors = [];
$success = "";
$adminData = [
    'matricule' => '',
    'nom' => '',
    'prenom' => '',
    'email' => '',
    'telephone' => '',
    'role' => 'admin'
];

// Traitement du formulaire d'ajout
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["ajouter"])) {
    // Récupération et validation des données
    $matricule = filter_input(INPUT_POST, "matricule", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $nom = filter_input(INPUT_POST, "nom", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $prenom = filter_input(INPUT_POST, "prenom", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
    $telephone = filter_input(INPUT_POST, "telephone", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $role = filter_input(INPUT_POST, "role", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $password = $_POST["password"] ?? '';
    $confirm_password = $_POST["confirm_password"] ?? '';

    // Validation des champs obligatoires
    if (empty($matricule)) {
        $errors[] = "⚠️ Le matricule est obligatoire.";
    }
    
    if (empty($nom)) {
        $errors[] = "⚠️ Le nom est obligatoire.";
    }
    
    if (empty($prenom)) {
        $errors[] = "⚠️ Le prénom est obligatoire.";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "⚠️ L'adresse email est invalide.";
    }
    
    if (empty($password)) {
        $errors[] = "⚠️ Le mot de passe est obligatoire.";
    }
    
    if ($password !== $confirm_password) {
        $errors[] = "⚠️ Les mots de passe ne correspondent pas.";
    }
    
    if (strlen($password) < 6) {
        $errors[] = "⚠️ Le mot de passe doit contenir au moins 6 caractères.";
    }

    // Sauvegarde des données pour réaffichage
    $adminData = [
        'matricule' => $matricule,
        'nom' => $nom,
        'prenom' => $prenom,
        'email' => $email,
        'telephone' => $telephone,
        'role' => $role
    ];

    // Vérification de l'unicité du matricule et email
    if (empty($errors)) {
        try {
            $stmt = $pdoMedical->prepare("SELECT id FROM utilisateurs WHERE matricule = ? OR email = ?");
            $stmt->execute([$matricule, $email]);
            
            if ($stmt->rowCount() > 0) {
                $errors[] = "⚠️ Un utilisateur avec ce matricule ou cette adresse email existe déjà.";
            }
        } catch (PDOException $e) {
            $errors[] = "❌ Erreur de vérification : " . $e->getMessage();
        }
    }

    // Si pas d'erreurs, insertion en base
    if (empty($errors)) {
        try {
            // Hash du mot de passe
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            // Insertion de l'administrateur
            $stmt = $pdoMedical->prepare("
                INSERT INTO utilisateurs 
                (matricule, nom, prenom, email, telephone,  role,  	mot_de_passe, statut, date_creation) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 'actif', NOW())
            ");
            
            $stmt->execute([
                $matricule,
                $nom,
                $prenom,
                $email,
                $telephone,
                $role,
                $password_hash
            ]);
            
            // Journalisation de l'action
            $logStmt = $pdoMedical->prepare("
                INSERT INTO system_logs 
                (user_id, action_type, action_description, ip_address, user_agent) 
                VALUES (?, 'ADD_ADMIN', ?, ?, ?)
            ");
            
            $logDescription = "Ajout de l'administrateur: $nom $prenom ($matricule) - Rôle: $role";
            $logStmt->execute([
                $_SESSION['user_id'],
                $logDescription,
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT']
            ]);

            $_SESSION['success'] = "✅ Administrateur ajouté avec succès !";
            header("Location: gestion_administrateurs.php");
            exit;

        } catch (PDOException $e) {
            $errors[] = "❌ Erreur lors de l'ajout de l'administrateur : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>👨‍💼 Ajouter un Administrateur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
            --light-color: #f8f9fc;
            --dark-color: #5a5c69;
        }
        
        .admin-creation {
            background-color: #f8f9fc;
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
            padding: 1.25rem 1.5rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }
        
        .required::after {
            content: " *";
            color: var(--danger-color);
        }
        
        .btn {
            border-radius: 0.5rem;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, var(--primary-color), #2e59d9);
            border: none;
            box-shadow: 0 4px 15px rgba(78, 115, 223, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(78, 115, 223, 0.4);
        }
        
        .password-strength {
            height: 4px;
            border-radius: 2px;
            margin-top: 0.25rem;
            transition: all 0.3s ease;
        }
        
        .strength-weak { background-color: var(--danger-color); width: 25%; }
        .strength-fair { background-color: var(--warning-color); width: 50%; }
        .strength-good { background-color: var(--info-color); width: 75%; }
        .strength-strong { background-color: var(--success-color); width: 100%; }
        
        .feature-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(45deg, var(--primary-color), #2e59d9);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .feature-card {
            text-align: center;
            padding: 1.5rem;
            border-radius: 0.5rem;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            height: 100%;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
        }
        
        .role-badge {
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-weight: 500;
            margin: 0.25rem;
        }
        
        .badge-admin { background: linear-gradient(45deg, var(--info-color), #2c9faf); color: white; }
        .badge-super-admin { background: linear-gradient(45deg, var(--primary-color), #2e59d9); color: white; }
        .badge-user { background: linear-gradient(45deg, var(--secondary-color), #6c757d); color: white; }
        
        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
        
        .password-input-group {
            position: relative;
        }
    </style>
</head>
<body class="admin-creation">
    <div class="container-fluid py-4">
        <!-- Messages d'erreur -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Erreurs</h5>
                <?php foreach ($errors as $error): ?>
                    <div><?= htmlspecialchars($error) ?></div>
                <?php endforeach; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- En-tête -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 mb-0 text-gray-800">
                    <i class="fas fa-user-plus me-2"></i>Ajouter un Administrateur
                </h1>
                <p class="text-muted mb-0">Créez un nouveau compte administrateur pour le système</p>
            </div>
            <div class="d-flex gap-2">
                <a href="gestion_administrateurs.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Retour à la liste
                </a>
            </div>
        </div>

        <div class="row">
            <!-- Formulaire d'ajout -->
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-user-cog me-2"></i>Informations de l'administrateur
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="adminForm">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="matricule" class="form-label required">Matricule</label>
                                    <input type="text" class="form-control" id="matricule" name="matricule" 
                                           value="<?= htmlspecialchars($adminData['matricule']) ?>" 
                                           placeholder="Ex: ADM_001" required>
                                    <div class="form-text">Identifiant unique de l'administrateur</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="role" class="form-label required">Rôle</label>
                                    <select class="form-control" id="role" name="role" required>
                                        <option value="admin" <?= $adminData['role'] === 'admin' ? 'selected' : '' ?>>Administrateur</option>
                                        <option value="super_admin" <?= $adminData['role'] === 'super_admin' ? 'selected' : '' ?>>Super Administrateur</option>
                                    </select>
                                    <div class="form-text">Niveau de permissions dans le système</div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="nom" class="form-label required">Nom</label>
                                    <input type="text" class="form-control" id="nom" name="nom" 
                                           value="<?= htmlspecialchars($adminData['nom']) ?>" 
                                           placeholder="Ex: Dupont" required>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="prenom" class="form-label required">Prénom</label>
                                    <input type="text" class="form-control" id="prenom" name="prenom" 
                                           value="<?= htmlspecialchars($adminData['prenom']) ?>" 
                                           placeholder="Ex: Jean" required>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label required">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?= htmlspecialchars($adminData['email']) ?>" 
                                           placeholder="exemple@domaine.com" required>
                                    <div class="form-text">L'adresse email servira pour la connexion</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="telephone" class="form-label">Téléphone</label>
                                    <input type="tel" class="form-control" id="telephone" name="telephone" 
                                           value="<?= htmlspecialchars($adminData['telephone']) ?>" 
                                           placeholder="+225 01 23 45 67 89">
                                </div>
                            </div>
                            
                            <!-- <div class="mb-3">
                                <label for="departement" class="form-label">Département</label>
                                <input type="text" class="form-control" id="departement" name="departement" 
                                       value="<?= htmlspecialchars($adminData['departement']) ?>" 
                                       placeholder="Ex: Informatique, Médical, Administration">
                                <div class="form-text">Département ou service de l'administrateur</div>
                            </div> -->
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="password" class="form-label required">Mot de passe</label>
                                    <div class="password-input-group">
                                        <input type="password" class="form-control" id="password" name="password" 
                                               placeholder="●●●●●●●●" required minlength="6">
                                        <span class="password-toggle" onclick="togglePassword('password')">
                                            <i class="fas fa-eye"></i>
                                        </span>
                                    </div>
                                    <div class="password-strength" id="passwordStrength"></div>
                                    <div class="form-text">Minimum 6 caractères</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="confirm_password" class="form-label required">Confirmation</label>
                                    <div class="password-input-group">
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                               placeholder="●●●●●●●●" required>
                                        <span class="password-toggle" onclick="togglePassword('confirm_password')">
                                            <i class="fas fa-eye"></i>
                                        </span>
                                    </div>
                                    <div id="passwordMatch" class="form-text"></div>
                                </div>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <button type="submit" name="ajouter" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i> Créer l'administrateur
                                </button>
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-undo me-1"></i> Réinitialiser
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Informations et aide -->
            <div class="col-lg-4">
                <!-- Rôles et permissions -->
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-shield-alt me-2"></i>Rôles et Permissions
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <span class="role-badge badge-super-admin">Super Admin</span>
                            <small class="text-muted d-block mt-1">
                                Accès complet à toutes les fonctionnalités du système
                            </small>
                        </div>
                        <div class="mb-3">
                            <span class="role-badge badge-admin">Administrateur</span>
                            <small class="text-muted d-block mt-1">
                                Gestion des utilisateurs, médicaments et contenu
                            </small>
                        </div>
                        <div class="alert alert-info mt-3">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong>Attention :</strong> Le rôle Super Admin donne des permissions étendues.
                        </div>
                    </div>
                </div>
                
                <!-- Fonctionnalités -->
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-tasks me-2"></i>Fonctionnalités Administrateur
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="feature-card">
                                    <div class="feature-icon mx-auto">
                                        <i class="fas fa-users"></i>
                                    </div>
                                    <h6>Utilisateurs</h6>
                                    <small class="text-muted">Gestion des comptes</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="feature-card">
                                    <div class="feature-icon mx-auto">
                                        <i class="fas fa-pills"></i>
                                    </div>
                                    <h6>Médicaments</h6>
                                    <small class="text-muted">Gestion stock</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="feature-card">
                                    <div class="feature-icon mx-auto">
                                        <i class="fas fa-chart-bar"></i>
                                    </div>
                                    <h6>Rapports</h6>
                                    <small class="text-muted">Statistiques</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="feature-card">
                                    <div class="feature-icon mx-auto">
                                        <i class="fas fa-cogs"></i>
                                    </div>
                                    <h6>Paramètres</h6>
                                    <small class="text-muted">Configuration</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Guide rapide -->
                <div class="card shadow">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-lightbulb me-2"></i>Conseils
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <h6><i class="fas fa-exclamation-triangle me-2"></i>Sécurité</h6>
                            <small>
                                • Choisissez un mot de passe fort<br>
                                • Limitez les Super Admins<br>
                                • Vérifiez les permissions
                            </small>
                        </div>
                        <div class="alert alert-success">
                            <h6><i class="fas fa-check-circle me-2"></i>Bonnes pratiques</h6>
                            <small>
                                • Utilisez des matricules uniques<br>
                                • Vérifiez les emails<br>
                                • Documentez les départements
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        const passwordStrength = document.getElementById('passwordStrength');
        const passwordMatch = document.getElementById('passwordMatch');
        
        // Fonction pour basculer la visibilité du mot de passe
        window.togglePassword = function(fieldId) {
            const field = document.getElementById(fieldId);
            const icon = field.parentNode.querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        };
        
        // Vérification de la force du mot de passe
        password.addEventListener('input', function() {
            const value = this.value;
            let strength = 0;
            
            if (value.length >= 6) strength++;
            if (value.match(/[a-z]/) && value.match(/[A-Z]/)) strength++;
            if (value.match(/\d/)) strength++;
            if (value.match(/[^a-zA-Z\d]/)) strength++;
            
            // Mise à jour de l'indicateur de force
            passwordStrength.className = 'password-strength';
            if (value.length > 0) {
                if (strength <= 1) {
                    passwordStrength.classList.add('strength-weak');
                } else if (strength === 2) {
                    passwordStrength.classList.add('strength-fair');
                } else if (strength === 3) {
                    passwordStrength.classList.add('strength-good');
                } else {
                    passwordStrength.classList.add('strength-strong');
                }
            }
        });
        
        // Vérification de la correspondance des mots de passe
        confirmPassword.addEventListener('input', function() {
            if (password.value !== this.value) {
                passwordMatch.innerHTML = '<span class="text-danger"><i class="fas fa-times me-1"></i>Les mots de passe ne correspondent pas</span>';
            } else {
                passwordMatch.innerHTML = '<span class="text-success"><i class="fas fa-check me-1"></i>Les mots de passe correspondent</span>';
            }
        });
        
        // Validation du formulaire
        const form = document.getElementById('adminForm');
        form.addEventListener('submit', function(e) {
            const matricule = document.getElementById('matricule').value.trim();
            const nom = document.getElementById('nom').value.trim();
            const prenom = document.getElementById('prenom').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (!matricule) {
                e.preventDefault();
                alert('Veuillez saisir le matricule');
                document.getElementById('matricule').focus();
                return;
            }
            
            if (!nom) {
                e.preventDefault();
                alert('Veuillez saisir le nom');
                document.getElementById('nom').focus();
                return;
            }
            
            if (!prenom) {
                e.preventDefault();
                alert('Veuillez saisir le prénom');
                document.getElementById('prenom').focus();
                return;
            }
            
            if (!email || !email.includes('@')) {
                e.preventDefault();
                alert('Veuillez saisir une adresse email valide');
                document.getElementById('email').focus();
                return;
            }
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Le mot de passe doit contenir au moins 6 caractères');
                document.getElementById('password').focus();
                return;
            }
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Les mots de passe ne correspondent pas');
                document.getElementById('confirm_password').focus();
                return;
            }
        });
        
        // Génération automatique de matricule
        document.getElementById('nom').addEventListener('blur', function() {
            const matriculeInput = document.getElementById('matricule');
            const nomInput = document.getElementById('nom');
            const prenomInput = document.getElementById('prenom');
            
            if (!matriculeInput.value && nomInput.value && prenomInput.value) {
                const matricule = 'ADM_' + nomInput.value.substring(0, 3).toUpperCase() + 
                                prenomInput.value.substring(0, 3).toUpperCase() + 
                                Math.floor(100 + Math.random() * 900);
                matriculeInput.value = matricule;
            }
        });
        
        // Fermeture automatique des alertes
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                if (alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }
            }, 5000);
        });
    });
    </script>
</body>
</html>