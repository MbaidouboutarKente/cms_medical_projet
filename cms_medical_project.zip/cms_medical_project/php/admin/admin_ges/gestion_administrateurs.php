<?php
session_start();
require_once "../../config/db.php";

// Vérification du rôle Super Admin uniquement
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    header("Location: ../../config/auth.php");
    exit;
}

// Gestion des erreurs et des messages
$errors = $_SESSION['errors'] ?? [];
$success = $_SESSION['success'] ?? "";
unset($_SESSION['errors'], $_SESSION['success']);

// Initialisation des variables
$administrateurs = [];
$totalAdmins = 0;
$totalPages = 1;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Recherche et filtres
$search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '';
$roleFilter = filter_input(INPUT_GET, 'role', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '';
$statutFilter = filter_input(INPUT_GET, 'statut', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? '';

try {
    // Construction de la requête avec filtres
    $query = "SELECT * FROM utilisateurs WHERE role IN ('admin', 'super_admin')";
    $countQuery = "SELECT COUNT(*) FROM utilisateurs WHERE role IN ('admin', 'super_admin')";
    $params = [];
    
    if (!empty($search)) {
        $query .= " AND (matricule LIKE ? OR nom LIKE ? OR prenom LIKE ? OR email LIKE ?)";
        $countQuery .= " AND (matricule LIKE ? OR nom LIKE ? OR prenom LIKE ? OR email LIKE ?)";
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    if (!empty($roleFilter)) {
        $query .= " AND role = ?";
        $countQuery .= " AND role = ?";
        $params[] = $roleFilter;
    }
    
    if (!empty($statutFilter)) {
        $query .= " AND statut = ?";
        $countQuery .= " AND statut = ?";
        $params[] = $statutFilter;
    }
    
    $query .= " ORDER BY date_creation DESC LIMIT ? OFFSET ?";
    
    // Préparation et exécution de la requête principale
    $stmt = $pdoMedical->prepare($query);
    
    // Ajout des paramètres pour la pagination
    $paginationParams = array_merge($params, [$limit, $offset]);
    
    // Liaison des paramètres
    foreach ($paginationParams as $key => $value) {
        $paramType = is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR;
        $stmt->bindValue($key + 1, $value, $paramType);
    }
    
    $stmt->execute();
    $administrateurs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Comptage total pour la pagination
    $countStmt = $pdoMedical->prepare($countQuery);
    if (!empty($params)) {
        $countStmt->execute($params);
    } else {
        $countStmt->execute();
    }
    $totalAdmins = $countStmt->fetchColumn();
    $totalPages = ceil($totalAdmins / $limit);
    
} catch (PDOException $e) {
    error_log("Erreur BD administrateurs: " . $e->getMessage());
    $errors[] = "❌ Erreur de chargement des administrateurs : " . $e->getMessage();
}

// Suppression d'un administrateur
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_id"])) {
    $deleteId = intval($_POST["delete_id"]);
    
    try {
        // Empêcher la suppression de soi-même
        if ($deleteId == $_SESSION['user_id']) {
            $_SESSION['errors'] = ["❌ Vous ne pouvez pas supprimer votre propre compte."];
        } else {
            // Vérifier s'il reste au moins un Super Admin
            $stmt = $pdoMedical->prepare("SELECT COUNT(*) FROM utilisateurs WHERE role = 'super_admin' AND id != ?");
            $stmt->execute([$deleteId]);
            $superAdminCount = $stmt->fetchColumn();
            
            $stmt = $pdoMedical->prepare("SELECT role FROM utilisateurs WHERE id = ?");
            $stmt->execute([$deleteId]);
            $userRole = $stmt->fetchColumn();
            
            if ($userRole === 'super_admin' && $superAdminCount == 0) {
                $_SESSION['errors'] = ["❌ Impossible de supprimer le dernier Super Administrateur."];
            } else {
                // Supprimer l'administrateur
                $stmt = $pdoMedical->prepare("DELETE FROM utilisateurs WHERE id = ?");
                $stmt->execute([$deleteId]);
                
                // Journalisation
                $logStmt = $pdoMedical->prepare("
                    INSERT INTO system_logs 
                    (user_id, action_type, action_description, ip_address, user_agent) 
                    VALUES (?, 'DELETE_ADMIN', ?, ?, ?)
                ");
                
                $logDescription = "Suppression de l'administrateur ID: $deleteId";
                $logStmt->execute([
                    $_SESSION['user_id'],
                    $logDescription,
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
                $_SESSION['success'] = "✅ Administrateur supprimé avec succès.";
            }
        }
        
        header("Location: gestion_administrateurs.php");
        exit;
    } catch (PDOException $e) {
        $_SESSION['errors'] = ["❌ Erreur lors de la suppression : " . $e->getMessage()];
        header("Location: gestion_administrateurs.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>👨‍💼 Gestion des Administrateurs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-management {
            background-color: #f8f9fc;
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
            padding: 1rem 1.25rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: #5a5c69;
            padding: 1rem 0.75rem;
            background-color: #f8f9fc;
        }
        
        .badge-role {
            padding: 0.5rem 0.75rem;
            border-radius: 0.5rem;
            font-weight: 500;
        }
        
        .badge-super-admin { background: linear-gradient(45deg, #4e73df, #2e59d9); color: white; }
        .badge-admin { background: linear-gradient(45deg, #36b9cc, #2c9faf); color: white; }
        
        .badge-statut {
            padding: 0.4rem 0.6rem;
            border-radius: 0.25rem;
            font-size: 0.75rem;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(45deg, #1cc88a, #36b9cc);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 0.9rem;
        }
    </style>
</head>
<body class="admin-management">
    <div class="container-fluid py-4">
        <!-- Messages -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Erreurs</h5>
                <?php foreach ($errors as $error): ?>
                    <div><?= htmlspecialchars($error) ?></div>
                <?php endforeach; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($success) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- En-tête -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 mb-0 text-gray-800">
                    <i class="fas fa-users-cog me-2"></i>Gestion des Administrateurs
                </h1>
                <p class="text-muted mb-0">Gérez les comptes administrateurs du système</p>
            </div>
            <div class="d-flex gap-2">
                <a href="ajout_admin.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Nouvel Administrateur
                </a>
            </div>
        </div>

        <!-- Cartes de statistiques -->
        <div class="row mb-4">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                    Total Admins
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalAdmins ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-users-cog fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100 border-left-success">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                    Super Admins
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php 
                                        try {
                                            $stmt = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'super_admin'");
                                            echo $stmt->fetchColumn();
                                        } catch (PDOException $e) {
                                            echo "0";
                                        }
                                    ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-shield-alt fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100 border-left-info">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                    Admins
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php 
                                        try {
                                            $stmt = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'admin'");
                                            echo $stmt->fetchColumn();
                                        } catch (PDOException $e) {
                                            echo "0";
                                        }
                                    ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-user-cog fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card stats-card h-100 border-left-warning">
                <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                    Actifs
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?php 
                                        try {
                                            $stmt = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role IN ('admin', 'super_admin') AND statut = 'actif'");
                                            echo $stmt->fetchColumn();
                                        } catch (PDOException $e) {
                                            echo "0";
                                        }
                                    ?>
                                </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filtres et recherche -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-filter me-2"></i>Filtres et Recherche
                </h6>
            </div>
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Recherche</label>
                        <input type="text" name="search" class="form-control" placeholder="Matricule, nom, prénom, email..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Rôle</label>
                        <select name="role" class="form-control">
                            <option value="">Tous les rôles</option>
                            <option value="super_admin" <?= $roleFilter === 'super_admin' ? 'selected' : '' ?>>Super Admin</option>
                            <option value="admin" <?= $roleFilter === 'admin' ? 'selected' : '' ?>>Admin</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Statut</label>
                        <select name="statut" class="form-control">
                            <option value="">Tous les statuts</option>
                            <option value="actif" <?= $statutFilter === 'actif' ? 'selected' : '' ?>>Actif</option>
                            <option value="inactif" <?= $statutFilter === 'inactif' ? 'selected' : '' ?>>Inactif</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">&nbsp;</label>
                        <div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-filter me-1"></i> Appliquer
                            </button>
                            <a href="gestion_administrateurs.php" class="btn btn-secondary w-100 mt-2">
                                <i class="fas fa-times me-1"></i> Réinitialiser
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tableau des administrateurs -->
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-table me-2"></i>Liste des Administrateurs
                </h6>
                <span class="badge bg-primary"><?= $totalAdmins ?> administrateur(s)</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover" width="100%" cellspacing="0">
                        <thead class="table-light">
                            <tr>
                                <th>Admin</th>
                                <th>Matricule</th>
                                <th>Email</th>
                                <th>Téléphone</th>
                                <th>Département</th>
                                <th>Rôle</th>
                                <th>Statut</th>
                                <th>Date Création</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($administrateurs)): ?>
                                <tr>
                                    <td colspan="9" class="text-center py-4">
                                        <i class="fas fa-users-cog fa-2x text-muted mb-2 d-block"></i>
                                        <span class="text-muted">Aucun administrateur trouvé</span>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($administrateurs as $admin): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="user-avatar me-3">
                                                <?= substr($admin['prenom'], 0, 1) . substr($admin['nom'], 0, 1) ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold"><?= htmlspecialchars($admin['prenom']) ?> <?= htmlspecialchars($admin['nom']) ?></div>
                                                <small class="text-muted">ID: <?= $admin['id'] ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars($admin['matricule']) ?></strong>
                                    </td>
                                    <td><?= htmlspecialchars($admin['email']) ?></td>
                                    <td><?= htmlspecialchars($admin['telephone'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($admin['departement'] ?? 'N/A') ?></td>
                                    <td>
                                        <span class="badge-role badge-<?= $admin['role'] === 'super_admin' ? 'super-admin' : 'admin' ?>">
                                            <?= $admin['role'] === 'super_admin' ? 'Super Admin' : 'Admin' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge-statut <?= $admin['statut'] === 'actif' ? 'bg-success' : 'bg-danger' ?>">
                                            <?= $admin['statut'] === 'actif' ? 'Actif' : 'Inactif' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <small class="text-muted">
                                            <?= date('d/m/Y', strtotime($admin['date_creation'])) ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div class="d-flex justify-content-center">
                                            <a href="modifier_admin.php?id=<?= $admin['id'] ?>" class="btn btn-outline-primary btn-sm me-1" title="Modifier">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form method="POST" class="d-inline" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cet administrateur ?');">
                                                <input type="hidden" name="delete_id" value="<?= $admin['id'] ?>">
                                                <button type="submit" class="btn btn-outline-danger btn-sm" title="Supprimer"
                                                        <?= $admin['id'] == $_SESSION['user_id'] ? 'disabled' : '' ?>>
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <div class="card-footer">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&role=<?= $roleFilter ?>&statut=<?= $statutFilter ?>">
                                        <i class="fas fa-chevron-left"></i> Précédent
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php 
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            
                            for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&role=<?= $roleFilter ?>&statut=<?= $statutFilter ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&role=<?= $roleFilter ?>&statut=<?= $statutFilter ?>">
                                        Suivant <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                if (alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }
            }, 5000);
        });
    });
    </script>
</body>
</html>