<?php
session_start();
require_once "../../config/db.php";

// Vérification du rôle Super Admin uniquement
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    header("Location: ../../config/auth.php");
    exit;
}

// Initialisation des variables
$errors = [];
$success = "";
$adminData = [];
$adminId = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Vérifier si l'administrateur existe
if ($adminId <= 0) {
    $_SESSION['errors'] = ["❌ ID administrateur invalide."];
    header("Location: gestion_administrateurs.php");
    exit;
}

try {
    // Récupérer les données de l'administrateur
    $stmt = $pdoMedical->prepare("SELECT * FROM utilisateurs WHERE id = ? AND role IN ('admin', 'super_admin')");
    $stmt->execute([$adminId]);
    $adminData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$adminData) {
        $_SESSION['errors'] = ["❌ Administrateur non trouvé."];
        header("Location: gestion_administrateurs.php");
        exit;
    }
} catch (PDOException $e) {
    $_SESSION['errors'] = ["❌ Erreur de récupération des données : " . $e->getMessage()];
    header("Location: gestion_administrateurs.php");
    exit;
}

// Traitement du formulaire de modification
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["modifier"])) {
    // Récupération et validation des données
    $matricule = filter_input(INPUT_POST, "matricule", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $nom = filter_input(INPUT_POST, "nom", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $prenom = filter_input(INPUT_POST, "prenom", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
    $telephone = filter_input(INPUT_POST, "telephone", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $departement = filter_input(INPUT_POST, "departement", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $role = filter_input(INPUT_POST, "role", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $statut = filter_input(INPUT_POST, "statut", FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $password = $_POST["password"] ?? '';
    $confirm_password = $_POST["confirm_password"] ?? '';

    // Validation des champs obligatoires
    if (empty($matricule)) {
        $errors[] = "⚠️ Le matricule est obligatoire.";
    }
    
    if (empty($nom)) {
        $errors[] = "⚠️ Le nom est obligatoire.";
    }
    
    if (empty($prenom)) {
        $errors[] = "⚠️ Le prénom est obligatoire.";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "⚠️ L'adresse email est invalide.";
    }
    
    // Validation du mot de passe si fourni
    if (!empty($password)) {
        if ($password !== $confirm_password) {
            $errors[] = "⚠️ Les mots de passe ne correspondent pas.";
        }
        
        if (strlen($password) < 6) {
            $errors[] = "⚠️ Le mot de passe doit contenir au moins 6 caractères.";
        }
    }

    // Vérification de l'unicité du matricule et email (exclure l'utilisateur courant)
    if (empty($errors)) {
        try {
            $stmt = $pdoMedical->prepare("SELECT id FROM utilisateurs WHERE (matricule = ? OR email = ?) AND id != ?");
            $stmt->execute([$matricule, $email, $adminId]);
            
            if ($stmt->rowCount() > 0) {
                $errors[] = "⚠️ Un autre utilisateur avec ce matricule ou cette adresse email existe déjà.";
            }
        } catch (PDOException $e) {
            $errors[] = "❌ Erreur de vérification : " . $e->getMessage();
        }
    }

    // Si pas d'erreurs, mise à jour en base
    if (empty($errors)) {
        try {
            // Préparer la requête de mise à jour
            if (!empty($password)) {
                // Mise à jour avec nouveau mot de passe
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdoMedical->prepare("
                    UPDATE utilisateurs 
                    SET matricule = ?, nom = ?, prenom = ?, email = ?, telephone = ?, 
                        departement = ?, role = ?, statut = ?, password_hash = ?, date_modification = NOW()
                    WHERE id = ?
                ");
                
                $stmt->execute([
                    $matricule,
                    $nom,
                    $prenom,
                    $email,
                    $telephone,
                    $departement,
                    $role,
                    $statut,
                    $password_hash,
                    $adminId
                ]);
            } else {
                // Mise à jour sans changer le mot de passe
                $stmt = $pdoMedical->prepare("
                    UPDATE utilisateurs 
                    SET matricule = ?, nom = ?, prenom = ?, email = ?, telephone = ?, 
                        departement = ?, role = ?, statut = ?, date_modification = NOW()
                    WHERE id = ?
                ");
                
                $stmt->execute([
                    $matricule,
                    $nom,
                    $prenom,
                    $email,
                    $telephone,
                    $departement,
                    $role,
                    $statut,
                    $adminId
                ]);
            }
            
            // Journalisation de l'action
            $logStmt = $pdoMedical->prepare("
                INSERT INTO system_logs 
                (user_id, action_type, action_description, ip_address, user_agent) 
                VALUES (?, 'UPDATE_ADMIN', ?, ?, ?)
            ");
            
            $logDescription = "Modification de l'administrateur: $nom $prenom ($matricule) - Rôle: $role - Statut: $statut";
            $logStmt->execute([
                $_SESSION['user_id'],
                $logDescription,
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT']
            ]);

            $_SESSION['success'] = "✅ Administrateur modifié avec succès !";
            header("Location: gestion_administrateurs.php");
            exit;

        } catch (PDOException $e) {
            $errors[] = "❌ Erreur lors de la modification : " . $e->getMessage();
        }
    }
    
    // Mettre à jour les données pour l'affichage
    $adminData = [
        'matricule' => $matricule,
        'nom' => $nom,
        'prenom' => $prenom,
        'email' => $email,
        'telephone' => $telephone,
        'departement' => $departement,
        'role' => $role,
        'statut' => $statut
    ];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>✏️ Modifier un Administrateur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
            --light-color: #f8f9fc;
            --dark-color: #5a5c69;
        }
        
        .admin-modification {
            background-color: #f8f9fc;
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
            padding: 1.25rem 1.5rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }
        
        .required::after {
            content: " *";
            color: var(--danger-color);
        }
        
        .btn {
            border-radius: 0.5rem;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, var(--primary-color), #2e59d9);
            border: none;
            box-shadow: 0 4px 15px rgba(78, 115, 223, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(78, 115, 223, 0.4);
        }
        
        .password-strength {
            height: 4px;
            border-radius: 2px;
            margin-top: 0.25rem;
            transition: all 0.3s ease;
        }
        
        .strength-weak { background-color: var(--danger-color); width: 25%; }
        .strength-fair { background-color: var(--warning-color); width: 50%; }
        .strength-good { background-color: var(--info-color); width: 75%; }
        .strength-strong { background-color: var(--success-color); width: 100%; }
        
        .user-avatar-large {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(45deg, var(--primary-color), #2e59d9);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 2rem;
            margin: 0 auto 1rem;
        }
        
        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
        
        .password-input-group {
            position: relative;
        }
        
        .info-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 0.75rem;
            padding: 1.5rem;
        }
        
        .role-badge {
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-weight: 500;
        }
        
        .badge-admin { background: linear-gradient(45deg, var(--info-color), #2c9faf); color: white; }
        .badge-super-admin { background: linear-gradient(45deg, var(--primary-color), #2e59d9); color: white; }
    </style>
</head>
<body class="admin-modification">
    <div class="container-fluid py-4">
        <!-- Messages d'erreur -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Erreurs</h5>
                <?php foreach ($errors as $error): ?>
                    <div><?= htmlspecialchars($error) ?></div>
                <?php endforeach; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- En-tête -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 mb-0 text-gray-800">
                    <i class="fas fa-user-edit me-2"></i>Modifier un Administrateur
                </h1>
                <p class="text-muted mb-0">Modifiez les informations de l'administrateur</p>
            </div>
            <div class="d-flex gap-2">
                <a href="gestion_administrateurs.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Retour à la liste
                </a>
            </div>
        </div>

        <div class="row">
            <!-- Formulaire de modification -->
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-user-cog me-2"></i>Informations de l'administrateur
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="adminForm">
                            <input type="hidden" name="admin_id" value="<?= $adminId ?>">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="matricule" class="form-label required">Matricule</label>
                                    <input type="text" class="form-control" id="matricule" name="matricule" 
                                           value="<?= htmlspecialchars($adminData['matricule'] ?? '') ?>" 
                                           placeholder="Ex: ADM_001" required>
                                    <div class="form-text">Identifiant unique de l'administrateur</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="role" class="form-label required">Rôle</label>
                                    <select class="form-control" id="role" name="role" required>
                                        <option value="admin" <?= ($adminData['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Administrateur</option>
                                        <option value="super_admin" <?= ($adminData['role'] ?? '') === 'super_admin' ? 'selected' : '' ?>>Super Administrateur</option>
                                    </select>
                                    <div class="form-text">Niveau de permissions dans le système</div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="nom" class="form-label required">Nom</label>
                                    <input type="text" class="form-control" id="nom" name="nom" 
                                           value="<?= htmlspecialchars($adminData['nom'] ?? '') ?>" 
                                           placeholder="Ex: Dupont" required>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="prenom" class="form-label required">Prénom</label>
                                    <input type="text" class="form-control" id="prenom" name="prenom" 
                                           value="<?= htmlspecialchars($adminData['prenom'] ?? '') ?>" 
                                           placeholder="Ex: Jean" required>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label required">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?= htmlspecialchars($adminData['email'] ?? '') ?>" 
                                           placeholder="exemple@domaine.com" required>
                                    <div class="form-text">L'adresse email servira pour la connexion</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="telephone" class="form-label">Téléphone</label>
                                    <input type="tel" class="form-control" id="telephone" name="telephone" 
                                           value="<?= htmlspecialchars($adminData['telephone'] ?? '') ?>" 
                                           placeholder="+225 01 23 45 67 89">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="departement" class="form-label">Département</label>
                                    <input type="text" class="form-control" id="departement" name="departement" 
                                           value="<?= htmlspecialchars($adminData['departement'] ?? '') ?>" 
                                           placeholder="Ex: Informatique, Médical, Administration">
                                    <div class="form-text">Département ou service de l'administrateur</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="statut" class="form-label required">Statut</label>
                                    <select class="form-control" id="statut" name="statut" required>
                                        <option value="actif" <?= ($adminData['statut'] ?? 'actif') === 'actif' ? 'selected' : '' ?>>Actif</option>
                                        <option value="inactif" <?= ($adminData['statut'] ?? 'actif') === 'inactif' ? 'selected' : '' ?>>Inactif</option>
                                    </select>
                                    <div class="form-text">Statut du compte administrateur</div>
                                </div>
                            </div>
                            
                            <div class="card mt-4 mb-4">
                                <div class="card-header bg-light">
                                    <h6 class="card-title mb-0">
                                        <i class="fas fa-lock me-2"></i>Modification du mot de passe
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i>
                                        Laissez ces champs vides si vous ne souhaitez pas modifier le mot de passe.
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="password" class="form-label">Nouveau mot de passe</label>
                                            <div class="password-input-group">
                                                <input type="password" class="form-control" id="password" name="password" 
                                                       placeholder="●●●●●●●●" minlength="6">
                                                <span class="password-toggle" onclick="togglePassword('password')">
                                                    <i class="fas fa-eye"></i>
                                                </span>
                                            </div>
                                            <div class="password-strength" id="passwordStrength"></div>
                                            <div class="form-text">Minimum 6 caractères</div>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label for="confirm_password" class="form-label">Confirmation</label>
                                            <div class="password-input-group">
                                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                                       placeholder="●●●●●●●●">
                                                <span class="password-toggle" onclick="togglePassword('confirm_password')">
                                                    <i class="fas fa-eye"></i>
                                                </span>
                                            </div>
                                            <div id="passwordMatch" class="form-text"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <button type="submit" name="modifier" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i> Enregistrer les modifications
                                </button>
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-undo me-1"></i> Réinitialiser
                                </button>
                                <a href="gestion_administrateurs.php" class="btn btn-outline-danger">
                                    <i class="fas fa-times me-1"></i> Annuler
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Informations et profil -->
            <div class="col-lg-4">
                <!-- Profil administrateur -->
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-id-card me-2"></i>Profil Administrateur
                        </h6>
                    </div>
                    <div class="card-body text-center">
                        <div class="user-avatar-large">
                            <?= substr($adminData['prenom'] ?? '', 0, 1) . substr($adminData['nom'] ?? '', 0, 1) ?>
                        </div>
                        <h5><?= htmlspecialchars($adminData['prenom'] ?? '') ?> <?= htmlspecialchars($adminData['nom'] ?? '') ?></h5>
                        <p class="text-muted"><?= htmlspecialchars($adminData['matricule'] ?? '') ?></p>
                        
                        <div class="mb-3">
                            <span class="role-badge badge-<?= ($adminData['role'] ?? '') === 'super_admin' ? 'super-admin' : 'admin' ?>">
                                <?= ($adminData['role'] ?? '') === 'super_admin' ? 'Super Admin' : 'Admin' ?>
                            </span>
                            <span class="badge <?= ($adminData['statut'] ?? 'actif') === 'actif' ? 'bg-success' : 'bg-danger' ?>">
                                <?= ($adminData['statut'] ?? 'actif') === 'actif' ? 'Actif' : 'Inactif' ?>
                            </span>
                        </div>
                        
                        <div class="text-start">
                            <p><strong><i class="fas fa-envelope me-2"></i>Email:</strong><br>
                            <?= htmlspecialchars($adminData['email'] ?? '') ?></p>
                            
                            <?php if (!empty($adminData['telephone'])): ?>
                            <p><strong><i class="fas fa-phone me-2"></i>Téléphone:</strong><br>
                            <?= htmlspecialchars($adminData['telephone']) ?></p>
                            <?php endif; ?>
                            
                            <?php if (!empty($adminData['departement'])): ?>
                            <p><strong><i class="fas fa-building me-2"></i>Département:</strong><br>
                            <?= htmlspecialchars($adminData['departement']) ?></p>
                            <?php endif; ?>
                            
                            <?php if (!empty($adminData['date_creation']) || !empty($adminData['created_at'])): ?>
                            <p><strong><i class="fas fa-calendar me-2"></i>Créé le:</strong><br>
                            <?= date('d/m/Y', strtotime($adminData['date_creation'] ?? $adminData['created_at'] ?? '')) ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Informations importantes -->
                <div class="card shadow">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-info-circle me-2"></i>Informations importantes
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <h6><i class="fas fa-exclamation-triangle me-2"></i>Attention</h6>
                            <small>
                                • La modification du rôle change les permissions<br>
                                • Le statut "Inactif" bloque la connexion<br>
                                • Vérifiez l'email avant sauvegarde
                            </small>
                        </div>
                        <div class="alert alert-info">
                            <h6><i class="fas fa-lightbulb me-2"></i>Conseils</h6>
                            <small>
                                • Modifiez le mot de passe si nécessaire<br>
                                • Conservez un contact téléphonique<br>
                                • Documentez les changements importants
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        const passwordStrength = document.getElementById('passwordStrength');
        const passwordMatch = document.getElementById('passwordMatch');
        
        // Fonction pour basculer la visibilité du mot de passe
        window.togglePassword = function(fieldId) {
            const field = document.getElementById(fieldId);
            const icon = field.parentNode.querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        };
        
        // Vérification de la force du mot de passe
        password.addEventListener('input', function() {
            const value = this.value;
            let strength = 0;
            
            if (value.length >= 6) strength++;
            if (value.match(/[a-z]/) && value.match(/[A-Z]/)) strength++;
            if (value.match(/\d/)) strength++;
            if (value.match(/[^a-zA-Z\d]/)) strength++;
            
            // Mise à jour de l'indicateur de force
            passwordStrength.className = 'password-strength';
            if (value.length > 0) {
                if (strength <= 1) {
                    passwordStrength.classList.add('strength-weak');
                } else if (strength === 2) {
                    passwordStrength.classList.add('strength-fair');
                } else if (strength === 3) {
                    passwordStrength.classList.add('strength-good');
                } else {
                    passwordStrength.classList.add('strength-strong');
                }
            }
        });
        
        // Vérification de la correspondance des mots de passe
        confirmPassword.addEventListener('input', function() {
            if (password.value && this.value) {
                if (password.value !== this.value) {
                    passwordMatch.innerHTML = '<span class="text-danger"><i class="fas fa-times me-1"></i>Les mots de passe ne correspondent pas</span>';
                } else {
                    passwordMatch.innerHTML = '<span class="text-success"><i class="fas fa-check me-1"></i>Les mots de passe correspondent</span>';
                }
            } else {
                passwordMatch.innerHTML = '';
            }
        });
        
        // Validation du formulaire
        const form = document.getElementById('adminForm');
        form.addEventListener('submit', function(e) {
            const matricule = document.getElementById('matricule').value.trim();
            const nom = document.getElementById('nom').value.trim();
            const prenom = document.getElementById('prenom').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (!matricule) {
                e.preventDefault();
                alert('Veuillez saisir le matricule');
                document.getElementById('matricule').focus();
                return;
            }
            
            if (!nom) {
                e.preventDefault();
                alert('Veuillez saisir le nom');
                document.getElementById('nom').focus();
                return;
            }
            
            if (!prenom) {
                e.preventDefault();
                alert('Veuillez saisir le prénom');
                document.getElementById('prenom').focus();
                return;
            }
            
            if (!email || !email.includes('@')) {
                e.preventDefault();
                alert('Veuillez saisir une adresse email valide');
                document.getElementById('email').focus();
                return;
            }
            
            if (password && password.length < 6) {
                e.preventDefault();
                alert('Le mot de passe doit contenir au moins 6 caractères');
                document.getElementById('password').focus();
                return;
            }
            
            if (password && password !== confirmPassword) {
                e.preventDefault();
                alert('Les mots de passe ne correspondent pas');
                document.getElementById('confirm_password').focus();
                return;
            }
        });
        
        // Fermeture automatique des alertes
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                if (alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }
            }, 5000);
        });
    });
    </script>
</body>
</html>