<?php
session_start();

// Activation des erreurs pour le débogage
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "../../config/db.php";

// Vérification rôle admin ou super_admin avec privilèges étendus pour super_admin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'super_admin'])) {
    $_SESSION['error'] = "Accès non autorisé. Rôle administrateur requis.";
    header("Location: ../../config/auth.php");
    exit;
}

// Vérification des privilèges spéciaux pour super_admin
$is_super_admin = ($_SESSION['role'] === 'super_admin');

// Initialisation des variables
$errors = [];
$success = "";
$userData = [
    'matricule' => '',
    'nom' => '',
    'prenom' => '',
    'email' => '',
    'telephone' => '',
    'role' => 'medecin',
    'specialite' => '',
    'adresse' => ''
];

// Rôles disponibles - restrictions pour admin normal
if ($is_super_admin) {
    // Super_admin peut créer tous les rôles y compris d'autres super_admin
    $roles = [
        'medecin' => 'Médecin',
        'infirmier' => 'Infirmier',
        'patient' => 'Patient',
        'admin' => 'Administrateur',
        'super_admin' => 'Super Administrateur'
    ];
} else {
    // Admin normal ne peut pas créer de super_admin
    $roles = [
        'medecin' => 'Médecin',
        'infirmier' => 'Infirmier',
        'patient' => 'Patient',
        'admin' => 'Administrateur'
    ];
}

// Spécialités médicales
$specialites = [
    '' => 'Sélectionner une spécialité',
    'cardiologie' => 'Cardiologie',
    'dermatologie' => 'Dermatologie',
    'pediatrie' => 'Pédiatrie',
    'chirurgie' => 'Chirurgie',
    'gynecologie' => 'Gynécologie',
    'ophtalmologie' => 'Ophtalmologie',
    'neurologie' => 'Neurologie',
    'psychiatrie' => 'Psychiatrie',
    'radiologie' => 'Radiologie',
    'urgentiste' => 'Médecin Urgentiste',
    'generaliste' => 'Médecin Généraliste'
];

// Traitement du formulaire d'ajout
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["ajouter"])) {
    // Récupération et validation des données
    $matricule = trim($_POST["matricule"] ?? '');
    $nom = trim($_POST["nom"] ?? '');
    $prenom = trim($_POST["prenom"] ?? '');
    $email = trim($_POST["email"] ?? '');
    $telephone = trim($_POST["telephone"] ?? '');
    $role = $_POST["role"] ?? 'medecin';
    $specialite = $_POST["specialite"] ?? '';
    $adresse = trim($_POST["adresse"] ?? '');
    $password = $_POST["password"] ?? '';
    $confirm_password = $_POST["confirm_password"] ?? '';

    // Vérification des privilèges pour la création de super_admin
    if ($role === 'super_admin' && !$is_super_admin) {
        $errors[] = "❌ Privilèges insuffisants : Vous ne pouvez pas créer un compte Super Administrateur.";
    }

    // Validation des champs obligatoires
    if (empty($matricule)) {
        $errors[] = "⚠️ Le matricule est obligatoire.";
    } elseif (!preg_match('/^[A-Z0-9_]+$/', $matricule)) {
        $errors[] = "⚠️ Le matricule ne doit contenir que des lettres majuscules, chiffres et underscores.";
    }

    if (empty($nom)) {
        $errors[] = "⚠️ Le nom est obligatoire.";
    } elseif (strlen($nom) < 2) {
        $errors[] = "⚠️ Le nom doit contenir au moins 2 caractères.";
    }

    if (empty($prenom)) {
        $errors[] = "⚠️ Le prénom est obligatoire.";
    } elseif (strlen($prenom) < 2) {
        $errors[] = "⚠️ Le prénom doit contenir au moins 2 caractères.";
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "⚠️ L'adresse email est invalide.";
    }

    if (empty($password)) {
        $errors[] = "⚠️ Le mot de passe est obligatoire.";
    } elseif (strlen($password) < 6) {
        $errors[] = "⚠️ Le mot de passe doit contenir au moins 6 caractères.";
    }

    if ($password !== $confirm_password) {
        $errors[] = "⚠️ Les mots de passe ne correspondent pas.";
    }

    if ($role === 'medecin' && empty($specialite)) {
        $errors[] = "⚠️ La spécialité est obligatoire pour les médecins.";
    }

    // Validation du téléphone
    if (!empty($telephone) && !preg_match('/^[\+]?[0-9\s\-\(\)]{8,}$/', $telephone)) {
        $errors[] = "⚠️ Le format du téléphone est invalide.";
    }

    // Sauvegarde des données pour réaffichage
    $userData = [
        'matricule' => $matricule,
        'nom' => $nom,
        'prenom' => $prenom,
        'email' => $email,
        'telephone' => $telephone,
        'role' => $role,
        'specialite' => $specialite,
        'adresse' => $adresse
    ];

    // Vérification de l'unicité du matricule et email
    if (empty($errors)) {
        try {
            $stmt = $pdoMedical->prepare("SELECT id FROM utilisateurs WHERE matricule = ? OR email = ?");
            $stmt->execute([$matricule, $email]);
            
            if ($stmt->rowCount() > 0) {
                $errors[] = "⚠️ Un utilisateur avec ce matricule ou cette adresse email existe déjà.";
            }
        } catch (PDOException $e) {
            $errors[] = "❌ Erreur de vérification : " . $e->getMessage();
        }
    }

    // Si pas d'erreurs, insertion en base
    if (empty($errors)) {
        try {
            // Hash du mot de passe
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            // Préparation de la requête d'insertion
            $columns = [
                'matricule', 'nom', 'prenom', 'email', 'telephone', 
                'role', 'mot_de_passe', 'statut', 'date_creation'
            ];
            $values = [
                $matricule, $nom, $prenom, $email, $telephone,
                $role, $password_hash, 'actif', date('Y-m-d H:i:s')
            ];
            $placeholders = array_fill(0, count($columns), '?');

            // Ajout des champs conditionnels
            if (!empty($specialite)) {
                $columns[] = 'specialite';
                $values[] = $specialite;
                $placeholders[] = '?';
            }

            if (!empty($adresse)) {
                $columns[] = 'adresse';
                $values[] = $adresse;
                $placeholders[] = '?';
            }

            $sql = "INSERT INTO utilisateurs (" . implode(', ', $columns) . ") 
                    VALUES (" . implode(', ', $placeholders) . ")";
            
            $stmt = $pdoMedical->prepare($sql);
            $stmt->execute($values);
            
            // Journalisation de l'action avec mention du privilège
            $logStmt = $pdoMedical->prepare("
                INSERT INTO system_logs 
                (user_id, action_type, action_description, ip_address, user_agent) 
                VALUES (?, 'ADD_USER', ?, ?, ?)
            ");
            
            $userRole = $_SESSION['role'];
            $logDescription = "Ajout de l'utilisateur: $nom $prenom ($matricule) - Rôle: $role - Créé par: $userRole";
            $logStmt->execute([
                $_SESSION['user_id'],
                $logDescription,
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT']
            ]);

            $_SESSION['success'] = "✅ Utilisateur ajouté avec succès !";
            header("Location: liste_users.php");
            exit;

        } catch (PDOException $e) {
            $errors[] = "❌ Erreur lors de l'ajout de l'utilisateur : " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>👥 Ajouter un Utilisateur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
            --light-color: #f8f9fc;
            --dark-color: #5a5c69;
            --super-admin-color: #8B008B;
        }
        
        .user-creation {
            background-color: #f8f9fc;
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
            padding: 1.25rem 1.5rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }
        
        .required::after {
            content: " *";
            color: var(--danger-color);
        }
        
        .btn {
            border-radius: 0.5rem;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, var(--primary-color), #2e59d9);
            border: none;
            box-shadow: 0 4px 15px rgba(78, 115, 223, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(78, 115, 223, 0.4);
        }
        
        .password-strength {
            height: 4px;
            border-radius: 2px;
            margin-top: 0.25rem;
            transition: all 0.3s ease;
        }
        
        .strength-weak { background-color: var(--danger-color); width: 25%; }
        .strength-fair { background-color: var(--warning-color); width: 50%; }
        .strength-good { background-color: var(--info-color); width: 75%; }
        .strength-strong { background-color: var(--success-color); width: 100%; }
        
        .role-badge {
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-weight: 500;
            margin: 0.25rem;
        }
        
        .badge-medecin { background: linear-gradient(45deg, var(--primary-color), #2e59d9); color: white; }
        .badge-infirmier { background: linear-gradient(45deg, var(--info-color), #2c9faf); color: white; }
        .badge-patient { background: linear-gradient(45deg, var(--success-color), #1a9f6e); color: white; }
        .badge-admin { background: linear-gradient(45deg, var(--warning-color), #d9822b); color: white; }
        .badge-super-admin { background: linear-gradient(45deg, var(--super-admin-color), #6A0DAD); color: white; }
        
        .password-toggle {
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
        
        .password-input-group {
            position: relative;
        }
        
        .feature-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(45deg, var(--primary-color), #2e59d9);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .feature-card {
            text-align: center;
            padding: 1.5rem;
            border-radius: 0.5rem;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            height: 100%;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
        }
        
        .conditional-field {
            display: none;
            animation: fadeIn 0.3s ease;
        }
        
        .super-admin-badge {
            background: linear-gradient(45deg, var(--super-admin-color), #6A0DAD);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }
        
        .privilege-info {
            border-left: 4px solid var(--super-admin-color);
            background-color: rgba(139, 0, 139, 0.05);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="user-creation">
    <div class="container-fluid py-4">
        <!-- Messages d'erreur -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Erreurs</h5>
                <?php foreach ($errors as $error): ?>
                    <div><?= htmlspecialchars($error) ?></div>
                <?php endforeach; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- En-tête -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 mb-0 text-gray-800">
                    <i class="fas fa-user-plus me-2"></i>Ajouter un Utilisateur
                    <?php if ($is_super_admin): ?>
                        <span class="super-admin-badge">Super Admin</span>
                    <?php endif; ?>
                </h1>
                <p class="text-muted mb-0">
                    Créez un nouveau compte utilisateur pour le système médical
                    <?php if ($is_super_admin): ?>
                        <span class="text-success"><i class="fas fa-crown me-1"></i>Privilèges étendus activés</span>
                    <?php endif; ?>
                </p>
            </div>
            <div class="d-flex gap-2">
                <a href="liste_users.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Retour à la liste
                </a>
            </div>
        </div>

        <div class="row">
            <!-- Formulaire d'ajout -->
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-user-circle me-2"></i>Informations personnelles
                            <?php if ($is_super_admin): ?>
                                <small class="text-success ms-2"><i class="fas fa-crown me-1"></i>Mode Super Admin</small>
                            <?php endif; ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="userForm">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="matricule" class="form-label required">Matricule</label>
                                    <input type="text" class="form-control" id="matricule" name="matricule" 
                                           value="<?= htmlspecialchars($userData['matricule']) ?>" 
                                           placeholder="Ex: MED_001, INF_001" required
                                           pattern="[A-Z0-9_]+" title="Lettres majuscules, chiffres et underscores uniquement">
                                    <div class="form-text">Identifiant unique de l'utilisateur</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="role" class="form-label required">Rôle</label>
                                    <select class="form-control" id="role" name="role" required>
                                        <?php foreach ($roles as $value => $label): ?>
                                            <option value="<?= $value ?>" <?= $userData['role'] === $value ? 'selected' : '' ?>>
                                                <?= $label ?>
                                                <?php if ($value === 'super_admin'): ?>
                                                    <i class="fas fa-crown ms-1"></i>
                                                <?php endif; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="form-text">
                                        Niveau de permissions dans le système
                                        <?php if (!$is_super_admin): ?>
                                            <span class="text-warning"><i class="fas fa-info-circle me-1"></i>Privilèges limités</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="nom" class="form-label required">Nom</label>
                                    <input type="text" class="form-control" id="nom" name="nom" 
                                           value="<?= htmlspecialchars($userData['nom']) ?>" 
                                           placeholder="Ex: Dupont" required minlength="2">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="prenom" class="form-label required">Prénom</label>
                                    <input type="text" class="form-control" id="prenom" name="prenom" 
                                           value="<?= htmlspecialchars($userData['prenom']) ?>" 
                                           placeholder="Ex: Jean" required minlength="2">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label required">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?= htmlspecialchars($userData['email']) ?>" 
                                           placeholder="exemple@domaine.com" required>
                                    <div class="form-text">L'adresse email servira pour la connexion</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="telephone" class="form-label">Téléphone</label>
                                    <input type="tel" class="form-control" id="telephone" name="telephone" 
                                           value="<?= htmlspecialchars($userData['telephone']) ?>" 
                                           placeholder="+225 01 23 45 67 89"
                                           pattern="[\+]?[0-9\s\-\(\)]{8,}">
                                    <div class="form-text">Format international recommandé</div>
                                </div>
                            </div>
                                                        
                            <!-- Champ spécialité (conditionnel pour les médecins) -->
                            <div class="mb-3 conditional-field" id="specialite-field">
                                <label for="specialite" class="form-label required">Spécialité médicale</label>
                                <select class="form-control" id="specialite" name="specialite">
                                    <?php foreach ($specialites as $value => $label): ?>
                                        <option value="<?= $value ?>" <?= $userData['specialite'] === $value ? 'selected' : '' ?>>
                                            <?= $label ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="password" class="form-label required">Mot de passe</label>
                                    <div class="password-input-group">
                                        <input type="password" class="form-control" id="password" name="password" 
                                               placeholder="●●●●●●●●" required minlength="6">
                                        <span class="password-toggle" onclick="togglePassword('password')">
                                            <i class="fas fa-eye"></i>
                                        </span>
                                    </div>
                                    <div class="password-strength" id="passwordStrength"></div>
                                    <div class="form-text">Minimum 6 caractères</div>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label for="confirm_password" class="form-label required">Confirmation</label>
                                    <div class="password-input-group">
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                               placeholder="●●●●●●●●" required>
                                        <span class="password-toggle" onclick="togglePassword('confirm_password')">
                                            <i class="fas fa-eye"></i>
                                        </span>
                                    </div>
                                    <div id="passwordMatch" class="form-text"></div>
                                </div>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <button type="submit" name="ajouter" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i> Créer l'utilisateur
                                </button>
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="fas fa-undo me-1"></i> Réinitialiser
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Informations et aide -->
            <div class="col-lg-4">
                <!-- Rôles et permissions -->
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-shield-alt me-2"></i>Rôles et Permissions
                        </h6>
                    </div>
                    <div class="card-body">
                        <?php if ($is_super_admin): ?>
                            <div class="mb-3 privilege-info p-2">
                                <span class="role-badge badge-super-admin">Super Administrateur</span>
                                <small class="text-muted d-block mt-1">
                                    <i class="fas fa-crown me-1"></i>Accès complet + Gestion des autres administrateurs
                                </small>
                            </div>
                        <?php endif; ?>
                        <div class="mb-3">
                            <span class="role-badge badge-admin">Administrateur</span>
                            <small class="text-muted d-block mt-1">
                                Accès complet à toutes les fonctionnalités du système
                            </small>
                        </div>
                        <div class="mb-3">
                            <span class="role-badge badge-medecin">Médecin</span>
                            <small class="text-muted d-block mt-1">
                                Gestion des patients, prescriptions, consultations
                            </small>
                        </div>
                        <div class="mb-3">
                            <span class="role-badge badge-infirmier">Infirmier</span>
                            <small class="text-muted d-block mt-1">
                                Soins patients, gestion des médicaments, observations
                            </small>
                        </div>
                        <div class="mb-3">
                            <span class="role-badge badge-patient">Patient</span>
                            <small class="text-muted d-block mt-1">
                                Consultation de ses rendez-vous et informations
                            </small>
                        </div>
                    </div>
                </div>
                
                <!-- Guide rapide -->
                <div class="card shadow">
                    <div class="card-header">
                        <h6 class="card-title mb-0">
                            <i class="fas fa-lightbulb me-2"></i>Conseils de création
                        </h6>
                    </div>
                    <div class="card-body">
                        <?php if ($is_super_admin): ?>
                            <div class="alert alert-dark">
                                <h6><i class="fas fa-crown me-2"></i>Privilèges Super Admin</h6>
                                <small>
                                    • Vous pouvez créer des comptes Super Admin<br>
                                    • Accès complet à tous les modules<br>
                                    • Gestion de tous les utilisateurs
                                </small>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-secondary">
                                <h6><i class="fas fa-user-shield me-2"></i>Privilèges Admin</h6>
                                <small>
                                    • Création de tous les rôles sauf Super Admin<br>
                                    • Gestion des utilisateurs standard<br>
                                    • Accès aux fonctionnalités administratives
                                </small>
                            </div>
                        <?php endif; ?>
                        <div class="alert alert-warning">
                            <h6><i class="fas fa-exclamation-triangle me-2"></i>Sécurité</h6>
                            <small>
                                • Choisissez un mot de passe fort<br>
                                • Utilisez des matricules uniques<br>
                                • Vérifiez les emails
                            </small>
                        </div>
                        <div class="alert alert-info">
                            <h6><i class="fas fa-info-circle me-2"></i>Bonnes pratiques</h6>
                            <small>
                                • Complétez toutes les informations<br>
                                • Vérifiez la spécialité pour les médecins<br>
                                • Documentez le département
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        const passwordStrength = document.getElementById('passwordStrength');
        const passwordMatch = document.getElementById('passwordMatch');
        const roleSelect = document.getElementById('role');
        const specialiteField = document.getElementById('specialite-field');
        const specialiteSelect = document.getElementById('specialite');
        
        // Fonction pour basculer la visibilité du mot de passe
        window.togglePassword = function(fieldId) {
            const field = document.getElementById(fieldId);
            const icon = field.parentNode.querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        };
        
        // Gestion des champs conditionnels
        function toggleConditionalFields() {
            const role = roleSelect.value;
            
            // Spécialité pour les médecins
            if (role === 'medecin') {
                specialiteField.style.display = 'block';
                specialiteSelect.required = true;
            } else {
                specialiteField.style.display = 'none';
                specialiteSelect.required = false;
            }
        }
        
        // Écouteur pour le changement de rôle
        roleSelect.addEventListener('change', toggleConditionalFields);
        
        // Initialisation
        toggleConditionalFields();
        
        // Vérification de la force du mot de passe
        password.addEventListener('input', function() {
            const value = this.value;
            let strength = 0;
            
            if (value.length >= 6) strength++;
            if (value.match(/[a-z]/) && value.match(/[A-Z]/)) strength++;
            if (value.match(/\d/)) strength++;
            if (value.match(/[^a-zA-Z\d]/)) strength++;
            
            // Mise à jour de l'indicateur de force
            passwordStrength.className = 'password-strength';
            if (value.length > 0) {
                if (strength <= 1) {
                    passwordStrength.classList.add('strength-weak');
                } else if (strength === 2) {
                    passwordStrength.classList.add('strength-fair');
                } else if (strength === 3) {
                    passwordStrength.classList.add('strength-good');
                } else {
                    passwordStrength.classList.add('strength-strong');
                }
            }
        });
        
        // Vérification de la correspondance des mots de passe
        confirmPassword.addEventListener('input', function() {
            if (password.value !== this.value) {
                passwordMatch.innerHTML = '<span class="text-danger"><i class="fas fa-times me-1"></i>Les mots de passe ne correspondent pas</span>';
            } else {
                passwordMatch.innerHTML = '<span class="text-success"><i class="fas fa-check me-1"></i>Les mots de passe correspondent</span>';
            }
        });
        
        // Génération automatique de matricule
        document.getElementById('nom').addEventListener('blur', function() {
            const matriculeInput = document.getElementById('matricule');
            const nomInput = document.getElementById('nom');
            const prenomInput = document.getElementById('prenom');
            const roleInput = document.getElementById('role');
            
            if (!matriculeInput.value && nomInput.value && prenomInput.value) {
                const prefix = roleInput.value.toUpperCase().substring(0, 3);
                const matricule = prefix + '_' + 
                                nomInput.value.substring(0, 3).toUpperCase() + 
                                prenomInput.value.substring(0, 2).toUpperCase() + 
                                Math.floor(100 + Math.random() * 900);
                matriculeInput.value = matricule;
            }
        });
        
        // Validation du formulaire
        const form = document.getElementById('userForm');
        form.addEventListener('submit', function(e) {
            const matricule = document.getElementById('matricule').value.trim();
            const nom = document.getElementById('nom').value.trim();
            const prenom = document.getElementById('prenom').value.trim();
            const email = document.getElementById('email').value.trim();
            const role = document.getElementById('role').value;
            const specialite = document.getElementById('specialite').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (!matricule) {
                e.preventDefault();
                alert('Veuillez saisir le matricule');
                document.getElementById('matricule').focus();
                return;
            }
            
            if (!nom || nom.length < 2) {
                e.preventDefault();
                alert('Veuillez saisir un nom valide (au moins 2 caractères)');
                document.getElementById('nom').focus();
                return;
            }
            
            if (!prenom || prenom.length < 2) {
                e.preventDefault();
                alert('Veuillez saisir un prénom valide (au moins 2 caractères)');
                document.getElementById('prenom').focus();
                return;
            }
            
            if (!email || !email.includes('@')) {
                e.preventDefault();
                alert('Veuillez saisir une adresse email valide');
                document.getElementById('email').focus();
                return;
            }
            
            if (role === 'medecin' && !specialite) {
                e.preventDefault();
                alert('Veuillez sélectionner une spécialité pour le médecin');
                document.getElementById('specialite').focus();
                return;
            }
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Le mot de passe doit contenir au moins 6 caractères');
                document.getElementById('password').focus();
                return;
            }
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Les mots de passe ne correspondent pas');
                document.getElementById('confirm_password').focus();
                return;
            }
        });
        
        // Fermeture automatique des alertes
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                if (alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }
            }, 5000);
        });
    });
    </script>
</body>
</html>