<?php
// Activation des erreurs en développement (à désactiver en production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

require_once "../../config/db.php";

// Vérification rôle super admin OU admin (avec restrictions)
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['super_admin', 'admin'])) {
    header("Location: ../../config/auth.php");
    exit;
}

// Vérification des privilèges étendus pour super_admin
$is_super_admin = ($_SESSION['role'] === 'super_admin');
$is_admin = ($_SESSION['role'] === 'admin');

// Initialisation CSRF
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Traitement des actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérification CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Erreur de sécurité : Token invalide");
    }

    $action = $_POST['action'] ?? '';
    $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);

    try {
        switch ($action) {
            case 'promote_to_admin':
                if ($userId && $is_super_admin) {
                    // Seul le super_admin peut promouvoir en admin
                    $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET role = 'admin' WHERE id = ? AND role != 'super_admin'");
                    $stmt->execute([$userId]);
                    logAction($pdoMedical, $_SESSION['user_id'], "Promotion utilisateur $userId en admin");
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Utilisateur promu administrateur'];
                } else {
                    $_SESSION['flash_message'] = ['type' => 'danger', 'message' => 'Privilèges insuffisants pour cette action'];
                }
                break;

            case 'promote_to_super_admin':
                if ($userId && $is_super_admin) {
                    // Seul le super_admin peut promouvoir en super_admin
                    $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET role = 'super_admin' WHERE id = ? AND role = 'admin'");
                    $stmt->execute([$userId]);
                    logAction($pdoMedical, $_SESSION['user_id'], "Promotion admin $userId en super_admin");
                    $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Administrateur promu Super Admin'];
                } else {
                    $_SESSION['flash_message'] = ['type' => 'danger', 'message' => 'Privilèges insuffisants pour cette action'];
                }
                break;

            case 'demote_to_user':
                if ($userId) {
                    if ($is_super_admin) {
                        // Super_admin peut rétrograder admin vers user
                        $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET role = 'user' WHERE id = ? AND role = 'admin'");
                        $stmt->execute([$userId]);
                        logAction($pdoMedical, $_SESSION['user_id'], "Rétrogradation admin $userId vers user");
                        $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Administrateur rétrogradé'];
                    } elseif ($is_admin) {
                        // Admin normal peut rétrograder user (mais pas admin)
                        $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET role = 'user' WHERE id = ? AND role NOT IN ('admin', 'super_admin')");
                        $stmt->execute([$userId]);
                        logAction($pdoMedical, $_SESSION['user_id'], "Rétrogradation utilisateur $userId");
                        $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Utilisateur rétrogradé'];
                    }
                }
                break;

            case 'demote_super_admin':
                if ($userId && $is_super_admin) {
                    // Seul le super_admin peut rétrograder un autre super_admin
                    $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET role = 'admin' WHERE id = ? AND role = 'super_admin' AND id != ?");
                    $stmt->execute([$userId, $_SESSION['user_id']]);
                    if ($stmt->rowCount() > 0) {
                        logAction($pdoMedical, $_SESSION['user_id'], "Rétrogradation super_admin $userId vers admin");
                        $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Super Admin rétrogradé en administrateur'];
                    } else {
                        $_SESSION['flash_message'] = ['type' => 'danger', 'message' => 'Impossible de se rétrograder soi-même'];
                    }
                } else {
                    $_SESSION['flash_message'] = ['type' => 'danger', 'message' => 'Privilèges insuffisants pour cette action'];
                }
                break;

            case 'delete_user':
                if ($userId && $userId != $_SESSION['user_id']) {
                    if ($is_super_admin) {
                        // Super_admin peut désactiver n'importe qui sauf lui-même
                        $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET is_active = 0, deleted_at = NOW() WHERE id = ?");
                        $stmt->execute([$userId]);
                        logAction($pdoMedical, $_SESSION['user_id'], "Désactivation utilisateur $userId");
                        $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Utilisateur désactivé'];
                    } elseif ($is_admin) {
                        // Admin normal peut désactiver seulement les non-admins
                        $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET is_active = 0, deleted_at = NOW() WHERE id = ? AND role NOT IN ('admin', 'super_admin')");
                        $stmt->execute([$userId]);
                        if ($stmt->rowCount() > 0) {
                            logAction($pdoMedical, $_SESSION['user_id'], "Désactivation utilisateur $userId");
                            $_SESSION['flash_message'] = ['type' => 'success', 'message' => 'Utilisateur désactivé'];
                        } else {
                            $_SESSION['flash_message'] = ['type' => 'danger', 'message' => 'Impossible de désactiver un administrateur'];
                        }
                    }
                } else {
                    $_SESSION['flash_message'] = ['type' => 'danger', 'message' => 'Auto-suppression interdite'];
                }
                break;

            case 'reset_password':
                if ($userId) {
                    if ($is_super_admin || ($is_admin && $userId != $_SESSION['user_id'])) {
                        $tempPassword = generateTempPassword();
                        $hashedPassword = password_hash($tempPassword, PASSWORD_DEFAULT);
                        
                        $stmt = $pdoMedical->prepare("UPDATE utilisateurs SET password = ?, must_reset_password = 1 WHERE id = ?");
                        $stmt->execute([$hashedPassword, $userId]);
                        
                        logAction($pdoMedical, $_SESSION['user_id'], "Réinitialisation mot de passe utilisateur $userId");
                        $_SESSION['flash_message'] = [
                            'type' => 'success', 
                            'message' => "Mot de passe réinitialisé. Nouveau mot de passe temporaire : $tempPassword"
                        ];
                    } else {
                        $_SESSION['flash_message'] = ['type' => 'danger', 'message' => 'Privilèges insuffisants pour cette action'];
                    }
                }
                break;
        }

        header("Location: liste_users.php");
        exit;
    } catch (PDOException $e) {
        error_log("User action error: " . $e->getMessage());
        $_SESSION['flash_message'] = ['type' => 'danger', 'message' => 'Erreur lors de l\'opération'];
        header("Location: liste_users.php");
        exit;
    }
}

// Récupération des utilisateurs avec pagination
$currentPage = max(1, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT) ?? 1);
$perPage = 10;
$offset = ($currentPage - 1) * $perPage;

// Filtres de recherche
$search = filter_input(INPUT_GET, 'search', FILTER_SANITIZE_SPECIAL_CHARS) ?? '';
$roleFilter = filter_input(INPUT_GET, 'role', FILTER_SANITIZE_SPECIAL_CHARS) ?? '';

// Construction de la requête selon les privilèges
if ($is_super_admin) {
    // Super_admin voit tous les utilisateurs
    $query = "SELECT * FROM utilisateurs WHERE is_active = 1";
    $countQuery = "SELECT COUNT(*) FROM utilisateurs WHERE is_active = 1";
} else {
    // Admin normal ne voit pas les super_admins
    $query = "SELECT * FROM utilisateurs WHERE is_active = 1 AND role != 'super_admin'";
    $countQuery = "SELECT COUNT(*) FROM utilisateurs WHERE is_active = 1 AND role != 'super_admin'";
}

$params = [];

if (!empty($search)) {
    $query .= " AND (nom LIKE ? OR email LIKE ?)";
    $countQuery .= " AND (nom LIKE ? OR email LIKE ?)";
    $searchTerm = "%$search%";
    $params = array_merge($params, [$searchTerm, $searchTerm]);
}

if (!empty($roleFilter) && in_array($roleFilter, ['admin', 'etudiant', 'medecin', 'infirmier', 'super_admin'])) {
    $query .= " AND role = ?";
    $countQuery .= " AND role = ?";
    $params[] = $roleFilter;
}

// Comptage total
$totalUsers = $pdoMedical->prepare($countQuery);
$totalUsers->execute($params);
$total = $totalUsers->fetchColumn();

// Récupération des utilisateurs
$query .= " ORDER BY 
    CASE role 
        WHEN 'super_admin' THEN 1
        WHEN 'admin' THEN 2
        WHEN 'medecin' THEN 3
        WHEN 'infirmier' THEN 4
        WHEN 'etudiant' THEN 5
        ELSE 6
    END, date_inscription DESC 
    LIMIT $perPage OFFSET $offset";
    
$stmt = $pdoMedical->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupération des rôles disponibles pour le filtre
if ($is_super_admin) {
    $roles = $pdoMedical->query("SELECT DISTINCT role FROM utilisateurs")->fetchAll(PDO::FETCH_COLUMN);
} else {
    $roles = $pdoMedical->query("SELECT DISTINCT role FROM utilisateurs WHERE role != 'super_admin'")->fetchAll(PDO::FETCH_COLUMN);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Utilisateurs - <?= $is_super_admin ? 'Super Admin' : 'Admin' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/css/admin.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
            --light-color: #f8f9fc;
            --dark-color: #5a5c69;
            --super-admin-color: #8B008B;
        }
        
        .user-management {
            background-color: #f8f9fc;
            min-height: 100vh;
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
            padding: 1rem 1.25rem;
            border-radius: 0.75rem 0.75rem 0 0 !important;
        }
        
        .table-responsive {
            border-radius: 0 0 0.75rem 0.75rem;
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table th {
            border-top: none;
            font-weight: 600;
            color: var(--dark-color);
            padding: 1rem 0.75rem;
            background-color: #f8f9fc;
        }
        
        .table td {
            padding: 0.75rem;
            vertical-align: middle;
        }
        
        .badge {
            font-size: 0.75rem;
            font-weight: 500;
            padding: 0.35em 0.65em;
        }
        
        .btn-group-sm > .btn {
            padding: 0.25rem 0.5rem;
            border-radius: 0.35rem;
        }
        
        .page-item.active .page-link {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .page-link {
            color: var(--primary-color);
        }
        
        .page-link:hover {
            color: var(--primary-color);
        }
        
        .filter-card .form-control {
            border-radius: 0.5rem;
        }
        
        .user-actions .btn {
            margin-right: 0.25rem;
        }
        
        .stats-card {
            border-left: 0.25rem solid var(--primary-color);
        }
        
        .user-role-badge {
            font-size: 0.7rem;
            padding: 0.3em 0.6em;
        }
        
        .action-btn {
            transition: all 0.15s ease-in-out;
        }
        
        .action-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.1);
        }
        
        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 0.5rem;
        }
        
        .user-name {
            display: flex;
            align-items: center;
        }
        
        .super-admin-badge {
            background: linear-gradient(45deg, var(--super-admin-color), #6A0DAD);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }
        
        .privilege-indicator {
            border-left: 4px solid var(--super-admin-color);
            background-color: rgba(139, 0, 139, 0.05);
        }
        
        .role-super_admin { background: linear-gradient(45deg, var(--super-admin-color), #6A0DAD); color: white; }
        .role-admin { background-color: var(--primary-color); color: white; }
        .role-medecin { background-color: var(--info-color); color: white; }
        .role-infirmier { background-color: var(--success-color); color: white; }
        .role-etudiant { background-color: var(--warning-color); color: white; }
        .role-user { background-color: var(--secondary-color); color: white; }
        
        @media (max-width: 768px) {
            .user-actions .btn-group {
                display: flex;
                flex-direction: column;
            }
            
            .user-actions .btn {
                margin-bottom: 0.25rem;
                margin-right: 0;
            }
            
            .table-responsive {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body class="user-management">
    <div class="wrapper">
        <!-- <?php include __DIR__.'/../includes/sidebar_super_admin.php'; ?> -->

        <div class="main-content">
            <!-- <?php include __DIR__.'/../includes/topbar.php'; ?> -->

            <div class="container-fluid py-4">
                <!-- Messages flash -->
                <?php if (isset($_SESSION['flash_message'])): ?>
                    <div class="alert alert-<?= $_SESSION['flash_message']['type'] ?> alert-dismissible fade show mt-3" role="alert">
                        <?= $_SESSION['flash_message']['message'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php unset($_SESSION['flash_message']); ?>
                <?php endif; ?>

                <!-- Titre et boutons -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <div>
                        <h1 class="h3 mb-0 text-gray-800">
                            Gestion des Utilisateurs
                            <?php if ($is_super_admin): ?>
                                <span class="super-admin-badge">Super Admin</span>
                            <?php else: ?>
                                <span class="badge bg-primary">Admin</span>
                            <?php endif; ?>
                        </h1>
                        <p class="text-muted mb-0">
                            <?= $is_super_admin ? 
                                'Supervisez et gérez tous les utilisateurs de la plateforme' : 
                                'Gérez les utilisateurs standard de la plateforme' 
                            ?>
                        </p>
                    </div>
                    <a href="ajout_user.php" class="d-none d-sm-inline-block btn btn-primary shadow-sm">
                        <i class="fas fa-user-plus fa-sm text-white-50 me-1"></i> Ajouter un utilisateur
                    </a>
                </div>

                <!-- Cartes de statistiques -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stats-card h-100">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Utilisateurs
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $total ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php if ($is_super_admin): ?>
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stats-card h-100 border-left-warning">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Super Admins
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php 
                                                $superAdminCount = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'super_admin' AND is_active = 1")->fetchColumn();
                                                echo $superAdminCount;
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-crown fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stats-card h-100 border-left-success">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Administrateurs
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php 
                                                $adminCount = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role = 'admin' AND is_active = 1")->fetchColumn();
                                                echo $adminCount;
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-shield fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card stats-card h-100 border-left-info">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Personnel Médical
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php 
                                                $medicalCount = $pdoMedical->query("SELECT COUNT(*) FROM utilisateurs WHERE role IN ('medecin', 'infirmier') AND is_active = 1")->fetchColumn();
                                                echo $medicalCount;
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-md fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filtres -->
                <div class="card shadow mb-4 filter-card">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 font-weight-bold text-primary">
                            <i class="fas fa-filter me-2"></i>Filtres et Recherche
                        </h6>
                        <span class="badge bg-light text-dark"><?= $total ?> résultat(s)</span>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="row g-3 align-items-end">
                            <div class="col-md-5">
                                <label for="search" class="form-label small text-muted">Recherche par nom ou email</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" name="search" id="search" class="form-control" placeholder="Rechercher..." 
                                           value="<?= htmlspecialchars($search) ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="role" class="form-label small text-muted">Filtrer par rôle</label>
                                <select name="role" id="role" class="form-select">
                                    <option value="">Tous les rôles</option>
                                    <?php foreach ($roles as $role): ?>
                                        <option value="<?= $role ?>" <?= $role === $roleFilter ? 'selected' : '' ?>>
                                            <?= ucfirst($role) ?>
                                            <?php if ($role === 'super_admin'): ?>
                                                <i class="fas fa-crown ms-1"></i>
                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-filter me-1"></i> Appliquer
                                </button>
                                <a href="liste_users.php" class="btn btn-outline-secondary w-100 mt-2">
                                    <i class="fas fa-times me-1"></i> Réinitialiser
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Tableau des utilisateurs -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 font-weight-bold text-primary">
                            <i class="fas fa-table me-2"></i>Liste des Utilisateurs
                            <?php if (!$is_super_admin): ?>
                                <small class="text-muted ms-2">(Super Admins masqués)</small>
                            <?php endif; ?>
                        </h6>
                        <div>
                            <span class="badge bg-primary">Page <?= $currentPage ?> sur <?= ceil($total / $perPage) ?></span>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover" width="100%" cellspacing="0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Utilisateur</th>
                                        <th>Email</th>
                                        <th>Rôle</th>
                                        <th>Inscription</th>
                                        <th>Dernière connexion</th>
                                        <th class="text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($users)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-4">
                                                <i class="fas fa-user-slash fa-2x text-muted mb-2 d-block"></i>
                                                <span class="text-muted">Aucun utilisateur trouvé</span>
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td>
                                                <div class="user-name">
                                                    <div class="user-avatar" style="background-color: <?= 
                                                        $user['role'] === 'super_admin' ? 'var(--super-admin-color)' : 
                                                        ($user['role'] === 'admin' ? 'var(--primary-color)' : 
                                                        ($user['role'] === 'medecin' ? 'var(--info-color)' : 
                                                        ($user['role'] === 'infirmier' ? 'var(--success-color)' : 
                                                        ($user['role'] === 'etudiant' ? 'var(--warning-color)' : 'var(--secondary-color)'))))
                                                    ?>;">
                                                        <?= strtoupper(substr($user['nom'], 0, 1)) ?>
                                                    </div>
                                                    <div>
                                                        <div class="fw-bold"><?= htmlspecialchars($user['nom']) ?></div>
                                                        <small class="text-muted">ID: <?= $user['id'] ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?= htmlspecialchars($user['email']) ?></td>
                                            <td>
                                                <span class="badge user-role-badge role-<?= $user['role'] ?>">
                                                    <?php if ($user['role'] === 'super_admin'): ?>
                                                        <i class="fas fa-crown me-1"></i>
                                                    <?php elseif ($user['role'] === 'admin'): ?>
                                                        <i class="fas fa-user-shield me-1"></i>
                                                    <?php elseif ($user['role'] === 'medecin'): ?>
                                                        <i class="fas fa-user-md me-1"></i>
                                                    <?php elseif ($user['role'] === 'infirmier'): ?>
                                                        <i class="fas fa-user-nurse me-1"></i>
                                                    <?php elseif ($user['role'] === 'etudiant'): ?>
                                                        <i class="fas fa-user-graduate me-1"></i>
                                                    <?php else: ?>
                                                        <i class="fas fa-user me-1"></i>
                                                    <?php endif; ?>
                                                    <?= ucfirst($user['role']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <small><?= date('d/m/Y', strtotime($user['date_inscription'])) ?></small>
                                            </td>
                                            <td>
                                                <small><?= $user['last_login'] ? date('d/m/Y H:i', strtotime($user['last_login'])) : '<span class="text-muted">Jamais</span>' ?></small>
                                            </td>
                                            <td>
                                                <div class="user-actions d-flex justify-content-center">
                                                    <a href="edit_user.php?id=<?= $user['id'] ?>" 
                                                       class="btn btn-outline-primary btn-sm action-btn" title="Modifier">
                                                        <i class="fas fa-edit"></i>
                                                    </a>

                                                    <!-- Actions selon le rôle et les privilèges -->
                                                    <?php if ($user['role'] === 'super_admin'): ?>
                                                        <?php if ($is_super_admin && $user['id'] != $_SESSION['user_id']): ?>
                                                            <form method="POST" class="d-inline" onsubmit="return confirm('Êtes-vous sûr de vouloir rétrograder ce Super Admin ?');">
                                                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                                <input type="hidden" name="action" value="demote_super_admin">
                                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                                <button type="submit" class="btn btn-outline-warning btn-sm action-btn" title="Rétrograder Super Admin">
                                                                    <i class="fas fa-arrow-down"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>

                                                    <?php elseif ($user['role'] === 'admin'): ?>
                                                        <?php if ($is_super_admin && $user['id'] != $_SESSION['user_id']): ?>
                                                            <form method="POST" class="d-inline" onsubmit="return confirm('Promouvoir en Super Admin ?');">
                                                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                                <input type="hidden" name="action" value="promote_to_super_admin">
                                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                                <button type="submit" class="btn btn-outline-dark btn-sm action-btn" title="Promouvoir Super Admin">
                                                                    <i class="fas fa-crown"></i>
                                                                </button>
                                                            </form>
                                                            <form method="POST" class="d-inline">
                                                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                                <input type="hidden" name="action" value="demote_to_user">
                                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                                <button type="submit" class="btn btn-outline-warning btn-sm action-btn" title="Rétrograder">
                                                                    <i class="fas fa-user-minus"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>

                                                    <?php else: ?>
                                                        <!-- Actions pour les utilisateurs non-admins -->
                                                        <?php if ($is_super_admin): ?>
                                                            <form method="POST" class="d-inline">
                                                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                                <input type="hidden" name="action" value="promote_to_admin">
                                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                                <button type="submit" class="btn btn-outline-success btn-sm action-btn" title="Promouvoir admin">
                                                                    <i class="fas fa-user-shield"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>

                                                        <?php if ($user['role'] !== 'user' && ($is_super_admin || $is_admin)): ?>
                                                            <form method="POST" class="d-inline">
                                                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                                <input type="hidden" name="action" value="demote_to_user">
                                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                                <button type="submit" class="btn btn-outline-warning btn-sm action-btn" title="Rétrograder vers utilisateur">
                                                                    <i class="fas fa-user"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    <?php endif; ?>

                                                    <!-- Réinitialisation mot de passe -->
                                                    <?php if (($is_super_admin || ($is_admin && $user['id'] != $_SESSION['user_id'])) && $user['role'] !== 'super_admin'): ?>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                            <input type="hidden" name="action" value="reset_password">
                                                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                            <button type="submit" class="btn btn-outline-info btn-sm action-btn" title="Réinitialiser mot de passe">
                                                                <i class="fas fa-key"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>

                                                    <!-- Désactivation -->
                                                    <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                                        <?php if ($is_super_admin || ($is_admin && $user['role'] !== 'admin' && $user['role'] !== 'super_admin')): ?>
                                                            <form method="POST" class="d-inline" onsubmit="return confirm('Êtes-vous sûr de vouloir désactiver cet utilisateur ?');">
                                                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                                <input type="hidden" name="action" value="delete_user">
                                                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                                <button type="submit" class="btn btn-outline-danger btn-sm action-btn" title="Désactiver">
                                                                    <i class="fas fa-user-slash"></i>
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination -->
                        <?php if ($total > $perPage): ?>
                        <div class="card-footer">
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center mb-0">
                                    <?php if ($currentPage > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?= $currentPage - 1 ?>&search=<?= urlencode($search) ?>&role=<?= $roleFilter ?>">
                                                <i class="fas fa-chevron-left"></i> Précédent
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php 
                                    $totalPages = ceil($total / $perPage);
                                    $startPage = max(1, $currentPage - 2);
                                    $endPage = min($totalPages, $currentPage + 2);
                                    
                                    if ($startPage > 1) {
                                        echo '<li class="page-item"><a class="page-link" href="?page=1&search=' . urlencode($search) . '&role=' . $roleFilter . '">1</a></li>';
                                        if ($startPage > 2) {
                                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                        }
                                    }
                                    
                                    for ($i = $startPage; $i <= $endPage; $i++): ?>
                                        <li class="page-item <?= $i === $currentPage ? 'active' : '' ?>">
                                            <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&role=<?= $roleFilter ?>">
                                                <?= $i ?>
                                            </a>
                                        </li>
                                    <?php endfor; 
                                    
                                    if ($endPage < $totalPages) {
                                        if ($endPage < $totalPages - 1) {
                                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                                        }
                                        echo '<li class="page-item"><a class="page-link" href="?page=' . $totalPages . '&search=' . urlencode($search) . '&role=' . $roleFilter . '">' . $totalPages . '</a></li>';
                                    }
                                    ?>

                                    <?php if ($currentPage < $totalPages): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?= $currentPage + 1 ?>&search=<?= urlencode($search) ?>&role=<?= $roleFilter ?>">
                                                Suivant <i class="fas fa-chevron-right"></i>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/js/admin.js"></script>
    <script>
    // Activation des tooltips
    document.addEventListener('DOMContentLoaded', function() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Auto-dismiss alerts after 5 seconds
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                if (alert) {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }
            }, 5000);
        });
    });
    </script>
</body>
</html>