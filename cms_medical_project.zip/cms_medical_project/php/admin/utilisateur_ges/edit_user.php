<?php
// superadmin_edit_user.php

// Initialisation de la session et vérification des autorisations
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Protection contre les attaques
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');

// Vérification des droits super_admin OU admin (avec restrictions)
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['super_admin', 'admin'])) {
    header("Location: ../../config/auth.php");
    exit;
}

// Vérification des privilèges étendus pour super_admin
$is_super_admin = ($_SESSION['role'] === 'super_admin');
$is_admin = ($_SESSION['role'] === 'admin');

// Connexion à la base de données
require_once "../../config/db.php";

// Initialisation des variables
$error = '';
$success = '';
$user = [];

// Récupération de l'ID utilisateur à modifier
$user_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
if (!$user_id) {
    header("Location: superadmin_users.php");
    exit;
}

// Récupération des données de l'utilisateur
try {
    $stmt = $pdoMedical->prepare("SELECT * FROM utilisateurs WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        header("Location: superadmin_users.php");
        exit;
    }
    
    // Vérification des privilèges pour la modification
    if ($is_admin && $user['role'] === 'super_admin') {
        // Un admin normal ne peut pas modifier un super_admin
        $_SESSION['flash_message'] = ['type' => 'danger', 'message' => 'Privilèges insuffisants pour modifier un Super Admin'];
        header("Location: superadmin_users.php");
        exit;
    }
    
    // Empêcher l'auto-modification du rôle
    if ($user_id == $_SESSION['user_id']) {
        $self_edit = true;
    } else {
        $self_edit = false;
    }
} catch (PDOException $e) {
    $error = "Erreur lors de la récupération des données utilisateur";
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validation CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Erreur de sécurité. Veuillez réessayer.";
    } else {
        // Récupération et nettoyage des données
        $nom = filter_input(INPUT_POST, 'nom', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $prenom = filter_input(INPUT_POST, 'prenom', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $telephone = filter_input(INPUT_POST, 'telephone', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $departement = filter_input(INPUT_POST, 'departement', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $specialite = filter_input(INPUT_POST, 'specialite', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $adresse = filter_input(INPUT_POST, 'adresse', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $role = filter_var($_POST['role'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $actif = isset($_POST['actif']) ? 1 : 0;

        // Validation des données
        if (empty($nom) || empty($prenom) || empty($email) || empty($role)) {
            $error = "Tous les champs obligatoires doivent être remplis";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "L'adresse email n'est pas valide";
        } elseif (!in_array($role, ['etudiant', 'infirmier', 'medecin', 'admin', 'super_admin'])) {
            $error = "Rôle utilisateur invalide";
        } else {
            // Vérifications de sécurité selon les privilèges
            if ($is_admin) {
                // Admin normal ne peut pas créer/modifier des super_admins
                if ($role === 'super_admin') {
                    $error = "Privilèges insuffisants : vous ne pouvez pas attribuer le rôle Super Admin";
                }
                // Admin normal ne peut pas modifier un super_admin existant
                if ($user['role'] === 'super_admin') {
                    $error = "Privilèges insuffisants : vous ne pouvez pas modifier un Super Admin";
                }
            }
            
            // Empêcher l'auto-rétrogradation
            if ($self_edit && $role !== 'super_admin' && $user['role'] === 'super_admin') {
                $error = "Vous ne pouvez pas vous rétrograder vous-même";
            }

            if (empty($error)) {
                // Mise à jour en base de données
                try {
                    $sql = "UPDATE utilisateurs 
                            SET nom = ?, prenom = ?, email = ?, telephone = ?, 
                                departement = ?, specialite = ?, adresse = ?, 
                                role = ?, is_active = ?, updated_at = NOW() 
                            WHERE id = ?";
                    
                    $stmt = $pdoMedical->prepare($sql);
                    $stmt->execute([
                        $nom, $prenom, $email, $telephone, 
                        $departement, $specialite, $adresse,
                        $role, $actif, $user_id
                    ]);
                    
                    // Journalisation de l'action
                    $logStmt = $pdoMedical->prepare("
                        INSERT INTO system_logs 
                        (user_id, action_type, action_description, ip_address, user_agent) 
                        VALUES (?, 'EDIT_USER', ?, ?, ?)
                    ");
                    
                    $logDescription = "Modification utilisateur: {$user['nom']} {$user['prenom']} (ID: $user_id) - Nouveau rôle: $role";
                    $logStmt->execute([
                        $_SESSION['user_id'],
                        $logDescription,
                        $_SERVER['REMOTE_ADDR'],
                        $_SERVER['HTTP_USER_AGENT']
                    ]);
                    
                    $success = "Utilisateur mis à jour avec succès";
                    // Rechargement des données
                    $stmt = $pdoMedical->prepare("SELECT * FROM utilisateurs WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    $error = "Erreur lors de la mise à jour : " . $e->getMessage();
                }
            }
        }
    }
}

// Génération du token CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Spécialités médicales
$specialites = [
    '' => 'Sélectionner une spécialité',
    'cardiologie' => 'Cardiologie',
    'dermatologie' => 'Dermatologie',
    'pediatrie' => 'Pédiatrie',
    'chirurgie' => 'Chirurgie',
    'gynecologie' => 'Gynécologie',
    'ophtalmologie' => 'Ophtalmologie',
    'neurologie' => 'Neurologie',
    'psychiatrie' => 'Psychiatrie',
    'radiologie' => 'Radiologie',
    'urgentiste' => 'Médecin Urgentiste',
    'generaliste' => 'Médecin Généraliste'
];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier Utilisateur - <?= $is_super_admin ? 'SuperAdmin' : 'Admin' ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4a6fa5;
            --secondary-color: #6c757d;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --super-admin-color: #8B008B;
        }
        
        body {
            background-color: #f5f7fa;
            color: #333;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ddd;
        }
        
        .header h1 {
            color: var(--dark-color);
            margin: 0;
        }
        
        .super-admin-badge {
            background: linear-gradient(45deg, var(--super-admin-color), #6A0DAD);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }
        
        .card {
            background: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            border: none;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: border 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 0.2rem rgba(74, 111, 165, 0.25);
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: none;
        }
        
        .role-selector {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .role-option {
            flex: 1;
            min-width: 150px;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }
        
        .role-option:hover {
            border-color: var(--primary-color);
        }
        
        .role-option input[type="radio"] {
            display: none;
        }
        
        .role-option input[type="radio"]:checked + .role-label {
            background-color: var(--primary-color);
            color: white;
        }
        
        .role-label {
            display: block;
            padding: 10px;
            border-radius: 4px;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .role-super_admin {
            border-color: var(--super-admin-color);
        }
        
        .role-super_admin .role-label {
            background: linear-gradient(45deg, var(--super-admin-color), #6A0DAD);
            color: white;
        }
        
        .role-admin .role-label {
            background-color: var(--primary-color);
            color: white;
        }
        
        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .user-info-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .user-info-card h5 {
            margin-bottom: 15px;
            opacity: 0.9;
        }
        
        .info-item {
            display: flex;
            justify-content: between;
            margin-bottom: 8px;
        }
        
        .info-label {
            font-weight: 600;
            opacity: 0.8;
            min-width: 120px;
        }
        
        .conditional-field {
            display: none;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .privilege-warning {
            border-left: 4px solid var(--danger-color);
            background-color: rgba(220, 53, 69, 0.05);
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .role-selector {
                flex-direction: column;
            }
            
            .role-option {
                min-width: auto;
            }
            
            .container {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
                Modifier l'utilisateur
                <?php if ($is_super_admin): ?>
                    <span class="super-admin-badge">Super Admin</span>
                <?php else: ?>
                    <span class="badge bg-primary">Admin</span>
                <?php endif; ?>
            </h1>
            <a href="superadmin_users.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-1"></i> Retour à la liste
            </a>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>
        
        <!-- Informations sur l'utilisateur -->
        <div class="user-info-card">
            <h5><i class="fas fa-user-circle me-2"></i>Informations actuelles</h5>
            <div class="info-item">
                <span class="info-label">Nom complet:</span>
                <span><?= htmlspecialchars($user['nom'] ?? '') ?> <?= htmlspecialchars($user['prenom'] ?? '') ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Rôle actuel:</span>
                <span class="badge bg-light text-dark">
                    <?php if ($user['role'] === 'super_admin'): ?>
                        <i class="fas fa-crown me-1"></i>
                    <?php elseif ($user['role'] === 'admin'): ?>
                        <i class="fas fa-user-shield me-1"></i>
                    <?php endif; ?>
                    <?= ucfirst($user['role']) ?>
                </span>
            </div>
            <div class="info-item">
                <span class="info-label">Statut:</span>
                <span class="badge <?= $user['is_active'] ? 'bg-success' : 'bg-danger' ?>">
                    <?= $user['is_active'] ? 'Actif' : 'Inactif' ?>
                </span>
            </div>
        </div>

        <?php if ($self_edit): ?>
            <div class="privilege-warning">
                <h6><i class="fas fa-exclamation-triangle me-2"></i>Modification de votre propre compte</h6>
                <p class="mb-0">Vous modifiez votre propre compte utilisateur. Certaines restrictions s'appliquent pour des raisons de sécurité.</p>
            </div>
        <?php endif; ?>

        <div class="card">
            <form method="POST" action="" id="userForm">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nom" class="form-label">Nom <span class="text-danger">*</span></label>
                            <input type="text" id="nom" name="nom" class="form-control" 
                                   value="<?= htmlspecialchars($user['nom'] ?? '') ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="prenom" class="form-label">Prénom <span class="text-danger">*</span></label>
                            <input type="text" id="prenom" name="prenom" class="form-control" 
                                   value="<?= htmlspecialchars($user['prenom'] ?? '') ?>" required>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" id="email" name="email" class="form-control" 
                                   value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="telephone" class="form-label">Téléphone</label>
                            <input type="tel" id="telephone" name="telephone" class="form-control" 
                                   value="<?= htmlspecialchars($user['telephone'] ?? '') ?>">
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="departement" class="form-label">Département/Service</label>
                    <input type="text" id="departement" name="departement" class="form-control" 
                           value="<?= htmlspecialchars($user['departement'] ?? '') ?>">
                </div>
                
                <!-- Champ spécialité conditionnel -->
                <div class="form-group conditional-field" id="specialite-field">
                    <label for="specialite" class="form-label">Spécialité médicale</label>
                    <select class="form-control" id="specialite" name="specialite">
                        <?php foreach ($specialites as $value => $label): ?>
                            <option value="<?= $value ?>" <?= ($user['specialite'] ?? '') === $value ? 'selected' : '' ?>>
                                <?= $label ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="adresse" class="form-label">Adresse</label>
                    <textarea class="form-control" id="adresse" name="adresse" rows="3"><?= htmlspecialchars($user['adresse'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Rôle <span class="text-danger">*</span></label>
                    <?php if (!$is_super_admin && $user['role'] === 'super_admin'): ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-lock me-2"></i>Vous ne pouvez pas modifier le rôle d'un Super Admin
                        </div>
                    <?php else: ?>
                        <div class="role-selector">
                            <div class="role-option <?= $user['role'] === 'etudiant' ? 'role-admin' : '' ?>">
                                <input type="radio" id="role_etudiant" name="role" value="etudiant" 
                                    <?= ($user['role'] ?? '') === 'etudiant' ? 'checked' : '' ?>
                                    <?= ($is_admin && !$self_edit) ? '' : 'disabled' ?>>
                                <label for="role_etudiant" class="role-label">
                                    <i class="fas fa-user-graduate me-2"></i>Étudiant
                                </label>
                            </div>
                            <div class="role-option <?= $user['role'] === 'infirmier' ? 'role-admin' : '' ?>">
                                <input type="radio" id="role_infirmier" name="role" value="infirmier" 
                                    <?= ($user['role'] ?? '') === 'infirmier' ? 'checked' : '' ?>
                                    <?= ($is_admin && !$self_edit) ? '' : 'disabled' ?>>
                                <label for="role_infirmier" class="role-label">
                                    <i class="fas fa-user-nurse me-2"></i>Infirmier
                                </label>
                            </div>
                            <div class="role-option <?= $user['role'] === 'medecin' ? 'role-admin' : '' ?>">
                                <input type="radio" id="role_medecin" name="role" value="medecin" 
                                    <?= ($user['role'] ?? '') === 'medecin' ? 'checked' : '' ?>
                                    <?= ($is_admin && !$self_edit) ? '' : 'disabled' ?>>
                                <label for="role_medecin" class="role-label">
                                    <i class="fas fa-user-md me-2"></i>Médecin
                                </label>
                            </div>
                            <div class="role-option <?= $user['role'] === 'admin' ? 'role-admin' : '' ?>">
                                <input type="radio" id="role_admin" name="role" value="admin" 
                                    <?= ($user['role'] ?? '') === 'admin' ? 'checked' : '' ?>
                                    <?= $is_super_admin ? '' : 'disabled' ?>>
                                <label for="role_admin" class="role-label">
                                    <i class="fas fa-user-shield me-2"></i>Administrateur
                                </label>
                            </div>
                            <?php if ($is_super_admin && !$self_edit): ?>
                                <div class="role-option role-super_admin">
                                    <input type="radio" id="role_super_admin" name="role" value="super_admin" 
                                        <?= ($user['role'] ?? '') === 'super_admin' ? 'checked' : '' ?>>
                                    <label for="role_super_admin" class="role-label">
                                        <i class="fas fa-crown me-2"></i>Super Admin
                                    </label>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if ($is_admin): ?>
                            <div class="form-text text-warning">
                                <i class="fas fa-info-circle me-1"></i>Seul un Super Admin peut attribuer les rôles Administrateur et Super Admin
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <div class="form-check form-switch mb-3">
                    <input type="checkbox" id="actif" name="actif" class="form-check-input" 
                           <?= ($user['is_active'] ?? 0) ? 'checked' : '' ?>>
                    <label for="actif" class="form-check-label">Compte activé</label>
                </div>
                
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Date de création :</strong> <?= htmlspecialchars($user['date_inscription'] ?? 'Non renseignée') ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Dernière modification :</strong> <?= htmlspecialchars($user['updated_at'] ?? 'Non renseignée') ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Enregistrer les modifications
                    </button>
                    <a href="liste_users.php" class="btn btn-secondary">
                        <i class="fas fa-times me-1"></i> Annuler
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const roleRadios = document.querySelectorAll('input[name="role"]');
        const specialiteField = document.getElementById('specialite-field');
        
        // Gestion des champs conditionnels
        function toggleConditionalFields() {
            const selectedRole = document.querySelector('input[name="role"]:checked');
            
            if (selectedRole && selectedRole.value === 'medecin') {
                specialiteField.style.display = 'block';
            } else {
                specialiteField.style.display = 'none';
            }
        }
        
        // Écouteurs pour les changements de rôle
        roleRadios.forEach(radio => {
            radio.addEventListener('change', toggleConditionalFields);
        });
        
        // Initialisation
        toggleConditionalFields();
        
        // Validation du formulaire
        const form = document.getElementById('userForm');
        form.addEventListener('submit', function(e) {
            const nom = document.getElementById('nom').value.trim();
            const prenom = document.getElementById('prenom').value.trim();
            const email = document.getElementById('email').value.trim();
            const role = document.querySelector('input[name="role"]:checked');
            
            if (!nom || !prenom || !email || !role) {
                e.preventDefault();
                alert('Veuillez remplir tous les champs obligatoires');
                return;
            }
            
            if (!email.includes('@')) {
                e.preventDefault();
                alert('Veuillez saisir une adresse email valide');
                return;
            }
        });
    });
    </script>
</body>
</html>