<?php
session_start();
require_once '../../config/db.php';


// Vérification des permissions
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    header("Location: ../../config/auth.php");
    exit;
}

// Vérification de la connexion PDO à campus_db
if (!isset($pdoCampus)) {
    die("❌ Erreur de connexion à la base de données campus");
}

// Paramètres de pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Filtres
$filiereFilter = $_GET['filiere'] ?? '';
$niveauFilter = $_GET['niveau'] ?? '';
$statutFilter = $_GET['statut'] ?? '';
$searchFilter = $_GET['search'] ?? '';

// Paramètres de tri
$sortBy = $_GET['sort'] ?? 'date_inscription';
$sortOrder = $_GET['order'] ?? 'DESC';
$allowedSortColumns = ['matricule', 'nom', 'prenom', 'email', 'filiere', 'niveau', 'date_inscription', 'statut'];
$allowedOrders = ['ASC', 'DESC'];

// Validation des paramètres de tri
if (!in_array($sortBy, $allowedSortColumns)) {
    $sortBy = 'date_inscription';
}
if (!in_array($sortOrder, $allowedOrders)) {
    $sortOrder = 'DESC';
}

// Construction de la requête
$query = "SELECT * FROM etudiants WHERE 1=1";
$countQuery = "SELECT COUNT(*) FROM etudiants WHERE 1=1";
$params = [];
$countParams = [];

// Application des filtres
if (!empty($filiereFilter)) {
    $query .= " AND filiere = ?";
    $countQuery .= " AND filiere = ?";
    $params[] = $filiereFilter;
    $countParams[] = $filiereFilter;
}

if (!empty($niveauFilter)) {
    $query .= " AND niveau = ?";
    $countQuery .= " AND niveau = ?";
    $params[] = $niveauFilter;
    $countParams[] = $niveauFilter;
}

if (!empty($statutFilter)) {
    $query .= " AND statut = ?";
    $countQuery .= " AND statut = ?";
    $params[] = $statutFilter;
    $countParams[] = $statutFilter;
}

if (!empty($searchFilter)) {
    $query .= " AND (matricule LIKE ? OR nom LIKE ? OR prenom LIKE ? OR email LIKE ?)";
    $countQuery .= " AND (matricule LIKE ? OR nom LIKE ? OR prenom LIKE ? OR email LIKE ?)";
    $searchTerm = "%$searchFilter%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $countParams[] = $searchTerm;
    $countParams[] = $searchTerm;
    $countParams[] = $searchTerm;
    $countParams[] = $searchTerm;
}

// Ajout du tri
$query .= " ORDER BY $sortBy $sortOrder";

// Ajout de la pagination avec paramètres positionnels
$query .= " LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

try {
    // Récupération des étudiants depuis campus_db
    $stmt = $pdoCampus->prepare($query);
    
    // Liaison des paramètres avec types explicites
    $paramIndex = 1;
    foreach ($params as $param) {
        if ($paramIndex > count($params) - 2) {
            // Les deux derniers paramètres sont LIMIT et OFFSET (entiers)
            $stmt->bindValue($paramIndex, $param, PDO::PARAM_INT);
        } else {
            $stmt->bindValue($paramIndex, $param);
        }
        $paramIndex++;
    }
    
    $stmt->execute();
    $etudiants = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Comptage total (sans pagination)
    $countStmt = $pdoCampus->prepare($countQuery);
    $countStmt->execute($countParams);
    $totalEtudiants = $countStmt->fetchColumn();
    $totalPages = ceil($totalEtudiants / $limit);

    // Récupération des filières uniques depuis campus_db
    $filieresStmt = $pdoCampus->query("SELECT DISTINCT filiere FROM etudiants WHERE filiere IS NOT NULL AND filiere != '' ORDER BY filiere");
    $filieres = $filieresStmt->fetchAll(PDO::FETCH_COLUMN);

    // Récupération des niveaux uniques depuis campus_db
    $niveauxStmt = $pdoCampus->query("SELECT DISTINCT niveau FROM etudiants WHERE niveau IS NOT NULL AND niveau != '' ORDER BY niveau");
    $niveaux = $niveauxStmt->fetchAll(PDO::FETCH_COLUMN);

} catch (PDOException $e) {
    error_log("Erreur chargement étudiants: " . $e->getMessage());
    $etudiants = [];
    $totalEtudiants = 0;
    $totalPages = 1;
    $filieres = [];
    $niveaux = [];
    $error = "Erreur lors du chargement des étudiants: " . $e->getMessage();
}

// Fonction pour générer l'URL avec les paramètres
function buildUrl($params = []) {
    $currentParams = $_GET;
    unset($currentParams['page']); // On enlève la page courante
    $mergedParams = array_merge($currentParams, $params);
    return '?' . http_build_query($mergedParams);
}

// Fonction pour générer l'URL de tri
function buildSortUrl($column) {
    $currentParams = $_GET;
    $currentSort = $_GET['sort'] ?? 'date_inscription';
    $currentOrder = $_GET['order'] ?? 'DESC';
    
    if ($currentSort === $column) {
        $newOrder = $currentOrder === 'ASC' ? 'DESC' : 'ASC';
    } else {
        $newOrder = 'ASC';
    }
    
    $currentParams['sort'] = $column;
    $currentParams['order'] = $newOrder;
    
    return '?' . http_build_query($currentParams);
}

// Fonction pour obtenir l'icône de tri
function getSortIcon($column) {
    $currentSort = $_GET['sort'] ?? 'date_inscription';
    $currentOrder = $_GET['order'] ?? 'DESC';
    
    if ($currentSort === $column) {
        return $currentOrder === 'ASC' ? 'fa-sort-up' : 'fa-sort-down';
    }
    return 'fa-sort';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Étudiants - MedicalSystem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
        }
        
        body {
            background-color: #f8f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            border-radius: 0.75rem 0.75rem 0 0 !important;
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
        }
        
        .btn {
            border-radius: 0.5rem;
            font-weight: 500;
        }
        
        .form-control, .form-select {
            border-radius: 0.5rem;
        }
        
        .required::after {
            content: " *";
            color: var(--danger-color);
        }
        
        .form-section {
            background-color: #f8f9fa;
            border-radius: 0.5rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .form-section h6 {
            color: var(--primary-color);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 0.5rem;
        }
        
        .database-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 0.7rem;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="superadmin_dashboard.php">
                <i class="fas fa-hospital me-2"></i>
                <strong>MedicalSystem</strong> - Super Admin
            </a>
            
            <div class="d-flex align-items-center">
                <span class="navbar-text text-light me-3">
                    <i class="fas fa-user-shield me-1"></i>
                    <?= htmlspecialchars($_SESSION['user_name'] ?? 'Super Admin') ?>
                </span>
                
            </div>
        </div>
    </nav>

    <div class="container-fluid py-4">
        <!-- En-tête -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 mb-1 text-gray-800">
                    <i class="fas fa-users me-2"></i>Liste des Étudiants
                </h1>
                <p class="text-muted mb-0">Gestion du registre des étudiants - Base: campus_db</p>
            </div>
            <div class="d-flex gap-2">
                <a href="ajout_etudiant.php" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Nouvel étudiant
                </a>
                
            </div>
        </div>

        <!-- Messages d'erreur -->
        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Filtres -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-filter me-2"></i>Filtres de recherche
                </h6>
            </div>
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Filière</label>
                        <select name="filiere" class="form-select">
                            <option value="">Toutes les filières</option>
                            <?php foreach ($filieres as $filiere): ?>
                                <option value="<?= htmlspecialchars($filiere) ?>" <?= $filiere === $filiereFilter ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($filiere) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Niveau</label>
                        <select name="niveau" class="form-select">
                            <option value="">Tous les niveaux</option>
                            <?php foreach ($niveaux as $niveau): ?>
                                <option value="<?= htmlspecialchars($niveau) ?>" <?= $niveau === $niveauFilter ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($niveau) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-2">
                        <label class="form-label">Statut</label>
                        <select name="statut" class="form-select">
                            <option value="">Tous les statuts</option>
                            <option value="actif" <?= $statutFilter === 'actif' ? 'selected' : '' ?>>Actif</option>
                            <option value="inactif" <?= $statutFilter === 'inactif' ? 'selected' : '' ?>>Inactif</option>
                        </select>
                    </div>
                    
                    <div class="col-md-5">
                        <label class="form-label">Recherche</label>
                        <input type="text" name="search" class="form-control" placeholder="Matricule, nom, prénom, email..." value="<?= htmlspecialchars($searchFilter) ?>">
                    </div>
                    
                    <div class="col-12">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search me-2"></i>Appliquer les filtres
                            </button>
                            <a href="liste_etudiants.php" class="btn btn-secondary">
                                <i class="fas fa-times me-2"></i>Réinitialiser
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tableau des étudiants -->
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-table me-2"></i>Registre des étudiants
                    <?php if ($filiereFilter || $niveauFilter || $statutFilter || $searchFilter): ?>
                        <small class="text-muted">(Résultats filtrés)</small>
                    <?php endif; ?>
                </h6>
                <div>
                    <span class="badge bg-primary"><?= number_format($totalEtudiants) ?> étudiant(s)</span>
                    <?php if ($totalEtudiants > 0): ?>
                        <span class="badge bg-info">Page <?= $page ?> sur <?= $totalPages ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover" width="100%" cellspacing="0">
                        <thead class="table-light">
                            <tr>
                                <th class="<?= $sortBy === 'matricule' ? 'active-sort' : '' ?>">
                                    <a href="<?= buildSortUrl('matricule') ?>" class="text-decoration-none text-dark sortable">
                                        Matricule
                                        <i class="fas <?= getSortIcon('matricule') ?> sort-icon"></i>
                                    </a>
                                </th>
                                <th class="<?= $sortBy === 'nom' ? 'active-sort' : '' ?>">
                                    <a href="<?= buildSortUrl('nom') ?>" class="text-decoration-none text-dark sortable">
                                        Nom & Prénom
                                        <i class="fas <?= getSortIcon('nom') ?> sort-icon"></i>
                                    </a>
                                </th>
                                <th class="<?= $sortBy === 'email' ? 'active-sort' : '' ?>">
                                    <a href="<?= buildSortUrl('email') ?>" class="text-decoration-none text-dark sortable">
                                        Email
                                        <i class="fas <?= getSortIcon('email') ?> sort-icon"></i>
                                    </a>
                                </th>
                                <th class="<?= $sortBy === 'filiere' ? 'active-sort' : '' ?>">
                                    <a href="<?= buildSortUrl('filiere') ?>" class="text-decoration-none text-dark sortable">
                                        Filière
                                        <i class="fas <?= getSortIcon('filiere') ?> sort-icon"></i>
                                    </a>
                                </th>
                                <th class="<?= $sortBy === 'niveau' ? 'active-sort' : '' ?>">
                                    <a href="<?= buildSortUrl('niveau') ?>" class="text-decoration-none text-dark sortable">
                                        Niveau
                                        <i class="fas <?= getSortIcon('niveau') ?> sort-icon"></i>
                                    </a>
                                </th>
                                <th class="<?= $sortBy === 'date_inscription' ? 'active-sort' : '' ?>">
                                    <a href="<?= buildSortUrl('date_inscription') ?>" class="text-decoration-none text-dark sortable">
                                        Date Inscription
                                        <i class="fas <?= getSortIcon('date_inscription') ?> sort-icon"></i>
                                    </a>
                                </th>
                                <th class="<?= $sortBy === 'statut' ? 'active-sort' : '' ?>">
                                    <a href="<?= buildSortUrl('statut') ?>" class="text-decoration-none text-dark sortable">
                                        Statut
                                        <i class="fas <?= getSortIcon('statut') ?> sort-icon"></i>
                                    </a>
                                </th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($etudiants)): ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <i class="fas fa-users fa-2x text-muted mb-2 d-block"></i>
                                        <span class="text-muted">Aucun étudiant trouvé</span>
                                        <?php if ($filiereFilter || $niveauFilter || $statutFilter || $searchFilter): ?>
                                            <br>
                                            <a href="liste_etudiants.php" class="btn btn-sm btn-primary mt-2">
                                                Afficher tous les étudiants
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($etudiants as $etudiant): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($etudiant['matricule']) ?></strong>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars($etudiant['nom']) ?> <?= htmlspecialchars($etudiant['prenom']) ?></strong>
                                        <?php if ($etudiant['date_naissance']): ?>
                                            <br>
                                            <small class="text-muted">
                                                <?= date('d/m/Y', strtotime($etudiant['date_naissance'])) ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($etudiant['email']) ?></td>
                                    <td><?= htmlspecialchars($etudiant['filiere'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($etudiant['niveau'] ?? 'N/A') ?></td>
                                    <td>
                                        <small class="text-muted">
                                            <?= date('d/m/Y', strtotime($etudiant['date_inscription'])) ?>
                                        </small>
                                    </td>
                                    <td>
                                        <span class="badge badge-statut <?= $etudiant['statut'] === 'actif' ? 'bg-success' : 'bg-danger' ?>">
                                            <?= $etudiant['statut'] === 'actif' ? 'Actif' : 'Inactif' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <button type="button" class="btn btn-outline-info" 
                                                    onclick="afficherDetails(<?= htmlspecialchars(json_encode($etudiant)) ?>)">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <a href="modifier_etudiant.php?id=<?= $etudiant['id'] ?>" class="btn btn-outline-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <div class="card-footer">
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center mb-0">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?= buildUrl(['page' => $page - 1]) ?>">
                                        <i class="fas fa-chevron-left"></i> Précédent
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php 
                            $startPage = max(1, $page - 2);
                            $endPage = min($totalPages, $page + 2);
                            
                            for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="<?= buildUrl(['page' => $i]) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?= buildUrl(['page' => $page + 1]) ?>">
                                        Suivant <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal de détails -->
    <div class="modal fade" id="detailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Détails de l'étudiant</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="detailsContent">
                    <!-- Contenu chargé dynamiquement -->
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function afficherDetails(etudiant) {
        const content = document.getElementById('detailsContent');
        
        const html = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Informations personnelles</h6>
                    <p><strong>Matricule:</strong> ${etudiant.matricule}</p>
                    <p><strong>Nom:</strong> ${etudiant.nom} ${etudiant.prenom}</p>
                    <p><strong>Email:</strong> ${etudiant.email}</p>
                    <p><strong>Date de naissance:</strong> ${etudiant.date_naissance ? new Date(etudiant.date_naissance).toLocaleDateString('fr-FR') : 'N/A'}</p>
                </div>
                <div class="col-md-6">
                    <h6>Informations académiques</h6>
                    <p><strong>Filière:</strong> ${etudiant.filiere || 'N/A'}</p>
                    <p><strong>Niveau:</strong> ${etudiant.niveau || 'N/A'}</p>
                    <p><strong>Statut étudiant:</strong> ${etudiant.statut_etudiant || 'N/A'}</p>
                    <p><strong>Date d'inscription:</strong> ${new Date(etudiant.date_inscription).toLocaleDateString('fr-FR')}</p>
                    <p><strong>Statut:</strong> <span class="badge ${etudiant.statut === 'actif' ? 'bg-success' : 'bg-danger'}">${etudiant.statut === 'actif' ? 'Actif' : 'Inactif'}</span></p>
                </div>
            </div>
        `;
        
        content.innerHTML = html;
        new bootstrap.Modal(document.getElementById('detailsModal')).show();
    }

    // Auto-submit du formulaire quand certains filtres changent
    document.querySelector('select[name="filiere"]').addEventListener('change', function() {
        this.form.submit();
    });
    
    document.querySelector('select[name="niveau"]').addEventListener('change', function() {
        this.form.submit();
    });
    
    document.querySelector('select[name="statut"]').addEventListener('change', function() {
        this.form.submit();
    });
    </script>
</body>
</html>