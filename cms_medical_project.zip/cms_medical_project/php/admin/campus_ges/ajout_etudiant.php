<?php
session_start();
require_once '../../config/db.php';

// Vérification des permissions
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    header("Location: ../../config/auth.php");
    exit;
}

// Vérification de la connexion PDO à campus_db
if (!isset($pdoCampus)) {
    die("❌ Erreur de connexion à la base de données campus");
}

$success = '';
$error = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Récupération et validation des données
        $matricule = trim($_POST['matricule']);
        $nom = trim($_POST['nom']);
        $prenom = trim($_POST['prenom']);
        $email = trim($_POST['email']);
        $filiere = trim($_POST['filiere']);
        $niveau = trim($_POST['niveau']);
        $statut_etudiant = trim($_POST['statut_etudiant']);
        $date_naissance = $_POST['date_naissance'];
        $date_inscription = $_POST['date_inscription'] ?? date('Y-m-d');

        // Validation des champs obligatoires
        if (empty($matricule) || empty($nom) || empty($prenom) || empty($email)) {
            throw new Exception("Tous les champs obligatoires doivent être remplis");
        }

        // Validation de l'email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("L'adresse email n'est pas valide");
        }

        // Vérification de l'unicité du matricule et email dans campus_db
        $checkStmt = $pdoCampus->prepare("
            SELECT id FROM etudiants 
            WHERE matricule = ? OR email = ?
        ");
        $checkStmt->execute([$matricule, $email]);
        
        if ($checkStmt->rowCount() > 0) {
            throw new Exception("Un étudiant avec ce matricule ou cette adresse email existe déjà");
        }

        // Insertion dans campus_db
        $insertStmt = $pdoCampus->prepare("
            INSERT INTO etudiants 
            (matricule, nom, prenom, email, filiere, niveau, statut_etudiant, date_naissance, date_inscription, statut) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'actif')
        ");

        $insertStmt->execute([
            $matricule,
            $nom,
            $prenom,
            $email,
            $filiere,
            $niveau,
            $statut_etudiant,
            $date_naissance,
            $date_inscription
        ]);

        // Journalisation de l'action dans medical_db - CORRECTION ICI
        if (isset($pdoMedical)) {
            try {
                // Solution 1: Récupérer l'ID utilisateur numérique depuis la table utilisateurs
                $userStmt = $pdoMedical->prepare("SELECT id FROM utilisateurs WHERE user_id = ? OR matricule = ?");
                $userStmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
                $user = $userStmt->fetch(PDO::FETCH_ASSOC);
                
                $userId = $user ? $user['id'] : null;
                
                // Solution 2: Si pas d'ID numérique, utiliser NULL ou une valeur par défaut
                if (!$userId) {
                    // Chercher l'ID du super admin
                    $adminStmt = $pdoMedical->prepare("SELECT id FROM utilisateurs WHERE role = 'super_admin' LIMIT 1");
                    $adminStmt->execute();
                    $admin = $adminStmt->fetch(PDO::FETCH_ASSOC);
                    $userId = $admin ? $admin['id'] : 1; // Valeur par défaut
                }
                
                $logStmt = $pdoMedical->prepare("
                    INSERT INTO system_logs 
                    (user_id, action_type, action_description, ip_address, user_agent) 
                    VALUES (?, 'ADD_STUDENT', ?, ?, ?)
                ");
                
                $logDescription = "Ajout de l'étudiant: $nom $prenom ($matricule) - Filière: $filiere";
                $logStmt->execute([
                    $userId,
                    $logDescription,
                    $_SERVER['REMOTE_ADDR'],
                    $_SERVER['HTTP_USER_AGENT']
                ]);
                
            } catch (Exception $logError) {
                // En cas d'erreur de journalisation, on continue mais on la log
                error_log("Erreur journalisation: " . $logError->getMessage());
                // On ne bloque pas l'ajout de l'étudiant à cause de la journalisation
            }
        }

        $success = "✅ Étudiant ajouté avec succès dans campus_db!";
        
        // Réinitialisation du formulaire après succès
        $_POST = [];

    } catch (Exception $e) {
        $error = "❌ Erreur: " . $e->getMessage();
    }
}

// Récupération des filières existantes pour les suggestions depuis campus_db
try {
    $filieresStmt = $pdoCampus->query("
        SELECT DISTINCT filiere 
        FROM etudiants 
        WHERE filiere IS NOT NULL AND filiere != '' 
        ORDER BY filiere
    ");
    $filieres = $filieresStmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
    $filieres = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Étudiant - MedicalSystem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #858796;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
        }
        
        body {
            background-color: #f8f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .navbar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .card {
            border: none;
            border-radius: 0.75rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            border-radius: 0.75rem 0.75rem 0 0 !important;
            background-color: #fff;
            border-bottom: 1px solid #e3e6f0;
        }
        
        .btn {
            border-radius: 0.5rem;
            font-weight: 500;
        }
        
        .form-control, .form-select {
            border-radius: 0.5rem;
        }
        
        .required::after {
            content: " *";
            color: var(--danger-color);
        }
        
        .form-section {
            background-color: #f8f9fa;
            border-radius: 0.5rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .form-section h6 {
            color: var(--primary-color);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 0.5rem;
        }
        
        .database-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 0.7rem;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="superadmin_dashboard.php">
                <i class="fas fa-hospital me-2"></i>
                <strong>MedicalSystem</strong> - Super Admin
            </a>
            
            <div class="d-flex align-items-center">
                <span class="navbar-text text-light me-3">
                    <i class="fas fa-user-shield me-1"></i>
                    <?= htmlspecialchars($_SESSION['user_name'] ?? 'Super Admin') ?>
                </span>
                
            </div>
        </div>
    </nav>

    <div class="container-fluid py-4">
        <!-- En-tête -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <div>
                <h1 class="h3 mb-1 text-gray-800">
                    <i class="fas fa-user-graduate me-2"></i>Ajouter un Étudiant
                </h1>
                <p class="text-muted mb-0">Gestion des inscriptions étudiantes - Base: campus_db</p>
            </div>
            <div class="d-flex gap-2">
                <a href="liste_etudiants.php" class="btn btn-outline-primary">
                    <i class="fas fa-list me-2"></i>Liste des étudiants
                </a>
               
            </div>
        </div>

        <!-- Messages -->
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?= $success ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Formulaire -->
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card shadow">
                    <div class="card-header py-3 position-relative">
                        <h6 class="m-0 font-weight-bold text-primary">
                            <i class="fas fa-id-card me-2"></i>Informations de l'étudiant
                        </h6>
                        <span class="badge bg-info database-badge">campus_db</span>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="studentForm">
                            <!-- Section Informations personnelles -->
                            <div class="form-section">
                                <h6><i class="fas fa-user me-2"></i>Informations personnelles</h6>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label required">Matricule</label>
                                        <input type="text" class="form-control" name="matricule" 
                                               value="<?= htmlspecialchars($_POST['matricule'] ?? '') ?>" 
                                               required pattern="[A-Za-z0-9]{5,20}"
                                               title="Le matricule doit contenir entre 5 et 20 caractères alphanumériques">
                                        <div class="form-text">Identifiant unique de l'étudiant</div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label required">Email</label>
                                        <input type="email" class="form-control" name="email" 
                                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label required">Nom</label>
                                        <input type="text" class="form-control" name="nom" 
                                               value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" required>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label required">Prénom</label>
                                        <input type="text" class="form-control" name="prenom" 
                                               value="<?= htmlspecialchars($_POST['prenom'] ?? '') ?>" required>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label required">Date de naissance</label>
                                        <input type="date" class="form-control" name="date_naissance" 
                                               value="<?= htmlspecialchars($_POST['date_naissance'] ?? '') ?>" required
                                               max="<?= date('Y-m-d', strtotime('-16 years')) ?>">
                                        <div class="form-text">L'étudiant doit avoir au moins 16 ans</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Section Scolarité -->
                            <div class="form-section">
                                <h6><i class="fas fa-graduation-cap me-2"></i>Informations académiques</h6>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Filière</label>
                                        <input type="text" class="form-control" name="filiere" 
                                               value="<?= htmlspecialchars($_POST['filiere'] ?? '') ?>" 
                                               list="filieres-list">
                                        <datalist id="filieres-list">
                                            <?php foreach ($filieres as $filiere): ?>
                                                <option value="<?= htmlspecialchars($filiere) ?>">
                                            <?php endforeach; ?>
                                        </datalist>
                                        <div class="form-text">Ex: Informatique, Médecine, Droit, etc.</div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label">Niveau</label>
                                        <select class="form-select" name="niveau">
                                            <option value="">Sélectionner un niveau</option>
                                            <option value="Licence 1" <?= ($_POST['niveau'] ?? '') === 'Licence 1' ? 'selected' : '' ?>>Licence 1</option>
                                            <option value="Licence 2" <?= ($_POST['niveau'] ?? '') === 'Licence 2' ? 'selected' : '' ?>>Licence 2</option>
                                            <option value="Licence 3" <?= ($_POST['niveau'] ?? '') === 'Licence 3' ? 'selected' : '' ?>>Licence 3</option>
                                            <option value="Master 1" <?= ($_POST['niveau'] ?? '') === 'Master 1' ? 'selected' : '' ?>>Master 1</option>
                                            <option value="Master 2" <?= ($_POST['niveau'] ?? '') === 'Master 2' ? 'selected' : '' ?>>Master 2</option>
                                            <option value="Doctorat" <?= ($_POST['niveau'] ?? '') === 'Doctorat' ? 'selected' : '' ?>>Doctorat</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label">Statut étudiant</label>
                                        <select class="form-select" name="statut_etudiant">
                                            <option value="">Sélectionner un statut</option>
                                            <option value="Présentiel" <?= ($_POST['statut_etudiant'] ?? '') === 'Présentiel' ? 'selected' : '' ?>>Présentiel</option>
                                            <option value="Distanciel" <?= ($_POST['statut_etudiant'] ?? '') === 'Distanciel' ? 'selected' : '' ?>>Distanciel</option>
                                            <option value="Alternance" <?= ($_POST['statut_etudiant'] ?? '') === 'Alternance' ? 'selected' : '' ?>>Alternance</option>
                                            <option value="Echange" <?= ($_POST['statut_etudiant'] ?? '') === 'Echange' ? 'selected' : '' ?>>Échange</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label">Date d'inscription</label>
                                        <input type="date" class="form-control" name="date_inscription" 
                                               value="<?= htmlspecialchars($_POST['date_inscription'] ?? date('Y-m-d')) ?>">
                                        <div class="form-text">Date d'inscription dans le système</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Boutons -->
                            <div class="row mt-4">
                                <div class="col-12">
                                    <div class="d-flex gap-2 justify-content-end">
                                        <button type="reset" class="btn btn-secondary">
                                            <i class="fas fa-undo me-2"></i>Réinitialiser
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-save me-2"></i>Enregistrer l'étudiant
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer mt-5 py-3 bg-white border-top">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted">&copy; 2024 MedicalSystem. Super Admin Dashboard.</span>
                </div>
                <div>
                    <span class="text-muted">
                        <i class="fas fa-clock me-1"></i>
                        <?= date('d/m/Y H:i') ?>
                    </span>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Validation côté client
    document.getElementById('studentForm').addEventListener('submit', function(e) {
        const matricule = document.querySelector('input[name="matricule"]').value;
        const email = document.querySelector('input[name="email"]').value;
        const dateNaissance = document.querySelector('input[name="date_naissance"]').value;
        
        // Validation du matricule
        if (!/^[A-Za-z0-9]{5,20}$/.test(matricule)) {
            e.preventDefault();
            alert('Le matricule doit contenir entre 5 et 20 caractères alphanumériques');
            return;
        }
        
        // Validation de la date de naissance
        if (dateNaissance) {
            const birthDate = new Date(dateNaissance);
            const minDate = new Date();
            minDate.setFullYear(minDate.getFullYear() - 16);
            
            if (birthDate > minDate) {
                e.preventDefault();
                alert('L\'étudiant doit avoir au moins 16 ans');
                return;
            }
        }
    });

    // Génération automatique de matricule si vide
    document.querySelector('input[name="nom"]').addEventListener('blur', function() {
        const matriculeInput = document.querySelector('input[name="matricule"]');
        const nomInput = document.querySelector('input[name="nom"]');
        const prenomInput = document.querySelector('input[name="prenom"]');
        
        if (!matriculeInput.value && nomInput.value && prenomInput.value) {
            const matricule = (nomInput.value.substring(0, 3) + prenomInput.value.substring(0, 3) + 
                            Math.floor(1000 + Math.random() * 9000)).toUpperCase();
            matriculeInput.value = matricule;
        }
    });
    </script>
</body>
</html>