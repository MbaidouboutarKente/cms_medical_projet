<?php
session_start();
require_once "config/db.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Vérification de connexion
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: config/auth.php");
    exit;
}

$userID = intval(preg_replace('/^[A-Z]+_/', '', $_SESSION['user_id']));
$userRole = $_SESSION['role'];

// Déterminer le type d'utilisateur et ses permissions
$rolesPersonnel = ['medecin', 'infirmier', 'admin', 'secretaire', 'technicien'];
$estPersonnel = in_array($userRole, $rolesPersonnel);

if (!$estPersonnel) {
    die("Accès réservé au personnel");
}

// Système de notifications
$notifications = [];
$personnelDisponible = [];
$typesRendezVous = [];
$rdvs = [];

try {
    // Récupération des informations du personnel
    $queryPersonnel = $pdoMedical->prepare("
        SELECT id, nom, prenom, email, role, specialite, telephone 
        FROM utilisateurs 
        WHERE id = ?
    ");
    $queryPersonnel->execute([$userID]);
    $personnel = $queryPersonnel->fetch();
    
    if (!$personnel) {
        throw new Exception("Utilisateur non trouvé");
    }

    // Récupération des rendez-vous selon le rôle
    switch ($userRole) {
        case 'medecin':
            // Rendez-vous médicaux + patients référés
            $queryRdvs = $pdoMedical->prepare("
                SELECT r.*, u.nom as patient_nom, u.prenom as patient_prenom,
                       'Consultation médicale' as type_rendez_vous,
                       '#3a7bd5' as type_couleur
                FROM rendez_vous r
                JOIN utilisateurs u ON r.patient_id = u.id
                WHERE r.medecin_id = ?
                ORDER BY r.date_rdv DESC
            ");
            $queryRdvs->execute([$userID]);
            break;
            
        case 'infirmier':
            // Rendez-vous infirmiers
            $queryRdvs = $pdoMedical->prepare("
                SELECT r.*, u.nom as patient_nom, u.prenom as patient_prenom,
                       'Soins infirmiers' as type_rendez_vous,
                       '#00d2ff' as type_couleur
                FROM rendez_vous r
                JOIN utilisateurs u ON r.patient_id = u.id
                WHERE r.infirmier_id = ?
                ORDER BY r.date_rdv DESC
            ");
            $queryRdvs->execute([$userID]);
            break;
            
        default:
            // Pour admin, secrétaire, etc. - tous les rendez-vous
            $queryRdvs = $pdoMedical->prepare("
                SELECT r.*, u.nom as patient_nom, u.prenom as patient_prenom,
                       CASE 
                         WHEN r.medecin_id IS NOT NULL THEN 'Consultation médicale'
                         WHEN r.infirmier_id IS NOT NULL THEN 'Soins infirmiers'
                         ELSE 'Rendez-vous'
                       END as type_rendez_vous,
                       CASE 
                         WHEN r.medecin_id IS NOT NULL THEN '#3a7bd5'
                         WHEN r.infirmier_id IS NOT NULL THEN '#00d2ff'
                         ELSE '#95a5a6'
                       END as type_couleur
                FROM rendez_vous r
                JOIN utilisateurs u ON r.patient_id = u.id
                WHERE r.statut != 'Annulé'
                ORDER BY r.date_rdv DESC
                LIMIT 50
            ");
            $queryRdvs->execute();
    }
    
    $rdvs = $queryRdvs->fetchAll();

    // Récupération des membres du personnel disponibles
    $queryPersonnelDispo = $pdoMedical->prepare("
        SELECT id, nom, prenom, role, specialite 
        FROM utilisateurs 
        WHERE role IN ('medecin', 'infirmier', 'admin', 'secretaire', 'technicien')
        AND is_active = 1
        ORDER BY role, nom
    ");
    $queryPersonnelDispo->execute();
    $personnelDisponible = $queryPersonnelDispo->fetchAll();

    // Types de rendez-vous prédéfinis (simulés)
    $typesRendezVous = [
        ['id' => 1, 'nom' => 'Consultation médicale', 'duree' => 30, 'couleur' => '#3a7bd5'],
        ['id' => 2, 'nom' => 'Soins infirmiers', 'duree' => 20, 'couleur' => '#00d2ff'],
        ['id' => 3, 'nom' => 'Administratif', 'duree' => 15, 'couleur' => '#2ecc71'],
        ['id' => 4, 'nom' => 'Bilan de santé', 'duree' => 45, 'couleur' => '#f39c12'],
        ['id' => 5, 'nom' => 'Urgence', 'duree' => 60, 'couleur' => '#e74c3c']
    ];

} catch (PDOException $e) {
    die("Erreur base de données: " . $e->getMessage());
} catch (Exception $e) {
    die($e->getMessage());
}

// Traitement des actions
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === "prendre_rendez_vous") {
            $patient_id = (int)$_POST['patient_id'];
            $personnel_id = (int)$_POST['personnel_id'];
            $type_rendez_vous = trim($_POST['type_rendez_vous']);
            $date_rdv = $_POST['date_rdv'];
            $motif = trim($_POST['motif']);
            
            // Validation
            if (empty($motif) || empty($date_rdv) || empty($patient_id)) {
                throw new Exception("Tous les champs sont obligatoires");
            }
            
            // Déterminer le type de personnel
            $queryPersonnelType = $pdoMedical->prepare("SELECT role FROM utilisateurs WHERE id = ?");
            $queryPersonnelType->execute([$personnel_id]);
            $personnelType = $queryPersonnelType->fetchColumn();
            
            if ($personnelType === 'medecin') {
                $stmt = $pdoMedical->prepare("
                    INSERT INTO rendez_vous 
                    (patient_id, medecin_id, date_rdv, motif, statut, created_at) 
                    VALUES (?, ?, ?, ?, 'Confirmé', NOW())
                ");
            } elseif ($personnelType === 'infirmier') {
                $stmt = $pdoMedical->prepare("
                    INSERT INTO rendez_vous 
                    (patient_id, infirmier_id, date_rdv, motif, statut, created_at) 
                    VALUES (?, ?, ?, ?, 'Confirmé', NOW())
                ");
            } else {
                throw new Exception("Type de personnel non supporté");
            }
            
            if ($stmt->execute([$patient_id, $personnel_id, $date_rdv, $motif])) {
                $message = "✅ Rendez-vous programmé avec succès";
                // Recharger les données
                $queryRdvs->execute([$userID]);
                $rdvs = $queryRdvs->fetchAll();
            }
            
        } elseif ($action === "annuler_rdv") {
            $rdv_id = (int)$_POST['rdv_id'];
            $raison = trim($_POST['raison_annulation'] ?? '');
            
            $stmt = $pdoMedical->prepare("
                UPDATE rendez_vous 
                SET statut = 'Annulé'
                WHERE id = ?
            ");
            
            if ($stmt->execute([$rdv_id])) {
                $message = "✅ Rendez-vous annulé";
                // Recharger les données
                $queryRdvs->execute([$userID]);
                $rdvs = $queryRdvs->fetchAll();
            }
        }
        
    } catch (Exception $e) {
        $message = "🔴 Erreur: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Personnel | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            width: 95%;
            max-width: 1400px;
            margin: 1rem auto;
            padding: 0 1rem;
        }
        
        .header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--white);
            padding: 2rem;
            border-radius: var(--radius);
            margin-bottom: 2rem;
            text-align: center;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }
        
        .header::before {
            content: "";
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
            transform: rotate(30deg);
        }
        
        .header h1 {
            font-size: 2.2rem;
            margin-bottom: 0.5rem;
            position: relative;
        }
        
        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
            position: relative;
        }
        
        .profile-card {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            margin-bottom: 2rem;
            position: relative;
            border-left: 5px solid var(--primary);
        }
        
        .profile-card h2 {
            color: var(--primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            font-size: 1.5rem;
        }
        
        .profile-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }
        
        .info-item {
            background: var(--light-gray);
            padding: 1rem;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            transition: transform 0.3s ease;
        }
        
        .info-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .info-item i {
            color: var(--primary);
            font-size: 1.2rem;
            width: 30px;
            height: 30px;
            background: rgba(58, 123, 213, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .info-content h3 {
            font-size: 1rem;
            color: var(--dark);
            margin-bottom: 0.3rem;
        }
        
        .info-content p {
            font-size: 1.1rem;
            font-weight: 500;
            color: var(--primary-dark);
        }
        
        .rdv-card {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 0;
            margin-bottom: 3rem;
            overflow: hidden;
        }
        
        .alert {
            padding: 1.2rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            border-left: 5px solid;
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 1rem;
            animation: fadeIn 0.5s ease;
        }
        
        .alert i {
            font-size: 1.5rem;
        }
        
        .alert-success {
            background-color: rgba(46, 204, 113, 0.1);
            color: #27ae60;
            border-color: var(--success);
        }
        
        .alert-danger {
            background-color: rgba(231, 76, 60, 0.1);
            color: #c0392b;
            border-color: var(--danger);
        }
        
        .table-container {
            overflow-x: auto;
            padding: 0 1.5rem 1.5rem;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
            min-width: 800px;
        }
        
        .table th, .table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .table th {
            background-color: var(--primary);
            color: var(--white);
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
        }
        
        .table tr:nth-child(even) {
            background-color: var(--light-gray);
        }
        
        .table tr:hover {
            background-color: rgba(58, 123, 213, 0.05);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.7rem 1.5rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.95rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            margin: 0.3rem;
            white-space: nowrap;
        }
        
        .btn i {
            font-size: 1rem;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: var(--white);
        }
        
        .btn-primary:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.3);
        }
        
        .btn-success {
            background-color: var(--success);
            color: var(--white);
        }
        
        .btn-success:hover {
            background-color: #27ae60;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(46, 204, 113, 0.3);
        }
        
        .btn-outline {
            background: transparent;
            border: 1px solid var(--primary);
            color: var(--primary);
        }
        
        .btn-outline:hover {
            background: var(--primary);
            color: var(--white);
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 0.8rem 1rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(58, 123, 213, 0.2);
        }
        
        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }
        
        .nav-menu {
            display: flex;
            justify-content: space-between;
            background-color: var(--dark);
            padding: 1rem 2rem;
            border-radius: var(--radius);
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
        }
        
        .nav-menu a {
            color: var(--white);
            text-decoration: none;
            padding: 0.7rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.7rem;
        }
        
        .nav-menu a:hover {
            background-color: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        
        .tab-buttons {
            display: flex;
            margin-bottom: 0;
            border-bottom: 1px solid var(--light-gray);
            background: var(--light-gray);
        }
        
        .tab-btn {
            padding: 1.2rem 2rem;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            color: var(--gray);
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.7rem;
        }
        
        .tab-btn:hover {
            color: var(--primary);
            background: rgba(58, 123, 213, 0.05);
        }
        
        .tab-btn.active {
            color: var(--primary);
            border-bottom: 3px solid var(--primary);
            background: var(--white);
        }
        
        .tab-content {
            display: none;
            padding: 2rem;
            animation: fadeIn 0.5s ease;
        }
        
        .tab-content h2 {
            color: var(--primary-dark);
            margin-bottom: 1.5rem;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .tab-content.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .diagnostic-form {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: var(--radius);
            margin-top: 1.5rem;
        }
        
        .status-badge {
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }
        
        .status-confirmed {
            background-color: rgba(46, 204, 113, 0.1);
            color: var(--success);
        }
        
        .status-pending {
            background-color: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }
        
        .status-completed {
            background-color: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }
        
        .status-cancelled {
            background-color: rgba(231, 76, 60, 0.1);
            color: var(--danger);
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }
        
        .empty-state h3 {
            font-size: 1.3rem;
            margin-bottom: 0.5rem;
            color: var(--dark);
        }
        
        .badge {
            padding: 0.3rem 0.6rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-primary {
            background: rgba(58, 123, 213, 0.1);
            color: var(--primary);
        }
        
        .consultation-history {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .consultation-history h2 {
            color: var(--primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            font-size: 1.5rem;
        }
        
        .history-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .history-table th, .history-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .history-table th {
            background-color: var(--primary);
            color: var(--white);
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
        }
        
        .history-table tr:nth-child(even) {
            background-color: var(--light-gray);
        }
        
        .history-table tr:hover {
            background-color: rgba(58, 123, 213, 0.05);
        }
        
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        
        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
        }
        
        .btn-info {
            background-color: var(--info);
            color: var(--white);
        }
        
        .btn-info:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(52, 152, 219, 0.3);
        }
        
        .btn-secondary {
            background-color: var(--secondary);
            color: var(--white);
        }
        
        .btn-secondary:hover {
            background-color: #00b8d9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 210, 255, 0.3);
        }
        
        .tooltip {
            position: relative;
            display: inline-block;
        }
        
        .tooltip .tooltiptext {
            visibility: hidden;
            width: 120px;
            background-color: var(--dark);
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            bottom: 125%;
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
            font-size: 0.8rem;
        }
        
        .tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }
        
        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 0 0.5rem;
            }
            
            .nav-menu {
                flex-direction: column;
                gap: 0.5rem;
                padding: 1rem;
            }
            
            .profile-info {
                grid-template-columns: 1fr;
            }
            
            .tab-buttons {
                overflow-x: auto;
                white-space: nowrap;
                padding-bottom: 0.5rem;
            }
            
            .tab-btn {
                padding: 1rem 1.2rem;
                font-size: 0.9rem;
            }
            
            .header h1 {
                font-size: 1.8rem;
            }
            
            .history-table {
                display: block;
                overflow-x: auto;
            }
        }

        /* Styles pour les rôles */
        .role-badge {
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .role-medecin { background: rgba(58, 123, 213, 0.1); color: var(--primary); }
        .role-infirmier { background: rgba(0, 210, 255, 0.1); color: var(--secondary); }
        .role-admin { background: rgba(46, 204, 113, 0.1); color: var(--success); }
        .role-secretaire { background: rgba(243, 156, 18, 0.1); color: var(--warning); }
        .role-technicien { background: rgba(149, 165, 166, 0.1); color: var(--gray); }
        
        .type-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav-menu">
            <div>
                <a href="dashboard_personnel.php"><i class="fas fa-home"></i> Tableau de bord</a>
                <a href="calendrier_universel.php"><i class="fas fa-calendar-alt"></i> Calendrier</a>
                <a href="prise_rdv.php"><i class="fas fa-calendar-plus"></i> Prendre RDV</a>
                <?php if ($userRole === 'medecin'): ?>
                    <a href="patients.php"><i class="fas fa-user-injured"></i> Dossier patients</a>
                <?php endif; ?>
                <?php if (in_array($userRole, ['admin', 'secretaire'])): ?>
                    <a href="gestion_personnel.php"><i class="fas fa-users-cog"></i> Gestion Personnel</a>
                <?php endif; ?>
            </div>
            <div>
                <a href="profil.php"><i class="fas fa-user-cog"></i> <?= htmlspecialchars($personnel['prenom']) ?></a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
            </div>
        </div>

        <div class="header">
            <h1>
                <i class="fas 
                    <?= $userRole === 'medecin' ? 'fa-user-md' : 
                       ($userRole === 'infirmier' ? 'fa-user-nurse' : 
                       ($userRole === 'admin' ? 'fa-user-shield' : 'fa-user-tie')) ?>">
                </i> 
                Tableau de bord <?= ucfirst($userRole) ?>
            </h1>
            <p>Bienvenue Dr. <?= htmlspecialchars($personnel['nom']) ?> - Gestion des rendez-vous et planning</p>
        </div>

        <?php if (!empty($message)): ?>
            <div class="alert alert-<?= strpos($message, '✅') !== false ? 'success' : 'danger' ?>">
                <i class="fas <?= strpos($message, '✅') !== false ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <div class="profile-card">
            <h2><i class="fas fa-id-card"></i> Profil Personnel</h2>
            <div class="profile-info">
                <div class="info-item">
                    <i class="fas fa-user"></i>
                    <div class="info-content">
                        <h3>Identité</h3>
                        <p><?= htmlspecialchars($personnel['prenom'] . ' ' . $personnel['nom']) ?></p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-id-badge"></i>
                    <div class="info-content">
                        <h3>Rôle</h3>
                        <p>
                            <span class="role-badge role-<?= $userRole ?>">
                                <?= strtoupper($userRole) ?>
                            </span>
                        </p>
                    </div>
                </div>
                
                <div class="info-item">
                    <i class="fas fa-envelope"></i>
                    <div class="info-content">
                        <h3>Email</h3>
                        <p><?= htmlspecialchars($personnel['email']) ?></p>
                    </div>
                </div>
                
                <?php if (!empty($personnel['specialite'])): ?>
                <div class="info-item">
                    <i class="fas fa-stethoscope"></i>
                    <div class="info-content">
                        <h3>Spécialité</h3>
                        <p><?= htmlspecialchars($personnel['specialite']) ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="rdv-card">
            <div class="tab-buttons">
                <button class="tab-btn active" onclick="openTab(event, 'mes_rdv')">
                    <i class="fas fa-calendar-check"></i> Mes Rendez-vous (<?= count($rdvs) ?>)
                </button>
                <button class="tab-btn" onclick="openTab(event, 'prendre_rdv')">
                    <i class="fas fa-calendar-plus"></i> Prendre un RDV
                </button>
                <button class="tab-btn" onclick="openTab(event, 'personnel')">
                    <i class="fas fa-users"></i> Personnel Disponible
                </button>
            </div>

            <div id="mes_rdv" class="tab-content active">
                <h2><i class="fas fa-calendar-check"></i> Mes Rendez-vous à venir</h2>
                
                <?php if (empty($rdvs)): ?>
                    <div class="empty-state">
                        <i class="fas fa-calendar-times"></i>
                        <h3>Aucun rendez-vous programmé</h3>
                        <p>Vous n'avez aucun rendez-vous de prévu pour le moment.</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Patient</th>
                                    <th>Date/Heure</th>
                                    <th>Type</th>
                                    <th>Motif</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rdvs as $rdv): ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($rdv['patient_nom'] . ' ' . $rdv['patient_prenom']) ?></strong>
                                        </td>
                                        <td>
                                            <?= date('d/m/Y', strtotime($rdv['date_rdv'])) ?><br>
                                            <small><?= date('H:i', strtotime($rdv['date_rdv'])) ?></small>
                                        </td>
                                        <td>
                                            <span class="type-indicator" style="background-color: <?= $rdv['type_couleur'] ?? '#3a7bd5' ?>"></span>
                                            <?= htmlspecialchars($rdv['type_rendez_vous'] ?? 'Consultation') ?>
                                        </td>
                                        <td><?= htmlspecialchars($rdv['motif'] ?? 'Non spécifié') ?></td>
                                        <td>
                                            <span class="status-badge 
                                                <?= $rdv['statut'] === 'Confirmé' ? 'status-confirmed' : 
                                                   ($rdv['statut'] === 'Terminé' ? 'status-completed' : 
                                                   ($rdv['statut'] === 'Annulé' ? 'status-cancelled' : 'status-pending')) ?>">
                                                <i class="fas <?= $rdv['statut'] === 'Confirmé' ? 'fa-check-circle' : 
                                                   ($rdv['statut'] === 'Terminé' ? 'fa-clipboard-check' : 
                                                   ($rdv['statut'] === 'Annulé' ? 'fa-times-circle' : 'fa-clock')) ?>"></i>
                                                <?= $rdv['statut'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <button class="btn btn-outline tooltip" title="Voir détails">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <?php if ($rdv['statut'] === 'Confirmé'): ?>
                                                    <button class="btn btn-success tooltip" title="Commencer">
                                                        <i class="fas fa-play"></i>
                                                    </button>
                                                    <button class="btn btn-danger tooltip" title="Annuler" onclick="annulerRdv(<?= $rdv['id'] ?>)">
                                                        <i class="fas fa-times"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <div id="prendre_rdv" class="tab-content">
                <h2><i class="fas fa-calendar-plus"></i> Prendre un Rendez-vous</h2>
                
                <form method="post" class="diagnostic-form">
                    <input type="hidden" name="action" value="prendre_rendez_vous">
                    
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Patient :</label>
                        <select name="patient_id" class="form-control" required>
                            <option value="">Sélectionner un patient</option>
                            <!-- Liste des patients depuis la base -->
                            <?php
                            try {
                                $queryPatients = $pdoMedical->prepare("SELECT id, nom, prenom FROM utilisateurs WHERE role = 'patient' ORDER BY nom");
                                $queryPatients->execute();
                                $patients = $queryPatients->fetchAll();
                                foreach ($patients as $patient): ?>
                                    <option value="<?= $patient['id'] ?>">
                                        <?= htmlspecialchars($patient['prenom'] . ' ' . $patient['nom']) ?>
                                    </option>
                                <?php endforeach;
                            } catch (Exception $e) {
                                echo '<option value="">Erreur de chargement des patients</option>';
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-user-md"></i> Personnel :</label>
                        <select name="personnel_id" class="form-control" required>
                            <option value="">Sélectionner le personnel</option>
                            <?php foreach ($personnelDisponible as $pers): ?>
                                <option value="<?= $pers['id'] ?>">
                                    <?= htmlspecialchars($pers['prenom'] . ' ' . $pers['nom']) ?> 
                                    - <span class="role-badge role-<?= $pers['role'] ?>"><?= strtoupper($pers['role']) ?></span>
                                    <?php if (!empty($pers['specialite'])): ?>
                                        (<?= $pers['specialite'] ?>)
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-calendar-alt"></i> Type de rendez-vous :</label>
                        <select name="type_rendez_vous" class="form-control" required>
                            <option value="">Sélectionner le type</option>
                            <?php foreach ($typesRendezVous as $type): ?>
                                <option value="<?= htmlspecialchars($type['nom']) ?>">
                                    <?= htmlspecialchars($type['nom']) ?> (<?= $type['duree'] ?> min)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-clock"></i> Date et heure :</label>
                        <input type="datetime-local" name="date_rdv" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-comment-medical"></i> Motif de la consultation :</label>
                        <textarea name="motif" class="form-control" placeholder="Décrire le motif du rendez-vous..." required rows="3"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-calendar-plus"></i> Programmer le rendez-vous
                    </button>
                </form>
            </div>

            <div id="personnel" class="tab-content">
                <h2><i class="fas fa-users"></i> Personnel Disponible</h2>
                
                <div class="profile-info">
                    <?php foreach ($personnelDisponible as $pers): ?>
                        <div class="info-item">
                            <i class="fas 
                                <?= $pers['role'] === 'medecin' ? 'fa-user-md' : 
                                   ($pers['role'] === 'infirmier' ? 'fa-user-nurse' : 
                                   ($pers['role'] === 'admin' ? 'fa-user-shield' : 'fa-user-tie')) ?>">
                            </i>
                            <div class="info-content">
                                <h3><?= htmlspecialchars($pers['prenom'] . ' ' . $pers['nom']) ?></h3>
                                <p>
                                    <span class="role-badge role-<?= $pers['role'] ?>">
                                        <?= strtoupper($pers['role']) ?>
                                    </span>
                                    <?php if (!empty($pers['specialite'])): ?>
                                        <br><small><?= htmlspecialchars($pers['specialite']) ?></small>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function openTab(evt, tabName) {
            // Masquer tous les contenus d'onglets
            const tabContents = document.getElementsByClassName("tab-content");
            for (let i = 0; i < tabContents.length; i++) {
                tabContents[i].classList.remove("active");
            }
            
            // Désactiver tous les boutons d'onglets
            const tabButtons = document.getElementsByClassName("tab-btn");
            for (let i = 0; i < tabButtons.length; i++) {
                tabButtons[i].classList.remove("active");
            }
            
            // Afficher l'onglet actuel
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
            
            // Stocker l'onglet actif dans localStorage
            localStorage.setItem('lastActiveTab', tabName);
        }
        
        // Par défaut, ouvrir le premier onglet ou le dernier onglet actif
        document.addEventListener('DOMContentLoaded', function() {
            const lastActiveTab = localStorage.getItem('lastActiveTab');
            if (lastActiveTab) {
                document.getElementById(lastActiveTab).classList.add("active");
                document.querySelector(`.tab-btn[onclick*="${lastActiveTab}"]`).classList.add("active");
            } else {
                document.querySelector('.tab-btn').click();
            }
        });
        
        function annulerRdv(rdvId) {
            if (confirm('Êtes-vous sûr de vouloir annuler ce rendez-vous ?')) {
                const raison = prompt('Raison de l\'annulation :');
                if (raison !== null) {
                    // Envoyer la requête d'annulation
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.innerHTML = `
                        <input type="hidden" name="action" value="annuler_rdv">
                        <input type="hidden" name="rdv_id" value="${rdvId}">
                        <input type="hidden" name="raison_annulation" value="${raison}">
                    `;
                    document.body.appendChild(form);
                    form.submit();
                }
            }
        }
    </script>
</body>
</html>