<?php
session_start();
require_once "db.php";

// Activation du débogage
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Vérification rôle médecin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'medecin') {
    header("Location: auth.php");
    exit;
}

// 🔹 Extraction de l'ID médecin
$medecinID = intval($_SESSION['user_id']);

// 🔹 Sécurisation des données entrantes
function secure($data) {
    return htmlspecialchars(trim($data));
}

// 🔹 Gestion des actions sur les rendez-vous
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_rdv']) && isset($_POST['rdv_id'])) {
    $rdv_id = (int)$_POST['rdv_id'];
    $action = secure($_POST['action_rdv']);

    try {
        switch ($action) {
            case 'accepter':
                $stmt = $pdoMedical->prepare("UPDATE rendez_vous SET 
                    medecin_id = ?, 
                    statut = 'confirmé',
                    updated_at = NOW()
                    WHERE id = ?");
                $stmt->execute([$medecinID, $rdv_id]);
                $_SESSION['message'] = "✅ Rendez-vous confirmé avec succès!";
                break;

            case 'rejeter':
                $motif_rejet = isset($_POST['motif_rejet']) ? secure($_POST['motif_rejet']) : 'Non spécifié';
                $stmt = $pdoMedical->prepare("UPDATE rendez_vous SET 
                    statut = 'rejeté',
                    motif_rejet = ?,
                    date_rejet = NOW()
                    WHERE id = ?");
                $stmt->execute([$motif_rejet, $rdv_id]);
                $_SESSION['message'] = "⛔ Rendez-vous rejeté.";
                break;

            case 'terminer':
                $diagnostic = secure($_POST['diagnostic']);
                $prescription = secure($_POST['prescription']);
                $stmt = $pdoMedical->prepare("UPDATE rendez_vous SET 
                    statut = 'terminé',
                    orientation_medecin = ?, 
                    recommandations_medecin = ?, 
                    updated_at = NOW()
                    WHERE id = ? AND medecin_id = ?");
                $stmt->execute([$diagnostic, $prescription, $rdv_id, $medecinID]);
                $_SESSION['message'] = "🔹 Consultation terminée!";
                break;
        }

        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
        
    } catch (PDOException $e) {
        error_log("❌ Erreur SQL : " . $e->getMessage());
        $error = "Erreur lors du traitement: " . $e->getMessage();
    }
}

// 🔹 Requête unifiée pour récupérer les rendez-vous
$rdvsQuery = $pdoMedical->prepare("
    SELECT 
        r.id, r.date_rdv, r.type_rdv, r.statut, r.medecin_id, r.infirmier_id, 
        r.recommandations_medecin, r.diagnostic_infirmier, 
        u.id AS patient_id, u.nom AS patient_nom, u.image AS patient_image,
        m.nom AS medecin_nom, i.nom AS infirmier_nom, 
        p.groupe_sanguin, p.allergies,
        CASE
            WHEN r.infirmier_id IS NOT NULL THEN 'Référence infirmière'
            ELSE 'Consultation médicale'
        END AS source_rdv,
        CASE
            WHEN r.statut = 'en attente' AND r.medecin_id IS NULL THEN '⚠ À valider'
            ELSE r.statut
        END AS statut_affichage
    FROM rendez_vous r
    JOIN utilisateurs u ON r.patient_id = u.id
    LEFT JOIN utilisateurs m ON r.medecin_id = m.id
    LEFT JOIN utilisateurs i ON r.infirmier_id = i.id
    LEFT JOIN patients p ON r.patient_id = p.user_id
    WHERE (r.medecin_id = ? OR r.infirmier_id IS NOT NULL)
    ORDER BY 
        CASE r.statut
            WHEN 'en attente' THEN 0
            WHEN 'confirmé' THEN 1
            WHEN 'terminé' THEN 2
            ELSE 3
        END,
        r.date_rdv DESC
");
$rdvsQuery->execute([$medecinID]);
$allRdvs = $rdvsQuery->fetchAll(PDO::FETCH_ASSOC);

// 🔹 Séparation des RDV pour affichage
$rdvEnAttente = array_filter($allRdvs, fn($rdv) => $rdv['statut'] === 'en attente' && $rdv['medecin_id'] != $medecinID);
$rdvConfirmes = array_filter($allRdvs, fn($rdv) => $rdv['statut'] === 'confirmé' && $rdv['medecin_id'] == $medecinID);
$rdvTermines = array_filter($allRdvs, fn($rdv) => $rdv['statut'] === 'terminé' && $rdv['medecin_id'] == $medecinID);

?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendrier Médical</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .calendar-header {
            background-color: #0d6efd;
            color: white;
            border-radius: 0.5rem 0.5rem 0 0;
        }
        .rdv-card {
            transition: all 0.3s ease;
            border-left: 4px solid #0d6efd;
            margin-bottom: 20px;
        }
        .rdv-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .rdv-confirme { border-left-color: #198754; }
        .rdv-rejete { border-left-color: #dc3545; }
        .rdv-attente { border-left-color: #ffc107; }
        .rdv-termine { border-left-color: #6f42c1; }
        .rdv-direct { border-left-color: #17a2b8; }
        .patient-badge {
            background-color: #e9ecef;
            color: #495057;
        }
        .time-badge {
            background-color: #0d6efd;
            color: white;
        }
        .modal-header {
            background-color: #0d6efd;
            color: white;
        }
        .nav-pills .nav-link.active {
            background-color: #0d6efd;
        }
        .patient-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        .diagnostic-area {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 10px;
            margin-top: 10px;
        }
        .source-badge {
            font-size: 0.75rem;
            margin-left: 5px;
        }
        .badge-reference {
            background-color: #6c757d;
        }
        .badge-direct {
            background-color: #17a2b8;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="bi bi-calendar-check"></i> Calendrier Médical</a>
        </div>
    </nav>

    <div class="container">
        <!-- Messages de notification -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $_SESSION['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <ul class="nav nav-pills mb-4" id="rdvTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="attente-tab" data-bs-toggle="pill" data-bs-target="#attente" type="button">
                    En attente <span class="badge bg-warning"><?= count($rdvEnAttente) ?></span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="confirmes-tab" data-bs-toggle="pill" data-bs-target="#confirmes" type="button">
                    Confirmés <span class="badge bg-success"><?= count($rdvConfirmes) ?></span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="termines-tab" data-bs-toggle="pill" data-bs-target="#termines" type="button">
                    Terminés <span class="badge bg-secondary"><?= count($rdvTermines) ?></span>
                </button>
            </li>
        </ul>

        <div class="tab-content" id="rdvTabsContent">
            <!-- Onglet RDV en attente -->
            <div class="tab-pane fade show active" id="attente" role="tabpanel">
                <?php if (empty($rdvEnAttente)): ?>
                    <div class="alert alert-info">Aucun rendez-vous en attente de confirmation.</div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($rdvEnAttente as $rdv): ?>
                            <div class="col-md-6">
                                <div class="card rdv-card <?= $rdv['infirmier_id'] ? 'rdv-attente' : 'rdv-direct' ?>">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <div class="d-flex align-items-center">
                                                <?php if (!empty($rdv['patient_image'])): ?>
                                                    <img src="uploads/<?= $rdv['patient_image'] ?>" class="patient-img" alt="<?= $rdv['patient_nom'] ?>">
                                                <?php else: ?>
                                                    <div class="patient-img bg-light d-flex align-items-center justify-content-center">
                                                        <i class="bi bi-person-fill"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div>
                                                    <h5 class="mb-0"><?= $rdv['patient_nom'] ?> <?= $rdv['patient_prenom'] ?>
                                                        <span class="badge badge-source <?= $rdv['infirmier_id'] ? 'badge-reference' : 'badge-direct' ?>">
                                                            <?= $rdv['source_rdv'] ?>
                                                        </span>
                                                    </h5>
                                                    <?php if ($rdv['infirmier_nom']): ?>
                                                        <small class="text-muted">
                                                            Référé par: <?= $rdv['infirmier_prenom'] ?> <?= $rdv['infirmier_nom'] ?>
                                                        </small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <span class="badge bg-warning"><?= $rdv['statut_affichage'] ?></span>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between mt-3">
                                            <span class="badge time-badge rounded-pill">
                                                <i class="bi bi-clock"></i> <?= date('d/m/Y H:i', strtotime($rdv['date_rdv'])) ?>
                                            </span>
                                            <span class="badge bg-light text-dark">
                                                <?= $rdv['type_rdv'] ?>
                                            </span>
                                        </div>
                                        
                                        <?php if (!empty($rdv['diagnostic_infirmier'])): ?>
                                            <div class="diagnostic-area mt-3">
                                                <h6><i class="bi bi-clipboard2-pulse"></i> Diagnostic infirmier:</h6>
                                                <p><?= nl2br($rdv['diagnostic_infirmier']) ?></p>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <div class="action-buttons mt-3">
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="rdv_id" value="<?= $rdv['id'] ?>">
                                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                <button type="submit" name="action_rdv" value="accepter" class="btn btn-success btn-sm">
                                                    <i class="bi bi-check-circle"></i> Accepter
                                                </button>
                                            </form>
                                            
                                            <button class="btn btn-danger btn-sm" data-bs-toggle="modal" 
                                                data-bs-target="#rejetModal" data-rdv-id="<?= $rdv['id'] ?>">
                                                <i class="bi bi-x-circle"></i> Rejeter
                                            </button>
                                            
                                            <a href="dossier_patient.php?id=<?= $rdv['patient_id'] ?>" class="btn btn-info btn-sm">
                                                <i class="bi bi-file-earmark-medical"></i> Dossier
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Onglet RDV confirmés -->
            <div class="tab-pane fade" id="confirmes" role="tabpanel">
                <?php if (empty($rdvConfirmes)): ?>
                    <div class="alert alert-info">Aucun rendez-vous confirmé à venir.</div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($rdvConfirmes as $rdv): ?>
                            <div class="col-md-6">
                                <div class="card rdv-card rdv-confirme">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <div class="d-flex align-items-center">
                                                <?php if (!empty($rdv['patient_image'])): ?>
                                                    <img src="uploads/<?= $rdv['patient_image'] ?>" class="patient-img" alt="<?= $rdv['patient_nom'] ?>">
                                                <?php else: ?>
                                                    <div class="patient-img bg-light d-flex align-items-center justify-content-center">
                                                        <i class="bi bi-person-fill"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div>
                                                    <h5 class="mb-0"><?= $rdv['patient_nom'] ?> <?= $rdv['patient_prenom'] ?></h5>
                                                    <small class="text-muted">
                                                        <?= $rdv['source_rdv'] ?>
                                                    </small>
                                                </div>
                                            </div>
                                            <span class="badge bg-success">Confirmé</span>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between mt-3">
                                            <span class="badge time-badge rounded-pill">
                                                <i class="bi bi-clock"></i> <?= date('d/m/Y H:i', strtotime($rdv['date_rdv'])) ?>
                                            </span>
                                            <span class="badge bg-light text-dark">
                                                <?= $rdv['type_rdv'] ?>
                                            </span>
                                        </div>
                                        
                                        <div class="action-buttons mt-3">
                                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" 
                                                data-bs-target="#terminerModal" 
                                                data-rdv-id="<?= $rdv['id'] ?>"
                                                data-patient-nom="<?= $rdv['patient_nom'] ?> <?= $rdv['patient_prenom'] ?>">
                                                <i class="bi bi-check2-all"></i> Terminer consultation
                                            </button>
                                            
                                            <a href="dossier_patient.php?id=<?= $rdv['patient_id'] ?>" class="btn btn-info btn-sm">
                                                <i class="bi bi-file-earmark-medical"></i> Dossier
                                            </a>
                                            
                                            <a href="#" class="btn btn-warning btn-sm">
                                                <i class="bi bi-calendar-x"></i> Reporter
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Onglet RDV terminés -->
            <div class="tab-pane fade" id="termines" role="tabpanel">
                <?php if (empty($rdvTermines)): ?>
                    <div class="alert alert-info">Aucune consultation terminée récemment.</div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($rdvTermines as $rdv): ?>
                            <div class="col-md-6">
                                <div class="card rdv-card rdv-termine">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <div class="d-flex align-items-center">
                                                <?php if (!empty($rdv['patient_image'])): ?>
                                                    <img src="uploads/<?= $rdv['patient_image'] ?>" class="patient-img" alt="<?= $rdv['patient_nom'] ?>">
                                                <?php else: ?>
                                                    <div class="patient-img bg-light d-flex align-items-center justify-content-center">
                                                        <i class="bi bi-person-fill"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <div>
                                                    <h5 class="mb-0"><?= $rdv['patient_nom'] ?> <?= $rdv['patient_prenom'] ?></h5>
                                                    <small class="text-muted">
                                                        Consultation le <?= date('d/m/Y', strtotime($rdv['updated_at'])) ?>
                                                    </small>
                                                </div>
                                            </div>
                                            <span class="badge bg-secondary">Terminé</span>
                                        </div>
                                        
                                        <div class="diagnostic-area mt-3">
                                            <h6><i class="bi bi-clipboard2-pulse"></i> Diagnostic:</h6>
                                            <p><?= !empty($rdv['orientation_medecin']) ? nl2br($rdv['orientation_medecin']) : 'Non renseigné' ?></p>
                                            
                                            <h6 class="mt-2"><i class="bi bi-capsule"></i> Prescription:</h6>
                                            <p><?= !empty($rdv['recommandations_medecin']) ? nl2br($rdv['recommandations_medecin']) : 'Aucune' ?></p>
                                        </div>
                                        
                                        <div class="action-buttons mt-3">
                                            <a href="dossier_patient.php?id=<?= $rdv['patient_id'] ?>" class="btn btn-info btn-sm">
                                                <i class="bi bi-file-earmark-medical"></i> Dossier
                                            </a>
                                            
                                            <a href="certificat.php?rdv_id=<?= $rdv['id'] ?>" class="btn btn-secondary btn-sm">
                                                <i class="bi bi-file-earmark-text"></i> Certificat
                                            </a>
                                            
                                            <a href="#" class="btn btn-primary btn-sm">
                                                <i class="bi bi-calendar-plus"></i> Nouveau RDV
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal pour rejet de RDV -->
    <div class="modal fade" id="rejetModal" tabindex="-1" aria-labelledby="rejetModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title" id="rejetModalLabel">Rejet du rendez-vous</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="rdv_id" id="rejetRdvId">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="action_rdv" value="rejeter">
                        
                        <div class="mb-3">
                            <label for="motif_rejet" class="form-label">Motif du rejet</label>
                            <textarea class="form-control" id="motif_rejet" name="motif_rejet" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-danger">Confirmer le rejet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal pour terminer consultation -->
    <div class="modal fade" id="terminerModal" tabindex="-1" aria-labelledby="terminerModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="terminerModalLabel">Terminer la consultation</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="rdv_id" id="terminerRdvId">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="action_rdv" value="terminer">
                        
                        <div class="mb-3">
                            <h6>Patient: <span id="patientNomTerminer" class="fw-bold"></span></h6>
                        </div>
                        
                        <div class="mb-3">
                            <label for="diagnostic" class="form-label">Diagnostic médical *</label>
                            <textarea class="form-control" id="diagnostic" name="diagnostic" rows="5" required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="prescription" class="form-label">Prescription</label>
                            <textarea class="form-control" id="prescription" name="prescription" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Demande Avis Infirmier -->
    <div class="modal fade" id="demanderInfirmierModal" tabindex="-1" aria-labelledby="demanderInfirmierModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="demander_avis_infirmier.php">
                    <div class="modal-header bg-warning text-dark">
                        <h5 class="modal-title" id="demanderInfirmierModalLabel">Demande d'avis infirmier</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="rdv_id" id="demanderInfirmierRdvId">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        
                        <div class="mb-3">
                            <label for="infirmier_id" class="form-label">Infirmier *</label>
                            <select class="form-select" id="infirmier_id" name="infirmier_id" required>
                                <option value="">Sélectionner un infirmier</option>
                                <?php foreach ($infirmiers as $infirmier): ?>
                                    <option value="<?= $infirmier['id'] ?>">
                                        <?= $infirmier['prenom'] ?> <?= $infirmier['nom'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="motif_avis" class="form-label">Motif de la demande *</label>
                            <textarea class="form-control" id="motif_avis" name="motif_avis" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-warning">Envoyer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Gestion des modals
        document.addEventListener('DOMContentLoaded', function() {
            // Modal de rejet
            const rejetModal = document.getElementById('rejetModal');
            if (rejetModal) {
                rejetModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    document.getElementById('rejetRdvId').value = button.getAttribute('data-rdv-id');
                });
            }
            
            // Modal terminer consultation
            const terminerModal = document.getElementById('terminerModal');
            if (terminerModal) {
                terminerModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    document.getElementById('terminerRdvId').value = button.getAttribute('data-rdv-id');
                    document.getElementById('patientNomTerminer').textContent = button.getAttribute('data-patient-nom');
                });
            }
            
            // Modal demande avis infirmier
            const demanderInfirmierModal = document.getElementById('demanderInfirmierModal');
            if (demanderInfirmierModal) {
                demanderInfirmierModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    document.getElementById('demanderInfirmierRdvId').value = button.getAttribute('data-rdv-id');
                });
            }
            
            // Gestion des onglets dans l'URL
            if (window.location.hash) {
                const tabTrigger = document.querySelector(`[data-bs-target="${window.location.hash}"]`);
                if (tabTrigger) {
                    new bootstrap.Tab(tabTrigger).show();
                }
            }
            
            // Mise à jour de l'URL lors du changement d'onglet
            document.getElementById('rdvTabs').addEventListener('click', function(e) {
                if (e.target.classList.contains('nav-link')) {
                    window.location.hash = e.target.getAttribute('data-bs-target');
                }
            });
        });
    </script>
</body>
</html>