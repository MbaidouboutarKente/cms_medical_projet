<?php
session_start();
include "../config/db.php";

// 🔹 Vérifier que l'utilisateur est connecté
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'etudiant') {
    die("🔴 Accès refusé.");
}

session_regenerate_id(true);

// 🔹 Récupérer l'email de l'utilisateur depuis la session
$userEmail = $_SESSION['email'] ?? null;

if (!$userEmail) {
    die("🔴 Erreur : Email utilisateur non défini.");
}

// 🔹 Récupération des infos académiques avec l'email
$queryEtudiant = $pdoCampus->prepare("SELECT * FROM etudiants WHERE email = ?");
$queryEtudiant->execute([$userEmail]);
$etudiantData = $queryEtudiant->fetch();

if (!$etudiantData) {
    die("🔴 Erreur : Aucun étudiant trouvé avec cet email.");
}

// 🔹 Détermination de l'année scolaire actuelle
$anneeActuelle = date("Y");
$moisActuel = date("m");
$anneeScolaire = ($moisActuel >= 9) ? "$anneeActuelle-" . ($anneeActuelle + 1) : ($anneeActuelle - 1) . "-$anneeActuelle";

// 🔍 Vérification des paiements effectués pour CETTE année scolaire
$queryPayment = $pdoMedical->prepare("
    SELECT montant, statut, date_paiement FROM paiements 
    WHERE utilisateur_id = ? AND annee_scolaire = ? AND statut = 'payé'
");
$queryPayment->execute([intval(str_replace("MED_", "", $_SESSION['user_id'])), $anneeScolaire]);
$paiementData = $queryPayment->fetch();

// 🔹 Si le paiement a été effectué pour CETTE année, redirection vers le tableau de bord
if ($paiementData) {
    header("Location: dashboard_etudiant.php");
    exit;
}

// 🔍 Vérification des paiements des ANNÉES PRÉCÉDENTES pour déterminer le statut
$queryAncienPaiement = $pdoMedical->prepare("
    SELECT COUNT(*) as nb_paiements_anterieurs 
    FROM paiements 
    WHERE utilisateur_id = ? 
    AND annee_scolaire != ? 
    AND statut = 'payé'
    AND annee_scolaire < ?
");
$queryAncienPaiement->execute([
    intval(str_replace("MED_", "", $_SESSION['user_id'])),
    $anneeScolaire,
    $anneeScolaire
]);
$ancienPaiement = $queryAncienPaiement->fetch();

// 🔹 Détermination du statut réel de l'étudiant
$estNouveauReel = true; // Par défaut, considéré comme nouveau

// Si l'étudiant a déjà payé au moins une fois dans une année précédente, il n'est pas nouveau
if ($ancienPaiement && $ancienPaiement['nb_paiements_anterieurs'] > 0) {
    $estNouveauReel = false;
}

// 🔹 Vérification stricte du montant à payer basé sur le statut RÉEL
$montantCMS = $estNouveauReel ? 5000 : 3000;

// 🔹 Gestion du paiement
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Vérifier d'abord si un enregistrement existe déjà (au cas où)
        $checkExisting = $pdoMedical->prepare("
            SELECT id FROM paiements 
            WHERE utilisateur_id = ? AND annee_scolaire = ?
        ");
        $checkExisting->execute([intval(str_replace("MED_", "", $_SESSION['user_id'])), $anneeScolaire]);
        $existingPayment = $checkExisting->fetch();

        if ($existingPayment) {
            // Mettre à jour le paiement existant
            $queryUpdatePaiement = $pdoMedical->prepare("
                UPDATE paiements 
                SET montant = ?, statut = 'payé', date_paiement = NOW() 
                WHERE utilisateur_id = ? AND annee_scolaire = ?
            ");
            $success = $queryUpdatePaiement->execute([
                $montantCMS, 
                intval(str_replace("MED_", "", $_SESSION['user_id'])), 
                $anneeScolaire
            ]);
        } else {
            // Insérer un nouveau paiement
            $queryInsertPaiement = $pdoMedical->prepare("
                INSERT INTO paiements (utilisateur_id, montant, annee_scolaire, statut, date_paiement) 
                VALUES (?, ?, ?, 'payé', NOW())
            ");
            $success = $queryInsertPaiement->execute([
                intval(str_replace("MED_", "", $_SESSION['user_id'])), 
                $montantCMS, 
                $anneeScolaire
            ]);
        }

        if ($success) {
            $_SESSION['paiement_statut'] = 'payé';
            $_SESSION['montant_paye'] = $montantCMS;
            header("Location: dashboard_etudiant.php");
            exit;
        } else {
            $message = "🔴 Échec de l'enregistrement du paiement.";
        }
    } catch (PDOException $e) {
        $message = "🔴 Erreur SQL : " . $e->getMessage();
    }
}

// 🔹 Informations de debug (peut être retiré en production)
$debugInfo = [
    'statut_etudiant_bd' => $etudiantData['statut_etudiant'],
    'est_nouveau_reel' => $estNouveauReel ? 'OUI' : 'NON',
    'nb_paiements_anterieurs' => $ancienPaiement['nb_paiements_anterieurs'] ?? 0,
    'montant_calculé' => $montantCMS
];
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement CMS Médical</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-light: #6366f1;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --dark: #1f2937;
            --light: #f9fafb;
            --gray: #6b7280;
            --light-gray: #e5e7eb;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: #f3f4f6;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        header {
            text-align: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--light-gray);
        }
        
        h1 {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        h2 {
            font-size: 1.5rem;
            color: var(--dark);
            margin: 1.5rem 0 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .student-info {
            background-color: var(--light);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .info-item {
            margin-bottom: 0.5rem;
        }
        
        .info-item strong {
            color: var(--gray);
            display: block;
            font-weight: 500;
            margin-bottom: 0.25rem;
        }
        
        .payment-section {
            background-color: var(--light);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            text-align: center;
        }
        
        .amount {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary);
            margin: 1rem 0;
        }
        
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
            margin: 0.5rem 0;
        }
        
        .status-new {
            background-color: #fef3c7;
            color: #92400e;
            border: 1px solid #f59e0b;
        }
        
        .status-returning {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #10b981;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: white;
            border: none;
        }
        
        .btn-primary:hover {
            background-color: var(--success);
            transform: translateY(-2px);
        }
        
        .btn-secondary {
            background-color: white;
            color: var(--primary);
            border: 1px solid var(--primary);
        }
        
        .btn-secondary:hover {
            background-color: var(--light);
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .alert-success {
            background-color: #d1fae5;
            color: #065f46;
            border-left: 4px solid var(--success);
        }
        
        .alert-danger {
            background-color: #fee2e2;
            color: #991b1b;
            border-left: 4px solid var(--danger);
        }
        
        .alert-info {
            background-color: #dbeafe;
            color: #1e40af;
            border-left: 4px solid var(--primary);
        }
        
        .payment-status {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            font-size: 1.25rem;
            margin: 1rem 0;
        }
        
        .paid {
            color: var(--success);
        }
        
        .unpaid {
            color: var(--danger);
        }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--primary);
            text-decoration: none;
            margin-top: 1.5rem;
        }
        
        .back-link:hover {
            text-decoration: none;
        }
        
        .debug-info {
            background-color: #f3f4f6;
            padding: 1rem;
            border-radius: 8px;
            margin-top: 1rem;
            font-size: 0.8rem;
            color: var(--gray);
        }
        
        .tarif-explanation {
            background-color: #f0f9ff;
            padding: 1rem;
            border-radius: 8px;
            margin: 1rem 0;
            border-left: 4px solid var(--primary);
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 1rem;
                padding: 1.5rem;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-credit-card"></i> Paiement du CMS Médical</h1>
            <p>Gestion des paiements pour l'année scolaire <?php echo htmlspecialchars($anneeScolaire); ?></p>
        </header>
        
        <section class="student-info">
            <h2><i class="fas fa-user-graduate"></i> Informations Étudiant</h2>
            <div class="info-grid">
                <div class="info-item">
                    <strong>Nom complet</strong>
                    <?php echo htmlspecialchars($etudiantData['prenom'] . ' ' . $etudiantData['nom']); ?>
                </div>
                <div class="info-item">
                    <strong>Matricule</strong>
                    <?php echo htmlspecialchars($etudiantData['matricule']); ?>
                </div>
                <div class="info-item">
                    <strong>Email</strong>
                    <?php echo htmlspecialchars($etudiantData['email']); ?>
                </div>
                <div class="info-item">
                    <strong>Filière</strong>
                    <?php echo htmlspecialchars($etudiantData['filiere']); ?>
                </div>
                <div class="info-item">
                    <strong>Niveau</strong>
                    <?php echo htmlspecialchars($etudiantData['niveau']); ?>
                </div>
                <div class="info-item">
                    <strong>Statut académique</strong>
                    <?php echo htmlspecialchars($etudiantData['statut_etudiant']); ?>
                </div>
            </div>
            
            <!-- Affichage du statut de paiement réel -->
            <div style="margin-top: 1rem; text-align: center;">
                <?php if ($estNouveauReel): ?>
                    <div class="status-badge status-new">
                        <i class="fas fa-user-plus"></i>
                        Statut CMS : Nouveau étudiant
                    </div>
                <?php else: ?>
                    <div class="status-badge status-returning">
                        <i class="fas fa-user-check"></i>
                        Statut CMS : Étudiant récurrent
                    </div>
                <?php endif; ?>
            </div>
        </section>
        
        <section class="payment-section">
            <h2><i class="fas fa-money-bill-wave"></i> Détails du Paiement</h2>
            
            <?php if ($paiementData): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <p>Votre paiement a déjà été enregistré pour cette année scolaire.</p>
                </div>
                
                <div class="payment-status paid">
                    <i class="fas fa-check-circle"></i>
                    <span>Paiement confirmé</span>
                </div>
                
                <div class="info-grid">
                    <div class="info-item">
                        <strong>Montant payé</strong>
                        <?php echo htmlspecialchars($paiementData['montant']); ?> FCFA
                    </div>
                    <div class="info-item">
                        <strong>Date de paiement</strong>
                        <?php echo htmlspecialchars($paiementData['date_paiement']); ?>
                    </div>
                    <div class="info-item">
                        <strong>Statut</strong>
                        <?php echo htmlspecialchars($paiementData['statut']); ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Vous devez payer le CMS avant d'accéder aux informations médicales.</p>
                </div>
                
                <div class="payment-status unpaid">
                    <i class="fas fa-times-circle"></i>
                    <span>Paiement en attente</span>
                </div>
                
                <!-- Explication du tarif -->
                <div class="tarif-explanation">
                    <h3 style="font-size: 1.1rem; margin-bottom: 0.5rem;">
                        <i class="fas fa-info-circle"></i> Tarification CMS
                    </h3>
                    <p style="margin-bottom: 0.5rem;">
                        <strong>Nouveaux étudiants :</strong> 5 000 FCFA (première inscription CMS)
                    </p>
                    <p style="margin-bottom: 0;">
                        <strong>Étudiants récurrents :</strong> 3 000 FCFA (déjà payé au moins une fois)
                    </p>
                </div>
                
                <div class="amount">
                    <?php echo htmlspecialchars($montantCMS); ?> FCFA
                </div>
                
                <p style="color: var(--gray); margin-bottom: 1.5rem;">
                    <i class="fas fa-shield-alt"></i> Paiement sécurisé
                </p>
                
                <form method="POST">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-credit-card"></i> Payer maintenant
                    </button>
                </form>
                
                <?php if (!empty($message)): ?>
                    <div class="alert alert-danger" style="margin-top: 1rem;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </section>
        
        <!-- Debug info (à retirer en production) -->
        <div class="debug-info">
            <strong>Informations de debug :</strong><br>
            Statut BD: <?php echo $debugInfo['statut_etudiant_bd']; ?> | 
            Nouveau réel: <?php echo $debugInfo['est_nouveau_reel']; ?> | 
            Paiements antérieurs: <?php echo $debugInfo['nb_paiements_anterieurs']; ?> | 
            Montant: <?php echo $debugInfo['montant_calculé']; ?> FCFA
        </div>
        
        <a href="dashboard_etudiant.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Retour au tableau de bord
        </a>
    </div>
</body>
</html>