<?php
session_start();
require_once "../config/db.php";

// Activation du debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Vérification authentification
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'etudiant') {
    header("Location: ../config/auth.php");
    exit;
}

// Sécurité
session_regenerate_id(true);

// Récupération données utilisateur
$userID = filter_var(str_replace("MED_", "", $_SESSION['user_id']), FILTER_SANITIZE_NUMBER_INT);

try {
    // Récupération profil de base
    $queryUser = $pdoMedical->prepare("SELECT u.*, e.* 
                                        FROM medical_db.utilisateurs u
                                        JOIN campus_db.etudiants e ON u.matricule = e.matricule
                                        WHERE u.id = ?");

    $queryUser->execute([$userID]);
    $userData = $queryUser->fetch();

    if (!$userData) throw new Exception("Profil introuvable");

    // Détermination année scolaire (Septembre-Août)
    $moisActuel = date("m");
    $anneeScolaire = ($moisActuel >= 9) ? date("Y")."-".(date("Y")+1) : (date("Y")-1)."-".date("Y");

    // Vérification paiement avec gestion des erreurs
    $paiementStatut = 'non payé';
    $queryPayment = $pdoMedical->prepare("SELECT statut FROM paiements 
                                        WHERE utilisateur_id = ? AND annee_scolaire = ? 
                                        ORDER BY date_paiement DESC LIMIT 1");
    if ($queryPayment->execute([$userID, $anneeScolaire])) {
        $paiementStatut = strtolower(trim($queryPayment->fetchColumn() ?? 'non payé'));
    }

    $accesServices = in_array($paiementStatut, ['payé', 'paye', 'paid', 'validé']);

    // Récupération RDV à venir si accès autorisé
    $rdvAVenir = [];
    if ($accesServices) {
        $queryRdv = $pdoMedical->prepare("SELECT r.*, COALESCE(m.nom, i.nom) AS professionnel_nom,
                CASE WHEN r.medecin_id IS NOT NULL THEN 'Médecin' ELSE 'Infirmier' END AS professionnel_type
            FROM rendez_vous r
            LEFT JOIN utilisateurs m ON r.medecin_id = m.id
            LEFT JOIN utilisateurs i ON r.infirmier_id = i.id
            WHERE r.patient_id = ? AND r.statut = 'En attente'
            ORDER BY r.date_rdv DESC
        LIMIT 3");
                                        
        $queryRdv->execute([$userID]);
        $rdvAVenir = $queryRdv->fetchAll();
    }

    // Récupération de l'historique des consultations (toujours accessible)
    $historiqueConsultations = [];
    $queryHistorique = $pdoMedical->prepare("
        SELECT 
            c.*,
            r.date_rdv,
            r.type_rdv,
            r.statut,
            m.prenom AS medecin_prenom,
            m.nom AS medecin_nom,
            m.specialite AS medecin_specialite
        FROM consultations c
        JOIN rendez_vous r ON c.rendez_vous_id = r.id
        JOIN utilisateurs m ON r.medecin_id = m.id
        WHERE r.patient_id = ? AND r.statut = 'Terminé'
        ORDER BY r.date_rdv DESC
        LIMIT 5
    ");
    
    $queryHistorique->execute([$userID]);
    $historiqueConsultations = $queryHistorique->fetchAll();

    // Statistiques de l'historique
    $statsHistorique = [
        'total_consultations' => count($historiqueConsultations),
        'consultations_annee' => 0
    ];

    // Compter les consultations de l'année en cours
    $anneeEnCours = date('Y');
    foreach ($historiqueConsultations as $consult) {
        if (date('Y', strtotime($consult['date_rdv'])) == $anneeEnCours) {
            $statsHistorique['consultations_annee']++;
        }
    }

} catch (PDOException $e) {
    die("Erreur base de données: " . $e->getMessage());
} catch (Exception $e) {
    die($e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord - <?= htmlspecialchars($userData['prenom']) ?> | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #3498db;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        /* Header */
        .dashboard-header {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 2rem;
            position: relative;
            overflow: hidden;
        }

        .dashboard-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .welcome-text h1 {
            color: var(--primary);
            font-size: 2.2rem;
            margin-bottom: 0.5rem;
        }

        .welcome-text p {
            color: var(--gray);
            font-size: 1.1rem;
        }

        .profile-container {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .profile-picture {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            overflow: hidden;
            border: 3px solid var(--primary);
            box-shadow: var(--shadow);
        }

        .profile-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profile-info .profile-role {
            color: var(--gray);
            font-size: 0.9rem;
        }

        .profile-info .profile-role:first-child {
            color: var(--dark);
            font-size: 1.1rem;
            font-weight: 600;
        }

        /* Layout */
        .row {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        @media (max-width: 1024px) {
            .row {
                grid-template-columns: 1fr;
            }
        }

        /* Cards */
        .card {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--white);
            padding: 1.5rem;
            font-size: 1.2rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .card-body {
            padding: 2rem;
        }

        /* Profile Info */
        .profile-info {
            list-style: none;
        }

        .profile-info li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--light-gray);
        }

        .profile-info li:last-child {
            border-bottom: none;
        }

        .info-label {
            font-weight: 600;
            color: var(--primary);
        }

        /* Alerts */
        .alert {
            padding: 1.5rem;
            border-radius: var(--radius);
            margin-bottom: 1rem;
            text-align: center;
        }

        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            border: 1px solid var(--success);
            color: var(--success);
        }

        .alert-warning {
            background: rgba(243, 156, 18, 0.1);
            border: 1px solid var(--warning);
            color: var(--warning);
        }

        .alert-info {
            background: rgba(52, 152, 219, 0.1);
            border: 1px solid var(--info);
            color: var(--info);
        }

        .alert h3 {
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            background-color: var(--primary);
            color: var(--white);
        }

        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.2);
        }

        .btn-block {
            width: 100%;
            margin-top: 1rem;
        }

        .btn-primary {
            background: var(--primary);
        }

        .btn-success {
            background: var(--success);
        }

        .btn-warning {
            background: var(--warning);
        }

        .btn-info {
            background: var(--info);
        }

        /* Table */
        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1rem;
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--light-gray);
        }

        th {
            background: var(--light-gray);
            font-weight: 600;
            color: var(--primary);
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
        }

        tr:hover {
            background: var(--light-gray);
        }

        /* Services Grid */
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }

        .service-card {
            background: var(--light-gray);
            padding: 2rem;
            border-radius: var(--radius);
            text-align: center;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .service-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary);
            box-shadow: var(--shadow);
        }

        .service-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .service-card h3 {
            color: var(--primary);
            margin-bottom: 0.5rem;
            font-size: 1.2rem;
        }

        .service-card p {
            color: var(--gray);
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }

        /* Footer */
        .footer {
            background: var(--white);
            border-radius: var(--radius);
            padding: 1.5rem 2rem;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: center;
            gap: 2rem;
            flex-wrap: wrap;
        }

        .footer a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .footer a:hover {
            color: var(--primary-dark);
        }

        /* Empty States */
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }

        /* Status Badges */
        .status-badge {
            display: inline-block;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-paid {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
            border: 1px solid var(--success);
        }

        .status-pending {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
            border: 1px solid var(--warning);
        }

        .status-info {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
            border: 1px solid var(--info);
        }

        /* Historique Section */
        .historique-item {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border-left: 4px solid var(--info);
            transition: all 0.3s ease;
        }

        .historique-item:hover {
            transform: translateX(5px);
            box-shadow: var(--shadow);
        }

        .historique-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .historique-date {
            font-weight: 600;
            color: var(--primary);
        }

        .historique-medecin {
            color: var(--gray);
        }

        .historique-content {
            margin-top: 1rem;
        }

        .content-section {
            margin-bottom: 1rem;
        }

        .content-section h4 {
            color: var(--primary);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        /* Quick Actions */
        .quick-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }

        .btn-small {
            padding: 0.5rem 1rem;
            font-size: 0.8rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 1rem 0.5rem;
            }
            
            .dashboard-header {
                flex-direction: column;
                text-align: center;
            }
            
            .profile-container {
                flex-direction: column;
            }
            
            .welcome-text h1 {
                font-size: 1.8rem;
            }
            
            .services-grid {
                grid-template-columns: 1fr;
            }
            
            .footer {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            table {
                font-size: 0.8rem;
            }
            
            th, td {
                padding: 0.5rem;
            }
            
            .quick-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card {
            animation: fadeIn 0.6s ease;
        }

        .service-card {
            animation: fadeIn 0.6s ease;
        }

        /* Access Restricted */
        .access-restricted {
            opacity: 0.6;
            position: relative;
        }

        .access-restricted::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--danger);
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- En-tête -->
        <div class="dashboard-header">
            <div class="welcome-text">
                <h1><i class="fas fa-heartbeat"></i> Bienvenue, <?= htmlspecialchars($userData['prenom']) ?> !</h1>
                <p>Année scolaire <?= htmlspecialchars($anneeScolaire) ?></p>
            </div>
            
            <div class="profile-container">
                <div class="profile-picture">
                    <img src="<?= !empty($userData['image']) ? '../../img/uploads/' . htmlspecialchars($userData['image']) : '../../img/default-avatar.png' ?>" 
                         alt="Photo de profil" 
                         class="profile-img"
                         onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iNDAiIGN5PSI0MCIgcj0iNDAiIGZpbGw9IiMzYTdiZDUiLz4KPHN2ZyB4PSIyMCIgeT0iMjUiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgZmlsbD0id2hpdGUiPgo8cGF0aCBkPSJNNDAgMjVDNDYuMDggMjUgNTEgMjkuOTIgNTEgMzZDNTEgNDIuMDggNDYuMDggNDcgNDAgNDdDMzMuOTIgNDcgMjkgNDIuMDggMjkgMzZDMjkgMjkuOTIgMzMuOTIgMjUgNDAgMjVaTTQwIDEwQzQ0LjQyIDEwIDQ4IDEzLjU4IDQ4IDE4QzQ4IDIyLjQyIDQ0LjQyIDI2IDQwIDI2QzM1LjU4IDI2IDMyIDIyLjQyIDMyIDE4QzMyIDEzLjU4IDM1LjU4IDEwIDQwIDEwWiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cjwvc3ZnPg=='">
                </div>
                <div class="profile-info">
                    <p class="profile-role"><?= htmlspecialchars($userData['nom']) ?></p>
                    <p class="profile-role">
                        <i class="fas fa-user-graduate"></i>
                        <?= htmlspecialchars($userData['filiere']) ?> - <?= htmlspecialchars($userData['niveau']) ?>
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Colonne gauche -->
            <div class="col col-4">
                <!-- Carte Profil -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-id-card"></i> Mon Profil
                    </div>
                    <div class="card-body">
                        <ul class="profile-info">
                            <li>
                                <span class="info-label"><i class="fas fa-id-badge"></i> Matricule:</span>
                                <span><?= htmlspecialchars($userData['matricule']) ?></span>
                            </li>
                            <li>
                                <span class="info-label"><i class="fas fa-user"></i> Nom:</span>
                                <span><?= htmlspecialchars($userData['nom']) ?></span>
                            </li>
                            <li>
                                <span class="info-label"><i class="fas fa-user"></i> Prénom:</span>
                                <span><?= htmlspecialchars($userData['prenom']) ?></span>
                            </li>
                            <li>
                                <span class="info-label"><i class="fas fa-envelope"></i> Email:</span>
                                <span><?= htmlspecialchars($userData['email']) ?></span>
                            </li>
                            <li>
                                <span class="info-label"><i class="fas fa-graduation-cap"></i> Filière:</span>
                                <span><?= htmlspecialchars($userData['filiere']) ?></span>
                            </li>
                            <li>
                                <span class="info-label"><i class="fas fa-layer-group"></i> Niveau:</span>
                                <span><?= htmlspecialchars($userData['niveau']) ?></span>
                            </li>
                        </ul>
                        
                        <div class="quick-actions">
                            <a href="profil.php" class="btn btn-primary btn-small">
                                <i class="fas fa-edit"></i> Modifier
                            </a>
                            <a href="../dossiers/dossier_medical.php" class="btn btn-info btn-small">
                                <i class="fas fa-folder-medical"></i> Mon dossier
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Carte Paiement -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-credit-card"></i> Statut du Paiement
                    </div>
                    <div class="card-body">
                        <?php if ($accesServices): ?>
                            <div class="alert alert-success">
                                <h3><i class="fas fa-check-circle"></i> Paiement confirmé</h3>
                                <p>Vous avez accès à tous les services médicaux</p>
                                <span class="status-badge status-paid">Payé</span>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                <h3><i class="fas fa-exclamation-triangle"></i> Paiement en attente</h3>
                                <p>Accès limité aux services pour <?= htmlspecialchars($anneeScolaire) ?></p>
                                <span class="status-badge status-pending">En attente</span>
                                <a href="paiement.php" class="btn btn-warning btn-block">
                                    <i class="fas fa-credit-card"></i> Payer maintenant
                                </a>
                                <div class="alert alert-info" style="margin-top: 1rem; padding: 1rem;">
                                    <p><strong>Accès maintenu :</strong> Votre historique médical reste accessible</p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Historique Médical (Toujours accessible) -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-history"></i> Mon Historique Médical
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <h4><i class="fas fa-chart-bar"></i> Statistiques</h4>
                            <p><strong><?= $statsHistorique['total_consultations'] ?></strong> consultation(s) au total</p>
                            <p><strong><?= $statsHistorique['consultations_annee'] ?></strong> consultation(s) cette année</p>
                        </div>
                        
                        <a href="../dossiers/dossier_medical.php" class="btn btn-info btn-block">
                            <i class="fas fa-folder-open"></i> Voir mon dossier complet
                        </a>
                        
                        <a href="../rdv/liste_rdv.php" class="btn btn-primary btn-block" style="margin-top: 0.5rem;">
                            <i class="fas fa-list"></i> Historique des rendez-vous
                        </a>
                    </div>
                </div>
            </div>

            <!-- Colonne droite -->
            <div class="col col-8">
                <!-- RDV à venir (Seulement si paiement effectué) -->
                <?php if ($accesServices): ?>
                    <div class="card">
                        <div class="card-header">
                            <i class="fas fa-calendar-alt"></i> Mes prochains rendez-vous
                        </div>
                        <div class="card-body">
                            <?php if (!empty($rdvAVenir)): ?>
                                <div class="table-responsive">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Date et Heure</th>
                                                <th>Professionnel</th>
                                                <th>Type</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($rdvAVenir as $rdv): ?>
                                                <tr>
                                                    <td>
                                                        <i class="fas fa-calendar-day"></i>
                                                        <?= htmlspecialchars(date('d/m/Y à H:i', strtotime($rdv['date_rdv']))) ?>
                                                    </td>
                                                    <td>
                                                        <?= htmlspecialchars($rdv['professionnel_nom']) ?>
                                                        <br>
                                                        <small class="status-badge">
                                                            <?= htmlspecialchars($rdv['professionnel_type']) ?>
                                                        </small>
                                                    </td>
                                                    <td><?= htmlspecialchars(ucfirst($rdv['type_rdv'])) ?></td>
                                                    <td>
                                                        <a href="../rdv/details_rdv.php?id=<?= $rdv['id'] ?>" class="btn btn-primary btn-small">
                                                            <i class="fas fa-eye"></i> Détails
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div style="text-align: center; margin-top: 1.5rem;">
                                    <a href="../rdv/liste_rdv.php" class="btn btn-primary">
                                        <i class="fas fa-list"></i> Voir tous mes rendez-vous
                                    </a>
                                    <a href="../rdv/prendre_rdv.php" class="btn btn-success">
                                        <i class="fas fa-plus"></i> Nouveau rendez-vous
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="empty-state">
                                    <i class="fas fa-calendar-times"></i>
                                    <h3>Aucun rendez-vous à venir</h3>
                                    <p>Vous n'avez pas de rendez-vous programmé pour le moment.</p>
                                    <a href="../rdv/prendre_rdv.php" class="btn btn-primary">
                                        <i class="fas fa-plus"></i> Prendre un rendez-vous
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Message d'information si pas de paiement -->
                    <div class="card">
                        <div class="card-header">
                            <i class="fas fa-info-circle"></i> Accès aux Services
                        </div>
                        <div class="card-body">
                            <div class="alert alert-warning">
                                <h3><i class="fas fa-lock"></i> Services limités</h3>
                                <p>Le paiement de la contribution médicale pour <?= htmlspecialchars($anneeScolaire) ?> est requis pour :</p>
                                <ul style="text-align: left; margin: 1rem 0;">
                                    <li>Prendre de nouveaux rendez-vous</li>
                                    <li>Accéder à la pharmacie</li>
                                    <li>Demander des certificats médicaux</li>
                                    <li>Services d'urgence actuels</li>
                                </ul>
                                <p><strong>Votre historique médical reste entièrement accessible.</strong></p>
                                <a href="paiement.php" class="btn btn-warning">
                                    <i class="fas fa-credit-card"></i> Activer tous les services
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Services médicaux -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-medkit"></i> Services médicaux
                    </div>
                    <div class="card-body">
                        <div class="services-grid">
                            <!-- Services toujours accessibles -->
                            <div class="service-card">
                                <div class="service-icon"><i class="fas fa-folder-medical"></i></div>
                                <h3>Mon Dossier</h3>
                                <p>Consulter mon historique médical complet</p>
                                <a href="../dossiers/dossier_medical.php" class="btn btn-info">
                                    <i class="fas fa-folder-open"></i> Accéder
                                </a>
                            </div>

                            <div class="service-card">
                                <div class="service-icon"><i class="fas fa-history"></i></div>
                                <h3>Historique</h3>
                                <p>Voir mes consultations passées</p>
                                <a href="../consultations/mes_consultation.php" class="btn btn-info">
                                    <i class="fas fa-list"></i> Consulter
                                </a>
                            </div>

                            <div class="service-card">
                                <div class="service-icon"><i class="fas fa-file-medical"></i></div>
                                <h3>Résultats</h3>
                                <p>Consulter mes résultats d'analyses</p>
                                <a href="../consultations/resultats_analyses.php" class="btn btn-info">
                                    <i class="fas fa-file-medical-alt"></i> Consulter
                                </a>
                            </div>

                            <!-- Services conditionnels -->
                            <?php if ($accesServices): ?>
                                <div class="service-card">
                                    <div class="service-icon"><i class="fas fa-calendar-plus"></i></div>
                                    <h3>Prendre RDV</h3>
                                    <p>Nouveau rendez-vous médical</p>
                                    <a href="../rdv/prendre_rdv.php" class="btn btn-primary">
                                        <i class="fas fa-calendar-plus"></i> Accéder
                                    </a>
                                </div>
                                
                                <div class="service-card">
                                    <div class="service-icon"><i class="fas fa-prescription"></i></div>
                                    <h3>Pharmacie</h3>
                                    <p>Demander des médicaments</p>
                                    <a href="../pharmacie/pharmacie.php" class="btn btn-primary">
                                        <i class="fas fa-prescription"></i> Accéder
                                    </a>
                                </div>

                                <div class="service-card">
                                    <div class="service-icon"><i class="fas fa-file-certificate"></i></div>
                                    <h3>Certificats</h3>
                                    <p>Demander un certificat médical</p>
                                    <a href="../consultations/demande_certificat.php" class="btn btn-primary">
                                        <i class="fas fa-file-certificate"></i> Demander
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="service-card" style="opacity: 0.6;">
                                    <div class="service-icon"><i class="fas fa-calendar-plus"></i></div>
                                    <h3>Prendre RDV</h3>
                                    <p>Nouveau rendez-vous médical</p>
                                    <span class="status-badge status-pending">Paiement requis</span>
                                </div>
                                
                                <div class="service-card" style="opacity: 0.6;">
                                    <div class="service-icon"><i class="fas fa-prescription"></i></div>
                                    <h3>Pharmacie</h3>
                                    <p>Demander des médicaments</p>
                                    <span class="status-badge status-pending">Paiement requis</span>
                                </div>

                                <div class="service-card" style="opacity: 0.6;">
                                    <div class="service-icon"><i class="fas fa-file-certificate"></i></div>
                                    <h3>Certificats</h3>
                                    <p>Demander un certificat médical</p>
                                    <span class="status-badge status-pending">Paiement requis</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Dernières consultations (Toujours accessible) -->
                <?php if (!empty($historiqueConsultations)): ?>
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-file-medical-alt"></i> Dernières Consultations
                    </div>
                    <div class="card-body">
                        <?php foreach (array_slice($historiqueConsultations, 0, 3) as $consultation): ?>
                        <div class="historique-item">
                            <div class="historique-header">
                                <div>
                                    <div class="historique-date">
                                        <i class="fas fa-calendar-day"></i>
                                        <?= date('d/m/Y à H:i', strtotime($consultation['date_rdv'])) ?>
                                    </div>
                                    <div class="historique-medecin">
                                        <i class="fas fa-user-md"></i>
                                        Dr. <?= htmlspecialchars($consultation['medecin_prenom'] . ' ' . $consultation['medecin_nom']) ?>
                                    </div>
                                </div>
                                <span class="status-badge status-info">Terminé</span>
                            </div>
                            
                            <?php if (!empty($consultation['diagnostic'])): ?>
                            <div class="historique-content">
                                <div class="content-section">
                                    <h4><i class="fas fa-diagnoses"></i> Diagnostic</h4>
                                    <p><?= nl2br(htmlspecialchars(substr($consultation['diagnostic'], 0, 150))) ?>...
                                    </p>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($consultation['traitement'])): ?>
                                <div class="content-section">
                                    <h4><i class="fas fa-pills"></i> Traitement</h4>
                                    <p><?= nl2br(htmlspecialchars(substr($consultation['traitement'], 0, 150))) ?>...</p>
                                </div>
                            <?php endif; ?>
                            
                            <div style="text-align: right; margin-top: 1rem;">
                                <a href="../consultations/details_consultation.php?id=<?= $consultation['id'] ?>" class="btn btn-primary btn-small">
                                    <i class="fas fa-external-link-alt"></i> Voir les détails complets
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        
                        <div style="text-align: center; margin-top: 1.5rem;">
                            <a href="../consultations/historique_complet.php" class="btn btn-primary">
                                <i class="fas fa-history"></i> Voir tout l'historique
                            </a>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-file-medical-alt"></i> Historique des Consultations
                    </div>
                    <div class="card-body">
                        <div class="empty-state">
                            <i class="fas fa-file-medical"></i>
                            <h3>Aucune consultation enregistrée</h3>
                            <p>Votre historique de consultations apparaîtra ici.</p>
                            <a href="../rdv/prendre_rdv.php" class="btn btn-primary">
                                <i class="fas fa-calendar-plus"></i> Prendre un premier rendez-vous
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Pied de page -->
        <div class="footer">
            <a href="profil.php"><i class="fas fa-user-cog"></i> Mon profil</a>
            <a href="../dossiers/dossier_medical.php"><i class="fas fa-folder-medical"></i> Mon dossier</a>
            <a href="../assistance/aide.php"><i class="fas fa-question-circle"></i> Aide</a>
            <a href="logout.php" style="color: var(--danger);"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
        </div>
    </div>

    <script>
        // Animation au chargement
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.card');
            cards.forEach((card, index) => {
                card.style.animationDelay = (index * 0.1) + 's';
            });
        });

        // Notification pour nouveaux messages
        function checkNotifications() {
            // À implémenter avec WebSocket ou AJAX
            fetch('../api/check_notifications.php')
                .then(response => response.json())
                .then(data => {
                    if (data.unread > 0) {
                        showNotification(`Vous avez ${data.unread} nouveau(x) message(s)`);
                    }
                })
                .catch(error => console.error('Erreur notifications:', error));
        }

        function showNotification(message) {
            // Créer une notification toast
            const toast = document.createElement('div');
            toast.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: var(--primary);
                color: white;
                padding: 1rem 1.5rem;
                border-radius: var(--radius);
                box-shadow: var(--shadow);
                z-index: 1000;
                animation: slideIn 0.3s ease;
            `;
            toast.innerHTML = `
                <i class="fas fa-bell"></i> ${message}
            `;
            document.body.appendChild(toast);
            
            setTimeout(() => {
                toast.remove();
            }, 5000);
        }

        // Vérifier les notifications toutes les 30 secondes
        setInterval(checkNotifications, 30000);

        // Vérifier immédiatement au chargement
        checkNotifications();

        // Gestion des erreurs d'images de profil
        document.addEventListener('error', function(e) {
            if (e.target.classList.contains('profile-img')) {
                e.target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iNDAiIGN5PSI0MCIgcj0iNDAiIGZpbGw9IiMzYTdiZDUiLz4KPHN2ZyB4PSIyMCIgeT0iMjUiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgZmlsbD0id2hpdGUiPgo8cGF0aCBkPSJNNDAgMjVDNDYuMDggMjUgNTEgMjkuOTIgNTEgMzZDNTEgNDIuMDggNDYuMDggNDcgNDAgNDdDMzMuOTIgNDcgMjkgNDIuMDggMjkgMzZDMjkgMjkuOTIgMzMuOTIgMjUgNDAgMjVaTTQwIDEwQzQ0LjQyIDEwIDQ4IDEzLjU4IDQ4IDE4QzQ4IDIyLjQyIDQ0LjQyIDI2IDQwIDI2QzM1LjU4IDI2IDMyIDIyLjQyIDMyIDE4QzMyIDEzLjU4IDM1LjU4IDEwIDQwIDEwWiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cjwvc3ZnPg==';
            }
        }, true);
    </script>

    <style>
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .btn-small {
            padding: 0.5rem 1rem;
            font-size: 0.8rem;
        }
    </style>
</body>
</html>