<?php
session_start();
require_once "../config/db.php";

// Vérification de l'authentification
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'etudiant') {
    header("Location: ../config/auth.php");
    exit;
}

// Extraction de l'ID utilisateur selon le format
if (strpos($_SESSION['user_id'], 'MED_') === 0) {
    $userID = intval(str_replace("MED_", "", $_SESSION['user_id']));
} elseif (strpos($_SESSION['user_id'], 'ETU_') === 0) {
    $userID = intval(str_replace("ETU_", "", $_SESSION['user_id']));
} else {
    $userID = intval($_SESSION['user_id']);
}

// TRAITEMENT DU FORMULAIRE DE MODIFICATION
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_admin_data'])) {
    try {
        // Récupération et validation des données
        $telephone = !empty($_POST['telephone']) ? trim($_POST['telephone']) : null;
        $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
        $assurance_maladie = !empty($_POST['assurance_maladie']) ? trim($_POST['assurance_maladie']) : null;
        $numero_securite_sociale = !empty($_POST['numero_securite_sociale']) ? trim($_POST['numero_securite_sociale']) : null;
        $adresse = !empty($_POST['adresse']) ? trim($_POST['adresse']) : null;
        $ville = !empty($_POST['ville']) ? trim($_POST['ville']) : null;
        $code_postal = !empty($_POST['code_postal']) ? trim($_POST['code_postal']) : null;
        $pays = !empty($_POST['pays']) ? trim($_POST['pays']) : null;

        // Validation de base
        if (!$email) {
            throw new Exception("Adresse email invalide");
        }

        // Validation du numéro de sécurité sociale
        if ($numero_securite_sociale && !preg_match('/^[1-2]\s?\d{2}\s?\d{2}\s?\d{3}\s?\d{3}\s?\d{2}$/', $numero_securite_sociale)) {
            throw new Exception("Format du numéro de sécurité sociale invalide");
        }

        // Vérifier si l'email n'est pas déjà utilisé par un autre utilisateur
        $stmtCheckEmail = $pdoMedical->prepare("
            SELECT id FROM utilisateurs 
            WHERE email = ? AND id != ?
        ");
        $stmtCheckEmail->execute([$email, $userID]);
        
        if ($stmtCheckEmail->fetch()) {
            throw new Exception("Cette adresse email est déjà utilisée");
        }

        // Préparer la requête de mise à jour
        $updateFields = [];
        $params = [];

        // Champs de la table utilisateurs
        $utilisateurFields = [
            'telephone' => $telephone,
            'email' => $email,
            'adresse' => $adresse,
            'ville' => $ville,
            'code_postal' => $code_postal,
            'pays' => $pays
        ];

        foreach ($utilisateurFields as $field => $value) {
            $updateFields[] = "u.$field = ?";
            $params[] = $value;
        }

        // Vérifier si le patient existe
        $stmtPatient = $pdoMedical->prepare("SELECT id FROM patients WHERE utilisateur_id = ?");
        $stmtPatient->execute([$userID]);
        $patientExists = $stmtPatient->fetch();

        if ($patientExists) {
            // Mise à jour de la table patients
            $patientFields = [
                'assurance_maladie' => $assurance_maladie,
                'numero_securite_sociale' => $numero_securite_sociale
            ];

            foreach ($patientFields as $field => $value) {
                $updateFields[] = "p.$field = ?";
                $params[] = $value;
            }

            $sql = "UPDATE utilisateurs u 
                    LEFT JOIN patients p ON u.id = p.utilisateur_id 
                    SET " . implode(', ', $updateFields) . " 
                    WHERE u.id = ?";
        } else {
            // Mise à jour uniquement de la table utilisateurs
            $sql = "UPDATE utilisateurs u 
                    SET " . implode(', ', $updateFields) . " 
                    WHERE u.id = ?";
        }

        $params[] = $userID;

        // Exécuter la mise à jour
        $stmtUpdate = $pdoMedical->prepare($sql);
        $success = $stmtUpdate->execute($params);

        if ($success) {
            // Mettre à jour l'email dans la session si modifié
            if ($_SESSION['user_email'] !== $email) {
                $_SESSION['user_email'] = $email;
            }

            $_SESSION['success_message'] = "Vos données administratives ont été mises à jour avec succès";
        } else {
            throw new Exception("Erreur lors de la mise à jour des données");
        }

    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
    }

    // Redirection vers la même page pour éviter la resoumission du formulaire
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Récupération des informations de base de l'utilisateur
try {
    $stmtUser = $pdoMedical->prepare("
        SELECT u.* 
        FROM utilisateurs u 
        WHERE u.id = ?
    ");
    
    $stmtUser->execute([$userID]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        die("Utilisateur non trouvé");
    }

} catch (PDOException $e) {
    die("Erreur lors de la récupération des données utilisateur: " . $e->getMessage());
}

// Vérifier la structure de la table patients
try {
    $stmtStructure = $pdoMedical->prepare("DESCRIBE patients");
    $stmtStructure->execute();
    $columns = $stmtStructure->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    die("Erreur de structure de table: " . $e->getMessage());
}

// Construire la requête dynamiquement selon les colonnes disponibles
$selectColumns = ["u.*"];
$availableColumns = [
    'date_naissance', 'groupe_sanguin', 'allergies', 'antecedents', 
    'taille', 'poids', 'assurance_maladie', 'numero_securite_sociale'
];

foreach ($availableColumns as $column) {
    if (in_array($column, $columns)) {
        $selectColumns[] = "p.$column";
    }
}

// Ajouter l'ID du patient pour vérifier l'existence
$selectColumns[] = "p.id as patient_id";

$selectString = implode(', ', $selectColumns);

// Vérifier si le profil patient existe et récupérer les données
$patient = null;
$patientExists = false;
$consultations = [];
$antecedents = [];
$allergies = [];
$vaccinations = [];
$traitements = [];
$age = '';
$imc = null;
$categorie = '';
$stats = [];

try {
    $stmtPatient = $pdoMedical->prepare("
        SELECT $selectString
        FROM utilisateurs u
        LEFT JOIN patients p ON u.id = p.utilisateur_id
        WHERE u.id = ?
    ");
    
    $stmtPatient->execute([$userID]);
    $patient = $stmtPatient->fetch(PDO::FETCH_ASSOC);

    // CORRECTION : Vérifier si patient_id existe et n'est pas null
    if ($patient && isset($patient['patient_id']) && $patient['patient_id'] !== null) {
        $patientExists = true;
        
        // Récupération de l'historique des consultations
        try {
            $stmtConsultations = $pdoMedical->prepare("
                SELECT 
                    c.*,
                    r.date_rdv,
                    r.type_rdv,
                    r.statut,
                    m.prenom AS medecin_prenom,
                    m.nom AS medecin_nom,
                    m.specialite AS medecin_specialite
                FROM consultations c
                JOIN rendez_vous r ON c.rendez_vous_id = r.id
                JOIN utilisateurs m ON r.medecin_id = m.id
                WHERE r.patient_id = ?
                ORDER BY r.date_rdv DESC
            ");
            
            $stmtConsultations->execute([$userID]);
            $consultations = $stmtConsultations->fetchAll(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {
            $consultations = [];
            error_log("Erreur consultations: " . $e->getMessage());
        }

        // Récupération des antécédents médicaux
        try {
            $tableExists = $pdoMedical->query("SHOW TABLES LIKE 'antecedents_medicaux'")->fetch();
            if ($tableExists) {
                $stmtAntecedents = $pdoMedical->prepare("
                    SELECT * FROM antecedents_medicaux 
                    WHERE patient_id = ?
                    ORDER BY date DESC, date_creation DESC
                ");
                
                $stmtAntecedents->execute([$patient['patient_id']]);
                $antecedents = $stmtAntecedents->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e) {
            error_log("Erreur antécédents: " . $e->getMessage());
        }

        // Récupération des allergies
        try {
            $tableExists = $pdoMedical->query("SHOW TABLES LIKE 'allergies'")->fetch();
            if ($tableExists) {
                $stmtAllergies = $pdoMedical->prepare("
                    SELECT * FROM allergies 
                    WHERE patient_id = ?
                    ORDER BY date_diagnostic DESC
                ");
                
                $stmtAllergies->execute([$patient['patient_id']]);
                $allergies = $stmtAllergies->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e) {
            error_log("Erreur allergies: " . $e->getMessage());
        }

        // Récupération des vaccinations
        try {
            $tableExists = $pdoMedical->query("SHOW TABLES LIKE 'vaccinations'")->fetch();
            if ($tableExists) {
                $stmtVaccinations = $pdoMedical->prepare("
                    SELECT * FROM vaccinations 
                    WHERE patient_id = ?
                    ORDER BY date_vaccination DESC
                ");
                
                $stmtVaccinations->execute([$patient['patient_id']]);
                $vaccinations = $stmtVaccinations->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e) {
            error_log("Erreur vaccinations: " . $e->getMessage());
        }

        // Récupération des traitements en cours
        try {
            $tableExists = $pdoMedical->query("SHOW TABLES LIKE 'traitements'")->fetch();
            if ($tableExists) {
                $stmtTraitements = $pdoMedical->prepare("
                    SELECT * FROM traitements 
                    WHERE patient_id = ?
                    AND (date_fin IS NULL OR date_fin >= CURDATE())
                    ORDER BY date_debut DESC
                ");
                
                $stmtTraitements->execute([$patient['patient_id']]);
                $traitements = $stmtTraitements->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (PDOException $e) {
            error_log("Erreur traitements: " . $e->getMessage());
        }

        // Calcul de l'âge
        if (isset($patient['date_naissance']) && $patient['date_naissance']) {
            $birthDate = new DateTime($patient['date_naissance']);
            $today = new DateTime();
            $age = $birthDate->diff($today)->y;
        }

        // Calcul IMC si les données sont disponibles
        if (isset($patient['taille']) && $patient['taille'] && isset($patient['poids']) && $patient['poids']) {
            $taille_m = $patient['taille'] / 100;
            $imc = $patient['poids'] / ($taille_m * $taille_m);
            
            if ($imc < 18.5) $categorie = 'category-underweight';
            elseif ($imc < 25) $categorie = 'category-normal';
            elseif ($imc < 30) $categorie = 'category-overweight';
            else $categorie = 'category-obese';
        }

        // Statistiques
        $stats = [
            'consultations' => count($consultations),
            'antecedents' => count($antecedents) + (!empty($patient['antecedents']) ? 1 : 0),
            'allergies' => count($allergies) + (!empty($patient['allergies']) ? 1 : 0),
            'vaccinations' => count($vaccinations),
            'traitements' => count($traitements)
        ];
    }

} catch (PDOException $e) {
    error_log("Erreur lors de la récupération des données patient: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $patientExists ? 'Mon Dossier Médical Complet' : 'Créez votre Dossier Médical'; ?> | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --info: #3498db;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: var(--dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        .btn-retour {
            position: fixed;
            top: 20px;
            left: 20px;
            background: var(--white);
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            box-shadow: var(--shadow);
            cursor: pointer;
            font-size: 1.2rem;
            color: var(--primary);
            z-index: 1000;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        .btn-retour:hover {
            transform: translateX(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        /* Styles pour la page d'invitation */
        .invitation-card {
            background: var(--white);
            border-radius: 15px;
            padding: 3rem;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            text-align: center;
            position: relative;
            overflow: hidden;
            max-width: 1000px;
            margin: 0 auto;
        }

        .invitation-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .icon-hero {
            font-size: 4rem;
            color: var(--primary);
            margin-bottom: 1.5rem;
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin: 3rem 0;
        }

        .benefit-card {
            background: var(--light-gray);
            padding: 2rem;
            border-radius: var(--radius);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-left: 4px solid var(--primary);
        }

        .benefit-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow);
        }

        .benefit-icon {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }

        .cta-section {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--white);
            padding: 2.5rem;
            border-radius: var(--radius);
            margin: 2rem 0;
            position: relative;
            overflow: hidden;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.8rem;
            padding: 1rem 2.5rem;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: var(--white);
            color: var(--primary);
            box-shadow: 0 5px 15px rgba(255,255,255,0.2);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(255,255,255,0.3);
        }

        .btn-secondary {
            background: transparent;
            color: var(--white);
            border: 2px solid var(--white);
        }

        .btn-secondary:hover {
            background: var(--white);
            color: var(--primary);
        }

        .pulse {
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .user-welcome {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: var(--radius);
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-size: 1.5rem;
            font-weight: bold;
        }

        /* Styles pour le dossier médical complet */
        .header {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .page-title {
            color: var(--primary);
            font-size: 2.5rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .patient-header {
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 2rem;
            align-items: start;
            margin-bottom: 2rem;
        }

        .patient-avatar {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-size: 3rem;
            font-weight: bold;
            box-shadow: var(--shadow);
        }

        .patient-info h2 {
            color: var(--primary);
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }

        .patient-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }

        .meta-item {
            background: var(--light-gray);
            padding: 1rem;
            border-radius: 8px;
            border-left: 4px solid var(--primary);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin: 2rem 0;
        }

        .stat-card {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: var(--radius);
            text-align: center;
            box-shadow: var(--shadow);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--primary);
            display: block;
        }

        .stat-label {
            color: var(--gray);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .dossier-sections {
            display: grid;
            grid-template-columns: 1fr;
            gap: 2rem;
        }

        .section {
            background: var(--white);
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: var(--shadow);
        }

        .section-title {
            color: var(--primary);
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--light-gray);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .info-card {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            border-left: 4px solid var(--primary);
        }

        /* Bouton de modification */
        .btn-edit-toggle {
            background: var(--primary);
            color: var(--white);
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-edit-toggle:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        /* Transition pour l'affichage/le masquage */
        .info-display, .edit-form {
            transition: all 0.3s ease-in-out;
        }

        .edit-form {
            background: var(--light-gray);
            padding: 2rem;
            border-radius: var(--radius);
            margin-top: 1rem;
            border: 2px solid var(--primary);
            animation: slideDown 0.3s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Styles pour le formulaire administratif */
        .admin-form {
            max-width: 100%;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-group label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-input, .form-textarea {
            padding: 0.75rem 1rem;
            border: 2px solid var(--light-gray);
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--white);
        }

        .form-input:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(58, 123, 213, 0.1);
        }

        .form-textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-help {
            color: var(--gray);
            font-size: 0.8rem;
            margin-top: 0.3rem;
        }

        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            padding-top: 1.5rem;
            border-top: 2px solid var(--light-gray);
        }

        /* Messages de notification */
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            border-left: 4px solid;
        }

        .alert-success {
            background: rgba(39, 174, 96, 0.1);
            border-left-color: var(--success);
            color: var(--success);
        }

        .alert-error {
            background: rgba(231, 76, 60, 0.1);
            border-left-color: var(--danger);
            color: var(--danger);
        }

        /* Animation pour les modifications */
        @keyframes highlight {
            0% { background-color: rgba(58, 123, 213, 0.2); }
            100% { background-color: transparent; }
        }

        .highlight {
            animation: highlight 2s ease;
        }

        .consultation-card {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border-left: 4px solid var(--info);
            transition: all 0.3s ease;
        }

        .consultation-card:hover {
            transform: translateX(5px);
            box-shadow: var(--shadow);
        }

        .consultation-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .consultation-date {
            font-weight: 600;
            color: var(--primary);
        }

        .consultation-medecin {
            color: var(--gray);
        }

        .consultation-content {
            margin-top: 1rem;
        }

        .content-section {
            margin-bottom: 1rem;
        }

        .content-section h4 {
            color: var(--primary);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .antecedent-card, .allergie-card, .vaccination-card, .traitement-card {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            border-left: 4px solid var(--warning);
        }

        .allergie-card {
            border-left-color: var(--danger);
        }

        .vaccination-card {
            border-left-color: var(--success);
        }

        .traitement-card {
            border-left-color: var(--info);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .card-title {
            font-weight: 600;
            color: var(--dark);
            font-size: 1.1rem;
        }

        .card-date {
            color: var(--gray);
            font-size: 0.9rem;
        }

        .badge {
            display: inline-block;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-success {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }

        .badge-warning {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }

        .badge-danger {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger);
        }

        .badge-info {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray);
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }

        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
            flex-wrap: wrap;
        }

        .imc-value {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary);
        }

        .imc-category {
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-left: 1rem;
        }

        .category-normal {
            background: rgba(39, 174, 96, 0.1);
            color: var(--success);
        }

        .category-overweight {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }

        .category-obese {
            background: rgba(231, 76, 60, 0.1);
            color: var(--danger);
        }

        .category-underweight {
            background: rgba(52, 152, 219, 0.1);
            color: var(--info);
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .container {
                padding: 1rem 0.5rem;
            }
            
            .invitation-card {
                padding: 2rem 1.5rem;
            }
            
            .patient-header {
                grid-template-columns: 1fr;
                text-align: center;
            }
            
            .benefits-grid {
                grid-template-columns: 1fr;
            }
            
            .btn {
                width: 100%;
                margin-bottom: 1rem;
            }
            
            .page-title {
                font-size: 2rem;
            }
            
            .patient-info h2 {
                font-size: 1.5rem;
            }
            
            .patient-meta {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .consultation-header, .card-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .section-title {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
            
            .btn-edit-toggle {
                margin-left: 0;
                width: 100%;
                justify-content: center;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .form-actions .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <a href="javascript:history.back()" class="btn-retour" title="Retour">
        <i class="fas fa-arrow-left"></i>
    </a>

    <div class="container">
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?= $_SESSION['success_message'] ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?= $_SESSION['error_message'] ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <?php if ($patientExists): ?>
            <!-- AFFICHAGE DU DOSSIER MÉDICAL COMPLET -->
            <div class="header">
                <h1 class="page-title">
                    <i class="fas fa-folder-medical"></i>
                    Mon Dossier Médical Complet
                </h1>

                <!-- Informations patient -->
                <div class="patient-header">
                    <div class="patient-avatar">
                        <?= strtoupper(substr($patient['prenom'], 0, 1) . substr($patient['nom'], 0, 1)) ?>
                    </div>
                    <div class="patient-info">
                        <h2><?= htmlspecialchars($patient['prenom'] . ' ' . $patient['nom']) ?></h2>
                        <p style="color: var(--gray); margin-bottom: 1rem;">Étudiant - <?= htmlspecialchars($patient['email']) ?></p>
                        
                        <div class="patient-meta">
                            <?php if (isset($patient['date_naissance']) && $patient['date_naissance']): ?>
                            <div class="meta-item">
                                <strong>Âge</strong>
                                <?= $age ? $age . ' ans' : 'Non renseigné' ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (isset($patient['groupe_sanguin']) && $patient['groupe_sanguin']): ?>
                            <div class="meta-item">
                                <strong>Groupe sanguin</strong>
                                <?= htmlspecialchars($patient['groupe_sanguin']) ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (isset($patient['telephone']) && $patient['telephone']): ?>
                            <div class="meta-item">
                                <strong>Téléphone</strong>
                                <?= htmlspecialchars($patient['telephone']) ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($imc): ?>
                            <div class="meta-item">
                                <strong>IMC</strong>
                                <span class="imc-value"><?= number_format($imc, 1) ?></span>
                                <span class="imc-category <?= $categorie ?>">
                                    <?= number_format($imc, 1) ?>
                                </span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Statistiques -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <span class="stat-number"><?= $stats['consultations'] ?></span>
                        <span class="stat-label">Consultations</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-number"><?= $stats['antecedents'] ?></span>
                        <span class="stat-label">Antécédents</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-number"><?= $stats['allergies'] ?></span>
                        <span class="stat-label">Allergies</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-number"><?= $stats['vaccinations'] ?></span>
                        <span class="stat-label">Vaccinations</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-number"><?= $stats['traitements'] ?></span>
                        <span class="stat-label">Traitements</span>
                    </div>
                </div>
            </div>

            <div class="dossier-sections">
                <!-- Informations personnelles AVEC FORMULAIRE DE MODIFICATION -->
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-user-circle"></i>
                        Informations Personnelles
                        <button type="button" class="btn-edit-toggle" onclick="toggleEditForm()">
                            <i class="fas fa-edit"></i> Modifier
                        </button>
                    </h2>
                    
                    <!-- Affichage des informations (visible par défaut) -->
                    <div id="infoDisplay" class="info-display">
                        <div class="info-grid">
                            <div class="info-card">
                                <h4><i class="fas fa-id-card"></i> Identité</h4>
                                <p><strong>Nom complet:</strong> <?= htmlspecialchars($patient['prenom'] . ' ' . $patient['nom']) ?></p>
                                <p><strong>Email:</strong> <?= htmlspecialchars($patient['email']) ?></p>
                                <?php if (isset($patient['telephone']) && $patient['telephone']): ?>
                                <p><strong>Téléphone:</strong> <?= htmlspecialchars($patient['telephone']) ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <?php if (isset($patient['date_naissance']) && $patient['date_naissance']): ?>
                            <div class="info-card">
                                <h4><i class="fas fa-birthday-cake"></i> État civil</h4>
                                <p><strong>Date de naissance:</strong> 
                                    <?= date('d/m/Y', strtotime($patient['date_naissance'])) ?>
                                </p>
                                <p><strong>Âge:</strong> <?= $age ?> ans</p>
                                <?php if (isset($patient['groupe_sanguin']) && $patient['groupe_sanguin']): ?>
                                <p><strong>Groupe sanguin:</strong> 
                                    <?= htmlspecialchars($patient['groupe_sanguin']) ?>
                                </p>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($imc): ?>
                            <div class="info-card">
                                <h4><i class="fas fa-heartbeat"></i> Données physiques</h4>
                                <p><strong>Taille:</strong> <?= $patient['taille'] ?> cm</p>
                                <p><strong>Poids:</strong> <?= $patient['poids'] ?> kg</p>
                                <p><strong>IMC:</strong> 
                                    <span class="imc-value"><?= number_format($imc, 1) ?></span>
                                    <span class="imc-category <?= $categorie ?>">
                                        <?php 
                                            if ($imc < 18.5) echo 'Insuffisance pondérale';
                                            elseif ($imc < 25) echo 'Poids normal';
                                            elseif ($imc < 30) echo 'Surpoids';
                                            else echo 'Obésité';
                                        ?>
                                    </span>
                                </p>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ((isset($patient['assurance_maladie']) && $patient['assurance_maladie']) || 
                                     (isset($patient['numero_securite_sociale']) && $patient['numero_securite_sociale']) ||
                                     (isset($patient['adresse']) && $patient['adresse'])): ?>
                            <div class="info-card">
                                <h4><i class="fas fa-address-card"></i> Données Administratives</h4>
                                <?php if (isset($patient['assurance_maladie']) && $patient['assurance_maladie']): ?>
                                <p><strong>Assurance maladie:</strong> 
                                    <?= htmlspecialchars($patient['assurance_maladie']) ?>
                                </p>
                                <?php endif; ?>
                                <?php if (isset($patient['numero_securite_sociale']) && $patient['numero_securite_sociale']): ?>
                                <p><strong>Numéro sécurité sociale:</strong> 
                                    <?= '••••••••' . substr($patient['numero_securite_sociale'], -4) ?>
                                </p>
                                <?php endif; ?>
                                <?php if (isset($patient['adresse']) && $patient['adresse']): ?>
                                <p><strong>Adresse:</strong> 
                                    <?= nl2br(htmlspecialchars($patient['adresse'])) ?>
                                </p>
                                <?php endif; ?>
                                <?php if (isset($patient['ville']) && $patient['ville']): ?>
                                <p><strong>Ville:</strong> <?= htmlspecialchars($patient['ville']) ?></p>
                                <?php endif; ?>
                                <?php if (isset($patient['code_postal']) && $patient['code_postal']): ?>
                                <p><strong>Code postal:</strong> <?= htmlspecialchars($patient['code_postal']) ?></p>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Formulaire de modification (caché par défaut) -->
                    <div id="editForm" class="edit-form" style="display: none;">
                        <form id="adminDataForm" method="POST" class="admin-form">
                            <input type="hidden" name="update_admin_data" value="1">
                            <div class="form-grid">
                                <!-- Numéro de téléphone -->
                                <div class="form-group">
                                    <label for="telephone">
                                        <i class="fas fa-phone"></i> Numéro de téléphone
                                    </label>
                                    <input type="tel" id="telephone" name="telephone" 
                                           value="<?= htmlspecialchars($patient['telephone'] ?? '') ?>" 
                                           class="form-input" 
                                           placeholder="+33 1 23 45 67 89">
                                </div>

                                <!-- Email -->
                                <div class="form-group">
                                    <label for="email">
                                        <i class="fas fa-envelope"></i> Adresse email
                                    </label>
                                    <input type="email" id="email" name="email" 
                                           value="<?= htmlspecialchars($patient['email'] ?? '') ?>" 
                                           class="form-input" 
                                           placeholder="votre@email.com" required>
                                </div>

                                <!-- Assurance maladie -->
                                <div class="form-group">
                                    <label for="assurance_maladie">
                                        <i class="fas fa-shield-alt"></i> Assurance maladie
                                    </label>
                                    <input type="text" id="assurance_maladie" name="assurance_maladie" 
                                           value="<?= htmlspecialchars($patient['assurance_maladie'] ?? '') ?>" 
                                           class="form-input" 
                                           placeholder="Votre assurance maladie">
                                </div>

                                <!-- Numéro de sécurité sociale -->
                                <div class="form-group">
                                    <label for="numero_securite_sociale">
                                        <i class="fas fa-id-card"></i> Numéro de sécurité sociale
                                    </label>
                                    <input type="text" id="numero_securite_sociale" name="numero_securite_sociale" 
                                           value="<?= htmlspecialchars($patient['numero_securite_sociale'] ?? '') ?>" 
                                           class="form-input" 
                                           placeholder="1 23 45 67 891 234"
                                           pattern="[1-2]\s?\d{2}\s?\d{2}\s?\d{3}\s?\d{3}\s?\d{2}"
                                           title="Format: 1 23 45 67 891 234">
                                    <small class="form-help">Format: 1 23 45 67 891 234</small>
                                </div>

                                <!-- Adresse -->
                                <div class="form-group full-width">
                                    <label for="adresse">
                                        <i class="fas fa-home"></i> Adresse complète
                                    </label>
                                    <textarea id="adresse" name="adresse" class="form-textarea" 
                                              placeholder="Numéro, rue, code postal, ville"
                                              rows="3"><?= htmlspecialchars($patient['adresse'] ?? '') ?></textarea>
                                </div>

                                <!-- Ville -->
                                <div class="form-group">
                                    <label for="ville">Ville</label>
                                    <input type="text" id="ville" name="ville" 
                                           value="<?= htmlspecialchars($patient['ville'] ?? '') ?>" 
                                           class="form-input" 
                                           placeholder="Votre ville">
                                </div>

                                <!-- Code postal -->
                                <div class="form-group">
                                    <label for="code_postal">Code postal</label>
                                    <input type="text" id="code_postal" name="code_postal" 
                                           value="<?= htmlspecialchars($patient['code_postal'] ?? '') ?>" 
                                           class="form-input" 
                                           placeholder="75000"
                                           pattern="\d{5}"
                                           title="5 chiffres requis">
                                </div>

                                <!-- Pays -->
                                <div class="form-group">
                                    <label for="pays">Pays</label>
                                    <input type="text" id="pays" name="pays" 
                                           value="<?= htmlspecialchars($patient['pays'] ?? 'France') ?>" 
                                           class="form-input" 
                                           placeholder="France">
                                </div>
                            </div>

                            <div class="form-actions">
                                <button type="button" class="btn btn-secondary" onclick="toggleEditForm()">
                                    <i class="fas fa-times"></i> Annuler
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Enregistrer
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Le reste de votre code pour les autres sections (consultations, antécédents, etc.) -->
                <!-- Historique des consultations -->
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-history"></i>
                        Historique des Consultations
                    </h2>
                    <?php if (empty($consultations)): ?>
                        <div class="empty-state">
                            <i class="fas fa-stethoscope"></i>
                            <p>Aucune consultation enregistrée</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($consultations as $consultation): ?>
                        <div class="consultation-card">
                            <div class="consultation-header">
                                <div>
                                    <div class="consultation-date">
                                        <i class="fas fa-calendar-day"></i>
                                        <?= date('d/m/Y à H:i', strtotime($consultation['date_rdv'])) ?>
                                    </div>
                                    <div class="consultation-medecin">
                                        <i class="fas fa-user-md"></i>
                                        Dr. <?= htmlspecialchars($consultation['medecin_prenom'] . ' ' . $consultation['medecin_nom']) ?>
                                        <?php if ($consultation['medecin_specialite']): ?>
                                            - <?= htmlspecialchars($consultation['medecin_specialite']) ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <span class="badge badge-info"><?= htmlspecialchars($consultation['type_rdv']) ?></span>
                            </div>
                            
                            <div class="consultation-content">
                                <?php if (!empty($consultation['diagnostic'])): ?>
                                <div class="content-section">
                                    <h4><i class="fas fa-diagnoses"></i> Diagnostic</h4>
                                    <p><?= nl2br(htmlspecialchars($consultation['diagnostic'])) ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($consultation['prescription'])): ?>
                                <div class="content-section">
                                    <h4><i class="fas fa-prescription"></i> Prescription</h4>
                                    <p><?= nl2br(htmlspecialchars($consultation['prescription'])) ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($consultation['examens'])): ?>
                                <div class="content-section">
                                    <h4><i class="fas fa-microscope"></i> Examens</h4>
                                    <p><?= nl2br(htmlspecialchars($consultation['examens'])) ?></p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Les autres sections restent inchangées -->
                <!-- Antécédents médicaux -->
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-notes-medical"></i>
                        Antécédents Médicaux
                    </h2>
                    <?php if (empty($antecedents) && empty($patient['antecedents'])): ?>
                        <div class="empty-state">
                            <i class="fas fa-file-medical"></i>
                            <p>Aucun antécédent médical enregistré</p>
                        </div>
                    <?php else: ?>
                        <?php if (!empty($patient['antecedents'])): ?>
                        <div class="antecedent-card">
                            <div class="card-header">
                                <div class="card-title">Antécédents personnels</div>
                            </div>
                            <p><?= nl2br(htmlspecialchars($patient['antecedents'])) ?></p>
                        </div>
                        <?php endif; ?>
                        
                        <?php foreach ($antecedents as $antecedent): ?>
                        <div class="antecedent-card">
                            <div class="card-header">
                                <div class="card-title"><?= htmlspecialchars($antecedent['type']) ?></div>
                                <?php if ($antecedent['date']): ?>
                                    <div class="card-date">
                                        <?= date('d/m/Y', strtotime($antecedent['date'])) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <p><?= nl2br(htmlspecialchars($antecedent['description'])) ?></p>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Allergies -->
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-allergies"></i>
                        Allergies
                    </h2>
                    <?php if (empty($allergies) && empty($patient['allergies'])): ?>
                        <div class="empty-state">
                            <i class="fas fa-ban"></i>
                            <p>Aucune allergie déclarée</p>
                        </div>
                    <?php else: ?>
                        <?php if (!empty($patient['allergies'])): ?>
                        <div class="allergie-card">
                            <div class="card-header">
                                <div class="card-title">Allergies déclarées</div>
                            </div>
                            <p><?= nl2br(htmlspecialchars($patient['allergies'])) ?></p>
                        </div>
                        <?php endif; ?>
                        
                        <?php foreach ($allergies as $allergie): ?>
                        <div class="allergie-card">
                            <div class="card-header">
                                <div class="card-title"><?= htmlspecialchars($allergie['substance']) ?></div>
                                <?php if (isset($allergie['gravite']) && $allergie['gravite']): ?>
                                    <span class="badge badge-danger"><?= htmlspecialchars($allergie['gravite']) ?></span>
                                <?php endif; ?>
                            </div>
                            <?php if (isset($allergie['symptomes']) && $allergie['symptomes']): ?>
                                <p><strong>Symptômes:</strong> <?= htmlspecialchars($allergie['symptomes']) ?></p>
                            <?php endif; ?>
                            <?php if (isset($allergie['traitement_urgence']) && $allergie['traitement_urgence']): ?>
                                <p><strong>Traitement d'urgence:</strong> <?= htmlspecialchars($allergie['traitement_urgence']) ?></p>
                            <?php endif; ?>
                            <?php if (isset($allergie['date_diagnostic']) && $allergie['date_diagnostic']): ?>
                                <p class="card-date">
                                    Diagnostiquée le <?= date('d/m/Y', strtotime($allergie['date_diagnostic'])) ?>
                                </p>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Vaccinations -->
                <?php if (!empty($vaccinations)): ?>
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-syringe"></i>
                        Carnet de Vaccination
                    </h2>
                    <?php foreach ($vaccinations as $vaccination): ?>
                    <div class="vaccination-card">
                        <div class="card-header">
                            <div class="card-title"><?= htmlspecialchars($vaccination['vaccin']) ?></div>
                            <span class="badge badge-success">Vacciné</span>
                        </div>
                        <p><strong>Date:</strong> <?= date('d/m/Y', strtotime($vaccination['date_vaccination'])) ?></p>
                        <?php if (isset($vaccination['lot']) && $vaccination['lot']): ?>
                            <p><strong>Numéro de lot:</strong> <?= htmlspecialchars($vaccination['lot']) ?></p>
                        <?php endif; ?>
                        <?php if (isset($vaccination['rappel']) && $vaccination['rappel']): ?>
                            <p><strong>Rappel prévu:</strong> <?= date('d/m/Y', strtotime($vaccination['rappel'])) ?></p>
                        <?php endif; ?>
                        <?php if (isset($vaccination['medecin']) && $vaccination['medecin']): ?>
                            <p><strong>Médecin:</strong> <?= htmlspecialchars($vaccination['medecin']) ?></p>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <!-- Traitements en cours -->
                <?php if (!empty($traitements)): ?>
                <div class="section">
                    <h2 class="section-title">
                        <i class="fas fa-pills"></i>
                        Traitements en Cours
                    </h2>
                    <?php foreach ($traitements as $traitement): ?>
                    <div class="traitement-card">
                        <div class="card-header">
                            <div class="card-title"><?= htmlspecialchars($traitement['medicament']) ?></div>
                            <span class="badge badge-info">En cours</span>
                        </div>
                        <p><strong>Posologie:</strong> <?= htmlspecialchars($traitement['posologie']) ?></p>
                        <p><strong>Début:</strong> <?= date('d/m/Y', strtotime($traitement['date_debut'])) ?></p>
                        <?php if (isset($traitement['date_fin']) && $traitement['date_fin']): ?>
                            <p><strong>Fin prévue:</strong> <?= date('d/m/Y', strtotime($traitement['date_fin'])) ?></p>
                        <?php endif; ?>
                        <?php if (isset($traitement['raison']) && $traitement['raison']): ?>
                            <p><strong>Motif:</strong> <?= htmlspecialchars($traitement['raison']) ?></p>
                        <?php endif; ?>
                        <?php if (isset($traitement['effets_secondaires']) && $traitement['effets_secondaires']): ?>
                            <p><strong>Effets secondaires:</strong> <?= htmlspecialchars($traitement['effets_secondaires']) ?></p>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Boutons d'action -->
            <div class="action-buttons">
                <button onclick="window.print()" class="btn btn-print">
                    <i class="fas fa-print"></i> Imprimer le dossier
                </button>
                <a href="../rdv/liste_rdv.php" class="btn">
                    <i class="fas fa-calendar-alt"></i> Mes rendez-vous
                </a>
                <a href="../pharmacie/pharmacie.php" class="btn">
                    <i class="fas fa-prescription"></i> Pharmacie
                </a>
            </div>

        <?php else: ?>
            <!-- PAGE D'INVITATION À CRÉER LE PROFIL -->
            <div class="invitation-card">
                <div class="user-welcome">
                    <div class="user-avatar">
                        <?= strtoupper(substr($user['prenom'], 0, 1) . substr($user['nom'], 0, 1)) ?>
                    </div>
                    <div class="user-info">
                        <h3>Bonjour <?= htmlspecialchars($user['prenom']) ?> !</h3>
                        <p>Votre santé mérite une attention particulière</p>
                    </div>
                </div>

                <div class="icon-hero">
                    <i class="fas fa-heartbeat"></i>
                </div>

                <h1>Votre Dossier Médical Vous Attend</h1>
                <p class="subtitle">
                    Rejoignez des milliers d'étudiants qui gèrent déjà leur santé en toute sérénité grâce à leur dossier médical numérique sécurisé.
                </p>

                <div class="benefits-grid">
                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3 class="benefit-title">Sécurité Maximale</h3>
                        <p class="benefit-description">
                            Vos données médicales sont cryptées et protégées conformément aux normes de confidentialité les plus strictes.
                        </p>
                    </div>

                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h3 class="benefit-title">Gain de Temps</h3>
                        <p class="benefit-description">
                            Plus besoin de rapporter vos documents à chaque consultation. Tout est accessible instantanément par les professionnels de santé.
                        </p>
                    </div>

                    <div class="benefit-card">
                        <div class="benefit-icon">
                            <i class="fas fa-stethoscope"></i>
                        </div>
                        <h3 class="benefit-title">Soins Optimisés</h3>
                        <p class="benefit-description">
                            Vos antécédents, allergies et traitements sont toujours disponibles pour des soins plus précis et personnalisés.
                        </p>
                    </div>
                </div>

                <div class="cta-section">
                    <h2 class="cta-title">Prêt à prendre le contrôle de votre santé ?</h2>
                    <p class="cta-description">
                        Créez votre dossier médical en moins de 5 minutes et bénéficiez d'un suivi médical complet tout au long de vos études.
                    </p>
                    
                    <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                        <a href="../patient/creer_profil.php" class="btn btn-primary pulse">
                            <i class="fas fa-plus-circle"></i>
                            Créer mon dossier médical
                        </a>
                        <a href="../faq/sante.php" class="btn btn-secondary">
                            <i class="fas fa-question-circle"></i>
                            En savoir plus
                        </a>
                    </div>

                    <div class="security-badge">
                        <i class="fas fa-lock"></i>
                        <span>100% sécurisé et confidentiel</span>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Gestion de l'affichage/masquage du formulaire
        let isEditing = false;
        const originalData = {};

        function toggleEditForm() {
            const infoDisplay = document.getElementById('infoDisplay');
            const editForm = document.getElementById('editForm');
            const editButton = document.querySelector('.btn-edit-toggle');
            
            isEditing = !isEditing;
            
            if (isEditing) {
                // Passer en mode édition
                infoDisplay.style.display = 'none';
                editForm.style.display = 'block';
                editButton.innerHTML = '<i class="fas fa-eye"></i> Voir les informations';
                editButton.style.background = 'var(--gray)';
                
                // Stocker les valeurs originales
                const form = document.getElementById('adminDataForm');
                const inputs = form.querySelectorAll('input, textarea');
                inputs.forEach(input => {
                    originalData[input.name] = input.value;
                });
                
                // Focus sur le premier champ
                const firstInput = form.querySelector('input, textarea');
                if (firstInput) firstInput.focus();
                
            } else {
                // Revenir à l'affichage normal
                infoDisplay.style.display = 'block';
                editForm.style.display = 'none';
                editButton.innerHTML = '<i class="fas fa-edit"></i> Modifier';
                editButton.style.background = 'var(--primary)';
            }
        }

        // Validation en temps réel pour le numéro de sécurité sociale
        document.addEventListener('DOMContentLoaded', function() {
            const numeroSecuInput = document.getElementById('numero_securite_sociale');
            if (numeroSecuInput) {
                numeroSecuInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\s/g, '');
                    let formattedValue = '';
                    
                    if (value.length > 0) formattedValue += value[0];
                    if (value.length > 1) formattedValue += ' ' + value.substring(1, 3);
                    if (value.length > 3) formattedValue += ' ' + value.substring(3, 5);
                    if (value.length > 5) formattedValue += ' ' + value.substring(5, 8);
                    if (value.length > 8) formattedValue += ' ' + value.substring(8, 11);
                    if (value.length > 11) formattedValue += ' ' + value.substring(11, 13);
                    
                    e.target.value = formattedValue.trim();
                });
            }
            
            // Gestion de la soumission du formulaire
            const form = document.getElementById('adminDataForm');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const email = document.getElementById('email').value;
                    const numeroSecu = document.getElementById('numero_securite_sociale').value;
                    
                    if (!email) {
                        e.preventDefault();
                        showNotification('L\'adresse email est obligatoire', 'error');
                        return;
                    }
                    
                    if (numeroSecu && !/^[1-2]\s?\d{2}\s?\d{2}\s?\d{3}\s?\d{3}\s?\d{2}$/.test(numeroSecu)) {
                        e.preventDefault();
                        showNotification('Le format du numéro de sécurité sociale est invalide', 'error');
                        return;
                    }
                    
                    // Afficher un indicateur de chargement
                    const submitBtn = this.querySelector('button[type="submit"]');
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mise à jour...';
                    submitBtn.disabled = true;
                });
            }
        });

        // Fonction pour afficher les notifications
        function showNotification(message, type) {
            // Créer une notification temporaire
            const notification = document.createElement('div');
            notification.className = `alert alert-${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                ${message}
            `;
            
            notification.style.position = 'fixed';
            notification.style.top = '20px';
            notification.style.right = '20px';
            notification.style.zIndex = '10000';
            notification.style.minWidth = '300px';
            notification.style.boxShadow = 'var(--shadow)';
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 5000);
        }

        // Amélioration de l'impression
        window.addEventListener('beforeprint', function() {
            document.querySelector('.btn-retour').style.display = 'none';
            document.querySelectorAll('.btn, .btn-edit-toggle').forEach(btn => {
                btn.style.display = 'none';
            });
            // Cacher le formulaire d'édition s'il est ouvert
            const editForm = document.getElementById('editForm');
            if (editForm) editForm.style.display = 'none';
            const infoDisplay = document.getElementById('infoDisplay');
            if (infoDisplay) infoDisplay.style.display = 'block';
        });

        window.addEventListener('afterprint', function() {
            document.querySelector('.btn-retour').style.display = 'flex';
            document.querySelectorAll('.btn, .btn-edit-toggle').forEach(btn => {
                btn.style.display = 'inline-flex';
            });
        });
    </script>
</body>
</html>