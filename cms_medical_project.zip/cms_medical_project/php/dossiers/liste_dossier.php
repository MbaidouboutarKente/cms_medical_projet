<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "../config/db.php";

// Vérification rôle médecin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'medecin') {
    header("Location: ../auth.php");
    exit;
}

$medecinID = intval(preg_replace('/^[A-Z]+_/', '', $_SESSION['user_id']));

try {
    // Récupération de tous les patients avec leurs dernières consultations
    $queryPatients = $pdoMedical->prepare("
        SELECT 
            u.id,
            u.prenom,
            u.nom,
            u.email,
            u.telephone,
            u.image,
            p.date_naissance,
            p.groupe_sanguin,
            p.allergies,
            p.antecedents,
            COUNT(r.id) as nb_consultations,
            MAX(r.date_rdv) as derniere_consultation
        FROM utilisateurs u
        JOIN patients p ON u.id = p.utilisateur_id
        LEFT JOIN rendez_vous r ON u.id = r.patient_id AND r.medecin_id = ?
        WHERE u.role = 'etudiant'
        GROUP BY u.id, u.prenom, u.nom, u.email, u.telephone, p.date_naissance, p.groupe_sanguin, p.allergies, p.antecedents
        ORDER BY u.nom, u.prenom
    ");
    $queryPatients->execute([$medecinID]);
    $patients = $queryPatients->fetchAll();

    // Recherche et filtrage
    $search = $_GET['search'] ?? '';
    $filter = $_GET['filter'] ?? 'all';

    if ($search) {
        $patients = array_filter($patients, function($patient) use ($search) {
            return stripos($patient['prenom'] . ' ' . $patient['nom'], $search) !== false ||
                   stripos($patient['email'], $search) !== false;
        });
    }

    if ($filter === 'with_consultations') {
        $patients = array_filter($patients, function($patient) {
            return $patient['nb_consultations'] > 0;
        });
    } elseif ($filter === 'without_consultations') {
        $patients = array_filter($patients, function($patient) {
            return $patient['nb_consultations'] == 0;
        });
    }

} catch (PDOException $e) {
    die("Erreur base de données: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Dossiers Médicaux | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            width: 95%;
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
        /* Header Navigation */
        .nav-header {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1rem 2rem;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-links a {
            color: var(--primary);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .nav-links a:hover {
            color: var(--primary-dark);
        }
        
        /* Page Header */
        .page-header {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        .page-header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
        }
        
        .page-header h1 {
            color: var(--primary);
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        .stat-card {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            text-align: center;
            border-left: 3px solid var(--primary);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 600;
            color: var(--primary);
            display: block;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: var(--gray);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* Search and Filters */
        .search-section {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .search-form {
            display: grid;
            grid-template-columns: 1fr auto auto;
            gap: 1rem;
            align-items: end;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            padding: 0.75rem 1rem;
            border: 2px solid var(--light-gray);
            border-radius: 6px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            background-color: var(--primary);
            color: var(--white);
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.2);
        }
        
        .btn-outline {
            background: transparent;
            border: 2px solid var(--primary);
            color: var(--primary);
        }
        
        .btn-outline:hover {
            background: var(--primary);
            color: var(--white);
        }
        
        /* Patients Grid */
        .patients-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
        }
        
        .patient-card {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1.5rem;
            transition: all 0.3s ease;
            border-left: 4px solid var(--primary);
        }
        
        .patient-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .patient-header {
            display: flex;
            justify-content: between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }
        
        .patient-name {
            flex: 1;
        }
        
        .patient-name h3 {
            color: var(--primary);
            font-size: 1.2rem;
            margin-bottom: 0.25rem;
        }
        
        .patient-name p {
            color: var(--gray);
            font-size: 0.9rem;
        }
        
        .patient-avatar {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-weight: 600;
            font-size: 1.2rem;
        }
        
        .patient-info {
            margin-bottom: 1.5rem;
        }
        
        .info-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        
        .info-item i {
            color: var(--primary);
            width: 16px;
        }
        
        .patient-stats {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding-top: 1rem;
            border-top: 1px solid var(--light-gray);
        }
        
        .stat {
            text-align: center;
            flex: 1;
        }
        
        .stat-value {
            display: block;
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--primary);
        }
        
        .stat-label {
            font-size: 0.75rem;
            color: var(--gray);
            text-transform: uppercase;
        }
        
        .patient-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .btn-small {
            padding: 0.5rem 1rem;
            font-size: 0.8rem;
            flex: 1;
        }
        
        .btn-success {
            background-color: var(--success);
        }
        
        .btn-success:hover {
            background-color: #27ae60;
        }
        
        .badge {
            display: inline-block;
            padding: 0.3rem 0.6rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-primary {
            background: rgba(58, 123, 213, 0.1);
            color: var(--primary);
        }
        
        .badge-success {
            background: rgba(46, 204, 113, 0.1);
            color: var(--success);
        }
        
        .badge-warning {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--gray);
            grid-column: 1 / -1;
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }
        
        .text-gray {
            color: var(--gray);
        }
        
        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 0 0.5rem;
            }
            
            .nav-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .nav-links {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 1rem;
            }
            
            .nav-links a {
                margin: 0;
            }
            
            .search-form {
                grid-template-columns: 1fr;
            }
            
            .patients-grid {
                grid-template-columns: 1fr;
            }
            
            .patient-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .patient-avatar {
                align-self: center;
            }
            
            .patient-actions {
                flex-direction: column;
            }
        }

        /* Styles pour les images de profil des patients */
        .patient-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-weight: 600;
            font-size: 1.2rem;
            position: relative;
            overflow: hidden;
            flex-shrink: 0;
        }

        /* Avatar avec dégradé coloré */
        .avatar-gradient {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
        }

        /* Avatar avec image */
        .avatar-image {
            background: var(--light-gray);
            border: 3px solid var(--white);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .avatar-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        /* Avatar avec initiales */
        .avatar-initials {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-weight: 700;
            text-transform: uppercase;
        }

        /* Variantes de couleurs pour les avatars sans image */
        .avatar-color-1 { background: linear-gradient(135deg, #667eea, #764ba2); }
        .avatar-color-2 { background: linear-gradient(135deg, #f093fb, #f5576c); }
        .avatar-color-3 { background: linear-gradient(135deg, #4facfe, #00f2fe); }
        .avatar-color-4 { background: linear-gradient(135deg, #43e97b, #38f9d7); }
        .avatar-color-5 { background: linear-gradient(135deg, #fa709a, #fee140); }
        .avatar-color-6 { background: linear-gradient(135deg, #a8edea, #fed6e3); }

        /* Avatar avec statut en ligne */
        .avatar-status {
            position: relative;
        }

        .avatar-status::after {
            content: '';
            position: absolute;
            bottom: 2px;
            right: 2px;
            width: 12px;
            height: 12px;
            background: var(--success);
            border: 2px solid var(--white);
            border-radius: 50%;
        }

        /* Avatar avec statut occupé */
        .avatar-status-busy::after {
            background: var(--warning);
        }

        /* Avatar avec statut hors ligne */
        .avatar-status-offline::after {
            background: var(--gray);
        }

        /* Image de profil dans le header patient */
        .profile-img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--white);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: all 0.3s ease;
        }

        .profile-img:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }

        /* Version plus grande pour les profils détaillés */
        .profile-img-large {
            width: 100px;
            height: 100px;
            border: 4px solid var(--white);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }

        /* Version moyenne */
        .profile-img-medium {
            width: 80px;
            height: 80px;
            border: 3px solid var(--white);
        }

        /* Avatar avec badge de notification */
        .avatar-badge {
            position: relative;
        }

        .avatar-badge::before {
            content: attr(data-badge);
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: var(--white);
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 0.7rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        /* Avatar avec bordure animée */
        .avatar-pulse {
            animation: pulse 2s infinite;
            border: 2px solid transparent;
            background: linear-gradient(135deg, var(--primary), var(--secondary)) border-box;
            -webkit-mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
            mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(58, 123, 213, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(58, 123, 213, 0); }
            100% { box-shadow: 0 0 0 0 rgba(58, 123, 213, 0); }
        }

        /* Avatar carré arrondi */
        .avatar-rounded-square {
            border-radius: 15px;
        }

        /* Avatar avec ombre portée */
        .avatar-shadow {
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        /* Avatar avec effet de survol */
        .avatar-hover {
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .avatar-hover:hover {
            transform: scale(1.1) rotate(5deg);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        /* Container pour groupe d'avatars */
        .avatar-group {
            display: flex;
            align-items: center;
        }

        .avatar-stack {
            display: flex;
        }

        .avatar-stack .patient-avatar {
            margin-left: -10px;
            border: 2px solid var(--white);
        }

        .avatar-stack .patient-avatar:first-child {
            margin-left: 0;
        }

        /* Styles responsifs */
        @media (max-width: 768px) {
            .patient-avatar {
                width: 50px;
                height: 50px;
                font-size: 1rem;
            }
            
            .profile-img {
                width: 50px;
                height: 50px;
            }
            
            .profile-img-large {
                width: 80px;
                height: 80px;
            }
        }
        
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Header -->
        <div class="nav-header">
            <div>
                <h3><i class="fas fa-user-md"></i> Espace Médecin</h3>
            </div>
            <div class="nav-links">
                <a href="../medecin/dashboard_medecin.php"><i class="fas fa-home"></i> Tableau de bord</a>
                <!-- <a href="gestion_rdv.php"><i class="fas fa-calendar-alt"></i> Mes RDV</a>
                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a> -->
            </div>
        </div>

        <!-- Page Header -->
        <div class="page-header">
            <h1><i class="fas fa-folder-open"></i> Dossiers Médicaux des Patients</h1>
            <p class="text-gray">Consultez et gérez les dossiers médicaux de tous les étudiants</p>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-number"><?= count($patients) ?></span>
                    <span class="stat-label">Patients total</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">
                        <?= count(array_filter($patients, function($p) { return $p['nb_consultations'] > 0; })) ?>
                    </span>
                    <span class="stat-label">Avec consultations</span>
                </div>
                <div class="stat-card">
                    <span class="stat-number">
                        <?= count(array_filter($patients, function($p) { return $p['nb_consultations'] == 0; })) ?>
                    </span>
                    <span class="stat-label">Nouveaux patients</span>
                </div>
            </div>
        </div>

        <!-- Search and Filters -->
        <div class="search-section">
            <form method="GET" class="search-form">
                <div class="form-group">
                    <label for="search"><i class="fas fa-search"></i> Rechercher un patient</label>
                    <input type="text" 
                           id="search" 
                           name="search" 
                           class="form-control" 
                           placeholder="Nom, prénom ou email..."
                           value="<?= htmlspecialchars($search) ?>">
                </div>
                
                <div class="form-group">
                    <label for="filter"><i class="fas fa-filter"></i> Filtre</label>
                    <select id="filter" name="filter" class="form-control">
                        <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>Tous les patients</option>
                        <option value="with_consultations" <?= $filter === 'with_consultations' ? 'selected' : '' ?>>Avec consultations</option>
                        <option value="without_consultations" <?= $filter === 'without_consultations' ? 'selected' : '' ?>>Nouveaux patients</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn">
                        <i class="fas fa-search"></i> Appliquer
                    </button>
                </div>
            </form>
            
            <?php if ($search || $filter !== 'all'): ?>
                <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--light-gray);">
                    <a href="?search=&filter=all" class="btn btn-outline btn-small">
                        <i class="fas fa-times"></i> Effacer les filtres
                    </a>
                    <span class="text-gray" style="margin-left: 1rem;">
                        <?= count($patients) ?> patient(s) trouvé(s)
                    </span>
                </div>
            <?php endif; ?>
        </div>

        <!-- Patients Grid -->
        <div class="patients-grid">
            <?php if (empty($patients)): ?>
                <div class="empty-state">
                    <i class="fas fa-user-times"></i>
                    <h3>Aucun patient trouvé</h3>
                    <p>Aucun patient ne correspond à vos critères de recherche.</p>
                    <a href="?" class="btn" style="margin-top: 1rem;">
                        <i class="fas fa-redo"></i> Voir tous les patients
                    </a>
                </div>
            <?php else: ?>
                <?php foreach ($patients as $patient): ?>
                    <div class="patient-card">
                        <div class="patient-header">
                            <div class="patient-name">
                                <h3><?= htmlspecialchars($patient['prenom'] . ' ' . $patient['nom']) ?></h3>
                                <p><?= htmlspecialchars($patient['email']) ?></p>
                            </div>
                            
                            <?php if (!empty($patient['image'])): ?>
                                <!-- Avatar avec image réelle -->
                                <div class="patient-avatar avatar-image avatar-hover">
                                    <img src="<?= '../../img/uploads/' . htmlspecialchars($patient['image']) ?>" 
                                        alt="Photo de <?= htmlspecialchars($patient['prenom']) ?>"
                                        onerror="this.style.display='none'; this.parentElement.classList.add('avatar-gradient', 'avatar-initials'); this.parentElement.innerHTML='<?= strtoupper(substr($patient['prenom'] ?? '', 0, 1) . substr($patient['nom'] ?? '', 0, 1)) ?>'">
                                </div>
                            <?php else: ?>
                                <!-- Avatar avec initiales et couleur aléatoire -->
                                <?php
                                $colors = ['avatar-color-1', 'avatar-color-2', 'avatar-color-3', 'avatar-color-4', 'avatar-color-5'];
                                $colorClass = $colors[array_rand($colors)];
                                $initials = strtoupper(substr($patient['prenom'] ?? '', 0, 1) . substr($patient['nom'] ?? '', 0, 1));
                                ?>
                                <div class="patient-avatar avatar-gradient avatar-initials avatar-hover <?= $colorClass ?>">
                                    <?= $initials ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="patient-info">
                            <div class="info-item">
                                <i class="fas fa-birthday-cake" style="color: green"></i>
                                <span>
                                    <?php 
                                    $dateNaissance = $patient['date_naissance'] ?? null;
                                    if ($dateNaissance && $dateNaissance !== '0000-00-00' && $dateNaissance !== '2000-01-01') {
                                        echo htmlspecialchars(date('d/m/Y', strtotime($dateNaissance))) . 
                                            ' (' . (date('Y') - date('Y', strtotime($dateNaissance))) . ' ans)';
                                    } else {
                                        echo 'Âge non renseigné';
                                    }
                                    ?>
                                </span>
                            </div>
                            
                            <?php if (!empty($patient['telephone'])): ?>
                            <div class="info-item">
                                <i class="fas fa-phone"></i>
                                <span><?= htmlspecialchars($patient['telephone']) ?></span>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($patient['groupe_sanguin'])): ?>
                            <div class="info-item">
                                <i class="fas fa-tint" style="color: red"></i>
                                <span>Groupe <?= htmlspecialchars($patient['groupe_sanguin']) ?></span>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($patient['allergies'])): ?>
                            <div class="info-item">
                                <i class="fas fa-allergies"></i>
                                <span>Allergies déclarées</span>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="patient-stats">
                            <div class="stat">
                                <span class="stat-value"><?= $patient['nb_consultations'] ?></span>
                                <span class="stat-label">Consultations</span>
                            </div>
                            <div class="stat">
                                <span class="stat-value">
                                    <?= $patient['derniere_consultation'] ? 
                                        date('d/m/y', strtotime($patient['derniere_consultation'])) : 
                                        '---' ?>
                                </span>
                                <span class="stat-label">Dernière visite</span>
                            </div>
                        </div>
                        
                        <div class="patient-actions">
                            <a href="dossier_patient.php?id=<?= $patient['id'] ?>" class="btn btn-small">
                                <i class="fas fa-folder-open"></i> Dossier
                            </a>
                            <a href="../consultations/nouvelle_consultation.php?patient_id=<?= $patient['id'] ?>" class="btn btn-small btn-success">
                                <i class="fas fa-plus"></i> Consultation
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>