<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "../config/db.php";

// Vérification rôle médecin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'medecin') {
    header("Location: ../auth.php");
    exit;
}

// Extraction ID numérique
$patientID = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$medecinID = intval(preg_replace('/^[A-Z]+_/', '', $_SESSION['user_id']));

if ($patientID === 0) {
    die("ID patient invalide");
}

// Traitement du formulaire d'édition
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Mise à jour des informations de base
        if (isset($_POST['update_patient_info'])) {
            $date_naissance = !empty($_POST['date_naissance']) ? $_POST['date_naissance'] : null;
            $groupe_sanguin = $_POST['groupe_sanguin'] ?? null;
            $allergies = $_POST['allergies'] ?? null;
            $antecedents = $_POST['antecedents'] ?? null;
            $taille = !empty($_POST['taille']) ? (float)$_POST['taille'] : null;
            $poids = !empty($_POST['poids']) ? (float)$_POST['poids'] : null;
            $assurance_maladie = $_POST['assurance_maladie'] ?? null;
            $numero_securite_sociale = $_POST['numero_securite_sociale'] ?? null;

            $updateQuery = $pdoMedical->prepare("
                UPDATE patients 
                SET date_naissance = ?, groupe_sanguin = ?, allergies = ?, antecedents = ?,
                    taille = ?, poids = ?, assurance_maladie = ?, numero_securite_sociale = ?
                WHERE utilisateur_id = ?
            ");
            $updateQuery->execute([
                $date_naissance, $groupe_sanguin, $allergies, $antecedents,
                $taille, $poids, $assurance_maladie, $numero_securite_sociale, $patientID
            ]);
            
            $_SESSION['success_message'] = "Informations patient mises à jour avec succès";
        }

        // Ajout d'un antécédent médical
        if (isset($_POST['add_antecedent'])) {
            $type = $_POST['type_antecedent'] ?? '';
            $description = $_POST['description_antecedent'] ?? '';
            $date_antecedent = $_POST['date_antecedent'] ?? date('Y-m-d');

            if (!empty($type) && !empty($description)) {
                // Récupérer l'ID patient correct depuis la table patients
                $getPatientIdQuery = $pdoMedical->prepare("
                    SELECT id FROM patients WHERE utilisateur_id = ?
                ");
                $getPatientIdQuery->execute([$patientID]);
                $patientRow = $getPatientIdQuery->fetch();
                
                if ($patientRow) {
                    $realPatientId = $patientRow['id'];
                    
                    // Vérifier si la table a le champ created_by
                    $checkTableQuery = $pdoMedical->prepare("SHOW COLUMNS FROM antecedents_medicaux LIKE 'created_by'");
                    $checkTableQuery->execute();
                    $hasCreatedBy = $checkTableQuery->fetch();
                    
                    if ($hasCreatedBy) {
                        $insertQuery = $pdoMedical->prepare("
                            INSERT INTO antecedents_medicaux (patient_id, type, description, date, date_creation, created_by)
                            VALUES (?, ?, ?, ?, NOW(), ?)
                        ");
                        $insertQuery->execute([$realPatientId, $type, $description, $date_antecedent, $medecinID]);
                    } else {
                        $insertQuery = $pdoMedical->prepare("
                            INSERT INTO antecedents_medicaux (patient_id, type, description, date, date_creation)
                            VALUES (?, ?, ?, ?, NOW())
                        ");
                        $insertQuery->execute([$realPatientId, $type, $description, $date_antecedent]);
                    }
                    
                    $_SESSION['success_message'] = "Antécédent médical ajouté avec succès";
                } else {
                    $_SESSION['error_message'] = "Patient non trouvé dans la table patients";
                }
            }
        }

        // Suppression d'un antécédent
        if (isset($_POST['delete_antecedent'])) {
            $antecedent_id = (int)$_POST['antecedent_id'];
            
            $deleteQuery = $pdoMedical->prepare("
                DELETE FROM antecedents_medicaux 
                WHERE id = ? AND patient_id IN (SELECT id FROM patients WHERE utilisateur_id = ?)
            ");
            $deleteQuery->execute([$antecedent_id, $patientID]);
            
            $_SESSION['success_message'] = "Antécédent médical supprimé avec succès";
        }

        // Redirection pour éviter la resoumission du formulaire
        header("Location: dossier_patient.php?id=" . $patientID);
        exit;

    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Erreur lors de la mise à jour: " . $e->getMessage();
    }
}

try {
    // Informations patient avec jointure correcte
    $queryPatient = $pdoMedical->prepare("
        SELECT u.*, p.id as patient_table_id, p.date_naissance, p.groupe_sanguin, p.allergies, 
               p.antecedents, p.taille, p.poids, p.assurance_maladie, p.numero_securite_sociale
        FROM utilisateurs u
        JOIN patients p ON u.id = p.utilisateur_id
        WHERE u.id = ? AND u.role = 'etudiant'
    ");
    $queryPatient->execute([$patientID]);
    $patient = $queryPatient->fetch();

    if (!$patient) {
        die("Patient non trouvé");
    }

    // Historique des consultations avec ce médecin
    $queryConsultations = $pdoMedical->prepare("
        SELECT c.id AS consultation_id, c.diagnostic, c.prescription, c.examens, c.date_creation,
               r.id AS rdv_id, r.date_rdv, r.type_rdv, r.motif
        FROM consultations c
        JOIN rendez_vous r ON c.rendez_vous_id = r.id
        WHERE r.patient_id = ? AND r.medecin_id = ?
        ORDER BY r.date_rdv DESC
    ");
    $queryConsultations->execute([$patientID, $medecinID]);
    $consultations = $queryConsultations->fetchAll();

    // Antécédents importants - correction de la jointure
    $queryAntecedents = $pdoMedical->prepare("
        SELECT am.* 
        FROM antecedents_medicaux am
        JOIN patients p ON am.patient_id = p.id
        WHERE p.utilisateur_id = ?
        ORDER BY am.date_creation DESC
    ");
    $queryAntecedents->execute([$patientID]);
    $antecedents = $queryAntecedents->fetchAll();

    // Rendez-vous futurs
    $queryRdvFuturs = $pdoMedical->prepare("
        SELECT id, date_rdv, type_rdv, motif, statut
        FROM rendez_vous 
        WHERE patient_id = ? AND medecin_id = ? AND date_rdv >= NOW()
        ORDER BY date_rdv ASC
        LIMIT 5
    ");
    $queryRdvFuturs->execute([$patientID, $medecinID]);
    $rdvFuturs = $queryRdvFuturs->fetchAll();

} catch (PDOException $e) {
    die("Erreur base de données: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dossier médical - <?= htmlspecialchars($patient['prenom'] . ' ' . $patient['nom']) ?> | eHealth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Styles CSS précédents inchangés */
        :root {
            --primary: #3a7bd5;
            --primary-dark: #2c5fb3;
            --secondary: #00d2ff;
            --light: #f8f9fa;
            --dark: #2c3e50;
            --success: #2ecc71;
            --danger: #e74c3c;
            --warning: #f39c12;
            --info: #3498db;
            --gray: #95a5a6;
            --light-gray: #ecf0f1;
            --white: #ffffff;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 10px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
        }
        
        .container {
            width: 95%;
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
         /* Header Navigation */
        .nav-header {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 1rem 2rem;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-links a {
            color: var(--primary);
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .nav-links a:hover {
            color: var(--primary-dark);
        }
        
        .dossier-header {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }
        
        .dossier-header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
        }
        
        .patient-info {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 2rem;
        }
        
        .patient-main-info h1 {
            color: var(--primary);
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
        }
        
        .patient-main-info h2 {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .patient-stats {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
        }
        
        .stat-card {
            background: var(--light-gray);
            padding: 1rem 1.5rem;
            border-radius: 8px;
            text-align: center;
            min-width: 120px;
        }
        
        .stat-number {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary);
            display: block;
        }
        
        .stat-label {
            font-size: 0.8rem;
            color: var(--gray);
            text-transform: uppercase;
        }
        
        .dossier-sections {
            display: grid;
            grid-template-columns: 1fr;
            gap: 2rem;
        }
        
        .dossier-section {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 2rem;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 0.8rem;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .section-header h3 {
            color: var(--primary);
            font-size: 1.3rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .info-card {
            background: var(--light-gray);
            padding: 1.2rem;
            border-radius: 8px;
            border-left: 3px solid var(--primary);
        }
        
        .info-card p {
            margin-bottom: 0.8rem;
        }
        
        .info-card strong {
            color: var(--primary-dark);
        }
        
        .antecedents-list {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1rem;
        }
        
        .antecedent-item {
            background: var(--light-gray);
            padding: 1.2rem;
            border-radius: 8px;
            border-left: 3px solid var(--info);
            transition: transform 0.3s ease;
            position: relative;
        }
        
        .antecedent-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }
        
        .antecedent-item h4 {
            color: var(--info);
            margin-bottom: 0.5rem;
            font-size: 1rem;
        }
        
        .antecedent-item p {
            margin-bottom: 0.5rem;
        }
        
        .antecedent-item small {
            color: var(--gray);
            font-size: 0.8rem;
        }
        
        .consultations-table, .rdv-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        .consultations-table th, 
        .consultations-table td,
        .rdv-table th,
        .rdv-table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid var(--light-gray);
        }
        
        .consultations-table th,
        .rdv-table th {
            background-color: var(--primary);
            color: var(--white);
            font-weight: 500;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }
        
        .consultations-table tr:nth-child(even),
        .rdv-table tr:nth-child(even) {
            background-color: var(--light-gray);
        }
        
        .consultations-table tr:hover,
        .rdv-table tr:hover {
            background-color: rgba(58, 123, 213, 0.05);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.6rem 1rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.85rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            background-color: var(--primary);
            color: var(--white);
        }
        
        .btn:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(58, 123, 213, 0.2);
        }
        
        .btn-small {
            padding: 0.4rem 0.8rem;
            font-size: 0.8rem;
        }
        
        .btn-success {
            background-color: var(--success);
        }
        
        .btn-success:hover {
            background-color: #27ae60;
        }
        
        .btn-danger {
            background-color: var(--danger);
        }
        
        .btn-danger:hover {
            background-color: #c0392b;
        }
        
        .btn-warning {
            background-color: var(--warning);
        }
        
        .btn-warning:hover {
            background-color: #e67e22;
        }
        
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: var(--gray);
        }
        
        .empty-state i {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }
        
        .badge {
            display: inline-block;
            padding: 0.3rem 0.6rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-primary {
            background: rgba(58, 123, 213, 0.1);
            color: var(--primary);
        }
        
        .badge-success {
            background: rgba(46, 204, 113, 0.1);
            color: var(--success);
        }
        
        .badge-warning {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }
        
        .text-gray {
            color: var(--gray);
        }
        
        /* Styles pour les formulaires d'édition */
        .edit-form {
            background: var(--light-gray);
            padding: 1.5rem;
            border-radius: 8px;
            margin-top: 1rem;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 0.9rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(58, 123, 213, 0.2);
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 1rem;
        }
        
        .delete-form {
            display: inline;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
        }
        
        .alert-success {
            background: rgba(46, 204, 113, 0.1);
            border: 1px solid var(--success);
            color: var(--success);
        }
        
        .alert-error {
            background: rgba(231, 76, 60, 0.1);
            border: 1px solid var(--danger);
            color: var(--danger);
        }
        
        @media (max-width: 768px) {
            .container {
                width: 100%;
                padding: 0 0.5rem;
            }
            
            .nav-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .nav-links {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 1rem;
            }
            
            .nav-links a {
                margin: 0;
            }
            
            .patient-info {
                flex-direction: column;
                text-align: center;
            }
            
            .patient-stats {
                justify-content: center;
            }
            
            .dossier-section {
                padding: 1.5rem;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
            
            .consultations-table,
            .rdv-table {
                display: block;
                overflow-x: auto;
            }
            
            .section-header {
                flex-direction: column;
                gap: 1rem;
                align-items: flex-start;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
        }
        
        /* Styles pour les nouveaux champs */
        .physical-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .physical-stat {
            background: var(--light-gray);
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
            border-left: 3px solid var(--info);
        }
        
        .physical-stat .value {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--primary);
            display: block;
        }
        
        .physical-stat .label {
            font-size: 0.8rem;
            color: var(--gray);
            text-transform: uppercase;
        }
        
        .imc-value {
            font-weight: 600;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            margin-top: 0.3rem;
            display: inline-block;
        }
        
        .imc-normal { background: rgba(46, 204, 113, 0.2); color: var(--success); }
        .imc-overweight { background: rgba(243, 156, 18, 0.2); color: var(--warning); }
        .imc-obese { background: rgba(231, 76, 60, 0.2); color: var(--danger); }
        
        @media (max-width: 768px) {
            .physical-stats {
                grid-template-columns: 1fr 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Navigation Header -->
        <div class="nav-header">
            <div>
                <h3><i class="fas fa-user-md"></i> Espace Médecin</h3>
            </div>
            <div class="nav-links">
                <a href="../medecin/dashboard_medecin.php"><i class="fas fa-home"></i> Tableau de bord</a>
                <a href="../rdv/liste_rdv.php"><i class="fas fa-calendar-alt"></i> Mes RDV</a>
                <!-- <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Déconnexion</a> -->
            </div>
        </div>

        <!-- Messages d'alerte -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $_SESSION['success_message'] ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?= $_SESSION['error_message'] ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <!-- Patient Header -->
        <div class="dossier-header">
            <div class="patient-info">
                <div class="patient-main-info">
                    <h1><i class="fas fa-file-medical"></i> Dossier médical</h1>
                    <h2><?= htmlspecialchars($patient['prenom'] . ' ' . $patient['nom']) ?></h2>
                    <p class="text-gray">
                        <span class="badge badge-primary">Étudiant</span>
                        <span class="badge badge-primary">Email : <?= htmlspecialchars($patient['email']) ?></span>
                    </p>
                </div>
                <div class="patient-stats">
                    <div class="stat-card">
                        <span class="stat-number"><?= count($consultations) ?></span>
                        <span class="stat-label">Consultations</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-number"><?= count($antecedents) ?></span>
                        <span class="stat-label">Antécédents</span>
                    </div>
                    <div class="stat-card">
                        <span class="stat-number"><?= count($rdvFuturs) ?></span>
                        <span class="stat-label">RDV à venir</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="dossier-sections">
            <!-- Section Informations de base -->
            <section class="dossier-section">
                <div class="section-header">
                    <h3><i class="fas fa-user-circle"></i> Informations personnelles</h3>
                    <button type="button" class="btn btn-warning" onclick="toggleEditForm('patient-info-form')">
                        <i class="fas fa-edit"></i> Modifier
                    </button>
                </div>
                
                <!-- Formulaire d'édition (caché par défaut) -->
                <form id="patient-info-form" class="edit-form" method="POST" style="display: none;">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="date_naissance">Date de naissance</label>
                            <input type="date" class="form-control" id="date_naissance" name="date_naissance" 
                                   value="<?= htmlspecialchars($patient['date_naissance'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="groupe_sanguin">Groupe sanguin</label>
                            <select class="form-control" id="groupe_sanguin" name="groupe_sanguin">
                                <option value="">Non renseigné</option>
                                <option value="A+" <?= ($patient['groupe_sanguin'] ?? '') === 'A+' ? 'selected' : '' ?>>A+</option>
                                <option value="A-" <?= ($patient['groupe_sanguin'] ?? '') === 'A-' ? 'selected' : '' ?>>A-</option>
                                <option value="B+" <?= ($patient['groupe_sanguin'] ?? '') === 'B+' ? 'selected' : '' ?>>B+</option>
                                <option value="B-" <?= ($patient['groupe_sanguin'] ?? '') === 'B-' ? 'selected' : '' ?>>B-</option>
                                <option value="AB+" <?= ($patient['groupe_sanguin'] ?? '') === 'AB+' ? 'selected' : '' ?>>AB+</option>
                                <option value="AB-" <?= ($patient['groupe_sanguin'] ?? '') === 'AB-' ? 'selected' : '' ?>>AB-</option>
                                <option value="O+" <?= ($patient['groupe_sanguin'] ?? '') === 'O+' ? 'selected' : '' ?>>O+</option>
                                <option value="O-" <?= ($patient['groupe_sanguin'] ?? '') === 'O-' ? 'selected' : '' ?>>O-</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="taille">Taille (cm)</label>
                            <input type="number" class="form-control" id="taille" name="taille" 
                                   step="0.1" min="0" max="250"
                                   value="<?= htmlspecialchars($patient['taille'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="poids">Poids (kg)</label>
                            <input type="number" class="form-control" id="poids" name="poids" 
                                   step="0.1" min="0" max="300"
                                   value="<?= htmlspecialchars($patient['poids'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="assurance_maladie">Numéro d'assurance maladie</label>
                            <input type="text" class="form-control" id="assurance_maladie" name="assurance_maladie" 
                                   value="<?= htmlspecialchars($patient['assurance_maladie'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="numero_securite_sociale">Numéro de sécurité sociale</label>
                            <input type="text" class="form-control" id="numero_securite_sociale" name="numero_securite_sociale" 
                                   value="<?= htmlspecialchars($patient['numero_securite_sociale'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="allergies">Allergies connues</label>
                        <textarea class="form-control" id="allergies" name="allergies" 
                                  placeholder="Liste des allergies connues..."><?= htmlspecialchars($patient['allergies'] ?? '') ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="antecedents">Antécédents personnels</label>
                        <textarea class="form-control" id="antecedents" name="antecedents" 
                                  placeholder="Antécédents médicaux personnels..."><?= htmlspecialchars($patient['antecedents'] ?? '') ?></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn btn-danger" onclick="toggleEditForm('patient-info-form')">
                            <i class="fas fa-times"></i> Annuler
                        </button>
                        <button type="submit" class="btn btn-success" name="update_patient_info">
                            <i class="fas fa-save"></i> Enregistrer
                        </button>
                    </div>
                </form>

                <!-- Affichage des informations (visible par défaut) -->
                <div id="patient-info-display">
                    <div class="info-grid">
                        <div class="info-card">
                            <p><strong><i class="fas fa-birthday-cake"></i> Date de naissance :</strong> 
                                <?= $patient['date_naissance'] ? date('d/m/Y', strtotime($patient['date_naissance'])) : 'Non renseignée' ?>
                            </p>
                            <p><strong><i class="fas fa-tint" style="color: red"></i> Groupe sanguin :</strong> 
                                <?= $patient['groupe_sanguin'] ?? 'Non renseigné' ?>
                            </p>
                        </div>
                        
                        <div class="info-card">
                            <p><strong><i class="fas fa-allergies"></i> Allergies connues :</strong></p>
                            <p><?= !empty($patient['allergies']) ? nl2br(htmlspecialchars($patient['allergies'])) : 'Aucune allergie connue' ?></p>
                        </div>
                        
                        <div class="info-card">
                            <p><strong><i class="fas fa-notes-medical"></i> Antécédents personnels :</strong></p>
                            <p><?= !empty($patient['antecedents']) ? nl2br(htmlspecialchars($patient['antecedents'])) : 'Aucun antécédent déclaré' ?></p>
                        </div>
                    </div>
                    
                    <!-- Nouvelles informations physiques et administratives -->
                    <div class="physical-stats">
                        <div class="physical-stat">
                            <span class="value">
                                <?= $patient['taille'] ? htmlspecialchars($patient['taille']) . ' cm' : 'N/R' ?>
                            </span>
                            <span class="label">Taille</span>
                        </div>
                        
                        <div class="physical-stat">
                            <span class="value">
                                <?= $patient['poids'] ? htmlspecialchars($patient['poids']) . ' kg' : 'N/R' ?>
                            </span>
                            <span class="label">Poids</span>
                        </div>
                        
                        <div class="physical-stat">
                            <span class="value">
                                <?php
                                if ($patient['taille'] && $patient['poids']) {
                                    $taille_m = $patient['taille'] / 100;
                                    $imc = $patient['poids'] / ($taille_m * $taille_m);
                                    $imc_class = '';
                                    if ($imc < 18.5) $imc_class = 'imc-underweight';
                                    elseif ($imc < 25) $imc_class = 'imc-normal';
                                    elseif ($imc < 30) $imc_class = 'imc-overweight';
                                    else $imc_class = 'imc-obese';
                                    
                                    echo '<span class="imc-value ' . $imc_class . '">' . number_format($imc, 1) . '</span>';
                                } else {
                                    echo 'N/R';
                                }
                                ?>
                            </span>
                            <span class="label">IMC</span>
                        </div>
                    </div>
                    
                    <div class="info-grid" style="margin-top: 1.5rem;">
                        <div class="info-card">
                            <p><strong><i class="fas fa-id-card"></i> Assurance maladie :</strong></p>
                            <p><?= !empty($patient['assurance_maladie']) ? htmlspecialchars($patient['assurance_maladie']) : 'Non renseigné' ?></p>
                        </div>
                        
                        <div class="info-card">
                            <p><strong><i class="fas fa-shield-alt"></i> Sécurité sociale :</strong></p>
                            <p><?= !empty($patient['numero_securite_sociale']) ? htmlspecialchars($patient['numero_securite_sociale']) : 'Non renseigné' ?></p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- ... (le reste du code HTML reste inchangé) ... -->
            
            <!-- Section Rendez-vous futurs -->
            <?php if (!empty($rdvFuturs)): ?>
            <section class="dossier-section">
                <div class="section-header">
                    <h3><i class="fas fa-calendar-plus"></i> Rendez-vous à venir</h3>
                </div>
                <table class="rdv-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Motif</th>
                            <th>Statut</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rdvFuturs as $rdv): ?>
                            <tr>
                                <td>
                                    <?= date('d/m/Y', strtotime($rdv['date_rdv'])) ?>
                                    <small><?= date('H:i', strtotime($rdv['date_rdv'])) ?></small>
                                </td>
                                <td><?= htmlspecialchars($rdv['type_rdv']) ?></td>
                                <td><?= htmlspecialchars(substr($rdv['motif'] ?? '', 0, 50)) ?><?= strlen($rdv['motif'] ?? '') > 50 ? '...' : '' ?></td>
                                <td>
                                    <span class="badge badge-<?= $rdv['statut'] === 'Confirmé' ? 'success' : 'warning' ?>">
                                        <?= htmlspecialchars($rdv['statut']) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </section>
            <?php endif; ?>

            <!-- Section Antécédents -->
            <section class="dossier-section">
                <div class="section-header">
                    <h3><i class="fas fa-history"></i> Antécédents médicaux</h3>
                    <button type="button" class="btn btn-success" onclick="toggleEditForm('add-antecedent-form')">
                        <i class="fas fa-plus"></i> Ajouter
                    </button>
                </div>

                <!-- Formulaire d'ajout d'antécédent -->
                <form id="add-antecedent-form" class="edit-form" method="POST" style="display: none;">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="type_antecedent">Type d'antécédent</label>
                            <select class="form-control" id="type_antecedent" name="type_antecedent" required>
                                <option value="">Sélectionnez un type</option>
                                <option value="Maladie chronique">Maladie chronique</option>
                                <option value="Chirurgie">Chirurgie</option>
                                <option value="Allergie">Allergie</option>
                                <option value="Traitement long terme">Traitement long terme</option>
                                <option value="Hospitalisation">Hospitalisation</option>
                                <option value="Antécédent familial">Antécédent familial</option>
                                <option value="Autre">Autre</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="date_antecedent">Date</label>
                            <input type="date" class="form-control" id="date_antecedent" name="date_antecedent" 
                                   value="<?= date('Y-m-d') ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="description_antecedent">Description</label>
                        <textarea class="form-control" id="description_antecedent" name="description_antecedent" 
                                  placeholder="Décrivez l'antécédent médical..." required></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn btn-danger" onclick="toggleEditForm('add-antecedent-form')">
                            <i class="fas fa-times"></i> Annuler
                        </button>
                        <button type="submit" class="btn btn-success" name="add_antecedent">
                            <i class="fas fa-save"></i> Ajouter
                        </button>
                    </div>
                </form>

                <?php if (empty($antecedents)): ?>
                    <div class="empty-state">
                        <i class="fas fa-file-medical"></i>
                        <p>Aucun antécédent médical enregistré</p>
                    </div>
                <?php else: ?>
                    <div class="antecedents-list">
                        <?php foreach ($antecedents as $antecedent): ?>
                            <div class="antecedent-item">
                                <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                                    <div style="flex: 1;">
                                        <h4>
                                            <i class="fas fa-<?= $antecedent['type'] === 'Chirurgie' ? 'scalpel' : 'stethoscope' ?>"></i> 
                                            <?= htmlspecialchars($antecedent['type']) ?>
                                        </h4>
                                        <p><?= nl2br(htmlspecialchars($antecedent['description'])) ?></p>
                                        <small>
                                            <i class="fas fa-calendar-alt"></i> 
                                            Date : <?= date('d/m/Y', strtotime($antecedent['date'] ?? $antecedent['date_creation'])) ?>
                                        </small>
                                    </div>
                                    <form class="delete-form" method="POST" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cet antécédent ?');">
                                        <input type="hidden" name="antecedent_id" value="<?= $antecedent['id'] ?>">
                                        <button type="submit" class="btn btn-danger btn-small" name="delete_antecedent">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>

            <!-- Section Historique consultations -->
            <section class="dossier-section">
                <div class="section-header">
                    <h3><i class="fas fa-calendar-check"></i> Historique des consultations</h3>
                    <span class="badge badge-primary"><?= count($consultations) ?> consultation(s)</span>
                </div>
                <?php if (empty($consultations)): ?>
                    <div class="empty-state">
                        <i class="fas fa-calendar-times"></i>
                        <p>Aucune consultation passée avec ce patient</p>
                    </div>
                <?php else: ?>
                    <table class="consultations-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Diagnostic</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($consultations as $consult): ?>
                                <tr>
                                    <td>
                                        <?= date('d/m/Y', strtotime($consult['date_rdv'])) ?>
                                        <br><small class="text-gray"><?= date('H:i', strtotime($consult['date_rdv'])) ?></small>
                                    </td>
                                    <td><?= htmlspecialchars($consult['type_rdv']) ?></td>
                                    <td>
                                        <?php if (!empty($consult['diagnostic'])): ?>
                                            <?= htmlspecialchars(substr($consult['diagnostic'], 0, 50)) ?>
                                            <?= strlen($consult['diagnostic']) > 50 ? '...' : '' ?>
                                        <?php else: ?>
                                            <em class="text-gray">Non renseigné</em>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="../consultations/voir_consultation.php?id=<?= $consult['consultation_id'] ?>" 
                                           class="btn btn-small" 
                                           title="Voir la consultation">
                                            <i class="fas fa-eye"></i> Détails
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </section>
        </div>
    </div>

    <script>
        function toggleEditForm(formId) {
            const form = document.getElementById(formId);
            const display = document.getElementById('patient-info-display');
            
            if (form.style.display === 'none') {
                form.style.display = 'block';
                if (display) display.style.display = 'none';
            } else {
                form.style.display = 'none';
                if (display) display.style.display = 'block';
            }
        }
        
        // Calcul automatique de l'IMC
        function calculateIMC() {
            const taille = parseFloat(document.getElementById('taille').value) / 100;
            const poids = parseFloat(document.getElementById('poids').value);
            
            if (taille > 0 && poids > 0) {
                const imc = poids / (taille * taille);
                alert('IMC calculé : ' + imc.toFixed(1));
            }
        }
    </script>
</body>
</html>